/**
 * Payment Routes
 * REST API endpoints for payment management
 */

import express from "express";
import paymentController from "../controllers/payment.controller.js";

const router = express.Router();

/**
 * @route   GET /api/payments/stats
 * @desc    Get payment statistics
 * @access  Public
 * @query   userId?, driverId?
 */
router.get("/stats", paymentController.getPaymentStats);

/**
 * @route   GET /api/payments/ride/:rideId
 * @desc    Get payment details for a specific ride
 * @access  Public
 */
router.get("/ride/:rideId", paymentController.getPaymentByRide);

/**
 * @route   GET /api/payments/user/:userId
 * @desc    Get all payments for a user
 * @access  Public
 * @query   status?
 */
router.get("/user/:userId", paymentController.getPaymentsByUser);

/**
 * @route   GET /api/payments/driver/:driverId
 * @desc    Get all payments received by a driver
 * @access  Public
 * @query   status?
 */
router.get("/driver/:driverId", paymentController.getPaymentsByDriver);

/**
 * @route   POST /api/payments
 * @desc    Submit a payment for a completed ride
 * @access  Public
 * @body    {rideId, userId, driverId, amount, transactionId, paymentScreenshot, paymentMethod?, notes?}
 */
router.post("/", paymentController.submitPayment);

/**
 * @route   GET /api/payments/:id
 * @desc    Get a specific payment by ID
 * @access  Public
 */
router.get("/:id", paymentController.getPayment);

/**
 * @route   PATCH /api/payments/:id/status
 * @desc    Update payment status (for admin verification)
 * @access  Public (should be protected/admin only in production)
 * @body    {status, notes?, verifiedBy?}
 */
router.patch("/:id/status", paymentController.updatePaymentStatus);

export default router;
