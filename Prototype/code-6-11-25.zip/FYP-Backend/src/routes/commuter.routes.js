import express from "express";
import shareRideDetailsController from "../controllers/shareRideDetailscontroller.js";

const router = express.Router();

router.get(
  "/trusted-contacts/:userId",
  shareRideDetailsController.getTrustedContacts
);

export default router;