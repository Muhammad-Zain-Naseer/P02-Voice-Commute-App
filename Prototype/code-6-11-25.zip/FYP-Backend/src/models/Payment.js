/**
 * Payment Model
 * Represents a payment transaction for a completed ride
 */

import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    rideId: {
      type: String,
      required: true,
      index: true
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },
    driverId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    transactionId: {
      type: String,
      required: true,
      unique: true,
      index: true
    },
    paymentScreenshot: {
      type: String, // URL or base64 encoded image
      required: true
    },
    paymentMethod: {
      type: String,
      enum: ["bank_transfer", "mobile_money", "cash", "other"],
      default: "bank_transfer"
    },
    status: {
      type: String,
      enum: ["pending", "verified", "rejected"],
      default: "pending"
    },
    rideDetails: {
      source: {
        address: String,
        coordinates: {
          lat: Number,
          lng: Number
        }
      },
      destination: {
        address: String,
        coordinates: {
          lat: Number,
          lng: Number
        }
      }
    },
    submittedAt: {
      type: Date,
      default: Date.now
    },
    verifiedAt: {
      type: Date
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    notes: {
      type: String
    }
  },
  {
    timestamps: true
  }
);

// Index for querying payments by ride
paymentSchema.index({ rideId: 1 });

// Index for querying payments by user
paymentSchema.index({ userId: 1, createdAt: -1 });

// Index for querying payments by driver
paymentSchema.index({ driverId: 1, createdAt: -1 });

const Payment = mongoose.model("Payment", paymentSchema);

export default Payment;
