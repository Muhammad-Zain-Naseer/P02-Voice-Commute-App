/**
 * Payment Controller
 * REST API endpoints for payment management
 */

import Payment from "../models/Payment.js";
import connectionPoolService from "../services/connectionPool.service.js";
import logger from "../utils/logger.js";

class PaymentController {
  /**
   * Submit a payment for a completed ride
   * POST /api/payments
   */
  async submitPayment(req, res, next) {
    try {
      const {
        rideId,
        userId,
        driverId,
        amount,
        transactionId,
        paymentScreenshot,
        paymentMethod,
        notes
      } = req.body;

      logger.info(`💳 [PAYMENT] Payment submission request for ride: ${rideId}`);

      // Validate required fields
      if (!rideId || !userId || !driverId || !amount || !transactionId || !paymentScreenshot) {
        return res.status(400).json({
          success: false,
          error: "Missing required fields: rideId, userId, driverId, amount, transactionId, paymentScreenshot"
        });
      }

      // Validate amount
      if (amount <= 0) {
        return res.status(400).json({
          success: false,
          error: "Amount must be greater than 0"
        });
      }

      // Get ride details from connection pool (if still available)
      let rideDetails = null;
      const ride = connectionPoolService.getRide(rideId);
      if (ride) {
        rideDetails = {
          source: ride.source,
          destination: ride.destination
        };
      }

      // Check if payment already exists for this ride
      const existingPayment = await Payment.findOne({ rideId });
      if (existingPayment) {
        logger.warn(`⚠️ [PAYMENT] Payment already exists for ride: ${rideId}`);
        return res.status(409).json({
          success: false,
          error: "Payment already submitted for this ride",
          data: {
            payment: existingPayment
          }
        });
      }

      // Create payment record
      const payment = new Payment({
        rideId,
        userId,
        driverId,
        amount,
        transactionId,
        paymentScreenshot,
        paymentMethod: paymentMethod || "bank_transfer",
        status: "pending",
        rideDetails,
        notes,
        submittedAt: new Date()
      });

      await payment.save();

      logger.info(`✅ [PAYMENT] Payment submitted successfully: ${payment._id}`);

      res.status(201).json({
        success: true,
        message: "Payment submitted successfully",
        data: {
          payment: payment
        }
      });
    } catch (error) {
      // Handle duplicate transaction ID error
      if (error.code === 11000 && error.keyPattern?.transactionId) {
        logger.error(`❌ [PAYMENT] Duplicate transaction ID: ${req.body.transactionId}`);
        return res.status(409).json({
          success: false,
          error: "Transaction ID already exists. Please use a unique transaction ID."
        });
      }

      logger.error(`❌ [PAYMENT] Error in submitPayment: ${error.message}`);
      logger.error(`❌ [PAYMENT] Stack: ${error.stack}`);
      next(error);
    }
  }

  /**
   * Get payment details for a specific ride
   * GET /api/payments/ride/:rideId
   */
  async getPaymentByRide(req, res, next) {
    try {
      const { rideId } = req.params;

      logger.info(`🔍 [PAYMENT] Fetching payment for ride: ${rideId}`);

      const payment = await Payment.findOne({ rideId })
        .populate("userId", "name email")
        .populate("driverId", "name email");

      if (!payment) {
        return res.status(404).json({
          success: false,
          error: "Payment not found for this ride"
        });
      }

      res.status(200).json({
        success: true,
        data: {
          payment
        }
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in getPaymentByRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get all payments for a user
   * GET /api/payments/user/:userId
   */
  async getPaymentsByUser(req, res, next) {
    try {
      const { userId } = req.params;
      const { status } = req.query;

      logger.info(`🔍 [PAYMENT] Fetching payments for user: ${userId}`);

      const query = { userId };
      if (status) {
        query.status = status;
      }

      const payments = await Payment.find(query)
        .populate("driverId", "name email")
        .sort({ createdAt: -1 });

      res.status(200).json({
        success: true,
        data: {
          payments,
          count: payments.length
        }
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in getPaymentsByUser: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get all payments received by a driver
   * GET /api/payments/driver/:driverId
   */
  async getPaymentsByDriver(req, res, next) {
    try {
      const { driverId } = req.params;
      const { status } = req.query;

      logger.info(`🔍 [PAYMENT] Fetching payments for driver: ${driverId}`);

      const query = { driverId };
      if (status) {
        query.status = status;
      }

      const payments = await Payment.find(query)
        .populate("userId", "name email")
        .sort({ createdAt: -1 });

      res.status(200).json({
        success: true,
        data: {
          payments,
          count: payments.length
        }
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in getPaymentsByDriver: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get a specific payment by ID
   * GET /api/payments/:id
   */
  async getPayment(req, res, next) {
    try {
      const { id } = req.params;

      logger.info(`🔍 [PAYMENT] Fetching payment: ${id}`);

      const payment = await Payment.findById(id)
        .populate("userId", "name email")
        .populate("driverId", "name email");

      if (!payment) {
        return res.status(404).json({
          success: false,
          error: "Payment not found"
        });
      }

      res.status(200).json({
        success: true,
        data: {
          payment
        }
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in getPayment: ${error.message}`);
      next(error);
    }
  }

  /**
   * Update payment status (for admin verification)
   * PATCH /api/payments/:id/status
   */
  async updatePaymentStatus(req, res, next) {
    try {
      const { id } = req.params;
      const { status, notes, verifiedBy } = req.body;

      logger.info(`📝 [PAYMENT] Updating payment status: ${id} to ${status}`);

      if (!["pending", "verified", "rejected"].includes(status)) {
        return res.status(400).json({
          success: false,
          error: "Invalid status. Must be 'pending', 'verified', or 'rejected'"
        });
      }

      const updateData = {
        status,
        notes
      };

      if (status === "verified") {
        updateData.verifiedAt = new Date();
        if (verifiedBy) {
          updateData.verifiedBy = verifiedBy;
        }
      }

      const payment = await Payment.findByIdAndUpdate(
        id,
        updateData,
        { new: true, runValidators: true }
      )
        .populate("userId", "name email")
        .populate("driverId", "name email");

      if (!payment) {
        return res.status(404).json({
          success: false,
          error: "Payment not found"
        });
      }

      logger.info(`✅ [PAYMENT] Payment status updated: ${id} -> ${status}`);

      res.status(200).json({
        success: true,
        message: "Payment status updated successfully",
        data: {
          payment
        }
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in updatePaymentStatus: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get payment statistics
   * GET /api/payments/stats
   */
  async getPaymentStats(req, res, next) {
    try {
      const { userId, driverId } = req.query;

      logger.info(`📊 [PAYMENT] Fetching payment statistics`);

      const query = {};
      if (userId) query.userId = userId;
      if (driverId) query.driverId = driverId;

      const [totalPayments, pendingPayments, verifiedPayments, rejectedPayments, totalAmount] = await Promise.all([
        Payment.countDocuments(query),
        Payment.countDocuments({ ...query, status: "pending" }),
        Payment.countDocuments({ ...query, status: "verified" }),
        Payment.countDocuments({ ...query, status: "rejected" }),
        Payment.aggregate([
          { $match: query },
          { $match: { status: "verified" } },
          { $group: { _id: null, total: { $sum: "$amount" } } }
        ])
      ]);

      const stats = {
        totalPayments,
        pendingPayments,
        verifiedPayments,
        rejectedPayments,
        totalAmount: totalAmount[0]?.total || 0
      };

      res.status(200).json({
        success: true,
        data: stats
      });
    } catch (error) {
      logger.error(`❌ [PAYMENT] Error in getPaymentStats: ${error.message}`);
      next(error);
    }
  }
}

export default new PaymentController();
