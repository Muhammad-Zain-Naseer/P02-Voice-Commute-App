/**
 * Ride Controller
 * REST API endpoints for ride management (optional fallback to sockets)
 */

import connectionPoolService from "../services/connectionPool.service.js";
import logger from "../utils/logger.js";
import User from "../models/User.js";

class RideController {
  /**
   * Create a new ride request
   * POST /api/rides
   */
  async createRide(req, res, next) {
    try {
      const {
        userId,
        userName,
        source,
        destination,
        sourceCoordinates,
        destinationCoordinates
      } = req.body;

      // Validate input
      if (!source || !destination) {
        return res.status(400).json({
          success: false,
          error: "Source and destination are required"
        });
      }

      // Create ride
      const ride = connectionPoolService.addRide({
        userId: userId || "anonymous",
        userName: userName || "Anonymous User",
        userType: "commuter",
        source,
        destination,
        sourceCoordinates: sourceCoordinates || null,
        destinationCoordinates: destinationCoordinates || null,
        socketId: "rest-api" // Mark as REST API request
      });

      logger.info(`Ride created via REST API: ${ride.id}`);

      res.status(201).json({
        success: true,
        data: {
          ride: ride.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in createRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get all rides
   * GET /api/rides
   */
  async getRides(req, res, next) {
    try {
      const { status, userId } = req.query;

      const filters = {};
      if (status) {
        filters.status = status;
      }
      if (userId) {
        filters.userId = userId;
      }

      const rides = connectionPoolService.getRides(filters);

      logger.info(`Retrieved ${rides.length} rides via REST API`);

      res.status(200).json({
        success: true,
        data: {
          rides: rides.map((ride) => ride.toJSON()),
          count: rides.length
        }
      });
    } catch (error) {
      logger.error(`Error in getRides: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get pending rides (available for matching)
   * GET /api/rides/pending
   */
  async getPendingRides(req, res, next) {
    try {
      const rides = connectionPoolService.getPendingRides();

      logger.info(`Retrieved ${rides.length} pending rides via REST API`);

      res.status(200).json({
        success: true,
        data: {
          rides: rides.map((ride) => ride.toJSON()),
          count: rides.length
        }
      });
    } catch (error) {
      logger.error(`Error in getPendingRides: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get a specific ride by ID
   * GET /api/rides/:id
   */
  async getRide(req, res, next) {
    try {
      const { id } = req.params;

      const ride = connectionPoolService.getRide(id);

      if (!ride) {
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      res.status(200).json({
        success: true,
        data: {
          ride: ride.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in getRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Match a ride with a driver
   * POST /api/rides/:id/match
   */
  async matchRide(req, res, next) {
    try {
      const { id } = req.params;
      const { driverId, driverName } = req.body;

      if (!driverId) {
        return res.status(400).json({
          success: false,
          error: "Driver ID is required"
        });
      }

      const matchedRide = connectionPoolService.matchRide(id, {
        driverId,
        driverName: driverName || "Driver",
        socketId: "rest-api"
      });

      if (!matchedRide) {
        return res.status(404).json({
          success: false,
          error: "Ride not found or already matched"
        });
      }

      logger.info(`Ride matched via REST API: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: matchedRide.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in matchRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Cancel a ride
   * DELETE /api/rides/:id
   */
  async cancelRide(req, res, next) {
    try {
      const { id } = req.params;

      const cancelledRide = connectionPoolService.cancelRide(id);

      if (!cancelledRide) {
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      logger.info(`Ride cancelled via REST API: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: cancelledRide.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in cancelRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get connection pool statistics
   * GET /api/rides/stats
   */
  async getStats(req, res, next) {
    try {
      const stats = connectionPoolService.getStats();

      res.status(200).json({
        success: true,
        data: stats
      });
    } catch (error) {
      logger.error(`Error in getStats: ${error.message}`);
      next(error);
    }
  }

  /**
   * Rate a ride
   * POST /api/rides/:id/rate
   */
  async rateRide(req, res, next) {
    try {
      const { id } = req.params;
      const { rating } = req.body;
      // const commuterId = req.user.id;

      if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({
          success: false,
          error: "Invalid rating. Must be between 1 and 5."
        });
      }

      const ride = connectionPoolService.getRide(id);

      if (!ride) {
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      // status check
      /*
      if (ride.status !== 'completed') {
        return res.status(403).json({
          success: false,
          error: "Cannot rate a ride that is not completed"
        });
      }
      */
      // ---------------------------------------------

      const driverId = ride.matchedWith?.driverId;

      if (!driverId) {
        return res.status(400).json({
          success: false,
          error: "This ride has no driver assigned to rate."
        });
      }

      const driver = await User.findById(driverId);
      if (!driver) {
        return res.status(404).json({
          success: false,
          error: "Driver for this ride not found in database."
        });
      }

      driver.ratings.push(rating);

      const sum = driver.ratings.reduce((a, b) => a + b, 0);
      driver.averageRating = sum / driver.ratings.length;

      await driver.save();

      logger.info(
        `Ride rated: ${id} | Driver: ${driverId} | New Rating: ${rating}`
      );

      res.status(200).json({
        success: true,
        message: "Rating submitted successfully!",
        data: {
          driverId: driverId,
          newAverageRating: driver.averageRating
        }
      });
    } catch (error) {
      logger.error(`Error in rateRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Trigger SOS alert for a ride
   * POST /api/rides/:id/sos
   */
  async triggerSOS(req, res, next) {
    try {
      const { id } = req.params;
      const { location, message } = req.body;

      logger.warn(`🚨 [SOS API] SOS alert request for ride: ${id}`);

      const ride = connectionPoolService.getRide(id);

      if (!ride) {
        logger.error(`❌ [SOS API] Ride not found: ${id}`);
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      logger.warn(`🔍 [SOS API] Ride found. Status: ${ride.status}`);

      // Trigger SOS
      const sosData = {
        triggeredBy: ride.userId,
        location: location || null,
        message: message || "Emergency SOS triggered"
      };

      const updatedRide = connectionPoolService.triggerSOS(id, sosData);

      if (!updatedRide) {
        logger.error(`❌ [SOS API] Failed to trigger SOS for ride: ${id}`);
        return res.status(500).json({
          success: false,
          error: "Failed to trigger SOS"
        });
      }

      logger.warn(`✅ [SOS API] SOS triggered successfully for ride: ${id}`);

      // Send email to trusted contacts
      try {
        logger.warn(`🔍 [SOS API] Fetching user from database by email: ${ride.userEmail}`);

        const user = await User.findOne({ email: ride.userEmail }).select(
          "name email trustedContacts"
        );

        logger.warn(`🔍 [SOS API] User found: ${!!user}`);

        if (!user) {
          logger.error(`❌ [SOS API] User not found in database: ${ride.userId}`);
        } else {
          logger.warn(`👤 [SOS API] User: ${user.name}, Email: ${user.email}`);
          logger.warn(`📋 [SOS API] Trusted contacts: ${user.trustedContacts?.length || 0}`);
        }

        if (user && user.trustedContacts && user.trustedContacts.length > 0) {
          logger.warn(
            `📧 [SOS API] Sending emails to ${user.trustedContacts.length} trusted contact(s)`
          );

          const emailService = (await import("../services/emailService.js"))
            .default;

          // Prepare email data
          const sosEmailData = {
            commuterName: user.name || ride.userName,
            commuterEmail: user.email,
            driverName: updatedRide.matchedWith?.driverName || null,
            pickupLocation: updatedRide.source.address,
            dropoffLocation: updatedRide.destination.address,
            triggeredAt: updatedRide.sosAlert.triggeredAt,
            sosMessage: updatedRide.sosAlert.message
          };

          logger.warn(`📦 [SOS API] Email data: ${JSON.stringify(sosEmailData, null, 2)}`);

          // Send emails
          const emailPromises = user.trustedContacts.map(
            async (contact, index) => {
              try {
                logger.warn(
                  `📨 [SOS API] Sending email ${index + 1}/${user.trustedContacts.length} to ${contact.email}`
                );

                await emailService.sendSOSAlert(contact.email, sosEmailData);

                logger.warn(`✅ [SOS API] Email sent to ${contact.email}`);
              } catch (emailError) {
                logger.error(`❌ [SOS API] Failed to send email to ${contact.email}`);
                logger.error(`❌ [SOS API] Error: ${emailError.message}`);
              }
            }
          );

          // Wait for all emails
          await Promise.all(emailPromises);
          logger.warn(`✅ [SOS API] All SOS emails sent!`);
        } else {
          logger.warn(`⚠️ [SOS API] No trusted contacts for user ${ride.userId}`);
        }
      } catch (dbError) {
        logger.error(`❌ [SOS API] Database error: ${dbError.message}`);
        logger.error(`❌ [SOS API] Stack: ${dbError.stack}`);
      }

      logger.warn(`🚨 [SOS API] SOS alert completed for ride: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: updatedRide.toJSON(),
          sosAlert: updatedRide.sosAlert
        }
      });
    } catch (error) {
      logger.error(`❌ [SOS API] Error in triggerSOS: ${error.message}`);
      logger.error(`❌ [SOS API] Stack: ${error.stack}`);
      next(error);
    }
  }
}

export default new RideController();
