import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../widgets/custom_button.dart';
import '../widgets/sound_wave.dart';
import 'auth/signup_email_screen.dart';
import 'auth/login_email_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 40.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Top Section - Logo and Sound Wave
                Column(
                  children: [
                    const SizedBox(height: 20),
                    // Car Logo with text (combined)
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 100,
                      height: 100,
                    ),
                    const SizedBox(height: 50),
                    // Sound Wave
                    const SoundWave(),
                    const SizedBox(height: 40),
                    // Title Text
                    const Text(
                      'ایک انتخاب کریں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),

                // Middle Section - Buttons
                Column(
                  children: [
                    // New User Button
                    CustomButton(
                      text: 'نیا صارف',
                      onPressed: () {
                        // Navigate to signup
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SignupEmailScreen(),
                          ),
                        );
                      },
                      height: 60,
                      isPrimary: true,
                      borderColor: const Color(0xFFF682AA),
                      backgroundColor: const Color(0xFFF8BBD0),
                      textColor: const Color(0xFFCF4374),
                      fontSize: 20,
                    ),
                    const SizedBox(height: 16),
                    // Already Registered Button
                    CustomButton(
                      text: 'پہلے سے رجسٹر ہیں؟',
                      onPressed: () {
                        // Navigate to login
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LoginEmailScreen(),
                          ),
                        );
                      },
                      height: 60,
                      isPrimary: true,
                      borderColor: const Color(0xFFF682AA),
                      backgroundColor: const Color(0xFFFAECF1),
                      textColor: const Color(0xFFCF4374),
                      fontSize: 20,
                    ),
                    const SizedBox(height: 16),
                    // Register as Driver Button (smaller)
                    CustomButton(
                      text: 'رجسٹر بطور ڈرائیور',
                      onPressed: () {
                        // Navigate to driver registration
                        print('Navigate to driver registration');
                      },
                      height: 50,
                      isPrimary: false,
                      borderColor: const Color(0xFFCF4374),
                      backgroundColor: const Color(0xFFCF4374),
                      textColor: const Color(0xFFFFFFFF),
                      fontSize: 18,
                      isGradient: true,
                    ),
                  ],
                ),

                // Bottom Section - Microphone
                Column(
                  children: [
                    // Microphone Button
                    GestureDetector(
                      onTap: () {
                        // Handle voice input
                        print('Voice input activated');
                      },
                      child: Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.4),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374).withOpacity(0.2),
                              blurRadius: 15,
                              spreadRadius: 3,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Container(
                            width: 70,
                            height: 70,
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xFFF48FB1),
                                  Color(0xFFCF4374),
                                ],
                              ),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.mic,
                              color: Colors.white,
                              size: 36,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'بولنے کے لیے دبائیں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 13,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}