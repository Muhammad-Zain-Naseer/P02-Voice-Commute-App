import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'bookride/book_ride_page.dart';
import '../widgets/rate_ride_dialog.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  final String userEmail;
  final String userId;

  const HomeScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userId,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 32.0,
              vertical: 20.0,
            ),
            child: Column(
              children: [
                SvgPicture.asset(
                  'assets/icons/car_icon.svg',
                  width: 80,
                  height: 80,
                ),

                const SizedBox(height: 30),

                Text(
                  'خوش آمدید!',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 40),

                // Sound Wave Visualization
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.volume_up,
                        color: Color(0xFFCF4374),
                        size: 40,
                      ),
                      const SizedBox(width: 16),
                      // Sound wave bars
                      ...List.generate(15, (index) {
                        return Container(
                          width: 4,
                          height: 30 + (index % 3) * 20,
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFCF4374),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      }),
                      const SizedBox(width: 16),
                      const Icon(
                        Icons.volume_up,
                        color: Color(0xFFCF4374),
                        size: 40,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // Instruction Text
                const Text(
                  'سواری بُک کرنے کے لیے نیچے',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Color(0xFFCF4374),
                    height: 1.5,
                  ),
                ),
                const Text(
                  'دیا گیا بٹن دبائیں۔',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Color(0xFFCF4374),
                    height: 1.5,
                  ),
                ),

                const Spacer(),
                //  TEST RATE RIDE BUTTON  ---
                GestureDetector(
                  onTap: () {
                    const String FAKE_RIDE_ID =
                        "14740fc8-ab2d-42c6-b0d3-ce41c414f40c"; // UPDATE ID HERE

                    if (FAKE_RIDE_ID == "fake-ride-id") {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'update the FAKE_RIDE_ID in home_screen.dart',
                          ),
                          backgroundColor: Colors.red,
                        ),
                      );
                    } else {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return RateRideDialog(rideId: FAKE_RIDE_ID);
                        },
                      );
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFF48FB1), Color(0xFFCF4374)],
                      ),
                      borderRadius: BorderRadius.circular(35),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withOpacity(0.3),
                          blurRadius: 10,
                          spreadRadius: 1,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        'ٹیسٹ رائیڈ ریٹنگ',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                // Book Ride Button
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookRidePage(
                          userEmail: widget.userEmail,
                          userName: widget.userName,
                          userId: widget.userId,
                        ),
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    height: 70,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                      ),
                      borderRadius: BorderRadius.circular(35),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withOpacity(0.4),
                          blurRadius: 15,
                          spreadRadius: 2,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.directions_car,
                          color: Colors.white,
                          size: 32,
                        ),
                        SizedBox(width: 16),
                        Text(
                          'رائیڈ بُک کریں',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
