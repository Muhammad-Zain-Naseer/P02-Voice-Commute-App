import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import 'active_ride_page.dart';

/// Driver Dashboard - View and accept available rides
class AvailableRidesPage extends StatefulWidget {
  const AvailableRidesPage({super.key});

  @override
  State<AvailableRidesPage> createState() => _AvailableRidesPageState();
}

class _AvailableRidesPageState extends State<AvailableRidesPage> {
  final Uuid _uuid = const Uuid();
  List<RideRequest> _availableRides = [];
  bool _isConnected = false;
  String? _userId;

  @override
  void initState() {
    super.initState();
    // Initialize socket connection for driver
    _initializeDriverSocket();
  }

  /// Initialize socket connection as DRIVER
  Future<void> _initializeDriverSocket() async {
    try {
      // Generate unique driver ID
      _userId = _uuid.v4();

      Logger.log('🚗 Initializing driver socket connection...');

      // Connect to socket server as DRIVER
      await SocketService.connect(
        userId: _userId!,
        userName: 'Driver User', // TODO: Get from user profile
        userType: 'driver', // REQUIRED: This is a driver app
      );

      setState(() {
        _isConnected = SocketService.isConnected;
      });

      // Listen for initial ride list (automatically sent when driver joins)
      SocketService.onRideList((rides) {
        Logger.log('📥 Received initial ride list: ${rides.length} rides');
        if (mounted) {
          setState(() {
            _availableRides = rides;
          });
        }
      });

      // Listen for new rides
      SocketService.onNewRide((ride) {
        Logger.log('🆕 New ride available: ${ride.id}');
        if (mounted) {
          setState(() {
            // Add ride if not already in list
            if (!_availableRides.any((r) => r.id == ride.id)) {
              _availableRides.add(ride);
            }
          });

          // Show notification
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('New ride available: ${ride.source.address}'),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 3),
            ),
          );
        }
      });

      // Listen for ride list updates
      SocketService.onRideListUpdated((rides) {
        Logger.log('🔄 Ride list updated: ${rides.length} rides');
        if (mounted) {
          setState(() {
            _availableRides = rides;
          });
        }
      });

      // Listen for ride matched event
      SocketService.onRideMatched((ride, role) {
        Logger.log('🎉 Ride matched! Role: $role');
        if (mounted && role == 'driver') {
          // Remove from available rides
          setState(() {
            _availableRides.removeWhere((r) => r.id == ride.id);
          });

          // Show success dialog
          _showMatchedDialog(ride);
        }
      });

      // Listen for ride unavailable (another driver accepted it)
      SocketService.onRideUnavailable((rideId) {
        Logger.log('⚠️ Ride $rideId is no longer available');
        if (mounted) {
          setState(() {
            _availableRides.removeWhere((r) => r.id == rideId);
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Ride is no longer available'),
              backgroundColor: Colors.orange,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      });

      // Listen for ride errors
      SocketService.onRideError((message) {
        Logger.error('🔴 Ride error: $message');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $message'),
              backgroundColor: Colors.red,
            ),
          );
        }
      });

      // Listen for ride cancelled
      SocketService.onRideCancelled((rideId) {
        Logger.log('🚫 Ride cancelled: $rideId');
        if (mounted) {
          setState(() {
            _availableRides.removeWhere((r) => r.id == rideId);
          });
        }
      });

      Logger.log('✅ Driver socket initialized successfully');
    } catch (e) {
      Logger.error('💥 Failed to initialize driver socket: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to connect to server: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Show dialog when driver successfully matches with a ride
  void _showMatchedDialog(RideRequest ride) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text(
          '🎉 Ride Accepted!',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFCF4374),
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'You have successfully accepted this ride!',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'Passenger: ${ride.userName}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'From: ${ride.source.address}',
              style: const TextStyle(fontSize: 12),
            ),
            Text(
              'To: ${ride.destination.address}',
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Navigate to active ride page
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (context) => DriverActiveRidePage(
                    ride: ride,
                    driverId: _userId!,
                  ),
                ),
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFCF4374),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text('Start Navigation'),
          ),
        ],
      ),
    );
  }

  /// Accept a ride
  void _acceptRide(RideRequest ride) {
    if (_userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Driver ID not available'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    Logger.log('📤 Accepting ride: ${ride.id}');

    // Emit match ride event
    SocketService.matchRide(
      rideId: ride.id,
      driverId: _userId!,
      driverName: 'Driver User', // TODO: Get from user profile
    );

    // Show loading indicator
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Accepting ride...'),
        backgroundColor: Colors.blue,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    // Clean up socket listeners
    SocketService.removeAllListeners();
    SocketService.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text('Available Rides'),
        backgroundColor: const Color(0xFFCF4374),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Connection status
            Container(
              padding: const EdgeInsets.all(16),
              color: _isConnected ? Colors.green[50] : Colors.red[50],
              child: Row(
                children: [
                  Icon(
                    _isConnected ? Icons.check_circle : Icons.error,
                    color: _isConnected ? Colors.green : Colors.red,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _isConnected
                        ? 'Connected - Listening for rides...'
                        : 'Not connected',
                    style: TextStyle(
                      color: _isConnected ? Colors.green[900] : Colors.red[900],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Rides list
            Expanded(
              child: _availableRides.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.local_taxi,
                            size: 80,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No rides available',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey[600],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Waiting for ride requests...',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _availableRides.length,
                      itemBuilder: (context, index) {
                        final ride = _availableRides[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 16),
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.person,
                                      color: Color(0xFFCF4374),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      ride.userName,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(height: 24),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on,
                                      size: 20,
                                      color: Colors.green,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'From: ${ride.source.address}',
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.flag,
                                      size: 20,
                                      color: Colors.red,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'To: ${ride.destination.address}',
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () => _acceptRide(ride),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFFCF4374),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 12,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                    child: const Text(
                                      'Accept Ride',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}