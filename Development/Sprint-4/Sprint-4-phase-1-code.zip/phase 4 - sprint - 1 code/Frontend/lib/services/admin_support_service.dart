import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import 'storage_service.dart';

class AdminSupportService {
  // Fetch all support tickets 
  static Future<List<dynamic>> getTickets({String? status}) async {
    try {
      final token = await StorageService.getToken();
      
      // Append status query parameter if provided 
      String urlString = '${AppConfig.apiBaseUrl}/api/support/tickets';
      if (status != null && status.isNotEmpty) {
        urlString += '?status=$status';
      }
      
      final url = Uri.parse(urlString);

      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? [];
      } else {
        throw Exception('Failed to load tickets');
      }
    } catch (e) {
      print('Error fetching tickets: $e');
      return [];
    }
  }

  // Update the status of a ticket
  static Future<bool> updateTicketStatus(String ticketId, String newStatus) async {
    try {
      final token = await StorageService.getToken();
      final url = Uri.parse('${AppConfig.apiBaseUrl}/api/support/$ticketId/status');

      final response = await http.patch(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'status': newStatus}),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error updating ticket status: $e');
      return false;
    }
  }
}