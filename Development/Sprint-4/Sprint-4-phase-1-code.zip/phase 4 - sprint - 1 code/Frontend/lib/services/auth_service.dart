import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import 'storage_service.dart';
import 'socket_service.dart';
import '../utils/logger.dart';

class AuthService {

  static String get baseUrl => '${AppConfig.apiBaseUrl}/api/auth';
  
  Future<Map<String, dynamic>> signup({
    required String name,
    required String email,
    required String pin,
    String? trustedContactEmail,
    String? trustedContactName,
  }) async {
    try {
      final Map<String, dynamic> requestBody = {
        'name': name,
        'email': email,
        'pin': pin,
      };

      // Add trusted contact if provided
      if (trustedContactEmail != null && trustedContactEmail.isNotEmpty) {
        requestBody['trustedContactEmail'] = trustedContactEmail;
        if (trustedContactName != null && trustedContactName.isNotEmpty) {
          requestBody['trustedContactName'] = trustedContactName;
        }
      }

      final response = await http.post(
        Uri.parse('$baseUrl/signup'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 201) {
        return {
          'success': true,
          'message': responseData['message'],
          'data': responseData['data'],
        };
      } else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Signup failed',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  Future<Map<String, dynamic>> login({
    required String email,
    required String pin,
  }) async {
    try {
      
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'pin': pin,
        }),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        final backendSuccess = responseData['success'] ?? true;
        
        if (responseData['requiresResubmission'] == true) {
          return {
            'success': false,
            'message': responseData['message'] ?? 'Please resubmit documents',
            'requiresResubmission': true,
            'data': responseData['data'],
          };
        }
        
        // Normal successful login
        if (backendSuccess == true) {
          return {
            'success': true,
            'message': responseData['message'],
            'data': responseData['data'],
          };
        }
        
        // edge cases
        return {
          'success': false,
          'message': responseData['message'] ?? 'Login failed',
          'accountStatus': responseData['accountStatus'],
          'reason': responseData['reason'],
        };
      } 
      
      // Handle error responses (403, 401, etc.)
      else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Login failed',
          'accountStatus': responseData['accountStatus'],
          'reason': responseData['reason'],
        };
      }
    } catch (e) {
      print('🔴 [AUTH SERVICE] Exception: $e');
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  Future<Map<String, dynamic>> verifyEmail(String token) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/verify-email?token=$token'),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': responseData['message'],
          'data': responseData['data'],
        };
      } else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Verification failed',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  Future<Map<String, dynamic>> resendVerificationEmail(String email) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/resend-verification'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
        }),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': responseData['message'],
        };
      } else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Failed to resend email',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  Future<void> logout() async {
    try {
      Logger.log('👤 Logging out user...');
      
      await StorageService.clearUserData();
      
      SocketService.disconnect();
      
      Logger.log('✅ Logout successful');
    } catch (e) {
      Logger.error('❌ Error during logout: $e');
    }
  }
}