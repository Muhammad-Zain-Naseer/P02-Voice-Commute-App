import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import 'tts_cache_service.dart';

class VoiceService {
  static String get _baseUrl => '${AppConfig.apiBaseUrl}/api/voice';

  // ── Text to Speech — returns MP3 bytes ───
  static Future<Uint8List?> textToSpeech(String text,
      {String language = 'ur-PK'}) async {
    // Check cache first
    final cached = await TtsCacheService.get(text);
    if (cached != null) {
      print('TTS cache hit: "${text.substring(0, text.length.clamp(0, 20))}"');
      return cached;
    }

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/tts'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text, 'language': language}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final bytes = base64Decode(data['audioContent']);
          await TtsCacheService.put(text, bytes);
          return bytes;
        }
      }
      print('TTS failed: ${response.body}');
      return null;
    } catch (e) {
      print('TTS error: $e');
      return null;
    }
  }

  // ── Speech to Text — returns transcript ───
  static Future<String?> speechToText(String audioBase64) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/stt'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'audioBase64': audioBase64}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          return data['transcript'];
        }
      }
      print('STT failed: ${response.body}');
      return null;
    } catch (e) {
      print('STT error: $e');
      return null;
    }
  }

  // ── Extract email from Urdu phonetic transcript via Gemini ────
  static Future<String?> extractEmail(String transcript) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/extract-email'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'transcript': transcript}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return data['email'] as String?;
      }
      print('Extract email failed: ${response.body}');
    } catch (e) {
      print('Extract email error: $e');
    }
    return null;
  }

  // ── Interpret speech — via Gemini backend ────
  // Returns: 0 = new user, 1 = already registered, 2 = driver, -1 = no match
  static Future<int> interpretSpeech(String spoken) async {
    try {
      print('=== Calling Gemini interpret for: "$spoken"');
      final response = await http.post(
        Uri.parse('$_baseUrl/interpret'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'spoken': spoken}),
      ).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final matched = data['matched'] as int? ?? -1;
          print('=== Gemini matched: $matched (${data['confidence']}) — ${data['reasoning']}');
          return matched;
        }
      }
      print('=== Interpret API failed: ${response.body}');
    } catch (e) {
      print('=== Interpret error: $e');
    }

    return -1;
  }
}
