import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';

class RideService {
  static String get _baseUrl => AppConfig.apiBaseUrl;

  Future<bool> rateRide(String rideId, double rating) async {
    final url = Uri.parse('$_baseUrl/api/rides/$rideId/rate');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json; charset=UTF-8'},
        body: jsonEncode({'rating': rating}),
      );

      if (response.statusCode == 200) {
        print("Rating submitted successfully!");
        return true;
      } else {
        print("Failed to submit rating: ${response.body}");
        return false;
      }
    } catch (e) {
      print("Error calling rateRide API: $e");
      return false;
    }
  }
}
