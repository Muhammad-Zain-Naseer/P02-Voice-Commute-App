import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import '../utils/logger.dart';
import '../constants/app_config.dart';

class AudioApiService {
  static String get baseUrl => AppConfig.apiBaseUrl;

  // Note: Web blob handling is not supported in this mobile-only version
  // If you need web support, create a separate web-specific implementation

  /// Process audio bytes (for web) and extract locations
  /// Returns a map with 'source' and 'destination' or null on error
  static Future<Map<String, dynamic>?> processAudioBytes(Uint8List audioBytes, String filename) async {
    try {
      Logger.log('🌐 API Service: Starting audio processing from bytes');
      Logger.log('🌐 API Service: Audio size: ${audioBytes.length} bytes');

      final uri = Uri.parse('$baseUrl/api/audio/process');
      Logger.log('🌐 API Service: Request URL: $uri');

      final request = http.MultipartRequest('POST', uri);
      Logger.log('🌐 API Service: Created multipart request');

      // Add the audio file from bytes
      Logger.log('🌐 API Service: Adding audio bytes to request...');
      final audioFile = http.MultipartFile.fromBytes(
        'audio',
        audioBytes,
        filename: filename,
      );
      request.files.add(audioFile);
      Logger.log('🌐 API Service: Audio file added. Size: ${audioFile.length} bytes');

      // Send the request
      Logger.log('🌐 API Service: Sending request to backend...');
      final streamedResponse = await request.send();
      Logger.log('🌐 API Service: Response status code: ${streamedResponse.statusCode}');

      final response = await http.Response.fromStream(streamedResponse);
      Logger.log('🌐 API Service: Response body: ${response.body}');

      if (response.statusCode == 200) {
        Logger.log('🌐 API Service: Status 200 - Parsing JSON...');
        final jsonData = json.decode(response.body);
        Logger.log('🌐 API Service: Parsed JSON: $jsonData');

        if (jsonData['success'] == true && jsonData['data'] != null) {
          final locations = jsonData['data']['locations'];
          Logger.log('🌐 API Service: ✅ Locations extracted successfully!');
          Logger.log('🌐 API Service: Source: ${locations['source']}');
          Logger.log('🌐 API Service: Destination: ${locations['destination']}');

          return {
            'source': locations['source'] ?? '',
            'destination': locations['destination'] ?? '',
            'original_text': locations['original_text'] ?? '',
          };
        } else {
          Logger.error('🌐 API Service: ❌ JSON structure unexpected: success=${jsonData['success']}, data=${jsonData['data']}');
        }
      } else {
        Logger.error('🌐 API Service: ❌ Non-200 status code: ${response.statusCode}');
        Logger.error('🌐 API Service: Response body: ${response.body}');
      }

      return null;
    } catch (e, stackTrace) {
      Logger.error('🌐 API Service: 💥 ERROR: $e');
      Logger.error('🌐 API Service: Stack trace: $stackTrace');
      return null;
    }
  }

  /// Process audio file and extract locations
  /// Returns a map with 'source' and 'destination' or null on error
  static Future<Map<String, dynamic>?> processAudio(String audioFilePath) async {
    try {
      Logger.log('🌐 API Service: Starting audio processing');
      Logger.log('🌐 API Service: File path: $audioFilePath');

      final uri = Uri.parse('$baseUrl/api/audio/process');
      Logger.log('🌐 API Service: Request URL: $uri');

      final request = http.MultipartRequest('POST', uri);
      Logger.log('🌐 API Service: Created multipart request');

      // Add the audio file
      Logger.log('🌐 API Service: Adding audio file to request...');

      // On mobile, use fromPath
      final audioFile = await http.MultipartFile.fromPath(
        'audio',
        audioFilePath,
      );

      request.files.add(audioFile);
      Logger.log('🌐 API Service: Audio file added. Size: ${audioFile.length} bytes');

      // Send the request
      Logger.log('🌐 API Service: Sending request to backend...');
      final streamedResponse = await request.send();
      Logger.log('🌐 API Service: Response status code: ${streamedResponse.statusCode}');

      final response = await http.Response.fromStream(streamedResponse);
      Logger.log('🌐 API Service: Response body: ${response.body}');

      if (response.statusCode == 200) {
        Logger.log('🌐 API Service: Status 200 - Parsing JSON...');
        final jsonData = json.decode(response.body);
        Logger.log('🌐 API Service: Parsed JSON: $jsonData');

        if (jsonData['success'] == true && jsonData['data'] != null) {
          final locations = jsonData['data']['locations'];
          Logger.log('🌐 API Service: ✅ Locations extracted successfully!');
          Logger.log('🌐 API Service: Source: ${locations['source']}');
          Logger.log('🌐 API Service: Destination: ${locations['destination']}');

          return {
            'source': locations['source'] ?? '',
            'destination': locations['destination'] ?? '',
            'original_text': locations['original_text'] ?? '',
          };
        } else {
          Logger.error('🌐 API Service: ❌ JSON structure unexpected: success=${jsonData['success']}, data=${jsonData['data']}');
        }
      } else {
        Logger.error('🌐 API Service: ❌ Non-200 status code: ${response.statusCode}');
        Logger.error('🌐 API Service: Response body: ${response.body}');
      }

      return null;
    } catch (e, stackTrace) {
      Logger.error('🌐 API Service: 💥 ERROR: $e');
      Logger.error('🌐 API Service: Stack trace: $stackTrace');
      return null;
    }
  }
}
