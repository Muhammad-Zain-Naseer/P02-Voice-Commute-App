import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart'; 
import 'package:image_picker/image_picker.dart';
import '../constants/app_config.dart';

class DriverAuthService {
  static String get baseUrl => '${AppConfig.apiBaseUrl}/api/driver/auth';

  // --- REGISTRATION METHODS ---

  // Step 1: Request OTP
  static Future<Map<String, dynamic>> requestOTP(String email) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/request-otp'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to send OTP'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 2: Verify OTP 
  static Future<Map<String, dynamic>> verifyOTP(String email, String otp) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/verify-otp'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'otp': otp}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'token': data['data']['token'], 
          'email': data['data']['email']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Invalid or expired OTP'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 3: Submit Name 
  static Future<Map<String, dynamic>> submitName(String name, String token) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/submit-name'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'name': name}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'token': data['data']['token'], 
          'name': data['data']['name']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to save name'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 4: Submit CNIC 
  static Future<Map<String, dynamic>> submitCNIC(String cnic, String token) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/submit-cnic'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'cnic': cnic}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'token': data['data']['token'], 
          'cnic': data['data']['cnic']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to save CNIC'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 5: Submit Driving License 
  static Future<Map<String, dynamic>> submitDrivingLicense(
      String drivingLicense, String token) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/submit-license'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'drivingLicense': drivingLicense}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'token': data['data']['token'], 
          'drivingLicense': data['data']['drivingLicense']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to save driving license'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 6: Submit Vehicle Registration 
  static Future<Map<String, dynamic>> submitVehicleRegistration({
    required String registrationNumber,
    required String model,
    required String year,
    required String color,
    required XFile registrationPhoto,
    required String token,
  }) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/submit-vehicle'),
      );

      request.headers['Authorization'] = 'Bearer $token';

      request.fields['registrationNumber'] = registrationNumber;
      request.fields['model'] = model;
      request.fields['year'] = year;
      request.fields['color'] = color;

      String? mimeType = _getMimeType(registrationPhoto.name);

      if (kIsWeb) {
        final bytes = await registrationPhoto.readAsBytes();
        request.files.add(
          http.MultipartFile.fromBytes(
            'registrationPhoto',
            bytes,
            filename: registrationPhoto.name,
            contentType: mimeType != null 
                ? MediaType.parse(mimeType) 
                : null,
          ),
        );
      } else {
        var file = await http.MultipartFile.fromPath(
          'registrationPhoto',
          registrationPhoto.path,
          contentType: mimeType != null 
              ? MediaType.parse(mimeType) 
              : null,
        );
        request.files.add(file);
      }

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);
      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'token': data['data']['token'], 
          'vehicle': data['data']['vehicle']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to save vehicle registration'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Step 7: Submit PIN
  static Future<Map<String, dynamic>> submitPIN(String pin, String token) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/submit-pin'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'pin': pin}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'driver': data['data']['driver'],
          'token': data['data']['token'] 
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to complete registration'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // --- RESUBMISSION METHODS ---

  // Check if driver needs to resubmit documents
  static Future<Map<String, dynamic>> getResubmissionStatus(String token) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/resubmission-status'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'needsResubmission': data['data']['needsResubmission'],
          'adminMessage': data['data']['adminMessage'],
          'driver': data['data']['driver'],
          'status': data['data']['status'],
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to get resubmission status'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Resubmit all documents
  static Future<Map<String, dynamic>> resubmitDocuments({
    required String token,
    required String name,
    required String cnic,
    required String drivingLicense,
    required String registrationNumber,
    required String model,
    required String year,
    required String color,
    XFile? registrationPhoto,
  }) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/resubmit'),
      );

      request.headers['Authorization'] = 'Bearer $token';

      // Add all fields
      request.fields['name'] = name;
      request.fields['cnic'] = cnic;
      request.fields['drivingLicense'] = drivingLicense;
      request.fields['registrationNumber'] = registrationNumber;
      request.fields['model'] = model;
      request.fields['year'] = year;
      request.fields['color'] = color;

      // Add registration photo if provided
      if (registrationPhoto != null) {
        String? mimeType = _getMimeType(registrationPhoto.name);

        if (kIsWeb) {
          final bytes = await registrationPhoto.readAsBytes();
          request.files.add(
            http.MultipartFile.fromBytes(
              'registrationPhoto',
              bytes,
              filename: registrationPhoto.name,
              contentType: mimeType != null 
                  ? MediaType.parse(mimeType) 
                  : null,
            ),
          );
        } else {
          var file = await http.MultipartFile.fromPath(
            'registrationPhoto',
            registrationPhoto.path,
            contentType: mimeType != null 
                ? MediaType.parse(mimeType) 
                : null,
          );
          request.files.add(file);
        }
      }

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);
      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': data['message'],
          'driver': data['data']['driver']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to resubmit documents'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // --- AUTH & STATUS METHODS ---

  // Login
  static Future<Map<String, dynamic>> login(String email) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'driver': data['data']['driver'],
          'token': data['data']['token']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Login failed'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Get Registration Status
  static Future<Map<String, dynamic>> getRegistrationStatus(String token) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/registration-status'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return {
          'success': true,
          'registration': data['data']['registration']
        };
      } else {
        return {
          'success': false,
          'message': data['message'] ?? 'Failed to get status'
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Network error: $e'};
    }
  }

  // Helper for determining MIME types
  static String? _getMimeType(String filename) {
    final ext = filename.toLowerCase().split('.').last;
    switch (ext) {
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'pdf':
        return 'application/pdf';
      default:
        return null;
    }
  }
}