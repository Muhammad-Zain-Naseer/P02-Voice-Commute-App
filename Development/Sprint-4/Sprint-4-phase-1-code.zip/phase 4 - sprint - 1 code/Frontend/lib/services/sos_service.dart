import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/logger.dart';
import '../constants/app_config.dart';

/// SOS Service - Handles emergency SOS alerts via REST API
/// Uses HTTP instead of sockets for reliability during emergencies
class SOSService {
  static String get baseUrl => '${AppConfig.apiBaseUrl}/api/rides';
  static const Duration timeout = Duration(seconds: 30);

  /// Trigger SOS alert for a ride
  /// Returns Map with 'success' boolean and 'message' or 'data'
  ///
  /// This uses REST API instead of sockets for better reliability:
  /// - Works even if socket connection drops
  /// - Has retry mechanism built into HTTP
  /// - Critical for emergency situations
  static Future<Map<String, dynamic>> triggerSOS({
    required String rideId,
    Map<String, double>? location,
    String? message,
  }) async {
    try {
      Logger.log('🚨 [SOS SERVICE] Triggering SOS for ride: $rideId');
      Logger.log('🚨 [SOS SERVICE] Location: $location');
      Logger.log('🚨 [SOS SERVICE] Message: $message');

      final Map<String, dynamic> requestBody = {};

      // Add location if provided
      if (location != null) {
        requestBody['location'] = location;
      }

      // Add message if provided
      if (message != null && message.isNotEmpty) {
        requestBody['message'] = message;
      }

      Logger.log('🚨 [SOS SERVICE] Request body: ${jsonEncode(requestBody)}');
      Logger.log('🚨 [SOS SERVICE] Making POST request to: $baseUrl/$rideId/sos');

      final response = await http
          .post(
            Uri.parse('$baseUrl/$rideId/sos'),
            headers: {
              'Content-Type': 'application/json',
            },
            body: jsonEncode(requestBody),
          )
          .timeout(
            timeout,
            onTimeout: () {
              Logger.log('❌ [SOS SERVICE] Request timeout after ${timeout.inSeconds}s');
              throw Exception('SOS request timed out. Please try again.');
            },
          );

      Logger.log('🚨 [SOS SERVICE] Response status code: ${response.statusCode}');
      Logger.log('🚨 [SOS SERVICE] Response body: ${response.body}');

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Logger.log('✅ [SOS SERVICE] SOS triggered successfully!');
        Logger.log('✅ [SOS SERVICE] Response data: ${jsonEncode(responseData)}');

        return {
          'success': true,
          'message': 'SOS alert sent successfully',
          'data': responseData['data'],
        };
      } else {
        Logger.log('❌ [SOS SERVICE] SOS failed with status ${response.statusCode}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to trigger SOS',
        };
      }
    } on http.ClientException catch (e) {
      Logger.log('❌ [SOS SERVICE] Network error: $e');
      return {
        'success': false,
        'message': 'Network error. Please check your connection.',
      };
    } catch (e) {
      Logger.log('❌ [SOS SERVICE] Unexpected error: $e');
      return {
        'success': false,
        'message': 'Failed to trigger SOS: $e',
      };
    }
  }

  /// Trigger SOS with retry mechanism
  /// Attempts to send SOS up to maxRetries times
  /// Returns true if successful, false otherwise
  static Future<bool> triggerSOSWithRetry({
    required String rideId,
    Map<String, double>? location,
    String? message,
    int maxRetries = 3,
  }) async {
    Logger.log('🚨 [SOS SERVICE] Starting SOS with retry (max: $maxRetries)');

    for (int attempt = 1; attempt <= maxRetries; attempt++) {
      Logger.log('🚨 [SOS SERVICE] Attempt $attempt of $maxRetries');

      final result = await triggerSOS(
        rideId: rideId,
        location: location,
        message: message,
      );

      if (result['success'] == true) {
        Logger.log('✅ [SOS SERVICE] SOS sent successfully on attempt $attempt');
        return true;
      }

      if (attempt < maxRetries) {
        Logger.log('⚠️ [SOS SERVICE] Attempt $attempt failed, retrying in 2 seconds...');
        await Future.delayed(const Duration(seconds: 2));
      }
    }

    Logger.log('❌ [SOS SERVICE] All $maxRetries attempts failed');
    return false;
  }
}
