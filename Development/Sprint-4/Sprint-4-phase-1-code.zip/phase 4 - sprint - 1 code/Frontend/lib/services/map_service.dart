import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/logger.dart';
import '../constants/app_config.dart';

class MapService {
  static String get baseUrl => '${AppConfig.apiBaseUrl}/api/maps';

  static Future<Map<String, String>> translateAddresses({
    required String source,
    required String destination,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/translate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'source': source,
          'destination': destination,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log('✅ Translated: $source -> ${data['source']}');
        Logger.log('✅ Translated: $destination -> ${data['destination']}');
        return {
          'source': data['source'],
          'destination': data['destination'],
        };
      }
    } catch (e) {
      Logger.error('❌ Translation error: $e');
    }

    return {'source': source, 'destination': destination};
  }

  /// Geocode an address using backend Google Maps API
  static Future<Map<String, double>?> geocodeAddress(String address) async {
    try {
      Logger.log('📍 Geocoding address via backend: $address');
      Logger.log('📍 Using baseUrl: $baseUrl');

      // Ensure address has proper location context
      String fullAddress = address;
      if (!address.toLowerCase().contains('lahore') &&
          !address.toLowerCase().contains('pakistan')) {
        fullAddress = '$address, Lahore, Pakistan';
        Logger.log('📍 Enhanced address: $fullAddress');
      }

      final url = Uri.parse('$baseUrl/geocode');
      Logger.log('📍 Geocoding URL: $url');

      final response = await http
          .post(
            url,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'address': fullAddress,
            }),
          )
          .timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              Logger.error('❌ Geocoding request timed out after 30 seconds');
              throw Exception('Geocoding request timed out');
            },
          );

      Logger.log('📍 Geocoding response status: ${response.statusCode}');
      Logger.log('📍 Geocoding response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log(
            '✅ Geocoded: $fullAddress -> (${data['latitude']}, ${data['longitude']})');
        return {
          'latitude': (data['latitude'] as num).toDouble(),
          'longitude': (data['longitude'] as num).toDouble(),
        };
      } else {
        Logger.error(
            '❌ Geocoding failed with status ${response.statusCode}: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Geocoding error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return null;
  }

  static Future<Map<String, String>> calculateRoute({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
  }) async {
    try {
      Logger.log('🗺️ Calculating route: ($sourceLat, $sourceLng) -> ($destLat, $destLng)');
      final response = await http
          .post(
            Uri.parse('$baseUrl/calculate-route'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🗺️ Route response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log('✅ Route calculated: ${data['distance']}, ${data['duration']}');
        return {
          'distance': data['distance'],
          'duration': data['duration'],
        };
      } else {
        Logger.error('❌ Route calculation failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Route calculation error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return {'distance': 'N/A', 'duration': 'N/A'};
  }

  static Future<String> getDirectionsPolyline({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
  }) async {
    try {
      Logger.log('🛣️ Fetching directions polyline...');
      final response = await http
          .post(
            Uri.parse('$baseUrl/directions-polyline'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🛣️ Polyline response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final polyline = data['polyline'] ?? '';
        Logger.log('✅ Polyline fetched (${polyline.length} chars)');
        return polyline;
      } else {
        Logger.error('❌ Polyline fetch failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Polyline error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return '';
  }

  static Future<String> getStaticMapUrl({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
    required String polyline,
  }) async {
    try {
      Logger.log('🗺️ Fetching static map URL from backend...');
      Logger.log('🗺️ Coordinates: ($sourceLat, $sourceLng) -> ($destLat, $destLng)');
      Logger.log('🗺️ Polyline length: ${polyline.length}');

      final response = await http
          .post(
            Uri.parse('$baseUrl/static-map-url'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
              'polyline': polyline,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🗺️ Map URL response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final mapUrl = data['mapUrl'] ?? '';
        Logger.log('✅ Static map URL received (${mapUrl.length} chars)');
        Logger.log('🗺️ Map URL: $mapUrl');
        return mapUrl;
      } else {
        Logger.error('❌ Map URL fetch failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Static map URL error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return '';
  }
}