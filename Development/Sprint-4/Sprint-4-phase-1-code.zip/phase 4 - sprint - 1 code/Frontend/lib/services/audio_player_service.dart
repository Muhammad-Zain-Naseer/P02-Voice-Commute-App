import 'dart:async';
import 'dart:typed_data';
import 'package:just_audio/just_audio.dart';

class AudioPlayerService {
  static final AudioPlayer _player = AudioPlayer();
  static final _completerNotifier = StreamController<void>.broadcast();

  static Future<void> playBytes(Uint8List bytes) async {
    try {
      await _player.stop();
      final source = BytesAudioSource(bytes);
      await _player.setAudioSource(source);
      await _player.play();
      await _player.processingStateStream.firstWhere(
        (state) => state == ProcessingState.completed,
      );
    } catch (e) {
      print('Audio play error: $e');
    }
  }

  static Future<void> stop() async {
    await _player.stop();
  }

  static bool get isPlaying => _player.playing;
  static Stream<bool> get playingStream => _player.playingStream;

  static void dispose() {
    _player.dispose();
    _completerNotifier.close();
  }
}

class BytesAudioSource extends StreamAudioSource {
  final Uint8List _bytes;
  BytesAudioSource(this._bytes);

  @override
  Future<StreamAudioResponse> request([int? start, int? end]) async {
    start ??= 0;
    end ??= _bytes.length;
    return StreamAudioResponse(
      sourceLength: _bytes.length,
      contentLength: end - start,
      offset: start,
      stream: Stream.value(_bytes.sublist(start, end)),
      contentType: 'audio/mpeg',
    );
  }
}