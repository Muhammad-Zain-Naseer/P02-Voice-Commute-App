import 'package:flutter/material.dart';
import '../../models/ride_request.dart';
import '../../services/driver_service.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';

class EarningsPage extends StatefulWidget {
  const EarningsPage({super.key});

  @override
  State<EarningsPage> createState() => _EarningsPageState();
}

class _EarningsPageState extends State<EarningsPage> {
  late Future<Map<String, dynamic>> _earningsFuture;
  final DriverService _driverService = DriverService();
  bool _listenerAttached = false;

  @override
  void initState() {
    super.initState();
    _earningsFuture = _driverService.getEarningsHistory();
    _setupSocketListener();
  }

  void _setupSocketListener() async {
    if (_listenerAttached) return;

    if (SocketService.socket != null && SocketService.isConnected) {
      Logger.log("💰 EarningsPage: Attaching 'ride:completed' listener");
      
      SocketService.socket!.on('ride:completed', (data) async {
        Logger.log("💰 Socket received 'ride:completed': $data");
        
        try {
          final rideData = data is Map ? (data['ride'] ?? data) : null;
          
          if (rideData != null && rideData['amount'] != null) {
            Logger.log("💰 Using socket data directly with amount: ${rideData['amount']}");
            await Future.delayed(const Duration(milliseconds: 500));
          } else {
            Logger.log("💰 Socket data incomplete, waiting longer for DB sync");
            await Future.delayed(const Duration(seconds: 2));
          }
          
          Logger.log("💰 Refreshing Earnings List from API...");
          _refreshEarnings();
          
        } catch (e) {
          Logger.error("💰 Error processing socket data: $e");
          await Future.delayed(const Duration(seconds: 1));
          _refreshEarnings();
        }
      });

      _listenerAttached = true;
    } else {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) _setupSocketListener();
    }
  }

  void _refreshEarnings() {
    if (mounted) {
      setState(() {
        _earningsFuture = _driverService.getEarningsHistory();
      });
    }
  }

  String _formatDate(DateTime dateTime) {
    return "${dateTime.day}/${dateTime.month}/${dateTime.year}";
  }

  // Summary Card
  Widget _buildSummaryCard(double total) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFCF4374), Color(0xFF69223B)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'TOTAL THIS MONTH',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.white70,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Rs. ${total.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text('My Earnings'),
        backgroundColor: const Color(0xFFCF4374),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh),
            onPressed: _refreshEarnings,
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _earningsFuture,
        builder: (context, snapshot) {
          // Loading State
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFFCF4374)),
            );
          }

          // Error State
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 60, color: Colors.red),
                    const SizedBox(height: 16),
                    Text(
                      'Error loading earnings',
                      style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${snapshot.error}',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[600], fontSize: 14),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: _refreshEarnings,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Retry'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFCF4374),
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          // Empty State
          final rides = snapshot.data?['rides'] as List<RideRequest>?;
          final totalThisMonth = snapshot.data?['totalThisMonth'] as double?;

          if (rides == null || rides.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long, size: 80, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    'No Earnings Yet',
                    style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Your completed rides will appear here.',
                    style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                  ),
                ],
              ),
            );
          }

          // Data State
          return Column(
            children: [
              _buildSummaryCard(totalThisMonth ?? 0.0),

              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: rides.length,
                  itemBuilder: (context, index) {
                    final ride = rides[index];

                    final amount = ride.amount ?? 0.0;
                    final fare = "Rs. ${amount.toStringAsFixed(2)}";
                    
                    if (amount == 0) {
                      Logger.log("⚠️ Warning: Ride ${ride.id} has amount = 0");
                    }

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Top Row: Price and Date
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  fare,
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    color: amount > 0 
                                        ? const Color(0xFFCF4374) 
                                        : Colors.grey,
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      _formatDate(ride.createdAt),
                                      style: const TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        Icon(
                                          ride.paymentMethod == 'cash'
                                              ? Icons.money_rounded
                                              : Icons.credit_card,
                                          color: Colors.grey[600],
                                          size: 16,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          ride.paymentMethod?.toString() ?? 'N/A',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey[700],
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const Divider(height: 24),

                            // Ride Details: From
                            Row(
                              children: [
                                const Icon(
                                  Icons.location_on,
                                  size: 20,
                                  color: Colors.green,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    ride.source.address,
                                    style: const TextStyle(fontSize: 14),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),

                            // Ride Details: To
                            Row(
                              children: [
                                const Icon(
                                  Icons.flag,
                                  size: 20,
                                  color: Colors.red,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    ride.destination.address,
                                    style: const TextStyle(fontSize: 14),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}