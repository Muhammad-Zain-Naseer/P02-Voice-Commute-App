import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../widgets/custom_button.dart';
import '../widgets/sound_wave.dart';
import '../services/voice_service.dart';
import '../services/audio_player_service.dart';
import 'auth/signup_email_screen.dart';
import 'auth/login_email_screen.dart';
import 'auth/driverSignup/driver_signup_email_screen.dart';
import '../utils/web_speech_stub.dart'
    if (dart.library.html) '../utils/web_speech.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;
  int _highlightedButton = -1;
  int _pendingNavigation = -1;
  bool _hasUserInteracted = false;
  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    if (!kIsWeb) {
      _setupAudio();
    }
  }

  void _startPulse() => _pulseController.repeat(reverse: true);

  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    await _speakWelcome();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && mounted) {
        await _speakWelcome();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakAndWait(String text) async {
    if (_isMuted || _speechCancelled) return;
    if (mounted) setState(() => _isSpeaking = true);
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakWelcome() async {
    _speechCancelled = false;
    _cancelReplayTimer();
    if (mounted) setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted || _speechCancelled) return;

    await _speakAndWait('ایک انتخاب کریں');
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted || _speechCancelled) return;

    setState(() => _highlightedButton = 0);
    await _speakAndWait('نیا صارف');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) return;

    setState(() => _highlightedButton = 1);
    await _speakAndWait('پہلے سے رجسٹر ہیں');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) return;

    setState(() => _highlightedButton = 2);
    await _speakAndWait('رجسٹر بطور ڈرائیور');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) return;

    await _speakAndWait('بولنے کے لیے مائیکروفون دبائیں');
    if (mounted && !_speechCancelled) _startReplayTimer();
  }

  // ── MAIN toggle — routes to web or native ─────
  Future<void> _toggleListening() async {
    if (_isInterpreting) return;

    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      if (kIsWeb) {
        _stopWebSpeech();
      } else {
        await _stopRecordingAndProcess();
      }
      return;
    }

    if (kIsWeb) {
      _startWebSpeech();
    } else {
      await _startNativeRecording();
    }
  }

  // ── WEB: browser Web Speech API ───────
  void _startWebSpeech() {
    _cancelReplayTimer();
    AudioPlayerService.stop();

    startWebSpeech(
      onResult: (transcript) {},
      onError: () {},
    );

    setState(() {
      _isListening = true;
      _pendingNavigation = -1;
    });
    _startPulse();
    print('=== Web Speech started');

    // Poll for result every 300ms
    Timer.periodic(const Duration(milliseconds: 300), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      final transcript = getWebTranscript();
      if (transcript != null) {
        t.cancel();
        _stopPulse();
        setState(() => _isListening = false);
        print('=== Web transcript: $transcript');
        if (transcript.trim().isNotEmpty) {
          _handleTranscript(transcript);
        } else {
          _startReplayTimer();
        }
      }
    });

    _autoStopTimer = Timer(const Duration(seconds: 8), () {
      stopWebSpeech();
      _stopPulse();
      if (mounted) setState(() => _isListening = false);
      _startReplayTimer();
    });
  }

  void _stopWebSpeech() {
    stopWebSpeech();
    _stopPulse();
    setState(() => _isListening = false);
    _startReplayTimer();
  }

  // ── NATIVE: records WAV → Google Cloud STT ──────
  Future<void> _startNativeRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      print('=== Microphone permission denied');
      return;
    }

    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/hersafar_voice.wav';

      final oldFile = File(path);
      if (await oldFile.exists()) await oldFile.delete();

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      final isRecording = await _recorder.isRecording();
      if (!isRecording) {
        print('=== Recorder failed to start');
        _startReplayTimer();
        return;
      }

      setState(() {
        _isListening = true;
        _pendingNavigation = -1;
      });
      _startPulse();
      print('=== Native recording started');

      _amplitudeTimer =
          Timer.periodic(const Duration(milliseconds: 500), (t) async {
        if (!_isListening) {
          t.cancel();
          return;
        }
        final amp = await _recorder.getAmplitude();
        print('=== Amp: ${amp.current.toStringAsFixed(1)}');
      });

      _autoStopTimer = Timer(const Duration(seconds: 8), () {
        if (_isListening) _stopRecordingAndProcess();
      });
    } catch (e) {
      print('=== Start recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      print('=== Recording stopped: $path');

      if (path == null) {
        _startReplayTimer();
        return;
      }

      setState(() => _isInterpreting = true);

      final file = File(path);
      if (!await file.exists()) {
        print('=== Recording file not found');
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      final bytes = await file.readAsBytes();
      print('=== File size: ${bytes.length} bytes');

      if (bytes.isEmpty) {
        print('=== Recording file is empty');
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      final audioBase64 = base64Encode(bytes);
      final transcript = await VoiceService.speechToText(audioBase64);
      print('=== Transcript: $transcript');

      if (transcript == null || transcript.trim().isEmpty) {
        print('=== Empty transcript');
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      await _handleTranscript(transcript);
    } catch (e) {
      print('=== STT error: $e');
      setState(() {
        _isListening = false;
        _isInterpreting = false;
      });
      _startReplayTimer();
    }
  }

  // ── Shared: interpret + navigate ───────────────
  Future<void> _handleTranscript(String transcript) async {
    if (mounted) setState(() => _isInterpreting = true);

    int matched = await VoiceService.interpretSpeech(transcript);
    print('=== Gemini matched: $matched');

    if (matched == -1) {
      matched = _keywordFallback(transcript);
      print('=== Keyword fallback: $matched');
    }

    if (!mounted) return;
    setState(() => _isInterpreting = false);

    if (matched != -1) {
      _cancelReplayTimer();
      setState(() {
        _highlightedButton = matched;
        _pendingNavigation = matched;
      });
      Future.delayed(const Duration(milliseconds: 800), () {
        _navigateTo(matched);
      });
    } else {
      _startReplayTimer();
    }
  }

  int _keywordFallback(String transcript) {
    final t = transcript.toLowerCase().trim();
    if (t.contains('driver') || t.contains('drive') ||
        t.contains('gaari') || t.contains('gari') ||
        t.contains('chalana') || t.contains('ڈرائیور')) return 2;
    if (t.contains('login') || t.contains('log in') ||
        t.contains('signin') || t.contains('already') ||
        t.contains('pehle') || t.contains('پہلے')) return 1;
    if (t.contains('new') || t.contains('signup') ||
        t.contains('register') || t.contains('naya') ||
        t.contains('نیا') || t.contains('create')) return 0;
    return -1;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() {
        _isSpeaking = false;
        _highlightedButton = -1;
      });
      _cancelReplayTimer();
    } else {
      setState(() => _highlightedButton = -1);
      await _speakWelcome(); // resets _speechCancelled itself
      _startReplayTimer();
    }
  }

  void _navigateTo(int index) {
    _speechCancelled = true;
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    AudioPlayerService.stop();
    if (!kIsWeb) _recorder.stop();
    if (mounted) {
      setState(() {
        _isSpeaking = false;
        _isListening = false;
      });
    }
    if (!mounted) return;
    setState(() {
      _highlightedButton = -1;
      _pendingNavigation = -1;
    });
    switch (index) {
      case 0:
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const SignupEmailScreen()));
        break;
      case 1:
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const LoginEmailScreen()));
        break;
      case 2:
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => const DriverSignupEmailScreen()));
        break;
    }
  }

  @override
  void dispose() {
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();

    if (!kIsWeb) _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
              ),
            ),
            child: SafeArea(
              child: SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height -
                        MediaQuery.of(context).padding.top -
                        MediaQuery.of(context).padding.bottom,
                  ),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32.0, vertical: 10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              const SizedBox(height: 10),
                              Align(
                                alignment: Alignment.topRight,
                                child: GestureDetector(
                                  onTap: _toggleMute,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.5),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      _isMuted
                                          ? Icons.volume_off_rounded
                                          : Icons.volume_up_rounded,
                                      color: const Color(0xFFCF4374),
                                      size: 24,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              SvgPicture.asset(
                                'assets/icons/logo_hersafar.svg',
                                width: 160,
                                height: 100,
                              ),
                              const SizedBox(height: 24),
                              SoundWave(isAnimating: _isSpeaking),
                              const SizedBox(height: 20),
                              const Text(
                                'ایک انتخاب کریں',
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFCF4374),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(vertical: 16.0),
                            child: Column(
                              children: [
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 0,
                                  child: CustomButton(
                                    text: 'نیا صارف',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(0);
                                    },
                                    height: 60,
                                    isPrimary: true,
                                    borderColor: const Color(0xFFF682AA),
                                    backgroundColor: const Color(0xFFF8BBD0),
                                    textColor: const Color(0xFFCF4374),
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 1,
                                  child: CustomButton(
                                    text: 'پہلے سے رجسٹر ہیں؟',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(1);
                                    },
                                    height: 60,
                                    isPrimary: true,
                                    borderColor: const Color(0xFFF682AA),
                                    backgroundColor: const Color(0xFFFAECF1),
                                    textColor: const Color(0xFFCF4374),
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 2,
                                  child: CustomButton(
                                    text: 'رجسٹر بطور ڈرائیور',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(2);
                                    },
                                    height: 50,
                                    isPrimary: false,
                                    borderColor: const Color(0xFFCF4374),
                                    backgroundColor: const Color(0xFFCF4374),
                                    textColor: Colors.white,
                                    fontSize: 18,
                                    isGradient: true,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 16.0),
                            child: Column(
                              children: [
                                _MicButton(
                                  isListening: _isListening,
                                  isInterpreting: _isInterpreting,
                                  pulseAnimation: _pulseAnimation,
                                  onTap: _isInterpreting
                                      ? null
                                      : _toggleListening,
                                ),
                                const SizedBox(height: 12),
                                AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 300),
                                  child: Text(
                                    _isInterpreting
                                        ? 'سمجھ رہا ہوں...'
                                        : _isListening
                                            ? 'سننا بند کریں'
                                            : 'بولنے کے لیے دبائیں',
                                    key: ValueKey(
                                        '$_isListening$_isInterpreting'),
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: (_isListening || _isInterpreting)
                                          ? const Color(0xFF8B1A4A)
                                          : const Color(0xFFCF4374),
                                      fontWeight:
                                          (_isListening || _isInterpreting)
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (kIsWeb && !_hasUserInteracted)
            GestureDetector(
              onTap: () {
                setState(() => _hasUserInteracted = true);
                _speakWelcome();
                _startReplayTimer();
              },
              child: Container(
                color: const Color(0xFFF8BBD0).withOpacity(0.92),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.touch_app,
                          size: 60, color: Color(0xFFCF4374)),
                      SizedBox(height: 16),
                      Text(
                        'شروع کرنے کے لیے تھپتھپائیں',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Tap anywhere to start',
                        style: TextStyle(
                            fontSize: 16, color: Color(0xFFCF4374)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MicButton extends StatelessWidget {
  final bool isListening;
  final bool isInterpreting;
  final Animation<double> pulseAnimation;
  final VoidCallback? onTap;

  const _MicButton({
    required this.isListening,
    required this.isInterpreting,
    required this.pulseAnimation,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedBuilder(
        animation: pulseAnimation,
        builder: (context, child) {
          return Stack(
            alignment: Alignment.center,
            children: [
              if (isListening)
                Transform.scale(
                  scale: pulseAnimation.value,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFCF4374).withOpacity(0.25),
                        width: 2,
                      ),
                    ),
                  ),
                ),
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (isListening || isInterpreting)
                      ? const Color(0xFFCF4374).withOpacity(0.12)
                      : Colors.white.withOpacity(0.35),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCF4374)
                          .withOpacity(isListening ? 0.4 : 0.15),
                      blurRadius: isListening ? 28 : 12,
                      spreadRadius: isListening ? 6 : 2,
                    ),
                  ],
                ),
              ),
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: isListening
                        ? [const Color(0xFFE91E8C), const Color(0xFF9C0055)]
                        : isInterpreting
                            ? [
                                const Color(0xFFCF4374),
                                const Color(0xFF8B1A4A),
                              ]
                            : [
                                const Color(0xFFF06292),
                                const Color(0xFFCF4374),
                              ],
                    stops: const [0.0, 1.0],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCF4374).withOpacity(0.5),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: isInterpreting
                    ? const Center(
                        child: SizedBox(
                          width: 32,
                          height: 32,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.5,
                          ),
                        ),
                      )
                    : Center(
                        child: Icon(
                          isListening
                              ? Icons.mic_rounded
                              : Icons.mic_none_rounded,
                          color: Colors.white,
                          size: 38,
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _AnimatedButton extends StatelessWidget {
  final bool isHighlighted;
  final Widget child;

  const _AnimatedButton({required this.isHighlighted, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: isHighlighted ? 1.06 : 1.0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: isHighlighted
              ? [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withOpacity(0.45),
                    blurRadius: 14,
                    spreadRadius: 3,
                  )
                ]
              : [],
        ),
        child: child,
      ),
    );
  }
}