import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../constants/app_config.dart';
import '../services/storage_service.dart';


class SupportTicketPage extends StatefulWidget {
  final String userId;
  final String role; 

  const SupportTicketPage({
    super.key,
    required this.userId,
    required this.role,
  });

  @override
  State<SupportTicketPage> createState() => _SupportTicketPageState();
}

class _SupportTicketPageState extends State<SupportTicketPage>
    with SingleTickerProviderStateMixin {
  
  String? _selectedCategory;
  final TextEditingController _textController = TextEditingController();
  
  bool _isRecording = false;
  bool _isLoading = false;
  String? _audioFilePath;

  late AnimationController _animationController;
  final _audioRecorder = AudioRecorder();

  final List<Map<String, dynamic>> _categories = [
    {
      'id': 'safety_concern',
      'title': 'حفاظتی مسئلہ',
      'icon': Icons.security,
    },
    {
      'id': 'payment_issue',
      'title': 'ادائیگی کا مسئلہ',
      'icon': Icons.account_balance_wallet,
    },
    {
      'id': 'behavior_complaint',
      'title': 'رویے کی شکایت',
      'icon': Icons.feedback,
    },
    {
      'id': 'app_bug',
      'title': 'ایپ کی خرابی',
      'icon': Icons.bug_report,
    },
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    _textController.dispose();
    _audioRecorder.dispose();
    super.dispose();
  }

  // --- Audio Recording Logic ---
  Future<void> _startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        final tempDir = await getTemporaryDirectory();
        final path = p.join(tempDir.path, 'support_audio_${DateTime.now().millisecondsSinceEpoch}.m4a');

        // Start recording
        await _audioRecorder.start(
          const RecordConfig(encoder: AudioEncoder.aacLc), 
          path: path,
        );

        setState(() {
          _isRecording = true;
          _audioFilePath = null; 
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('مائیکروفون کی اجازت درکار ہے (Microphone permission required)')),
          );
        }
      }
    } catch (e) {
      debugPrint("Error starting record: $e");
    }
  }

  Future<void> _stopRecording() async {
    try {
      // Stop the recorder and get the file path
      final path = await _audioRecorder.stop();
      
      setState(() {
        _isRecording = false;
        _audioFilePath = path; 
      });
      
      if (mounted && path != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('آواز ریکارڈ ہو گئی ہے', textDirection: TextDirection.rtl)),
        );
      }
    } catch (e) {
      debugPrint("Error stopping record: $e");
      setState(() => _isRecording = false);
    }
  }

  // --- API Submission Logic ---
  Future<void> _submitTicket() async {
    if (_selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('براہ کرم ایک مسئلہ منتخب کریں', textDirection: TextDirection.rtl)),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final token = await StorageService.getToken(); 
      
      var uri = Uri.parse('${AppConfig.apiBaseUrl}/api/support'); 

      var request = http.MultipartRequest('POST', uri);
      
      if (token != null) {
        request.headers['Authorization'] = 'Bearer $token'; 
      }
      
      request.fields['category'] = _selectedCategory!;
      request.fields['role'] = widget.role;
      
      if (_textController.text.isNotEmpty) {
        request.fields['descriptionText'] = _textController.text;
      }

      if (_audioFilePath != null) {
        request.files.add(
          await http.MultipartFile.fromPath('audio', _audioFilePath!),
        );
      }

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('آپ کی شکایت جمع کر دی گئی ہے', textDirection: TextDirection.rtl)),
          );
          Navigator.pop(context);
        }
      } else {
        throw Exception('Failed to submit ticket');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('کچھ غلط ہو گیا، دوبارہ کوشش کریں', textDirection: TextDirection.rtl)),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFDEAF0),
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFCF4374)),
        title: const Text(
          'مسئلہ رپورٹ کریں',
          style: TextStyle(
            color: Color(0xFFCF4374),
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Category Selection Grid
              const Text(
                'مسئلے کی قسم منتخب کریں',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF69223B),
                ),
              ),
              const SizedBox(height: 16),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.1,
                ),
                itemCount: _categories.length,
                itemBuilder: (context, index) {
                  final category = _categories[index];
                  final isSelected = _selectedCategory == category['id'];

                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedCategory = category['id'];
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected ? const Color(0xFFCF4374) : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            category['icon'],
                            size: 48,
                            color: isSelected ? Colors.white : const Color(0xFFCF4374),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            category['title'],
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: isSelected ? Colors.white : const Color(0xFF69223B),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 32),

              // 2. Hold to Record Button
              const Text(
                'آواز میں پیغام ریکارڈ کریں',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF69223B),
                ),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onLongPress: _startRecording,
                onLongPressUp: _stopRecording,
                child: AnimatedBuilder(
                  animation: _animationController,
                  builder: (context, child) {
                    return Container(
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isRecording
                            ? const Color(0xFFCF4374)
                            : Colors.white,
                        boxShadow: [
                          if (_isRecording)
                            BoxShadow(
                              color: const Color(0xFFCF4374)
                                  .withValues(alpha: 0.5 * _animationController.value),
                              blurRadius: 30 * _animationController.value,
                              spreadRadius: 15 * _animationController.value,
                            ),
                          const BoxShadow(
                            color: Colors.black12,
                            blurRadius: 10,
                            spreadRadius: 2,
                          )
                        ],
                      ),
                      child: Icon(
                        _isRecording ? Icons.mic : Icons.mic_none,
                        size: 60,
                        color: _isRecording ? Colors.white : const Color(0xFFCF4374),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _isRecording 
                  ? 'ریکارڈنگ ہو رہی ہے...' 
                  : (_audioFilePath != null ? 'آواز ریکارڈ ہو گئی' : 'بٹن دبا کر رکھیں'),
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontSize: 14,
                  color: _isRecording ? Colors.red : const Color(0xFFCF4374),
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 32),

              // 3. Optional Text Input
              TextField(
                controller: _textController,
                textDirection: TextDirection.rtl,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'تفصیلات لکھیں (اختیاری)',
                  hintTextDirection: TextDirection.rtl,
                  filled: true,
                  fillColor: Colors.white.withValues(alpha: 0.9),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),

              const SizedBox(height: 32),

              // 4. Submit Button
              ElevatedButton(
                onPressed: _isLoading ? null : _submitTicket,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        'جمع کروائیں',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}