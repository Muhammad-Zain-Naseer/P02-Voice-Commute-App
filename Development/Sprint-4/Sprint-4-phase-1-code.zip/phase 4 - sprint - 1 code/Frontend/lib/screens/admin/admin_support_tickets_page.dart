import 'package:flutter/material.dart';
import '../../services/admin_support_service.dart';
import '../../constants/app_config.dart';
import 'package:audioplayers/audioplayers.dart';

class AdminSupportTicketsPage extends StatefulWidget {
  const AdminSupportTicketsPage({super.key});

  @override
  State<AdminSupportTicketsPage> createState() => _AdminSupportTicketsPageState();
}

class _AdminSupportTicketsPageState extends State<AdminSupportTicketsPage> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<dynamic> _tickets = [];
  bool _isLoading = true;
  String _selectedFilter = 'open'; // 'open', 'resolved', or '' for all

  @override
  void initState() {
    super.initState();
    _fetchTickets();
  }
  @override
  void dispose() {
    _audioPlayer.dispose(); 
    super.dispose();
  }

  Future<void> _fetchTickets() async {
    setState(() => _isLoading = true);
    final tickets = await AdminSupportService.getTickets(status: _selectedFilter);
    setState(() {
      _tickets = tickets;
      _isLoading = false;
    });
  }

  Future<void> _resolveTicket(String ticketId) async {
    final success = await AdminSupportService.updateTicketStatus(ticketId, 'resolved');
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ticket marked as resolved')),
      );
      _fetchTickets(); // Refresh the list
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to update ticket')),
      );
    }
  }

  String _formatCategory(String category) {
    switch (category) {
      case 'safety_concern': return '⚠️ Safety Concern';
      case 'payment_issue': return '💰 Payment Issue';
      case 'behavior_complaint': return '🚗 Behavior Complaint';
      case 'app_bug': return '📱 App Bug';
      default: return category;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Support Tickets'),
        backgroundColor: const Color(0xFFCF4374),
        actions: [
          // Filter Dropdown
          DropdownButton<String>(
            value: _selectedFilter,
            dropdownColor: Colors.white,
            iconEnabledColor: Colors.white,
            style: const TextStyle(color: Colors.black),
            underline: const SizedBox(),
            items: const [
              DropdownMenuItem(value: '', child: Text('All Tickets')),
              DropdownMenuItem(value: 'open', child: Text('Open')),
              DropdownMenuItem(value: 'resolved', child: Text('Resolved')),
            ],
            onChanged: (value) {
              if (value != null) {
                setState(() => _selectedFilter = value);
                _fetchTickets();
              }
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFCF4374)))
          : _tickets.isEmpty
              ? const Center(child: Text('No tickets found.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _tickets.length,
                  itemBuilder: (context, index) {
                    final ticket = _tickets[index];
                    final isOpen = ticket['status'] == 'open';

                    return Card(
                      elevation: 3,
                      margin: const EdgeInsets.only(bottom: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(
                          color: isOpen ? Colors.red.withOpacity(0.5) : Colors.green.withOpacity(0.5),
                          width: 1,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header: Category and Status
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  _formatCategory(ticket['category'] ?? ''),
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Chip(
                                  label: Text(
                                    ticket['status']?.toUpperCase() ?? 'UNKNOWN',
                                    style: const TextStyle(color: Colors.white, fontSize: 12),
                                  ),
                                  backgroundColor: isOpen ? Colors.red : Colors.green,
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            
                            // User Info
                            Text('User ID: ${ticket['userId']} (${ticket['role']})',
                                style: TextStyle(color: Colors.grey[600], fontSize: 14)),
                            const SizedBox(height: 12),

                            // Description Text 
                            if (ticket['descriptionText'] != null && ticket['descriptionText'].toString().isNotEmpty)
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.grey[100],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(ticket['descriptionText']),
                              ),
                            
                            // Audio Attachment Indicator
                            if (ticket['audioUrl'] != null) ...[
                              const SizedBox(height: 12),
                              ElevatedButton.icon(
                                onPressed: () async {
                                  final fullAudioUrl = '${AppConfig.apiBaseUrl}${ticket['audioUrl']}';
                                  await _audioPlayer.play(UrlSource(fullAudioUrl));
                                  
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Playing voice note...')),
                                  );
                                },
                                icon: const Icon(Icons.play_arrow),
                                label: const Text('Play Voice Note'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blueAccent,
                                  foregroundColor: Colors.white,
                                ),
                              ),
                            ],

                            // Action Buttons
                            if (isOpen) ...[
                              const Divider(height: 32),
                              Align(
                                alignment: Alignment.centerRight,
                                child: ElevatedButton(
                                  onPressed: () => _resolveTicket(ticket['_id']),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    foregroundColor: Colors.white,
                                  ),
                                  child: const Text('Mark as Resolved'),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}