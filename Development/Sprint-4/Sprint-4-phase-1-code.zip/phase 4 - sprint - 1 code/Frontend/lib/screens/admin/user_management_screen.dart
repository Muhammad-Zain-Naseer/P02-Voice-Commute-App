import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/admin_service.dart';
import '../../widgets/custom_button.dart';

class UserManagementScreen extends StatefulWidget {
  final String token;

  const UserManagementScreen({super.key, required this.token});

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  late AdminService _adminService;

  List<dynamic> _users = [];
  bool _isLoading = false;
  int _currentPage = 1;
  int _totalPages = 1;

  String? _selectedRole;
  bool? _selectedVerificationStatus;
  String _searchQuery = '';

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _adminService = AdminService();
    _adminService.setToken(widget.token);
    _loadUsers();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUsers() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final data = await _adminService.getUsers(
        role: _selectedRole,
        isVerified: _selectedVerificationStatus,
        page: _currentPage,
      );

      if (data != null && mounted) {
        setState(() {
          _users = data['users'] ?? [];
          _totalPages = data['pages'] ?? 1;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error loading users: $e')));
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _searchUsers() async {
    if (_searchQuery.trim().isEmpty) {
      _loadUsers();
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final data = await _adminService.searchUsers(
        query: _searchQuery,
        page: _currentPage,
      );

      if (data != null && mounted) {
        setState(() {
          _users = data['users'] ?? [];
          _totalPages = data['pages'] ?? 1;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error searching users: $e')));
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _viewUserDetails(String userId) async {
    setState(() {
      _isLoading = true;
    });

    try {
      final activity = await _adminService.getUserActivity(userId);

      if (activity != null && mounted) {
        _showUserDetailsDialog(activity);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading user details: $e')),
        );
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showUserDetailsDialog(Map<String, dynamic> activity) {
    final user = activity['user'];
    final driverInfo = activity['driverInfo'];

    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 600),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.person, color: Color(0xFFCF4374), size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      user['name'] ?? 'Unknown',
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildDetailSection('User Information', [
                _buildDetailRow('User ID', user['userId']),
                _buildDetailRow('Email', user['email']),
                _buildDetailRow('Role', user['role']),
                _buildDetailRow(
                  'Status',
                  user['isActive'] == false
                      ? 'Deactivated'
                      : user['isSuspended'] == true
                      ? 'Suspended'
                      : 'Active',
                ),
                _buildDetailRow(
                  'Verified',
                  user['isVerified'] == true ? 'Yes' : 'No',
                ),
              ]),
              const SizedBox(height: 20),
              if (driverInfo != null) ...[
                _buildDetailSection('Driver Information', [
                  _buildDetailRow('CNIC', driverInfo['cnic']),
                  _buildDetailRow('Phone', driverInfo['phone']),
                  _buildDetailRow('License', driverInfo['drivingLicense']),
                  _buildDetailRow('Status', driverInfo['status']),
                ]),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: const Color(0xFFCF4374),
          ),
        ),
        const SizedBox(height: 12),
        ...children,
      ],
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w500,
                fontSize: 13,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value ?? 'N/A',
              style: GoogleFonts.poppins(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showActionDialog({
    required String title,
    required String userId,
    required String action,
    bool requiresReason = false,
  }) async {
    final reasonController = TextEditingController();
    String? selectedRole;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          title,
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (action == 'update_role') ...[
              const Text('Select new role:'),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Role',
                ),
                items: const [
                  DropdownMenuItem(value: 'commuter', child: Text('Commuter')),
                  DropdownMenuItem(value: 'driver', child: Text('Driver')),
                  DropdownMenuItem(value: 'admin', child: Text('Admin')),
                ],
                onChanged: (value) => selectedRole = value,
              ),
            ],
            if (requiresReason) ...[
              TextField(
                controller: reasonController,
                decoration: const InputDecoration(
                  labelText: 'Reason',
                  hintText: 'Enter reason...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
            ] else
              Text(
                'Are you sure you want to $action this user?',
                style: GoogleFonts.poppins(),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFCF4374),
            ),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );

    if (result == true && mounted) {
      await _performAction(
        action: action,
        userId: userId,
        reason: requiresReason ? reasonController.text : null,
        role: selectedRole,
      );
    }
  }

  Future<void> _performAction({
    required String action,
    required String userId,
    String? reason,
    String? role,
  }) async {
    bool success = false;
    String message = '';

    try {
      switch (action) {
        case 'verify':
          success = await _adminService.verifyUser(userId);
          message = success
              ? 'User verified successfully'
              : 'Failed to verify user';
          break;
        case 'activate':
          success = await _adminService.activateUser(userId);
          message = success
              ? 'User activated successfully'
              : 'Failed to activate user';
          break;
        case 'deactivate':
          success = await _adminService.deactivateUser(userId, reason: reason);
          message = success
              ? 'User deactivated successfully'
              : 'Failed to deactivate user';
          break;
        case 'suspend':
          if (reason != null && reason.isNotEmpty) {
            success = await _adminService.suspendUser(userId, reason);
            message = success
                ? 'User suspended successfully'
                : 'Failed to suspend user';
          }
          break;
        case 'unsuspend':
          success = await _adminService.unsuspendUser(userId);
          message = success
              ? 'User unsuspended successfully'
              : 'Failed to unsuspend user';
          break;
        case 'update_role':
          if (role != null) {
            success = await _adminService.updateUserRole(userId, role);
            message = success
                ? 'User role updated successfully'
                : 'Failed to update user role';
          }
          break;
        case 'delete':
          success = await _adminService.deleteUser(userId);
          message = success
              ? 'User deleted successfully'
              : 'Failed to delete user';
          break;
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: success ? Colors.green : Colors.red,
          ),
        );

        if (success) {
          _loadUsers();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'User Management',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0xFFCF4374),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // Search and Filter Section
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withValues(alpha: 0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // Search Bar
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search by name, email, or user ID...',
                    prefixIcon: const Icon(
                      Icons.search,
                      color: Color(0xFFCF4374),
                    ),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              setState(() {
                                _searchQuery = '';
                              });
                              _loadUsers();
                            },
                          )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFF682AA)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: Color(0xFFCF4374),
                        width: 2,
                      ),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  onSubmitted: (value) => _searchUsers(),
                ),
                const SizedBox(height: 12),
                // Filter Chips
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      FilterChip(
                        label: const Text('All Users'),
                        selected:
                            _selectedRole == null &&
                            _selectedVerificationStatus == null,
                        onSelected: (selected) {
                          if (selected) {
                            setState(() {
                              _selectedRole = null;
                              _selectedVerificationStatus = null;
                              _currentPage = 1;
                            });
                            _loadUsers();
                          }
                        },
                        selectedColor: const Color(0xFFCF4374),
                        labelStyle: TextStyle(
                          color:
                              _selectedRole == null &&
                                  _selectedVerificationStatus == null
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: const Text('Commuters'),
                        selected: _selectedRole == 'commuter',
                        onSelected: (selected) {
                          setState(() {
                            _selectedRole = selected ? 'commuter' : null;
                            _currentPage = 1;
                          });
                          _loadUsers();
                        },
                        selectedColor: const Color(0xFFCF4374),
                        labelStyle: TextStyle(
                          color: _selectedRole == 'commuter'
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: const Text('Drivers'),
                        selected: _selectedRole == 'driver',
                        onSelected: (selected) {
                          setState(() {
                            _selectedRole = selected ? 'driver' : null;
                            _currentPage = 1;
                          });
                          _loadUsers();
                        },
                        selectedColor: const Color(0xFFCF4374),
                        labelStyle: TextStyle(
                          color: _selectedRole == 'driver'
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: const Text('Verified'),
                        selected: _selectedVerificationStatus == true,
                        onSelected: (selected) {
                          setState(() {
                            _selectedVerificationStatus = selected
                                ? true
                                : null;
                            _currentPage = 1;
                          });
                          _loadUsers();
                        },
                        selectedColor: const Color(0xFFCF4374),
                        labelStyle: TextStyle(
                          color: _selectedVerificationStatus == true
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilterChip(
                        label: const Text('Unverified'),
                        selected: _selectedVerificationStatus == false,
                        onSelected: (selected) {
                          setState(() {
                            _selectedVerificationStatus = selected
                                ? false
                                : null;
                            _currentPage = 1;
                          });
                          _loadUsers();
                        },
                        selectedColor: const Color(0xFFCF4374),
                        labelStyle: TextStyle(
                          color: _selectedVerificationStatus == false
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Users List
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFCF4374),
                      strokeWidth: 3,
                    ),
                  )
                : _users.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.people_outline,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No users found',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _users.length,
                    itemBuilder: (context, index) {
                      final user = _users[index];
                      return _buildUserCard(user);
                    },
                  ),
          ),

          // Pagination
          if (_totalPages > 1)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.chevron_left),
                    onPressed: _currentPage > 1
                        ? () {
                            setState(() {
                              _currentPage--;
                            });
                            _searchQuery.isEmpty
                                ? _loadUsers()
                                : _searchUsers();
                          }
                        : null,
                  ),
                  Text(
                    'Page $_currentPage of $_totalPages',
                    style: GoogleFonts.poppins(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.chevron_right),
                    onPressed: _currentPage < _totalPages
                        ? () {
                            setState(() {
                              _currentPage++;
                            });
                            _searchQuery.isEmpty
                                ? _loadUsers()
                                : _searchUsers();
                          }
                        : null,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildUserCard(Map<String, dynamic> user) {
    final isActive = user['isActive'] ?? true;
    final isSuspended = user['isSuspended'] ?? false;
    final isVerified = user['isVerified'] ?? false;
    final role = user['role'] ?? 'commuter';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: _getRoleColor(role),
          child: Text(
            user['name']?.substring(0, 1).toUpperCase() ?? '?',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          user['name'] ?? 'Unknown',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              user['email'] ?? 'No email',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 4),
            Wrap(
              spacing: 4,
              children: [
                _buildStatusChip(role.toUpperCase(), _getRoleColor(role)),
                if (isVerified) _buildStatusChip('VERIFIED', Colors.green),
                if (!isActive) _buildStatusChip('DEACTIVATED', Colors.orange),
                if (isSuspended) _buildStatusChip('SUSPENDED', Colors.red),
              ],
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                        text: 'View Details',
                        onPressed: () => _viewUserDetails(user['userId']),
                        isPrimary: false,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    if (!isVerified)
                      _buildActionButton(
                        'Verify',
                        Icons.verified,
                        Colors.green,
                        () => _showActionDialog(
                          title: 'Verify User',
                          userId: user['userId'],
                          action: 'verify',
                        ),
                      ),
                    if (!isActive)
                      _buildActionButton(
                        'Activate',
                        Icons.check_circle,
                        Colors.green,
                        () => _showActionDialog(
                          title: 'Activate User',
                          userId: user['userId'],
                          action: 'activate',
                        ),
                      ),
                    if (isActive && !isSuspended)
                      _buildActionButton(
                        'Deactivate',
                        Icons.block,
                        Colors.orange,
                        () => _showActionDialog(
                          title: 'Deactivate User',
                          userId: user['userId'],
                          action: 'deactivate',
                          requiresReason: true,
                        ),
                      ),
                    if (!isSuspended && role != 'admin')
                      _buildActionButton(
                        'Suspend',
                        Icons.cancel,
                        Colors.red,
                        () => _showActionDialog(
                          title: 'Suspend User',
                          userId: user['userId'],
                          action: 'suspend',
                          requiresReason: true,
                        ),
                      ),
                    if (isSuspended)
                      _buildActionButton(
                        'Unsuspend',
                        Icons.check,
                        Colors.green,
                        () => _showActionDialog(
                          title: 'Unsuspend User',
                          userId: user['userId'],
                          action: 'unsuspend',
                        ),
                      ),
                    _buildActionButton(
                      'Change Role',
                      Icons.people,
                      Colors.blue,
                      () => _showActionDialog(
                        title: 'Update User Role',
                        userId: user['userId'],
                        action: 'update_role',
                      ),
                    ),
                    if (role != 'admin')
                      _buildActionButton(
                        'Delete',
                        Icons.delete,
                        Colors.red[900]!,
                        () => _showActionDialog(
                          title: 'Delete User',
                          userId: user['userId'],
                          action: 'delete',
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: 1),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildActionButton(
    String label,
    IconData icon,
    Color color,
    VoidCallback onPressed,
  ) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role) {
      case 'admin':
        return Colors.purple;
      case 'driver':
        return Colors.blue;
      case 'commuter':
      default:
        return const Color(0xFFCF4374);
    }
  }
}
