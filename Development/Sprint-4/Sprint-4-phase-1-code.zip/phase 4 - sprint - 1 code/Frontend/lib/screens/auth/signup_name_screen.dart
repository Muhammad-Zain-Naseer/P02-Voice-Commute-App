import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import 'signup_trusted_email_screen.dart';

class SignupNameScreen extends StatefulWidget {
  final String email;
  final String pin;
  
  const SignupNameScreen({
    super.key,
    required this.email,
    required this.pin,
  });

  @override
  State<SignupNameScreen> createState() => _SignupNameScreenState();
}

class _SignupNameScreenState extends State<SignupNameScreen> {
  final TextEditingController _nameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _continue() {
    if (_formKey.currentState!.validate()) {
      // Navigate to trusted contact email screen
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SignupTrustedEmailScreen(
            email: widget.email,
            pin: widget.pin,
            name: _nameController.text.trim(),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height - 
                    MediaQuery.of(context).padding.top - 
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
                  child: Column(
                    children: [
                      // Top section - Back button and logo
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(
                              Icons.arrow_back_ios,
                              color: Color(0xFFCF4374),
                              size: 24,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                          SvgPicture.asset(
                            'assets/icons/car_icon.svg',
                            width: 70,
                            height: 70,
                          ),
                          const SizedBox(width: 48),
                        ],
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // Sound Wave
                      const SoundWave(),
                      
                      const SizedBox(height: 40),
                      
                      // Title - Two lines
                      const Text(
                        'اپنا نام درج کریں',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                          height: 1.3,
                        ),
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // Name Input Field
                      Form(
                        key: _formKey,
                        child: TextFormField(
                          controller: _nameController,
                          textDirection: TextDirection.rtl,
                          keyboardType: TextInputType.name,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Color(0xFFCF4374),
                          ),
                          decoration: InputDecoration(
                            hintText: '(مثلاً فاطمہ احمد)',
                            hintStyle: TextStyle(
                              color: const Color(0xFFCF4374).withOpacity(0.4),
                              fontSize: 14,
                            ),
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.8),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFF682AA),
                                width: 1.5,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFF682AA),
                                width: 1.5,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFCF4374),
                                width: 2,
                              ),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Colors.red,
                                width: 1.5,
                              ),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Colors.red,
                                width: 2,
                              ),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 18,
                            ),
                            errorStyle: const TextStyle(height: 0),
                          ),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return '';
                            }
                            if (value.trim().length < 2) {
                              return '';
                            }
                            return null;
                          },
                        ),
                      ),
                      
                      const Spacer(),
                      
                      // Bottom Section - Mic and Next Button
                      Column(
                        children: [
                          // Microphone Button
                          GestureDetector(
                            onTap: () {
                              print('Voice input activated');
                            },
                            child: Container(
                              width: 120,
                              height: 120,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.4),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFCF4374).withOpacity(0.2),
                                    blurRadius: 20,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Container(
                                  width: 95,
                                  height: 95,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color(0xFFF48FB1),
                                        Color(0xFFCF4374),
                                      ],
                                    ),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.mic,
                                    color: Colors.white,
                                    size: 50,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'بولائیں کے لیے دبائیں',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                          const SizedBox(height: 30),
                          
                          // Next/Continue Button
                          GestureDetector(
                            onTap: _continue,
                            child: Container(
                              width: 200,
                              height: 56,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFFCF4374),
                                    Color(0xFF69223B),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFCF4374).withOpacity(0.3),
                                    blurRadius: 10,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Text(
                                    'اگلا',
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Icon(
                                    Icons.arrow_forward,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 25),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}