import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import '../../../widgets/sound_wave.dart';
import '../../../services/driver_auth_service.dart';
import 'driver_signup_pin_screen.dart';

// formatter to automatically convert text to uppercase
class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    return TextEditingValue(
      text: newValue.text.toUpperCase(),
      selection: newValue.selection,
    );
  }
}

class DriverSignupVehicleScreen extends StatefulWidget {
  final String email;
  final String token;

  const DriverSignupVehicleScreen({
    super.key,
    required this.email,
    required this.token,
  });

  @override
  State<DriverSignupVehicleScreen> createState() => _DriverSignupVehicleScreenState();
}

class _DriverSignupVehicleScreenState extends State<DriverSignupVehicleScreen> {
  final TextEditingController _registrationController = TextEditingController();
  final TextEditingController _modelController = TextEditingController();
  final TextEditingController _yearController = TextEditingController();
  final TextEditingController _colorController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  XFile? _registrationPhoto;
  final ImagePicker _picker = ImagePicker();

  @override
  void dispose() {
    _registrationController.dispose();
    _modelController.dispose();
    _yearController.dispose();
    _colorController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1800,
        maxHeight: 1800,
        imageQuality: 85,
      );
      
      if (image != null) {
        setState(() {
          _registrationPhoto = image;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تصویر منتخب کرنے میں خرابی'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _continue() async {
    if (_formKey.currentState!.validate()) {
      if (_registrationPhoto == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('براہ کرم گاڑی کی رجسٹریشن دستاویز منتخب کریں'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      setState(() {
        _isLoading = true;
      });

      try {
        // Call API to submit vehicle registration
        final result = await DriverAuthService.submitVehicleRegistration(
          registrationNumber: _registrationController.text.trim(),
          model: _modelController.text.trim(),
          year: _yearController.text.trim(),
          color: _colorController.text.trim(),
          registrationPhoto: _registrationPhoto!,
          token: widget.token,
        );

        if (!mounted) return;

        if (result['success']) {
          final newToken = result['token'];
          
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DriverSignupPinScreen(
                email: widget.email,
                token: newToken,
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result['message'] ?? 'Failed to save vehicle info'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, right: 4),
      child: Text(
        text,
        textDirection: TextDirection.rtl,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Color(0xFFCF4374),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    required String? Function(String?) validator,
    TextDirection textDirection = TextDirection.rtl,
    TextInputType keyboardType = TextInputType.text,
    TextCapitalization textCapitalization = TextCapitalization.none,
    bool autoCapitalize = false,
  }) {
    return TextFormField(
      controller: controller,
      textDirection: textDirection,
      textAlign: TextAlign.center,
      textCapitalization: textCapitalization,
      keyboardType: keyboardType,
      enabled: !_isLoading,
      inputFormatters: autoCapitalize ? [UpperCaseTextFormatter()] : null,
      style: const TextStyle(
        fontSize: 16,
        color: Color(0xFFCF4374),
      ),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: const Color(0xFFCF4374).withOpacity(0.4),
          fontSize: 14,
        ),
        filled: true,
        fillColor: Colors.white.withOpacity(0.8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: Color(0xFFF682AA),
            width: 1.5,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: Color(0xFFF682AA),
            width: 1.5,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: Color(0xFFCF4374),
            width: 2,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: Colors.red,
            width: 1.5,
          ),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(
            color: Colors.red,
            width: 2,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 16,
        ),
        errorStyle: const TextStyle(fontSize: 11),
      ),
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // Header
                  SizedBox(
                    height: 70,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(width: 48),
                        SvgPicture.asset(
                          'assets/icons/car_icon.svg',
                          width: 70,
                          height: 70,
                        ),
                        SizedBox(
                          width: 48,
                          child: IconButton(
                            icon: const Icon(
                              Icons.arrow_forward_ios,
                              color: Color(0xFFCF4374),
                              size: 24,
                            ),
                            onPressed: () => Navigator.pop(context),
                            padding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 20),
                  
                  const SoundWave(),
                  
                  const SizedBox(height: 30),
                  
                  const Text(
                    'گاڑی کی تفصیلات',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  
                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Registration Number
                        _buildLabel('رجسٹریشن نمبر'),
                        _buildTextField(
                          controller: _registrationController,
                          hintText: 'ABC-123',
                          textDirection: TextDirection.ltr,
                          textCapitalization: TextCapitalization.characters,
                          autoCapitalize: true,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'رجسٹریشن نمبر درج کریں';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Model
                        _buildLabel('گاڑی کا ماڈل'),
                        _buildTextField(
                          controller: _modelController,
                          hintText: 'HONDA CIVIC',
                          autoCapitalize: true,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'ماڈل درج کریں';
                            }
                            return null;
                          },
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Year and Color in one row
                        Row(
                          children: [
                            // Color
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  _buildLabel('رنگ'),
                                  _buildTextField(
                                    controller: _colorController,
                                    hintText: 'سفید',
                                    autoCapitalize: true,
                                    validator: (value) {
                                      if (value == null || value.trim().isEmpty) {
                                        return 'رنگ درج کریں';
                                      }
                                      return null;
                                    },
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            // Year
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  _buildLabel('سال'),
                                  _buildTextField(
                                    controller: _yearController,
                                    hintText: '2020',
                                    textDirection: TextDirection.ltr,
                                    keyboardType: TextInputType.number,
                                    validator: (value) {
                                      if (value == null || value.trim().isEmpty) {
                                        return 'سال درج کریں';
                                      }
                                      final year = int.tryParse(value.trim());
                                      if (year == null || year < 1990 || year > DateTime.now().year + 1) {
                                        return 'درست سال درج کریں';
                                      }
                                      return null;
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Image Picker with label
                        _buildLabel('گاڑی کی رجسٹریشن دستاویز'),
                        GestureDetector(
                          onTap: _isLoading ? null : _pickImage,
                          child: Container(
                            width: double.infinity,
                            height: 160,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.8),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFF682AA),
                                width: 1.5,
                              ),
                            ),
                            child: _registrationPhoto == null
                                ? Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.description_outlined,
                                        size: 45,
                                        color: const Color(0xFFCF4374).withOpacity(0.6),
                                      ),
                                      const SizedBox(height: 12),
                                      const Text(
                                        'رجسٹریشن دستاویز کی تصویر',
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          color: Color(0xFFCF4374),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'یہاں ٹیپ کر کے منتخب کریں',
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: const Color(0xFFCF4374).withOpacity(0.7),
                                        ),
                                      ),
                                    ],
                                  )
                                : Stack(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: Container(
                                          width: double.infinity,
                                          height: 160,
                                          padding: const EdgeInsets.all(8),
                                          child: kIsWeb
                                              ? Image.network(
                                                  _registrationPhoto!.path,
                                                  fit: BoxFit.contain, 
                                                  errorBuilder: (context, error, stackTrace) {
                                                    return const Center(
                                                      child: Icon(
                                                        Icons.error,
                                                        color: Colors.red,
                                                        size: 40,
                                                      ),
                                                    );
                                                  },
                                                )
                                              : Image.file(
                                                  File(_registrationPhoto!.path),
                                                  fit: BoxFit.contain, 
                                                ),
                                        ),
                                      ),
                                      // Remove button (X)
                                      Positioned(
                                        top: 8,
                                        right: 8,
                                        child: GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              _registrationPhoto = null;
                                            });
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.all(6),
                                            decoration: BoxDecoration(
                                              color: Colors.red.withOpacity(0.9),
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black.withOpacity(0.2),
                                                  blurRadius: 4,
                                                  spreadRadius: 1,
                                                ),
                                              ],
                                            ),
                                            child: const Icon(
                                              Icons.close,
                                              color: Colors.white,
                                              size: 20,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                  
                  GestureDetector(
                    onTap: _isLoading ? null : _continue,
                    child: Container(
                      width: 200,
                      height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFFCF4374),
                            Color(0xFF69223B),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFCF4374).withOpacity(0.3),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (_isLoading)
                            const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          else ...[
                            const Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                              size: 24,
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'اگلا',
                              textDirection: TextDirection.rtl,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 25),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}