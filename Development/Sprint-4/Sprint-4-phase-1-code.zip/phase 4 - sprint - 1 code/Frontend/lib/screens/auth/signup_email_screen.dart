import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../../widgets/sound_wave.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import 'signup_pin_screen.dart';
import '../../utils/web_speech_stub.dart'
    if (dart.library.html) '../../utils/web_speech.dart';

class SignupEmailScreen extends StatefulWidget {
  const SignupEmailScreen({super.key});

  @override
  State<SignupEmailScreen> createState() => _SignupEmailScreenState();
}

class _SignupEmailScreenState extends State<SignupEmailScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;
  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _setupAudio(); // works on both platforms (web audio unlocked by welcome screen tap)
  }

  void _startPulse() => _pulseController.repeat(reverse: true);
  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    _speechCancelled = false;
    await _speakPrompt();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && mounted) {
        await _speakPrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled) return;
    _cancelReplayTimer();
    if (mounted) setState(() => _isSpeaking = true);
    final bytes = await VoiceService.textToSpeech('اپنا ای میل درج کریں');
    if (bytes != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes);
    if (_speechCancelled) { if (mounted) setState(() => _isSpeaking = false); return; }
    await Future.delayed(const Duration(milliseconds: 200));
    final bytes2 = await VoiceService.textToSpeech('بولنے کے لیے مائیکروفون دبائیں');
    if (bytes2 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes2);
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted && !_speechCancelled) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      await _speakPrompt();
    }
  }

  Future<void> _toggleListening() async {
    if (_isInterpreting) return;
    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      if (kIsWeb) {
        _stopWebSpeech();
      } else {
        await _stopRecordingAndProcess();
      }
      return;
    }
    if (kIsWeb) {
      _startWebSpeech();
    } else {
      await _startRecording();
    }
  }

  void _startWebSpeech() {
    _cancelReplayTimer();
    AudioPlayerService.stop();

    startWebSpeech(onResult: (t) {}, onError: () {});

    setState(() => _isListening = true);
    _startPulse();

    Timer.periodic(const Duration(milliseconds: 300), (t) {
      if (!mounted) { t.cancel(); return; }
      final transcript = getWebTranscript();
      if (transcript != null) {
        t.cancel();
        _stopPulse();
        setState(() { _isListening = false; _isInterpreting = true; });
        if (transcript.trim().isNotEmpty) {
          VoiceService.extractEmail(transcript.trim()).then((email) {
            if (!mounted) return;
            setState(() {
              _emailController.text = (email != null && email.isNotEmpty)
                  ? email
                  : transcript.trim();
              _isInterpreting = false;
            });
            _startReplayTimer();
          });
        } else {
          setState(() => _isInterpreting = false);
          _startReplayTimer();
        }
      }
    });

    // No auto-stop — user taps mic again to stop (web speech ends naturally on silence)
  }

  void _stopWebSpeech() {
    stopWebSpeech();
    _stopPulse();
    setState(() => _isListening = false);
    _startReplayTimer();
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/hersafar_email_voice.wav';
      final old = File(path);
      if (await old.exists()) await old.delete();

      await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      if (!await _recorder.isRecording()) {
        _startReplayTimer();
        return;
      }

      setState(() => _isListening = true);
      _startPulse();

      _amplitudeTimer =
          Timer.periodic(const Duration(milliseconds: 500), (t) {
        if (!_isListening) t.cancel();
      });

      // No auto-stop — user taps mic again to stop
    } catch (e) {
      print('=== Email recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      if (path == null) { _startReplayTimer(); return; }

      setState(() => _isInterpreting = true);

      final file = File(path);
      if (!await file.exists() || (await file.length()) == 0) {
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      final bytes = await file.readAsBytes();
      final transcript = await VoiceService.speechToText(base64Encode(bytes));
      print('=== Email STT transcript: $transcript');

      if (transcript != null && transcript.trim().isNotEmpty) {
        // Use Gemini to convert Urdu phonetic spelling to actual email
        final email = await VoiceService.extractEmail(transcript.trim());
        print('=== Email extracted: $email');
        if (email != null && email.isNotEmpty) {
          setState(() => _emailController.text = email);
        } else {
          // Fallback: show raw transcript so user can manually correct
          setState(() => _emailController.text = transcript.trim());
        }
      }
    } catch (e) {
      print('=== Email STT error: $e');
    } finally {
      if (mounted) setState(() => _isInterpreting = false);
      _startReplayTimer();
    }
  }

  void _continue() {
    if (_formKey.currentState!.validate()) {
      _speechCancelled = true;
      _cancelReplayTimer();
      AudioPlayerService.stop();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              SignupPinScreen(email: _emailController.text.trim()),
        ),
      );
    }
  }

  @override
  void dispose() {
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _emailController.dispose();
    if (!kIsWeb) _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                // Top row — back, logo, mute
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios,
                          color: Color(0xFFCF4374), size: 24),
                      onPressed: () {
                        _speechCancelled = true;
                        _cancelReplayTimer();
                        AudioPlayerService.stop();
                        Navigator.pop(context);
                      },
                    ),
                    SvgPicture.asset('assets/icons/car_icon.svg',
                        width: 70, height: 70),
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isMuted
                              ? Icons.volume_off_rounded
                              : Icons.volume_up_rounded,
                          color: const Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                SoundWave(isAnimating: _isSpeaking || _isListening),

                const SizedBox(height: 40),

                const Text(
                  'اپنا ای میل درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 30),

                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _emailController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.emailAddress,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 16, color: Color(0xFFCF4374)),
                    decoration: InputDecoration(
                      hintText: 'example@email.com',
                      hintStyle: TextStyle(
                          color: const Color(0xFFCF4374).withOpacity(0.4),
                          fontSize: 16),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFF682AA), width: 1.5),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFF682AA), width: 1.5),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFCF4374), width: 2),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Colors.red, width: 1.5),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 2),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 18),
                      errorStyle: const TextStyle(height: 0),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) return '';
                      final emailRegex =
                          RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');
                      if (!emailRegex.hasMatch(value.trim())) return '';
                      return null;
                    },
                  ),
                ),

                const Spacer(),

                Column(
                  children: [
                    GestureDetector(
                      onTap: _isInterpreting ? null : _toggleListening,
                      child: AnimatedBuilder(
                        animation: _pulseAnimation,
                        builder: (context, child) {
                          return Stack(
                            alignment: Alignment.center,
                            children: [
                              if (_isListening)
                                Transform.scale(
                                  scale: _pulseAnimation.value,
                                  child: Container(
                                    width: 120,
                                    height: 120,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: const Color(0xFFCF4374).withOpacity(0.25),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                ),
                              Container(
                                width: 104,
                                height: 104,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: (_isListening || _isInterpreting)
                                      ? const Color(0xFFCF4374).withOpacity(0.12)
                                      : Colors.white.withOpacity(0.35),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFFCF4374)
                                          .withOpacity(_isListening ? 0.4 : 0.15),
                                      blurRadius: _isListening ? 28 : 12,
                                      spreadRadius: _isListening ? 6 : 2,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 84,
                                height: 84,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: _isListening
                                        ? [const Color(0xFFE91E8C), const Color(0xFF9C0055)]
                                        : _isInterpreting
                                            ? [const Color(0xFFCF4374), const Color(0xFF8B1A4A)]
                                            : [const Color(0xFFF06292), const Color(0xFFCF4374)],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFFCF4374).withOpacity(0.5),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: _isInterpreting
                                    ? const Center(
                                        child: SizedBox(
                                          width: 32,
                                          height: 32,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2.5,
                                          ),
                                        ),
                                      )
                                    : Center(
                                        child: Icon(
                                          _isListening
                                              ? Icons.mic_rounded
                                              : Icons.mic_none_rounded,
                                          color: Colors.white,
                                          size: 38,
                                        ),
                                      ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Text(
                        _isInterpreting
                            ? 'سمجھ رہی ہوں...'
                            : _isListening
                                ? 'سن رہی ہوں...'
                                : 'بولنے کے لیے دبائیں',
                        key: ValueKey('$_isListening$_isInterpreting'),
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 14,
                          color: (_isListening || _isInterpreting)
                              ? const Color(0xFF8B1A4A)
                              : const Color(0xFFCF4374),
                          fontWeight: (_isListening || _isInterpreting)
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    GestureDetector(
                      onTap: _continue,
                      child: Container(
                        width: 200,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFFCF4374),
                              Color(0xFF69223B),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color:
                                  const Color(0xFFCF4374).withOpacity(0.3),
                              blurRadius: 10,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text(
                              'اگلا',
                              textDirection: TextDirection.rtl,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(width: 8),
                            Icon(Icons.arrow_forward,
                                color: Colors.white, size: 24),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
