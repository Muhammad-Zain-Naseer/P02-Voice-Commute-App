import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../../widgets/sound_wave.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import 'signup_name_screen.dart';
import '../../utils/web_speech_stub.dart'
    if (dart.library.html) '../../utils/web_speech.dart';

class SignupPinScreen extends StatefulWidget {
  final String email;

  const SignupPinScreen({
    super.key,
    required this.email,
  });

  @override
  State<SignupPinScreen> createState() => _SignupPinScreenState();
}

class _SignupPinScreenState extends State<SignupPinScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;

  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _setupAudio();
  }

  void _startPulse() => _pulseController.repeat(reverse: true);
  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    _speechCancelled = false;
    await _speakPrompt();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && mounted) {
        await _speakPrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled) return;
    _cancelReplayTimer();
    if (mounted) setState(() => _isSpeaking = true);
    final bytes1 = await VoiceService.textToSpeech('چار ہندسوں کا پن بنائیں');
    if (bytes1 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes1);
    if (_speechCancelled) { if (mounted) setState(() => _isSpeaking = false); return; }
    await Future.delayed(const Duration(milliseconds: 200));
    final bytes2 = await VoiceService.textToSpeech('بولنے کے لیے مائیکروفون دبائیں');
    if (bytes2 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes2);
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted && !_speechCancelled) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _toggleListening() async {
    if (_isInterpreting) return;
    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      if (kIsWeb) {
        _stopWebSpeech();
      } else {
        await _stopRecordingAndProcess();
      }
      return;
    }
    if (kIsWeb) {
      _startWebSpeech();
    } else {
      await _startRecording();
    }
  }

  void _startWebSpeech() {
    _cancelReplayTimer();
    AudioPlayerService.stop();
    startWebSpeech(onResult: (t) {}, onError: () {});
    setState(() => _isListening = true);
    _startPulse();

    Timer.periodic(const Duration(milliseconds: 300), (t) {
      if (!mounted) { t.cancel(); return; }
      final transcript = getWebTranscript();
      if (transcript != null) {
        t.cancel();
        _stopPulse();
        setState(() => _isListening = false);
        if (transcript.trim().isNotEmpty) {
          final pin = _extractPin(transcript.trim());
          if (pin != null) setState(() => _pinController.text = pin);
        }
        _startReplayTimer();
      }
    });
  }

  void _stopWebSpeech() {
    stopWebSpeech();
    _stopPulse();
    setState(() => _isListening = false);
    _startReplayTimer();
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/hersafar_signup_pin_voice.wav';
      final old = File(path);
      if (await old.exists()) await old.delete();

      await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      if (!await _recorder.isRecording()) {
        _startReplayTimer();
        return;
      }

      setState(() => _isListening = true);
      _startPulse();

      _amplitudeTimer = Timer.periodic(const Duration(milliseconds: 500), (t) {
        if (!_isListening) t.cancel();
      });
    } catch (e) {
      print('=== Signup PIN recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      if (path == null) { _startReplayTimer(); return; }

      setState(() => _isInterpreting = true);

      final file = File(path);
      if (!await file.exists() || (await file.length()) == 0) {
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      final bytes = await file.readAsBytes();
      final transcript = await VoiceService.speechToText(base64Encode(bytes));

      if (transcript != null && transcript.trim().isNotEmpty) {
        final pin = _extractPin(transcript.trim());
        if (pin != null && mounted) setState(() => _pinController.text = pin);
      }
    } catch (e) {
      print('=== Signup PIN STT error: $e');
    } finally {
      if (mounted) setState(() => _isInterpreting = false);
      _startReplayTimer();
    }
  }

  /// Converts spoken Urdu/English digit words to a 4-digit PIN string.
  String? _extractPin(String transcript) {
    // Try direct 4-digit sequence first
    final directMatch = RegExp(r'\d{4}').firstMatch(transcript);
    if (directMatch != null) return directMatch.group(0);

    final wordMap = {
      'صفر': '0', 'zero': '0',
      'ایک': '1', 'ون': '1', 'one': '1', '۱': '1',
      'دو': '2', 'ٹو': '2', 'two': '2', '۲': '2',
      'تین': '3', 'تھری': '3', 'three': '3', '۳': '3',
      'چار': '4', 'فور': '4', 'four': '4', '۴': '4',
      'پانچ': '5', 'فائیو': '5', 'five': '5', '۵': '5',
      'چھ': '6', 'چھے': '6', 'سکس': '6', 'six': '6', '۶': '6',
      'سات': '7', 'سیون': '7', 'seven': '7', '۷': '7',
      'آٹھ': '8', 'ایٹ': '8', 'eight': '8', '۸': '8',
      'نو': '9', 'نائن': '9', 'nine': '9', '۹': '9',
    };

    String result = transcript;
    wordMap.forEach((word, digit) {
      result = result.replaceAll(word, digit);
    });

    final digits = result.replaceAll(RegExp(r'[^\d]'), '');
    return digits.length == 4 ? digits : null;
  }

  void _continue() {
    if (_formKey.currentState!.validate()) {
      _speechCancelled = true;
      _cancelReplayTimer();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SignupNameScreen(
            email: widget.email,
            pin: _pinController.text,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _speechCancelled = true;
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _recorder.dispose();
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                // Back button, logo, mute button
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                      ),
                      onPressed: () {
                        _speechCancelled = true;
                        _cancelReplayTimer();
                        Navigator.pop(context);
                      },
                    ),
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 60,
                      height: 60,
                    ),
                    IconButton(
                      icon: Icon(
                        _isMuted ? Icons.volume_off : Icons.volume_up,
                        color: const Color(0xFFCF4374),
                      ),
                      onPressed: _toggleMute,
                    ),
                  ],
                ),

                const SizedBox(height: 40),

                // Sound Wave
                SoundWave(isAnimating: _isSpeaking || _isListening),

                const SizedBox(height: 40),

                // Title
                const Text(
                  '4 ہندسوں کا PIN بنائیں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 40),

                // PIN Input Field
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _pinController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    obscureText: true,
                    maxLength: 4,
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                      letterSpacing: 20,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    decoration: InputDecoration(
                      hintText: '••••',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withOpacity(0.3),
                        fontSize: 32,
                        letterSpacing: 20,
                      ),
                      counterText: '',
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.7),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFCF4374),
                          width: 2,
                        ),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 1.5,
                        ),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 2,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 16,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'برائے مہربانی PIN درج کریں';
                      }
                      if (value.length != 4) {
                        return 'PIN 4 ہندسوں کا ہونا ضروری ہے';
                      }
                      return null;
                    },
                  ),
                ),

                const SizedBox(height: 16),

                // Hint text
                Text(
                  'یہ PIN آپ کے اکاؤنٹ کو محفوظ رکھنے کے لیے استعمال ہوگا',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: const Color(0xFFCF4374).withOpacity(0.7),
                  ),
                ),

                const Spacer(),

                // Microphone Button
                GestureDetector(
                  onTap: _toggleListening,
                  child: AnimatedBuilder(
                    animation: _pulseAnimation,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _isListening ? _pulseAnimation.value : 1.0,
                        child: child,
                      );
                    },
                    child: Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        color: _isListening
                            ? const Color(0xFFCF4374).withOpacity(0.15)
                            : Colors.white.withOpacity(0.4),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFCF4374).withOpacity(
                                _isListening ? 0.4 : 0.2),
                            blurRadius: _isListening ? 20 : 15,
                            spreadRadius: _isListening ? 5 : 3,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: _isListening
                                  ? [
                                      const Color(0xFFCF4374),
                                      const Color(0xFF9C1D4E),
                                    ]
                                  : [
                                      const Color(0xFFF48FB1),
                                      const Color(0xFFCF4374),
                                    ],
                            ),
                            shape: BoxShape.circle,
                          ),
                          child: _isInterpreting
                              ? const Padding(
                                  padding: EdgeInsets.all(20),
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2.5,
                                  ),
                                )
                              : Icon(
                                  _isListening ? Icons.stop : Icons.mic,
                                  color: Colors.white,
                                  size: 36,
                                ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  _isListening
                      ? 'سن رہا ہے...'
                      : _isInterpreting
                          ? 'سمجھ رہا ہے...'
                          : 'بولنے کے لیے دبائیں',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 30),

                // Continue Button
                GestureDetector(
                  onTap: _continue,
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: const Color(0xFFCF4374),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withOpacity(0.3),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.arrow_forward_ios,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
