import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import '../../widgets/custom_button.dart';
import '../../services/auth_service.dart';
import 'signup_success_screen.dart';

class SignupTrustedNameScreen extends StatefulWidget {
  final String email;
  final String pin;
  final String name;
  final String trustedContactEmail;
  
  const SignupTrustedNameScreen({
    super.key,
    required this.email,
    required this.pin,
    required this.name,
    required this.trustedContactEmail,
  });

  @override
  State<SignupTrustedNameScreen> createState() => _SignupTrustedNameScreenState();
}

class _SignupTrustedNameScreenState extends State<SignupTrustedNameScreen> {
  final TextEditingController _trustedNameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _trustedNameController.dispose();
    super.dispose();
  }

  Future<void> _signup() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        final authService = AuthService();
        final result = await authService.signup(
          name: widget.name,
          email: widget.email,
          pin: widget.pin,
          trustedContactEmail: widget.trustedContactEmail.isNotEmpty 
              ? widget.trustedContactEmail 
              : null,
          trustedContactName: _trustedNameController.text.trim().isNotEmpty 
              ? _trustedNameController.text.trim() 
              : null,
        );

        setState(() {
          _isLoading = false;
        });

        if (result['success']) {
          // Navigate to success screen
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SignupSuccessScreen(
                  email: widget.email,
                  name: widget.name,
                ),
              ),
            );
          }
        } else {
          // Show error message
          if (mounted) {
            // Check if user already exists
            if (result['message']?.toLowerCase().contains('already exists') == true ||
                result['message']?.toLowerCase().contains('موجود') == true) {
              _showUserExistsDialog();
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    result['message'] ?? 'اکاؤنٹ بنانے میں خرابی',
                    textDirection: TextDirection.rtl,
                  ),
                  backgroundColor: Colors.red,
                ),
              );
            }
          }
        }
      } catch (e) {
        setState(() {
          _isLoading = false;
        });
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'کوئی خرابی پیش آگئی: $e',
                textDirection: TextDirection.rtl,
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  Future<void> _skip() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final authService = AuthService();
      final result = await authService.signup(
        name: widget.name,
        email: widget.email,
        pin: widget.pin,
        trustedContactEmail: widget.trustedContactEmail.isNotEmpty 
            ? widget.trustedContactEmail 
            : null,
        trustedContactName: null,
      );

      setState(() {
        _isLoading = false;
      });

      if (result['success']) {
        // Navigate to success screen
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => SignupSuccessScreen(
                email: widget.email,
                name: widget.name,
              ),
            ),
          );
        }
      } else {
        // Show error message
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                result['message'] ?? 'اکاؤنٹ بنانے میں خرابی',
                textDirection: TextDirection.rtl,
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'کوئی خرابی پیش آگئی: $e',
              textDirection: TextDirection.rtl,
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showUserExistsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFFFAECF1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.error_outline,
                  color: Color(0xFFCF4374),
                  size: 50,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'یہ ای میل پہلے سے رجسٹرڈ ہے',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Go back to home/welcome screen
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  'واپس ہوم اسکرین',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                // Top section - Back button and logo
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 70,
                      height: 70,
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                
                const SizedBox(height: 30),
                
                // Sound Wave
                const SoundWave(),
                
                const SizedBox(height: 40),
                
                // Title
                const Text(
                  'قابل اعتماد رابطے کا نام',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                
                const SizedBox(height: 12),
                
                // Description
                Text(
                  '(اختیاری)',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 16,
                    color: const Color(0xFFCF4374).withOpacity(0.6),
                  ),
                ),
                
                const SizedBox(height: 30),
                
                // Trusted Contact Name Input Field
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _trustedNameController,
                    textDirection: TextDirection.rtl,
                    keyboardType: TextInputType.name,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Color(0xFFCF4374),
                    ),
                    decoration: InputDecoration(
                      hintText: 'رابطے کا نام',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withOpacity(0.4),
                        fontSize: 16,
                      ),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFCF4374),
                          width: 2,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 18,
                      ),
                    ),
                  ),
                ),
                
                const Spacer(),
                
                // Bottom Section - Buttons
                Column(
                  children: [
                    // Signup Button
                    _isLoading
                        ? const CircularProgressIndicator(
                            color: Color(0xFFCF4374),
                          )
                        : CustomButton(
                            text: 'سائن اپ کریں',
                            onPressed: _signup,
                            height: 56,
                            isPrimary: false,
                            backgroundColor: const Color(0xFFCF4374),
                            textColor: Colors.white,
                            fontSize: 20,
                            isGradient: true,
                          ),
                    const SizedBox(height: 16),
                    
                  ],
                ),
                
                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}