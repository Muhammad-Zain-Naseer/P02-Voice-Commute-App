import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/ride_request.dart';
import '../../models/driver_payment_details.dart';
import '../../services/payment_service.dart';
import '../../utils/logger.dart';

/// Payment Page - Shows payment details and allows submission
class PaymentPage extends StatefulWidget {
  final RideRequest ride;
  final String userId;
  final String driverId;
  final double amount;
  final DriverPaymentDetails driverPaymentDetails;
  final double? baseFare;
  final bool discountApplied;
  final double discountPercentage;
  final double discountAmount;

  const PaymentPage({
    super.key,
    required this.ride,
    required this.userId,
    required this.driverId,
    required this.amount,
    required this.driverPaymentDetails,
    this.baseFare,
    this.discountApplied = false,
    this.discountPercentage = 0,
    this.discountAmount = 0,
  });

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  final TextEditingController _transactionIdController =
      TextEditingController();
  final _formKey = GlobalKey<FormState>();

  String _selectedPaymentMethod = 'cash'; // Default to cash
  bool _isSubmitting = false;

  // Coupon state
  final TextEditingController _couponController = TextEditingController();
  bool _isValidatingCoupon = false;
  String? _appliedCouponCode;
  double _couponDiscountPercentage = 0;
  double _couponDiscountAmount = 0;
  String _couponMessage = '';

  final List<Map<String, String>> _paymentMethods = [
    {'value': 'cash', 'label': 'Cash'},
    {'value': 'easypaisa', 'label': 'EasyPaisa'},
    {'value': 'jazzcash', 'label': 'JazzCash'},
  ];

  @override
  void initState() {
    super.initState();
    // Log payment details when page loads
    Logger.log('💳 ========== PAYMENT PAGE INITIALIZED ==========');
    Logger.log('💳 Driver Payment Details Received:');
    Logger.log(
      '💳 EasyPaisa Title: ${widget.driverPaymentDetails.easyPaisaAccountTitle}',
    );
    Logger.log(
      '💳 EasyPaisa Number: ${widget.driverPaymentDetails.easyPaisaAccountNumber}',
    );
    Logger.log(
      '💳 JazzCash Title: ${widget.driverPaymentDetails.jazzCashAccountTitle}',
    );
    Logger.log(
      '💳 JazzCash Number: ${widget.driverPaymentDetails.jazzCashAccountNumber}',
    );
    Logger.log(
      '💳 Has EasyPaisa: ${widget.driverPaymentDetails.hasEasyPaisaAccount}',
    );
    Logger.log(
      '💳 Has JazzCash: ${widget.driverPaymentDetails.hasJazzCashAccount}',
    );
    Logger.log(
      '💳 Has Any Account: ${widget.driverPaymentDetails.hasAnyAccount}',
    );
    Logger.log('💳 ==============================================');
  }

  /// Generate a unique transaction ID for cash payments
  String _generateCashTransactionId() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = (timestamp % 10000).toString().padLeft(4, '0');
    final userIdShort = widget.userId.length > 6
        ? widget.userId.substring(widget.userId.length - 6)
        : widget.userId.padLeft(6, '0');
    return 'CASH-$timestamp-$userIdShort-$random';
  }

  /// Submit payment to backend
  Future<void> _submitPayment() async {
    // Debug logging
    Logger.log('🔍 ========== PAYMENT SUBMISSION DEBUG ==========');
    Logger.log('🔍 Ride ID: ${widget.ride.id}');
    Logger.log('🔍 User ID: ${widget.userId}');
    Logger.log('🔍 Driver ID: ${widget.driverId}');
    Logger.log('🔍 Amount: ${widget.amount}');
    Logger.log('🔍 Payment Method: $_selectedPaymentMethod');

    // Validate IDs are not empty
    if (widget.userId.isEmpty) {
      Logger.error('❌ User ID is empty!');
      _showErrorDialog(
        'User ID is missing. Please restart the app and try again.',
      );
      return;
    }

    if (widget.driverId.isEmpty) {
      Logger.error('❌ Driver ID is empty!');
      _showErrorDialog(
        'Driver ID is missing. Please restart the app and try again.',
      );
      return;
    }

    if (widget.ride.id.isEmpty) {
      Logger.error('❌ Ride ID is empty!');
      _showErrorDialog(
        'Ride ID is missing. Please restart the app and try again.',
      );
      return;
    }

    // For cash payment, skip form validation
    if (_selectedPaymentMethod == 'cash') {
      // Cash payment doesn't need transaction ID
      Logger.log('💳 Processing cash payment...');
    } else {
      // Validate form only for online payments
      if (!_formKey.currentState!.validate()) {
        return;
      }
    }

    setState(() {
      _isSubmitting = true;
    });

    Logger.log('💳 Submitting $_selectedPaymentMethod payment...');

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Colors.green),
                SizedBox(height: 16),
                Text(
                  'Submitting Payment...',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    try {
      // Generate unique transaction ID for cash payments
      final transactionId = _selectedPaymentMethod == 'cash'
          ? _generateCashTransactionId()
          : _transactionIdController.text.trim();

      Logger.log('💳 Transaction ID: $transactionId');

      final result = await PaymentService.submitPayment(
        rideId: widget.ride.id,
        userId: widget.userId,
        driverId: widget.driverId,
        amount: widget.amount - _couponDiscountAmount,
        transactionId: transactionId,
        paymentMethod: _selectedPaymentMethod,
        couponCode: _appliedCouponCode,
      );

      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }

      setState(() {
        _isSubmitting = false;
      });

      if (result['success'] == true) {
        Logger.log('✅ Payment submitted successfully');
        if (mounted) {
          _showSuccessDialog();
        }
      } else {
        final errorMessage = result['message'] ?? 'Failed to submit payment';
        Logger.error('❌ Payment failed: $errorMessage');

        // Check if it's a duplicate payment for the same ride
        if (errorMessage.contains('already submitted for this ride') ||
            errorMessage.contains('Payment already exists')) {
          if (mounted) {
            _showErrorDialog(
              'Payment has already been submitted for this ride. '
              'If you believe this is an error, please contact support.',
            );
          }
        } else if (errorMessage.contains('Transaction ID already exists')) {
          // For duplicate transaction ID, suggest using a different one
          if (mounted) {
            _showErrorDialog(
              'This transaction ID has already been used. '
              'Please enter a unique transaction ID from your payment receipt.',
            );
          }
        } else {
          if (mounted) {
            _showErrorDialog(errorMessage);
          }
        }
      }
    } catch (e) {
      Logger.error('❌ Payment error: $e');

      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }

      setState(() {
        _isSubmitting = false;
      });

      if (mounted) {
        _showErrorDialog('Network error. Please check your connection.');
      }
    }
  }

  /// Show success dialog
  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 32),
            SizedBox(width: 12),
            Text('Payment Submitted'),
          ],
        ),
        content: Text(
          _selectedPaymentMethod == 'cash'
              ? 'Cash payment confirmed successfully!'
              : 'Your payment has been submitted successfully. '
                    'It will be verified by the admin.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              final rideIdToRate = widget.ride.id;

              Navigator.of(context).pop();
              Navigator.of(context).pop();
              Navigator.of(context).pop(rideIdToRate);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Show error dialog
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red, size: 32),
            SizedBox(width: 12),
            Text('Payment Failed'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Copy account number to clipboard
  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label copied to clipboard'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  void dispose() {
    _transactionIdController.dispose();
    _couponController.dispose();
    super.dispose();
  }

  /// Validate and apply a coupon code
  Future<void> _applyCoupon() async {
    final code = _couponController.text.trim();
    if (code.isEmpty) return;

    setState(() {
      _isValidatingCoupon = true;
      _couponMessage = '';
    });

    final result = await PaymentService.validateCoupon(code);

    if (!mounted) return;

    if (result['success'] == true) {
      final discountPct = (result['discountPercentage'] as double);
      // Apply coupon on top of the already-discounted amount shown to user
      final couponDiscount = (widget.amount * discountPct / 100).roundToDouble();
      setState(() {
        _appliedCouponCode = result['code'] as String;
        _couponDiscountPercentage = discountPct;
        _couponDiscountAmount = couponDiscount;
        _couponMessage = 'Coupon applied: ${discountPct.toStringAsFixed(0)}% off!';
        _isValidatingCoupon = false;
      });
    } else {
      setState(() {
        _appliedCouponCode = null;
        _couponDiscountPercentage = 0;
        _couponDiscountAmount = 0;
        _couponMessage = result['message'] as String? ?? 'Invalid coupon code';
        _isValidatingCoupon = false;
      });
    }
  }

  /// Remove applied coupon
  void _removeCoupon() {
    setState(() {
      _appliedCouponCode = null;
      _couponDiscountPercentage = 0;
      _couponDiscountAmount = 0;
      _couponMessage = '';
      _couponController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Payment Details Card
              _buildPaymentDetailsCard(),
              const SizedBox(height: 16),

              // Coupon Code Section
              _buildCouponSection(),
              const SizedBox(height: 16),

              // Payment Method Dropdown
              _buildPaymentMethodDropdown(),
              const SizedBox(height: 20),

              // Conditional UI based on payment method
              if (_selectedPaymentMethod == 'cash')
                _buildCashPaymentNotice()
              else ...[
                // Driver Payment Details Card (for online payments)
                _buildDriverPaymentDetailsCard(),
                const SizedBox(height: 20),

                // Transaction ID Input
                _buildTransactionIdField(),
              ],

              const SizedBox(height: 12),

              // Submit Button
              _buildSubmitButton(),
            ],
          ),
        ),
      ),
    );
  }

  /// Build payment details card
  Widget _buildPaymentDetailsCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Payment Details',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            _buildDetailRow('Ride ID', widget.ride.id),
            _buildDetailRow('From', widget.ride.source.address),
            _buildDetailRow('To', widget.ride.destination.address),
            const Divider(height: 24),
            if (widget.discountApplied && widget.baseFare != null) ...[
              _buildDetailRow(
                'Original Fare',
                'Rs. ${widget.baseFare!.toStringAsFixed(2)}',
                strikethrough: true,
              ),
              const SizedBox(height: 6),
              _buildDiscountRow(
                '${widget.discountPercentage.toStringAsFixed(0)}% OFF',
                'First-ride Discount',
                '-Rs. ${widget.discountAmount.toStringAsFixed(2)}',
              ),
              const SizedBox(height: 6),
            ],
            if (_appliedCouponCode != null) ...[
              _buildDiscountRow(
                '${_couponDiscountPercentage.toStringAsFixed(0)}% OFF',
                'Coupon ($_appliedCouponCode)',
                '-Rs. ${_couponDiscountAmount.toStringAsFixed(2)}',
              ),
              const SizedBox(height: 6),
            ],
            if (widget.discountApplied || _appliedCouponCode != null)
              const Divider(height: 16),
            _buildDetailRow(
              _appliedCouponCode != null
                  ? 'Total (after coupon)'
                  : 'Amount',
              'Rs. ${(widget.amount - _couponDiscountAmount).toStringAsFixed(2)}',
              isAmount: true,
            ),
          ],
        ),
      ),
    );
  }

  /// Build coupon code input section
  Widget _buildCouponSection() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Have a Coupon?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (_appliedCouponCode == null) ...[
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _couponController,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(
                        hintText: 'Enter coupon code',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _isValidatingCoupon ? null : _applyCoupon,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: _isValidatingCoupon
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Text(
                              'Apply',
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                  ),
                ],
              ),
              if (_couponMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    _couponMessage,
                    style: TextStyle(
                      color: _couponMessage.contains('applied')
                          ? Colors.green
                          : Colors.red,
                      fontSize: 13,
                    ),
                  ),
                ),
            ] else ...[
              // Applied coupon chip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_offer, color: Colors.green, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '$_appliedCouponCode — ${_couponDiscountPercentage.toStringAsFixed(0)}% OFF applied',
                        style: const TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _removeCoupon,
                      child: const Icon(Icons.close, color: Colors.green, size: 20),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Build payment method dropdown
  Widget _buildPaymentMethodDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Payment Method',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          initialValue: _selectedPaymentMethod,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
          ),
          items: _paymentMethods.map((method) {
            return DropdownMenuItem(
              value: method['value'],
              child: Text(method['label']!),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedPaymentMethod = value!;
              // Reset form fields when changing payment method
              _transactionIdController.clear();
            });
          },
        ),
      ],
    );
  }

  /// Build driver payment details card (for EasyPaisa/JazzCash)
  Widget _buildDriverPaymentDetailsCard() {
    final accountTitle = _selectedPaymentMethod == 'easypaisa'
        ? widget.driverPaymentDetails.easyPaisaAccountTitle
        : widget.driverPaymentDetails.jazzCashAccountTitle;
    final accountNumber = _selectedPaymentMethod == 'easypaisa'
        ? widget.driverPaymentDetails.easyPaisaAccountNumber
        : widget.driverPaymentDetails.jazzCashAccountNumber;

    final methodLabel = _selectedPaymentMethod == 'easypaisa'
        ? 'EasyPaisa'
        : 'JazzCash';

    // Debug logging
    Logger.log('💳 Building payment details card for: $_selectedPaymentMethod');
    Logger.log(
      '💳 Account Title: "$accountTitle" (isEmpty: ${accountTitle.isEmpty})',
    );
    Logger.log(
      '💳 Account Number: "$accountNumber" (isEmpty: ${accountNumber.isEmpty})',
    );
    Logger.log(
      '💳 Will show details: ${accountTitle.isNotEmpty && accountNumber.isNotEmpty}',
    );

    return Card(
      elevation: 4,
      color: Colors.green[50],
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.account_balance_wallet,
                  color: Colors.green[700],
                  size: 28,
                ),
                const SizedBox(width: 12),
                Text(
                  'Pay Using $methodLabel',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[900],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (accountTitle.isEmpty || accountNumber.isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.warning, color: Colors.orange[900]),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Driver has not added $methodLabel account details yet',
                        style: TextStyle(color: Colors.orange[900]),
                      ),
                    ),
                  ],
                ),
              )
            else ...[
              _buildAccountDetailRow('Account Title', accountTitle),
              const SizedBox(height: 12),
              _buildAccountDetailRow(
                'Account Number',
                accountNumber,
                isCopyable: true,
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Build account detail row with copy button
  Widget _buildAccountDetailRow(
    String label,
    String value, {
    bool isCopyable = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
          if (isCopyable)
            IconButton(
              icon: const Icon(Icons.copy, color: Colors.green),
              onPressed: () => _copyToClipboard(value, label),
              tooltip: 'Copy',
            ),
        ],
      ),
    );
  }

  /// Build cash payment notice
  Widget _buildCashPaymentNotice() {
    return Card(
      elevation: 4,
      color: Colors.blue[50],
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Icon(Icons.money, size: 64, color: Colors.blue[700]),
            const SizedBox(height: 16),
            Text(
              'Cash Payment',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blue[900],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Please pay Rs. ${(widget.amount - _couponDiscountAmount).toStringAsFixed(2)} directly to the driver in cash.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.blue[800]),
            ),
            const SizedBox(height: 12),
            Text(
              'Confirm payment only after handing over the cash.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Build transaction ID field
  Widget _buildTransactionIdField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Transaction ID',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _transactionIdController,
          decoration: InputDecoration(
            hintText: 'Enter transaction ID',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
          ),
          validator: (value) {
            if (_selectedPaymentMethod != 'cash' &&
                (value == null || value.trim().isEmpty)) {
              return 'Transaction ID is required';
            }
            return null;
          },
        ),
      ],
    );
  }

  /// Build submit button
  Widget _buildSubmitButton() {
    final buttonText = _selectedPaymentMethod == 'cash'
        ? 'Confirm Cash Payment'
        : 'Submit Payment';

    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _isSubmitting ? null : _submitPayment,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: _isSubmitting
            ? const CircularProgressIndicator(color: Colors.white)
            : Text(
                buttonText,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
      ),
    );
  }

  /// Build a discount row with badge label and green styling
  Widget _buildDiscountRow(String badge, String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                badge,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(fontSize: 14, color: Colors.green),
            ),
          ],
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.green,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  /// Build detail row widget
  Widget _buildDetailRow(String label, String value, {bool isAmount = false, bool strikethrough = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 14, color: Colors.grey)),
          Flexible(
            child: Text(
              value,
              style: TextStyle(
                fontSize: isAmount ? 20 : 14,
                fontWeight: isAmount ? FontWeight.bold : FontWeight.normal,
                color: strikethrough ? Colors.grey : (isAmount ? Colors.green : Colors.black87),
                decoration: strikethrough ? TextDecoration.lineThrough : null,
              ),
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
