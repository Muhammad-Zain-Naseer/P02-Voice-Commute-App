import 'package:flutter/material.dart';
import '../../services/ride_details_sharing_service.dart';

class ShareRideScreen extends StatefulWidget {
  final String userId;
  final String rideId;
  final Map<String, dynamic> rideDetails;
  
  const ShareRideScreen({
    super.key,
    required this.userId,
    required this.rideId,
    required this.rideDetails,
  });

  @override
  State<ShareRideScreen> createState() => _ShareRideScreenState();
}

class _ShareRideScreenState extends State<ShareRideScreen> {
  final RideSharingService _rideSharingService = RideSharingService();
  List<Map<String, dynamic>> _trustedContacts = [];
  List<String> _selectedEmails = [];
  bool _isLoading = true;
  bool _selectAll = false;

  @override
  void initState() {
    super.initState();
    _loadTrustedContacts();
  }

  Future<void> _loadTrustedContacts() async {
     print('🔍 Loading trusted contacts for userId: ${widget.userId}'); // ADD THIS
    final result = await _rideSharingService.getTrustedContacts(
      userId: widget.userId,
    );

      print('📦 API Result: $result'); // ADD THIS

    if (result['success']) {

       print('✅ Contacts loaded: ${result['contacts']}');
      setState(() {
        _trustedContacts = List<Map<String, dynamic>>.from(result['contacts'] ?? []);
        _isLoading = false;
      });
    } else {
      print('❌ Failed: ${result['message']}'); 
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message'] ?? 'Failed to load contacts',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _toggleContact(String email) {
    setState(() {
      if (_selectedEmails.contains(email)) {
        _selectedEmails.remove(email);
      } else {
        _selectedEmails.add(email);
      }
      _selectAll = _selectedEmails.length == _trustedContacts.length;
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selectAll) {
        _selectedEmails.clear();
      } else {
        _selectedEmails = _trustedContacts.map((c) => c['email'].toString()).toList();
      }
      _selectAll = !_selectAll;
    });
  }

  Future<void> _shareRide() async {
    if (_selectedEmails.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one contact'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final result = await _rideSharingService.shareRideWithSelectedContacts(
      userId: widget.userId,
      rideId: widget.rideId,
      rideDetails: widget.rideDetails,
      contactEmails: _selectedEmails,
    );

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      if (result['success']) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: const Color(0xFFFAECF1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: const BorderSide(color: Color(0xFFF682AA), width: 2),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.check_circle,
                  color: Color(0xFFCF4374),
                  size: 60,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Ride Details Shared!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'منتخب رابطوں کو ای میل بھیج دی گئی',
                  style: const TextStyle(
                    fontSize: 16,
                    color: Color(0xFFCF4374),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close dialog
                  Navigator.of(context).pop(); // Go back to ride screen
                },
                child: const Text(
                  'ٹھیک ہے',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xFFCF4374),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message'] ?? 'Failed to share ride',
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Expanded(
                      child: Text(
                        'سواری کی تفصیلات شیئر کریں',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
              ),

              // Ride Details Summary
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFF682AA), width: 2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  _buildDetailRow('پِک اپ', widget.rideDetails['pickup'] ?? 'N/A'),
                  const SizedBox(height: 8),
                  _buildDetailRow('ڈراپ آف', widget.rideDetails['dropoff'] ?? 'N/A'),
                  const SizedBox(height: 8),
                  _buildDetailRow('ڈرائیور', widget.rideDetails['driverName'] ?? 'N/A'),
                  ],
                ),
              ),

              // Select All Checkbox
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  children: [
                    Checkbox(
                      value: _selectAll,
                      onChanged: (value) => _toggleSelectAll(),
                      activeColor: const Color(0xFFCF4374),
                    ),
                    const Text(
                      'سب منتخب کریں',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ),

              // Trusted Contacts List
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: Color(0xFFCF4374),
                        ),
                      )
                    : _trustedContacts.isEmpty
                        ? const Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.person_off,
                                  size: 60,
                                  color: Color(0xFFCF4374),
                                ),
                                SizedBox(height: 20),
                                Text(
                                  'کوئی قابل اعتماد رابطہ نہیں',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Color(0xFFCF4374),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            itemCount: _trustedContacts.length,
                            itemBuilder: (context, index) {
                              final contact = _trustedContacts[index];
                              final email = contact['email'].toString();
                              final name = contact['name']?.toString() ?? email;
                              final isSelected = _selectedEmails.contains(email);

                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? const Color(0xFFF8BBD0)
                                      : Colors.white.withOpacity(0.7),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isSelected
                                        ? const Color(0xFFCF4374)
                                        : const Color(0xFFF682AA),
                                    width: 2,
                                  ),
                                ),
                                child: CheckboxListTile(
                                  value: isSelected,
                                  onChanged: (value) => _toggleContact(email),
                                  activeColor: const Color(0xFFCF4374),
                                  title: Text(
                                    name,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFCF4374),
                                    ),
                                  ),
                                  subtitle: Text(
                                    email,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: const Color(0xFFCF4374).withOpacity(0.7),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
              ),

              // Share Button
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: GestureDetector(
                  onTap: _isLoading ? null : _shareRide,
                  child: Container(
                    width: double.infinity,
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFFCF4374),
                          Color(0xFF69223B),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withOpacity(0.3),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (_isLoading)
                          const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        else ...[
                          const Icon(
                            Icons.share,
                            color: Colors.white,
                            size: 28,
                          ),
                          const SizedBox(width: 12),
                          Text(
                            'شیئر کریں (${_selectedEmails.length})',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      children: [
        Text(
          '$label:',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Color(0xFFCF4374),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFFCF4374),
            ),
          ),
        ),
      ],
    );
  }
}
