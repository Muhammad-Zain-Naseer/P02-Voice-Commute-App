import 'package:flutter/material.dart';
import '../../models/ride_request.dart';
import '../../models/driver_payment_details.dart';
import '../../services/sos_service.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../utils/logger.dart';
import '../payment/payment_page.dart';
import 'share_ride_screen.dart';
import '../../widgets/live_tracking_map.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

/// Commuter Active Ride Page - Shows ongoing ride with SOS button
class CommuterActiveRidePage extends StatefulWidget {
  final RideRequest ride;
  final String userId;
  final String driverId;

  const CommuterActiveRidePage({
    super.key,
    required this.ride,
    required this.userId,
    required this.driverId,
  });

  @override
  State<CommuterActiveRidePage> createState() => _CommuterActiveRidePageState();
}

class _CommuterActiveRidePageState extends State<CommuterActiveRidePage> {
  bool _isSOSTriggered = false;
  bool _isCancelled = false;

  static const List<Map<String, dynamic>> _cancelReasons = [
    {'code': 'driver_request', 'label': 'ڈرائیور نے کہا منسوخ کریں', 'icon': Icons.warning_amber_rounded},
    {'code': 'long_wait', 'label': 'انتظار بہت طویل ہے', 'icon': Icons.timer_off_outlined},
    {'code': 'plans_changed', 'label': 'میرے منصوبے بدل گئے', 'icon': Icons.event_busy_outlined},
    {'code': 'wrong_location', 'label': 'غلط مقام', 'icon': Icons.location_off_outlined},
    {'code': 'other', 'label': 'دیگر', 'icon': Icons.more_horiz},
  ];
  double? _driverLat;
  double? _driverLng;
  double? _passengerLat;
  double? _passengerLng;
  double? _destinationLat;
  double? _destinationLng;
  String? _routePolyline;
  Timer? _passengerLocationTimer;
  int _locationUpdateCount = 0;

  Future<void> _setFallbackPassengerLocation() async {
    if (widget.ride.source.coordinates != null) {
      if (mounted) {
        setState(() {
          _passengerLat = widget.ride.source.coordinates!.lat;
          _passengerLng = widget.ride.source.coordinates!.lon;
        });
      }
      return;
    }

    try {
      final coords = await MapService.geocodeAddress(
        widget.ride.source.address,
      );
      if (coords != null && mounted) {
        setState(() {
          _passengerLat = coords['latitude'];
          _passengerLng = coords['longitude'];
        });
      }
    } catch (e) {
      Logger.error('âŒ Failed to geocode pickup address: $e');
    }
  }

  Future<void> _loadDestinationCoordinates() async {
    if (widget.ride.destination.coordinates != null) {
      if (mounted) {
        setState(() {
          _destinationLat = widget.ride.destination.coordinates!.lat;
          _destinationLng = widget.ride.destination.coordinates!.lon;
        });
      }
      return;
    }

    try {
      final coords = await MapService.geocodeAddress(
        widget.ride.destination.address,
      );
      if (coords != null && mounted) {
        setState(() {
          _destinationLat = coords['latitude'];
          _destinationLng = coords['longitude'];
        });
      }
    } catch (e) {
      Logger.error('❌ Failed to geocode destination: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _setupPaymentRequestListener();
    _ensureSocketConnection();
    _setupDriverLocationListener();
    _getPassengerCurrentLocation();
    _startPassengerLocationBroadcasting();
    _loadDestinationCoordinates();
  }

  @override
  void dispose() {
    _passengerLocationTimer?.cancel();
    SocketService.removeDriverLocationListener();
    // Don't remove the listener here - it needs to stay active for payment
    // The listener will be removed when the user completes payment or navigates home
    super.dispose();
  }

  /// Ensure socket connection is maintained after ride matching
  void _ensureSocketConnection() {
    SocketService.ensureConnection();
    Logger.log('🔌 Socket connection verified for active ride');
  }

  /// Listen for payment request from driver after ride completion
  void _setupPaymentRequestListener() {
    Logger.log('💳 Setting up payment request listener for commuter');

    SocketService.onPaymentRequest((data) {
      Logger.log(
        '💳 Payment request received in CommuterActiveRidePage: $data',
      );

      if (!mounted) {
        Logger.log('⚠️ Widget not mounted, skipping payment dialog');
        return;
      }

      try {
        // Extract fare information
        final fare = data['fare'] as Map<String, dynamic>;
        final distanceKm = (fare['distanceKm'] as num).toDouble();
        final totalAmount = (fare['totalAmount'] as num).toDouble();
        final baseFare = (fare['baseFare'] as num?)?.toDouble() ?? totalAmount;
        final discountApplied = (fare['discountApplied'] as bool?) ?? false;
        final discountPercentage = (fare['discountPercentage'] as num?)?.toDouble() ?? 0;
        final discountAmount = (fare['discountAmount'] as num?)?.toDouble() ?? 0;
        final rideNumber = (fare['rideNumber'] as num?)?.toInt() ?? 1;
        final ridesRemainingForDiscount = (fare['ridesRemainingForDiscount'] as num?)?.toInt() ?? 0;

        // Extract driver payment details
        Logger.log('🔍 Raw socket data received: ${data.toString()}');
        final driverPaymentDetailsJson =
            data['driverPaymentDetails'] as Map<String, dynamic>?;
        Logger.log(
          '🔍 Raw driverPaymentDetails JSON: $driverPaymentDetailsJson',
        );
        final driverPaymentDetails = DriverPaymentDetails.fromJson(
          driverPaymentDetailsJson,
        );

        Logger.log('✅ Parsed payment: PKR $totalAmount for $distanceKm km');
        Logger.log('💳 Driver payment details: $driverPaymentDetails');
        Logger.log(
          '💳 EasyPaisa: ${driverPaymentDetails.easyPaisaAccountTitle} / ${driverPaymentDetails.easyPaisaAccountNumber}',
        );
        Logger.log(
          '💳 JazzCash: ${driverPaymentDetails.jazzCashAccountTitle} / ${driverPaymentDetails.jazzCashAccountNumber}',
        );

        // Show payment dialog with calculated fare
        _showPaymentDialog(
          distanceKm,
          totalAmount,
          driverPaymentDetails,
          baseFare: baseFare,
          discountApplied: discountApplied,
          discountPercentage: discountPercentage,
          discountAmount: discountAmount,
          rideNumber: rideNumber,
          ridesRemainingForDiscount: ridesRemainingForDiscount,
        );
      } catch (e) {
        Logger.error('💥 Error processing payment request: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error processing payment: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    });

    Logger.log('✅ Payment listener setup complete');
  }

  /// Listen for driver location updates during active ride
  void _setupDriverLocationListener() {
    Logger.log(
      'ðŸ‘‚ Setting up driver location listener in CommuterActiveRidePage',
    );

    SocketService.onDriverLocationUpdate((
      rideId,
      lat,
      lng,
      heading,
      speed,
      timestamp,
    ) async {
      if (!mounted) {
        return;
      }

      if (rideId == widget.ride.id) {
        setState(() {
          _driverLat = lat;
          _driverLng = lng;
        });

        Logger.log('ðŸ“ Driver location updated: ($lat, $lng)');

        _locationUpdateCount++;
        final double? targetLat = _destinationLat ?? _passengerLat;
        final double? targetLng = _destinationLng ?? _passengerLng;
        if (targetLat != null &&
            targetLng != null &&
            _locationUpdateCount % 3 == 1) {
          try {
            final polyline = await MapService.getDirectionsPolyline(
              sourceLat: lat,
              sourceLng: lng,
              destLat: targetLat,
              destLng: targetLng,
            );

            if (mounted) {
              setState(() {
                _routePolyline = polyline;
              });
              Logger.log('ðŸ—ºï¸ Route polyline fetched');
            }
          } catch (e) {
            Logger.error('âŒ Failed to fetch route polyline: $e');
          }
        }
      }
    });

    Logger.log('âœ… Driver location listener setup complete');
  }

  /// Get passenger's current GPS location
  Future<void> _getPassengerCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        Logger.error('âŒ Location services are disabled');
        await _setFallbackPassengerLocation();
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          Logger.error('âŒ Location permissions denied');
          await _setFallbackPassengerLocation();
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        Logger.error('âŒ Location permissions permanently denied');
        await _setFallbackPassengerLocation();
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      if (mounted) {
        setState(() {
          _passengerLat = position.latitude;
          _passengerLng = position.longitude;
        });
        Logger.log(
          'ðŸ“ Passenger location: (${position.latitude}, ${position.longitude})',
        );
      }
    } catch (e) {
      Logger.error('ðŸ’¥ Error getting passenger location: $e');
      await _setFallbackPassengerLocation();
    }
  }

  /// Start broadcasting passenger location to driver during active ride
  void _startPassengerLocationBroadcasting() {
    Logger.log('ðŸ“¡ Starting passenger location broadcasting in active ride');

    _passengerLocationTimer?.cancel();
    _passengerLocationTimer = Timer.periodic(const Duration(seconds: 5), (
      timer,
    ) async {
      if (!mounted) {
        timer.cancel();
        return;
      }

      try {
        final serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          Logger.error('âŒ Location services are disabled');
          await _setFallbackPassengerLocation();
          return;
        }

        LocationPermission permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) {
          permission = await Geolocator.requestPermission();
          if (permission == LocationPermission.denied) {
            Logger.error('âŒ Location permissions denied');
            await _setFallbackPassengerLocation();
            return;
          }
        }

        if (permission == LocationPermission.deniedForever) {
          Logger.error('âŒ Location permissions permanently denied');
          await _setFallbackPassengerLocation();
          return;
        }

        final position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
          ),
        );

        if (mounted) {
          setState(() {
            _passengerLat = position.latitude;
            _passengerLng = position.longitude;
          });

          SocketService.emitPassengerLocation(
            rideId: widget.ride.id,
            latitude: position.latitude,
            longitude: position.longitude,
          );

          Logger.log(
            'ðŸ“ Passenger location broadcasted: (${position.latitude}, ${position.longitude})',
          );
        }
      } catch (e) {
        Logger.error('âŒ Failed to broadcast passenger location: $e');
        await _setFallbackPassengerLocation();
      }
    });
  }

  /// Show payment dialog with calculated fare
  void _showPaymentDialog(
    double distanceKm,
    double totalAmount,
    DriverPaymentDetails driverPaymentDetails, {
    double? baseFare,
    bool discountApplied = false,
    double discountPercentage = 0,
    double discountAmount = 0,
    int rideNumber = 1,
    int ridesRemainingForDiscount = 0,
  }) {
    final outerContext = context;
    showDialog(
      context: outerContext,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 32),
            SizedBox(width: 12),
            Text('Ride Completed'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Your ride has been completed successfully!',
              style: TextStyle(fontSize: 16),
            ),
            if (discountApplied) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_offer, color: Colors.green, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        ridesRemainingForDiscount > 0
                            ? 'Ride $rideNumber of 3 • $ridesRemainingForDiscount ride${ridesRemainingForDiscount > 1 ? 's' : ''} left with 20% discount!'
                            : 'Last discounted ride! Enjoy your 20% off.',
                        style: const TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFFCE4EC),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFF682AA), width: 2),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Distance:',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Text(
                        '${distanceKm.toStringAsFixed(1)} km',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Divider(),
                  const SizedBox(height: 12),
                  if (discountApplied && baseFare != null) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Original Fare:',
                          style: TextStyle(fontSize: 15, color: Colors.grey),
                        ),
                        Text(
                          'PKR ${baseFare.toStringAsFixed(0)}',
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.grey,
                            decoration: TextDecoration.lineThrough,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                '${discountPercentage.toStringAsFixed(0)}% OFF',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              'Discount:',
                              style: TextStyle(fontSize: 15, color: Colors.green),
                            ),
                          ],
                        ),
                        Text(
                          '-PKR ${discountAmount.toStringAsFixed(0)}',
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Divider(),
                    const SizedBox(height: 8),
                  ],
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total Fare:',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'PKR ${totalAmount.toStringAsFixed(0)}',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(); // Close dialog

                // Navigate to payment page
                Navigator.of(outerContext).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => PaymentPage(
                      ride: widget.ride,
                      userId: widget.userId,
                      driverId: widget.driverId,
                      amount: totalAmount,
                      driverPaymentDetails: driverPaymentDetails,
                      baseFare: baseFare,
                      discountApplied: discountApplied,
                      discountPercentage: discountPercentage,
                      discountAmount: discountAmount,
                    ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFCF4374),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Proceed to Payment',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Navigate to share ride screen
  void _shareRideDetails() {
    print('DEBUG userId: ${widget.userId}');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ShareRideScreen(
          userId: widget.userId,
          rideId: widget.ride.id,
          rideDetails: {
            'rideId': widget.ride.id,
            'pickup': widget.ride.source.address,
            'dropoff': widget.ride.destination.address,
            'driverName': widget.ride.matchedWith?.driverName ?? 'N/A',
            'estimatedArrival': 'In Progress',
            'trackingLink': 'https://hersafar.com/track/${widget.ride.id}',
          },
        ),
      ),
    );
  }

  /// Trigger SOS Alert using REST API for reliability
  Future<void> _triggerSOS() async {
    setState(() {
      _isSOSTriggered = true;
    });

    Logger.log('🚨 SOS TRIGGERED for ride: ${widget.ride.id}');

    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Colors.red),
                SizedBox(height: 16),
                Text(
                  'Sending SOS Alert...',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    try {
      // Send SOS via REST API (more reliable than socket)
      final result = await SOSService.triggerSOS(
        rideId: widget.ride.id,
        message: 'ایمرجنسی SOS مسافر نے متحرک کی',
      );

      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }

      if (result['success'] == true) {
        Logger.log('✅ SOS sent successfully!');

        // Show success dialog
        if (mounted) {
          _showSOSSuccessDialog();
        }
      } else {
        Logger.log('❌ SOS failed: ${result['message']}');

        // Reset state on failure
        setState(() {
          _isSOSTriggered = false;
        });

        // Show error dialog
        if (mounted) {
          _showSOSErrorDialog(result['message'] ?? 'Failed to send SOS');
        }
      }
    } catch (e) {
      Logger.log('❌ SOS error: $e');

      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }

      // Reset state on error
      setState(() {
        _isSOSTriggered = false;
      });

      // Show error dialog
      if (mounted) {
        _showSOSErrorDialog('Network error. Please try again.');
      }
    }
  }

  /// Show SOS success confirmation dialog
  void _showSOSSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFFF682AA), width: 2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle_outline,
                color: Colors.green,
                size: 60,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'SOS Alert Sent!',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Your trusted contacts have been notified via email.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.black87,
                height: 1.5,
              ),
            ),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text(
                'OK',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Show SOS error dialog
  void _showSOSErrorDialog(String errorMessage) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFFF682AA), width: 2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.error_outline,
                color: Colors.orange,
                size: 60,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'SOS Failed',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              errorMessage,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.black87,
                height: 1.5,
              ),
            ),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text(
                'Try Again',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmCancelRide(BuildContext context, {required String reasonCode, String? reasonText}) {
    setState(() => _isCancelled = true);
    _passengerLocationTimer?.cancel();
    SocketService.cancelRide(widget.ride.id, reasonCode: reasonCode, reasonText: reasonText);

    if (reasonCode == 'driver_request') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'سواری منسوخ کر دی گئی۔ ڈرائیور کی مشکوک سرگرمی رپورٹ کر دی گئی۔',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 4),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'سواری منسوخ کر دی گئی۔',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 3),
        ),
      );
    }

    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  void _showCancelReasonSheet(BuildContext context) {
    String? selectedCode;
    final TextEditingController otherController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
            top: 24,
            left: 20,
            right: 20,
          ),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'منسوخی کی وجہ بتائیں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'براہ کرم وجہ منتخب کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ),
              const SizedBox(height: 16),
              ...(_cancelReasons.map((reason) {
                final isSelected = selectedCode == reason['code'];
                return GestureDetector(
                  onTap: () => setSheetState(() => selectedCode = reason['code'] as String),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: isSelected ? const Color(0xFFFAECF1) : Colors.grey[50],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? const Color(0xFFCF4374) : Colors.grey[200]!,
                        width: isSelected ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Expanded(
                          child: Text(
                            reason['label'] as String,
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                              color: isSelected ? const Color(0xFFCF4374) : Colors.black87,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          reason['icon'] as IconData,
                          color: isSelected ? const Color(0xFFCF4374) : Colors.grey,
                          size: 22,
                        ),
                      ],
                    ),
                  ),
                );
              })),
              if (selectedCode == 'other') ...[
                const SizedBox(height: 8),
                TextField(
                  controller: otherController,
                  textDirection: TextDirection.rtl,
                  maxLines: 2,
                  decoration: InputDecoration(
                    hintText: 'وجہ لکھیں...',
                    hintTextDirection: TextDirection.rtl,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFCF4374), width: 2),
                    ),
                    contentPadding: const EdgeInsets.all(12),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.grey),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text('واپس جائیں', style: TextStyle(color: Colors.grey)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: selectedCode == null
                          ? null
                          : () {
                              final reasonText = selectedCode == 'other'
                                  ? otherController.text.trim()
                                  : null;
                              Navigator.pop(sheetContext);
                              _confirmCancelRide(
                                context,
                                reasonCode: selectedCode!,
                                reasonText: reasonText,
                              );
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFCF4374),
                        disabledBackgroundColor: Colors.grey[300],
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text(
                        'منسوخ کریں',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double? effectiveDriverLat = _driverLat ?? _passengerLat;
    final double? effectiveDriverLng = _driverLng ?? _passengerLng;
    final double? targetLat = _destinationLat ?? _passengerLat;
    final double? targetLng = _destinationLng ?? _passengerLng;
    final bool hasLiveLocations =
        effectiveDriverLat != null &&
        effectiveDriverLng != null &&
        targetLat != null &&
        targetLng != null;

    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text(
          'Active Ride',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFCF4374),
        elevation: 0,
        automaticallyImplyLeading: false, // Remove back button
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                SizedBox(
                  height: 260,
                  child: hasLiveLocations
                      ? LiveTrackingMap(
                          driverLat: effectiveDriverLat!,
                          driverLng: effectiveDriverLng!,
                          passengerLat: targetLat!,
                          passengerLng: targetLng!,
                          polylineEncoded: _routePolyline,
                          showRoute: true,
                        )
                      : const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(
                                color: Color(0xFFCF4374),
                              ),
                              SizedBox(height: 12),
                              Text(
                                'Loading map...',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),
                ),

                const SizedBox(height: 20),

                // Status Badge
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.directions_car, color: Colors.white, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Ride in Progress',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 40),

                // Ride Details Card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFF682AA),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withValues(alpha: 0.1),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Driver Info
                      if (widget.ride.matchedWith != null) ...[
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFCE4EC),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person,
                                color: Color(0xFFCF4374),
                                size: 28,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Driver',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  Text(
                                    widget.ride.matchedWith!.driverName,
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFCF4374),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        const Divider(color: Color(0xFFF682AA)),
                        const SizedBox(height: 24),
                      ],

                      // Source Location
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.location_on,
                            color: Colors.green,
                            size: 24,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Pickup Location',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  widget.ride.source.address,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    color: Colors.black87,
                                    height: 1.4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 20),

                      // Destination Location
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.flag, color: Colors.red, size: 24),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Drop-off Location',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  widget.ride.destination.address,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    color: Colors.black87,
                                    height: 1.4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Safety Message
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.3),
                      width: 1.5,
                    ),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, color: Colors.orange, size: 24),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'In case of emergency, press the SOS button below',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.black87,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Share Ride Button
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: ElevatedButton(
                    onPressed: _shareRideDetails,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFCF4374),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      elevation: 6,
                      shadowColor: const Color(
                        0xFFCF4374,
                      ).withValues(alpha: 0.4),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.share, color: Colors.white, size: 28),
                        SizedBox(width: 12),
                        Text(
                          'Share Ride Details',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // Cancel Ride Button
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: OutlinedButton(
                    onPressed: _isCancelled ? null : () => _showCancelReasonSheet(context),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFCF4374), width: 1.5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.cancel_outlined, color: Color(0xFFCF4374), size: 24),
                        SizedBox(width: 10),
                        Text(
                          'سواری منسوخ کریں',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // SOS Button
                SizedBox(
                  width: double.infinity,
                  height: 70,
                  child: ElevatedButton(
                    onPressed: _isSOSTriggered ? null : _triggerSOS,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isSOSTriggered
                          ? Colors.grey
                          : Colors.red,
                      disabledBackgroundColor: Colors.grey,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35),
                      ),
                      elevation: 8,
                      shadowColor: Colors.red.withValues(alpha: 0.4),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _isSOSTriggered
                              ? Icons.check_circle_outline
                              : Icons.warning_amber_rounded,
                          color: Colors.white,
                          size: 32,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          _isSOSTriggered ? 'SOS Triggered' : 'SOS Alert',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
