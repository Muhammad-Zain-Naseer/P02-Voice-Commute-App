import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:math' as math;
import 'package:record/record.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path_provider/path_provider.dart';

import '../../services/audio_api_service.dart';
import '../../services/location_service.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../services/admin_service.dart';
import '../../utils/logger.dart';

// Local page imports
import 'ride_waiting_page.dart';
import 'ride_started_page.dart';

class BookRidePage extends StatefulWidget {
  final String userId;
  final String userName;
  final String userEmail;

  const BookRidePage({
    super.key,
    required this.userId,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<BookRidePage> createState() => _BookRidePageState();
}

class _BookRidePageState extends State<BookRidePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  final AudioRecorder _audioRecorder = AudioRecorder();

  bool _isListening = false;
  bool _isProcessing = false;
  bool _isPublishing = false;

  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  String? _currentRideId;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    _loadCurrentLocation();
    _initializeSocket();
  }

  /// Initialize socket connection and event listeners
  Future<void> _initializeSocket() async {
    try {
      await SocketService.connect(
        userId: widget.userId,
        userName: widget.userName,
        userEmail: widget.userEmail,
        userType: 'commuter',
      );

      SocketService.onRideCreated((data) {
        Logger.log('✅ Ride created confirmation: $data');
        if (mounted) {
          setState(() {
            _isPublishing = false;
            _currentRideId = data['ride']['id'] as String?;
          });

          if (_currentRideId != null) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => RideWaitingPage(
                  rideId: _currentRideId!,
                  source: _sourceController.text,
                  destination: _destinationController.text,
                ),
              ),
            );
          }
        }
      });

      SocketService.onRideMatched((ride, role) {
        Logger.log('🎉 Ride matched! Role: $role');
        if (mounted) {
          Navigator.of(context).pop();
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => RideStartedPage(
                ride: ride,
                role: role,
              ),
            ),
          );
        }
      });

      SocketService.onRideError((message) {
        Logger.error('🔴 Ride error: $message');
        if (mounted) {
          setState(() {
            _isPublishing = false;
          });

          if (Navigator.canPop(context)) {
            Navigator.of(context).pop();
          }

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $message'),
              backgroundColor: Colors.red,
            ),
          );
        }
      });

      Logger.log('✅ Socket initialized successfully');
    } catch (e) {
      Logger.error('Failed to initialize socket: $e');
    }
  }

  /// Load current location and set it as source
  Future<void> _loadCurrentLocation() async {
    Logger.log('🌍 Loading current location on page load...');
    try {
      final location = await LocationService.getCurrentLocationAddress();
      if (location != null && mounted) {
        setState(() {
          _sourceController.text = location;
        });
        Logger.log('✅ Source set to current location: $location');
      }
    } catch (e) {
      Logger.error('❌ Error loading current location: $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _audioRecorder.dispose();
    _sourceController.dispose();
    _destinationController.dispose();
    SocketService.removeAllListeners();
    SocketService.disconnect();
    super.dispose();
  }

  /// Publish ride request to the connection pool
  Future<void> _publishRide() async {
    final source = _sourceController.text.trim();
    final destination = _destinationController.text.trim();

    if (source.isEmpty || destination.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'براہ کرم شروعاتی جگہ اور منزل دونوں درج کریں',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    if (source == destination) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'شروعاتی جگہ اور منزل ایک جیسی نہیں ہو سکتی',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (!SocketService.isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'سرور سے منسلک نہیں۔ دوبارہ کوشش کریں۔',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.red,
        ),
      );
      await _initializeSocket();
      return;
    }

    setState(() {
      _isPublishing = true;
    });

    try {
      Logger.log('Publishing ride request...');
      Logger.log('Geocoding addresses before sending...');

      final sourceCoords = await MapService.geocodeAddress(source);
      final destCoords = await MapService.geocodeAddress(destination);

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Failed to geocode addresses');
      }

      Logger.log(
        '✅ Source coords: ${sourceCoords['latitude']}, ${sourceCoords['longitude']}',
      );
      Logger.log(
        '✅ Dest coords: ${destCoords['latitude']}, ${destCoords['longitude']}',
      );

      // Check if source or destination is in an unsafe area
      final adminService = AdminService();
      final sourceCheck = await adminService.checkUnsafeLocation(
        latitude: sourceCoords['latitude'] as double,
        longitude: sourceCoords['longitude'] as double,
      );
      final destCheck = await adminService.checkUnsafeLocation(
        latitude: destCoords['latitude'] as double,
        longitude: destCoords['longitude'] as double,
      );

      final unsafeAreas = <Map<String, dynamic>>[];
      if (sourceCheck['isUnsafe'] == true) {
        for (var area in sourceCheck['areas']) {
          unsafeAreas.add({...area, 'locationType': 'pickup'});
        }
      }
      if (destCheck['isUnsafe'] == true) {
        for (var area in destCheck['areas']) {
          unsafeAreas.add({...area, 'locationType': 'destination'});
        }
      }

      // If unsafe areas found, show warning dialog
      if (unsafeAreas.isNotEmpty && mounted) {
        setState(() {
          _isPublishing = false;
        });

        final shouldContinue = await _showUnsafeAreaWarning(unsafeAreas);
        if (shouldContinue != true) {
          return;
        }

        setState(() {
          _isPublishing = true;
        });
      }

      SocketService.emitRideRequest(
        source: source,
        destination: destination,
        sourceCoordinates: sourceCoords,
        destinationCoordinates: destCoords,
      );
    } catch (e) {
      Logger.error('💥 Failed to publish ride: $e');

      setState(() {
        _isPublishing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  /// Show warning dialog for unsafe areas
  Future<bool?> _showUnsafeAreaWarning(List<Map<String, dynamic>> unsafeAreas) async {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Unsafe Area Warning',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Your ride involves unsafe areas:',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 16),
              ...unsafeAreas.map((area) {
                final locationType = area['locationType'] ?? 'location';
                final severity = area['severity'] ?? 'warning';
                final isBlocked = severity == 'blocked';

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isBlocked ? Colors.red.withValues(alpha: 0.1) : Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isBlocked ? Colors.red : Colors.orange,
                      width: 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: isBlocked ? Colors.red : Colors.orange,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              severity.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              area['name'] ?? 'Unsafe Area',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Location: ${locationType == 'pickup' ? 'Pickup' : 'Destination'}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Reason: ${area['reason'] ?? 'Not specified'}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[700],
                        ),
                      ),
                    ],
                  ),
                );
              }),
              const SizedBox(height: 8),
              // Check if any area is blocked
              if (unsafeAreas.any((area) => area['severity'] == 'blocked'))
                const Text(
                  '⚠️ Rides are not allowed in blocked areas for your safety.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.red,
                    fontWeight: FontWeight.w600,
                  ),
                )
              else
                const Text(
                  'You can still proceed, but exercise caution.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.orange,
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          // Only show continue button if no area is blocked
          if (!unsafeAreas.any((area) => area['severity'] == 'blocked'))
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
              ),
              child: const Text('Continue Anyway'),
            )
          else
            ElevatedButton(
              onPressed: () => Navigator.pop(context, false),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFCF4374),
                foregroundColor: Colors.white,
              ),
              child: const Text('OK'),
            ),
        ],
      ),
    );
  }

  Future<void> _toggleListening() async {
    Logger.log('🎤 Toggle listening called. Current state: $_isListening');

    if (_isProcessing) {
      Logger.log('⚠️ Already processing, ignoring click');
      return;
    }

    if (_isListening) {
      Logger.log('🛑 Stopping recording...');
      await _stopRecording();
    } else {
      Logger.log('▶️ Starting recording...');
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    setState(() {
      _isProcessing = true;
    });

    Logger.log('📱 Requesting microphone permission...');
    final status = await Permission.microphone.request();

    if (!status.isGranted) {
      Logger.error('❌ Permission denied!');
      setState(() {
        _isProcessing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Microphone permission is required'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    try {
      Logger.log('🎙️ Starting audio recorder...');

      if (kIsWeb) {
        await _audioRecorder.start(
          const RecordConfig(
            encoder: AudioEncoder.wav,
            numChannels: 1,
            sampleRate: 16000,
          ),
          path: 'audio_recording',
        );
      } else {
        final tempDir = await getTemporaryDirectory();
        final filePath =
            '${tempDir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await _audioRecorder.start(
          const RecordConfig(
            encoder: AudioEncoder.aacLc,
            numChannels: 1,
            sampleRate: 16000,
          ),
          path: filePath,
        );
      }

      Logger.log('✅ Recording started successfully!');
      setState(() {
        _isListening = true;
        _isProcessing = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Recording started...'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      Logger.error('💥 ERROR starting recording: $e');
      setState(() {
        _isProcessing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error starting recording: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _stopRecording() async {
    try {
      Logger.log('⏹️ Stopping audio recorder...');
      final path = await _audioRecorder.stop();

      setState(() {
        _isListening = false;
      });

      Logger.log('📍 Recording stopped. Path: $path');

      if (path != null && path.isNotEmpty) {
        Logger.log('🚀 Processing audio...');
        await _commonAudioProcessing(() => AudioApiService.processAudio(path));
      } else {
        Logger.error('⚠️ No recording path returned!');
      }
    } catch (e) {
      Logger.error('💥 ERROR stopping recording: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error stopping recording: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _commonAudioProcessing(
    Future<Map<String, dynamic>?> Function() apiCall,
  ) async {
    setState(() {
      _isProcessing = true;
    });

    try {
      Logger.log('📍 Attempting to get current location...');
      String? currentLocation =
          await LocationService.getCurrentLocationAddress();

      Logger.log('📡 Calling API service...');
      final result = await apiCall();
      Logger.log('📥 API Response: $result');

      if (result != null && mounted) {
        String source = '';
        if (currentLocation != null && currentLocation.isNotEmpty) {
          source = currentLocation;
        } else if (result['source'] != null &&
            result['source'].toString().isNotEmpty) {
          source = result['source'];
        }

        final destination = result['destination'] ?? '';
        Logger.log('✅ Success! Source: $source, Destination: $destination');

        setState(() {
          _sourceController.text = source;
          _destinationController.text = destination;
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Locations extracted!\nFrom: ${source.isEmpty ? "Not set" : source}\nTo: ${destination.isEmpty ? "Not found" : destination}',
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
      } else if (mounted) {
        Logger.error('❌ API returned null result');

        setState(() {
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to process audio. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e, stackTrace) {
      Logger.error('💥 ERROR processing audio: $e');
      Logger.error('Stack trace: $stackTrace');

      if (mounted) {
        setState(() {
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      body: SafeArea(
        child: Column(
          children: [
            // Header Section
            _buildHeader(),

            // Scrollable Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(
                  children: [
                    const SizedBox(height: 20),

                    // Voice Section with prompt
                    _buildVoiceSection(),

                    const SizedBox(height: 30),

                    // Divider
                    _buildDivider(),

                    const SizedBox(height: 30),

                    // Manual Input Section
                    _buildManualInputSection(),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
      child: Column(
        children: [
          // Logo
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset(
                'assets/icons/car_icon.svg',
                width: 80,
                height: 80,
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Greeting
          Text(
            'خوش آمدید، ${widget.userName}!',
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFF424242),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'کیا آپ رائیڈ نیک کرنا چاہیں؟',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 15,
              color: Color(0xFF757575),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoiceSection() {
    return Column(
      children: [
        // Voice prompt text
        const Text(
          'اپنی منزل بولیں',
          textDirection: TextDirection.rtl,
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: Color(0xFFC2185B),
          ),
        ),

        const SizedBox(height: 30),

        // Microphone button
        GestureDetector(
          onTap: () {
            Logger.log('👆 BUTTON CLICKED!');
            _toggleListening();
          },
          child: Container(
            width: 150,
            height: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: _isListening
                    ? [const Color(0xFFEC407A), const Color(0xFFF48FB1)]
                    : [const Color(0xFFF48FB1), const Color(0xFFF8BBD0)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFEC407A).withOpacity(0.4),
                  blurRadius: _isListening ? 30 : 20,
                  spreadRadius: _isListening ? 8 : 4,
                ),
              ],
            ),
            child: _isProcessing
                ? const CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 3,
                  )
                : Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 3,
                        strokeAlign: BorderSide.strokeAlignInside,
                      ),
                    ),
                    child: Icon(
                      _isListening ? Icons.stop_rounded : Icons.mic_rounded,
                      size: 70,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),

        const SizedBox(height: 20),

        // Waveform animation
        if (_isListening)
          SizedBox(
            height: 60,
            child: AnimatedBuilder(
              animation: _animationController,
              builder: (context, child) {
                return CustomPaint(
                  painter: WaveformPainter(
                    animation: _animationController.value,
                    isListening: _isListening,
                  ),
                  size: const Size(200, 60),
                );
              },
            ),
          )
        else
          Text(
            _isProcessing
                ? 'پروسیسنگ جاری ہے...'
                : 'مائیکروفون بٹن دبائیں اور بولیں',
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF9E9E9E),
            ),
          ),
      ],
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 1,
            color: const Color(0xFFE0E0E0),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            'یا',
            style: TextStyle(
              fontSize: 18,
              color: Color(0xFF9E9E9E),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: Container(
            height: 1,
            color: const Color(0xFFE0E0E0),
          ),
        ),
      ],
    );
  }

  Widget _buildManualInputSection() {
    return Column(
      children: [
        const Text(
          'لکھ کر بتائیں',
          textDirection: TextDirection.rtl,
          style: TextStyle(
            fontSize: 22,
            color: Color(0xFF424242),
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 20),

        // Source field
        _buildInputField(
          controller: _sourceController,
          hintText: 'شروعاتی جگہ (Source)',
          icon: Icons.location_on,
        ),

        const SizedBox(height: 16),

        // Destination field
        _buildInputField(
          controller: _destinationController,
          hintText: 'منزل (Destination)',
          icon: Icons.flag_rounded,
        ),

        const SizedBox(height: 24),

        // Publish button
        SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: (_isPublishing || _isProcessing) ? null : _publishRide,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFC2185B),
              disabledBackgroundColor: const Color(0xFFC2185B).withOpacity(0.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 4,
              shadowColor: const Color(0xFFC2185B).withOpacity(0.4),
            ),
            child: (_isPublishing || _isProcessing)
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : const Text(
                    'سواری شائع کریں',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        style: const TextStyle(
          fontSize: 16,
          color: Color(0xFF424242),
        ),
        decoration: InputDecoration(
          hintText: hintText,
          hintTextDirection: TextDirection.rtl,
          hintStyle: const TextStyle(
            color: Color(0xFFBDBDBD),
            fontSize: 16,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 18,
          ),
          suffixIcon: Icon(
            icon,
            color: const Color(0xFFEC407A),
            size: 24,
          ),
        ),
      ),
    );
  }
}

class WaveformPainter extends CustomPainter {
  final double animation;
  final bool isListening;

  WaveformPainter({required this.animation, required this.isListening});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..strokeCap = StrokeCap.round;

    const barCount = 7;
    final barWidth = 4.0;
    final spacing = 6.0;
    final totalWidth = (barCount * barWidth) + ((barCount - 1) * spacing);
    final startX = (size.width - totalWidth) / 2;
    final centerY = size.height / 2;

    for (int i = 0; i < barCount; i++) {
      final x = startX + (i * (barWidth + spacing)) + (barWidth / 2);

      final waveOffset = math.sin(
        (i / barCount * math.pi * 2) + (animation * math.pi * 4),
      );

      double barHeight;
      if (isListening) {
        barHeight = (15 + (waveOffset.abs() * 30)).clamp(10.0, 45.0);
      } else {
        barHeight = 10 + (waveOffset.abs() * 5);
      }

      paint.color = const Color(0xFFEC407A);

      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(x, centerY),
            width: barWidth,
            height: barHeight,
          ),
          const Radius.circular(2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(WaveformPainter oldDelegate) {
    return oldDelegate.animation != animation ||
        oldDelegate.isListening != isListening;
  }
}