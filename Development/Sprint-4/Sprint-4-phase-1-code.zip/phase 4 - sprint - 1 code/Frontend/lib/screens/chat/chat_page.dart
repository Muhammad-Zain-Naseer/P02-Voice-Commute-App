import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../../services/socket_service.dart';
import '../../services/encryption_service.dart';
import '../../utils/logger.dart';
import 'package:http/http.dart' as http;


// Conditional imports for platform-specific file operations
import 'file_utils_stub.dart' if (dart.library.io) 'file_utils_mobile.dart';

/// Chat Page for real-time messaging between driver and commuter
class ChatPage extends StatefulWidget {
  final String rideId;
  final String currentUserId;
  final String otherUserName;
  final String userType; // 'driver' or 'commuter'

  const ChatPage({
    super.key,
    required this.rideId,
    required this.currentUserId,
    required this.otherUserName,
    required this.userType,
  });

  /// Get unread count for a specific ride and user
  static int getUnreadCount(String rideId, String userId) {
    return _ChatPageState.getUnreadCountInternal(rideId, userId);
  }

  /// Clear unread count for a specific ride and user
  static void clearUnreadCount(String rideId, String userId) {
    _ChatPageState.clearUnreadCountInternal(rideId, userId);
  }

  /// Register a participant for a ride (call this when ride starts, before chat is opened)
  static void registerParticipant(String rideId, String userId) {
    _ChatPageState.registerParticipantInternal(rideId, userId);
  }

  /// Initialize the global chat listener (call this early in the ride flow)
  static void initializeGlobalListener() {
    _ChatPageState.ensureGlobalListenerSetup();
  }

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();

  bool _isRecording = false;
  String? _currentlyPlayingMessageId;
  DateTime? _recordingStartTime;

  // Static storage for chat messages per ride
  static final Map<String, List<ChatMessage>> _chatStorage = {};

  // Static storage for unread message count per ride per user
  static final Map<String, Map<String, int>> _unreadCounts = {};

  // Track ride participants (rideId -> Set of userIds)
  static final Map<String, Set<String>> _rideParticipants = {};

  // Track which chat windows are currently open (rideId -> Set of userIds viewing)
  static final Map<String, Set<String>> _activeViewers = {};

  // Track mounted ChatPage instances (rideId -> List of state instances)
  static final Map<String, List<_ChatPageState>> _mountedInstances = {};

  // Track if global listener is already set up
  static bool _isGlobalListenerSetup = false;

  List<ChatMessage> get _messages {
    final messages = _chatStorage[widget.rideId] ?? [];
    // Update isMe flag based on current user
    return messages.map((msg) {
      return ChatMessage(
        text: msg.text,
        senderId: msg.senderId,
        senderName: msg.senderName,
        timestamp: msg.timestamp,
        isMe: msg.senderId == widget.currentUserId,
        isVoice: msg.isVoice,
        audioData: msg.audioData,
        duration: msg.duration,
      );
    }).toList();
  }

  /// Get unread count for a specific ride and user (internal method)
  static int getUnreadCountInternal(String rideId, String userId) {
    return _unreadCounts[rideId]?[userId] ?? 0;
  }

  /// Clear unread count for a specific ride and user (internal method)
  static void clearUnreadCountInternal(String rideId, String userId) {
    if (_unreadCounts.containsKey(rideId)) {
      _unreadCounts[rideId]![userId] = 0;
    }
  }

  /// Increment unread count for a specific user (internal method)
  static void _incrementUnreadCount(String rideId, String userId) {
    if (!_unreadCounts.containsKey(rideId)) {
      _unreadCounts[rideId] = {};
    }
    _unreadCounts[rideId]![userId] = (_unreadCounts[rideId]![userId] ?? 0) + 1;
    Logger.log(
      '📬 Incremented unread count for user $userId in ride $rideId: ${_unreadCounts[rideId]![userId]}',
    );
  }

  /// Register a participant internally (can be called before chat is opened)
  static void registerParticipantInternal(String rideId, String userId) {
    if (!_rideParticipants.containsKey(rideId)) {
      _rideParticipants[rideId] = {};
    }
    _rideParticipants[rideId]!.add(userId);
    Logger.log('👥 Registered user $userId as participant for ride $rideId');

    // Also ensure the global listener is set up
    ensureGlobalListenerSetup();
  }

  /// Ensure global listener is set up (can be called multiple times safely)
  static void ensureGlobalListenerSetup() {
    if (_isGlobalListenerSetup) {
      return;
    }

    Logger.log('👂 Setting up GLOBAL chat message listener');
    _isGlobalListenerSetup = true;

    // Remove existing listener first to avoid duplicates
    if (SocketService.socket != null) {
      SocketService.socket!.off('chat:message');
    }

    SocketService.onChatMessage((message) {
      Logger.log('💬 Chat message received: $message');

      // Get the ride ID from the message
      final messageRideId = message['rideId'] as String;
      final senderId = message['senderId'] as String;

      // Decrypt message if encrypted
      String messageText = message['message'] as String;
      final isEncrypted = message['encrypted'] == true;

      if (isEncrypted && EncryptionService.hasSessionKey) {
        final iv = message['iv'] as String?;
        final authTag = message['authTag'] as String?;

        if (iv != null) {
          final decrypted = EncryptionService.decryptMessage(messageText, iv, authTag);
          if (decrypted != null) {
            messageText = decrypted;
            Logger.log('🔓 Message decrypted successfully');
          } else {
            Logger.error('❌ Failed to decrypt message');
            messageText = '[Encrypted message - unable to decrypt]';
          }
        }
      }

      // Add to static storage for the appropriate ride
      final newMessage = ChatMessage(
        text: messageText,
        senderId: senderId,
        senderName: message['senderName'] as String,
        timestamp: DateTime.now(),
        isMe: false, // Will be determined by each user individually
        isVoice: false,
      );

      if (!_chatStorage.containsKey(messageRideId)) {
        _chatStorage[messageRideId] = [];
      }
      _chatStorage[messageRideId]!.add(newMessage);

      // Increment unread count for ALL participants in this ride (except sender and active viewers)
      if (_rideParticipants.containsKey(messageRideId)) {
        final activeViewersForRide = _activeViewers[messageRideId] ?? {};

        for (String userId in _rideParticipants[messageRideId]!) {
          // Don't increment if user is sender or actively viewing the chat
          if (userId != senderId && !activeViewersForRide.contains(userId)) {
            _incrementUnreadCount(messageRideId, userId);
          } else if (activeViewersForRide.contains(userId)) {
            Logger.log(
              '👁️ User $userId is viewing chat, not incrementing unread count',
            );
          }
        }
      } else {
        // If no participants registered yet, we'll increment generically
        // The count will be assigned when the user checks
        Logger.log('⚠️ No participants registered for ride $messageRideId yet');
      }

      // Update UI for all mounted ChatPage instances for this ride
      if (_mountedInstances.containsKey(messageRideId)) {
        for (var instance in _mountedInstances[messageRideId]!) {
          if (instance.mounted) {
            instance.setState(() {});
            instance._scrollToBottom();
            Logger.log('🔄 Updated UI for mounted ChatPage instance');
          }
        }
      }

      Logger.log(
        '📬 Message stored for ride: $messageRideId from sender: $senderId',
      );
    });

    // Setup voice message listener
    if (SocketService.socket != null) {
      SocketService.socket!.off('chat:voice');
    }

    SocketService.onVoiceMessage((voiceMessage) {
      Logger.log('🎤 Voice message received: $voiceMessage');

      // Get the ride ID from the message
      final messageRideId = voiceMessage['rideId'] as String;
      final senderId = voiceMessage['senderId'] as String;

      // Decrypt audio if encrypted
      String audioData = voiceMessage['audioData'] as String;
      final isEncrypted = voiceMessage['encrypted'] == true;

      if (isEncrypted && EncryptionService.hasSessionKey) {
        final iv = voiceMessage['iv'] as String?;
        final authTag = voiceMessage['authTag'] as String?;

        if (iv != null) {
          final decrypted = EncryptionService.decryptBinary(audioData, iv, authTag);
          if (decrypted != null) {
            audioData = decrypted;
            Logger.log('🔓 Voice message decrypted successfully');
          } else {
            Logger.error('❌ Failed to decrypt voice message');
          }
        }
      }

      // Add to static storage for the appropriate ride
      final newMessage = ChatMessage(
        text: '[Voice Message]',
        senderId: senderId,
        senderName: voiceMessage['senderName'] as String,
        timestamp: DateTime.now(),
        isMe: false, // Will be determined by each user individually
        isVoice: true,
        audioData: audioData,
        duration: voiceMessage['duration'] as int?,
      );

      if (!_chatStorage.containsKey(messageRideId)) {
        _chatStorage[messageRideId] = [];
      }
      _chatStorage[messageRideId]!.add(newMessage);

      // Increment unread count for ALL participants in this ride (except sender and active viewers)
      if (_rideParticipants.containsKey(messageRideId)) {
        final activeViewersForRide = _activeViewers[messageRideId] ?? {};

        for (String userId in _rideParticipants[messageRideId]!) {
          // Don't increment if user is sender or actively viewing the chat
          if (userId != senderId && !activeViewersForRide.contains(userId)) {
            _incrementUnreadCount(messageRideId, userId);
          } else if (activeViewersForRide.contains(userId)) {
            Logger.log(
              '👁️ User $userId is viewing chat, not incrementing unread count',
            );
          }
        }
      }

      // Update UI for all mounted ChatPage instances for this ride
      if (_mountedInstances.containsKey(messageRideId)) {
        for (var instance in _mountedInstances[messageRideId]!) {
          if (instance.mounted) {
            instance.setState(() {});
            instance._scrollToBottom();
            Logger.log('🔄 Updated UI for voice message');
          }
        }
      }

      Logger.log(
        '🎤 Voice message stored for ride: $messageRideId from sender: $senderId',
      );
    });

    Logger.log('✅ Global chat listener setup complete');
  }

  @override
  void initState() {
    super.initState();
    // Initialize storage for this ride if not exists
    if (!_chatStorage.containsKey(widget.rideId)) {
      _chatStorage[widget.rideId] = [];
    }

    // Initialize unread count storage
    if (!_unreadCounts.containsKey(widget.rideId)) {
      _unreadCounts[widget.rideId] = {};
    }

    // Register this user as a participant in the ride
    if (!_rideParticipants.containsKey(widget.rideId)) {
      _rideParticipants[widget.rideId] = {};
    }
    _rideParticipants[widget.rideId]!.add(widget.currentUserId);
    Logger.log(
      '👥 Registered user ${widget.currentUserId} for ride ${widget.rideId}',
    );

    // Register as active viewer (chat window is open)
    if (!_activeViewers.containsKey(widget.rideId)) {
      _activeViewers[widget.rideId] = {};
    }
    _activeViewers[widget.rideId]!.add(widget.currentUserId);
    Logger.log(
      '👁️ User ${widget.currentUserId} is now viewing chat for ride ${widget.rideId}',
    );

    // Register this instance as mounted
    if (!_mountedInstances.containsKey(widget.rideId)) {
      _mountedInstances[widget.rideId] = [];
    }
    _mountedInstances[widget.rideId]!.add(this);
    Logger.log('📱 Registered ChatPage instance for ride ${widget.rideId}');

    // Clear unread count when opening chat
    clearUnreadCountInternal(widget.rideId, widget.currentUserId);

    _setupChatListener();

    // Scroll to bottom after build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _audioRecorder.dispose();
    _audioPlayer.dispose();

    // Unregister as active viewer (chat window is closing)
    if (_activeViewers.containsKey(widget.rideId)) {
      _activeViewers[widget.rideId]!.remove(widget.currentUserId);
      Logger.log(
        '👁️ User ${widget.currentUserId} stopped viewing chat for ride ${widget.rideId}',
      );
    }

    // Unregister this instance
    if (_mountedInstances.containsKey(widget.rideId)) {
      _mountedInstances[widget.rideId]!.remove(this);
      Logger.log('📱 Unregistered ChatPage instance for ride ${widget.rideId}');
    }

    // DO NOT remove chat listener when leaving - keep it active for background messages
    // The listener should remain active for the entire ride duration
    Logger.log('🗑️ Disposing ChatPage - keeping chat:message listener active');
    super.dispose();
  }

  /// Setup listener for incoming chat messages (delegates to static method)
  void _setupChatListener() {
    ensureGlobalListenerSetup();
  }

  /// Scroll to bottom of chat
  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  /// Send a text message
  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    Logger.log('📤 Sending chat message: $text');

    // Add to static storage immediately
    final newMessage = ChatMessage(
      text: text,
      senderId: widget.currentUserId,
      senderName: widget.userType == 'driver'
          ? 'You (Driver)'
          : 'You (Commuter)',
      timestamp: DateTime.now(),
      isMe: true,
    );

    if (!_chatStorage.containsKey(widget.rideId)) {
      _chatStorage[widget.rideId] = [];
    }
    _chatStorage[widget.rideId]!.add(newMessage);

    // Update UI
    setState(() {});

    // Emit to socket
    SocketService.sendChatMessage(
      rideId: widget.rideId,
      message: text,
      senderId: widget.currentUserId,
      senderName: widget.userType == 'driver' ? 'Driver' : 'Commuter',
    );

    // Clear input
    _messageController.clear();

    // Scroll to bottom
    _scrollToBottom();
  }

  /// Get temporary file path for mobile (helper to avoid calling on web)
  Future<String> _getMobileRecordingPath() async {
    if (kIsWeb) {
      throw UnsupportedError('File path not supported on web');
    }
    final tempDir = await getTemporaryDirectory();
    return '${tempDir.path}/voice_message_${DateTime.now().millisecondsSinceEpoch}.m4a';
  }

  /// Start recording voice message
  Future<void> _startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        if (kIsWeb) {
          // Web recording - no path needed, recorder handles it internally
          await _audioRecorder.start(
            const RecordConfig(
              encoder: AudioEncoder.wav,
              numChannels: 1,
              sampleRate: 16000,
            ),
            path: 'voice_message_${DateTime.now().millisecondsSinceEpoch}.wav',
          );
        } else {
          // Mobile recording - use actual file path
          final filePath = await _getMobileRecordingPath();

          await _audioRecorder.start(
            const RecordConfig(
              encoder: AudioEncoder.aacLc,
              numChannels: 1,
              sampleRate: 16000,
            ),
            path: filePath,
          );
        }

        setState(() {
          _isRecording = true;
          _recordingStartTime = DateTime.now();
        });

        Logger.log('🎤 Started recording voice message');
      } else {
        Logger.error('❌ Microphone permission denied');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Microphone permission is required for voice messages',
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      Logger.error('❌ Failed to start recording: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to start recording: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Read audio bytes from file on mobile (helper to avoid calling on web)
  Future<List<int>> _readMobileAudioFile(String path) async {
    if (kIsWeb) {
      throw UnsupportedError('File reading not supported on web');
    }
    final audioFile = File(path);
    final bytes = await audioFile.readAsBytes();
    await audioFile.delete(); // Clean up temp file
    return bytes;
  }

  /// Stop recording and send voice message
  Future<void> _stopRecordingAndSend() async {
    try {
      final path = await _audioRecorder.stop();

      if (path != null) {
        final duration = _recordingStartTime != null
            ? DateTime.now().difference(_recordingStartTime!).inSeconds
            : 0;

        late final List<int> audioBytes;

        if (kIsWeb) {
          final response = await http.get(Uri.parse(path));
          audioBytes = response.bodyBytes;
        } else {
          audioBytes = await _readMobileAudioFile(path);
        }

        final audioData = base64Encode(audioBytes);

        Logger.log(
          '🎤 Stopped recording. Duration: ${duration}s, Size: ${audioBytes.length} bytes',
        );

        // Add to local storage immediately
        final newMessage = ChatMessage(
          text: '[Voice Message]',
          senderId: widget.currentUserId,
          senderName: widget.userType == 'driver'
              ? 'You (Driver)'
              : 'You (Commuter)',
          timestamp: DateTime.now(),
          isMe: true,
          isVoice: true,
          audioData: audioData,
          duration: duration,
        );

        if (!_chatStorage.containsKey(widget.rideId)) {
          _chatStorage[widget.rideId] = [];
        }
        _chatStorage[widget.rideId]!.add(newMessage);

        // Update UI
        setState(() {
          _isRecording = false;
          _recordingStartTime = null;
        });

        // Send via socket
        SocketService.sendVoiceMessage(
          rideId: widget.rideId,
          audioData: audioData,
          duration: duration,
          senderId: widget.currentUserId,
          senderName: widget.userType == 'driver' ? 'Driver' : 'Commuter',
        );

        // Scroll to bottom
        _scrollToBottom();
      }
    } catch (e) {
      Logger.error('❌ Failed to stop recording: $e');
      setState(() {
        _isRecording = false;
        _recordingStartTime = null;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send voice message: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Delete mobile audio file (helper to avoid calling on web)
  Future<void> _deleteMobileAudioFile(String path) async {
    if (kIsWeb) {
      return; // No file to delete on web
    }
    final audioFile = File(path);
    await audioFile.delete();
  }

  /// Cancel recording without sending
  Future<void> _cancelRecording() async {
    try {
      final path = await _audioRecorder.stop();
      if (path != null && !kIsWeb) {
        // Only delete file on mobile (web doesn't use files)
        await _deleteMobileAudioFile(path);
      }

      setState(() {
        _isRecording = false;
        _recordingStartTime = null;
      });

      Logger.log('🎤 Recording cancelled');
    } catch (e) {
      Logger.error('❌ Failed to cancel recording: $e');
    }
  }

  /// Write and play audio file on mobile (helper to avoid calling on web)
  Future<String> _writeMobilePlaybackFile(List<int> audioBytes) async {
    if (kIsWeb) {
      throw UnsupportedError('File writing not supported on web');
    }
    final tempDir = await getTemporaryDirectory();
    final tempFile = File(
      '${tempDir.path}/playback_${DateTime.now().millisecondsSinceEpoch}.m4a',
    );
    await tempFile.writeAsBytes(audioBytes);
    return tempFile.path;
  }

  /// Delete mobile playback file (helper to avoid calling on web)
  Future<void> _deleteMobilePlaybackFile(String path) async {
    if (kIsWeb) {
      return;
    }
    final tempFile = File(path);
    await tempFile.delete();
  }

  /// Play a voice message
  Future<void> _playVoiceMessage(ChatMessage message) async {
    try {
      if (message.audioData == null) return;

      // Stop any currently playing audio
      await _audioPlayer.stop();

      // If this message is already playing, stop it
      if (_currentlyPlayingMessageId ==
          '${message.senderId}_${message.timestamp}') {
        setState(() {
          _currentlyPlayingMessageId = null;
        });
        return;
      }

      // Decode base64 to bytes
      final audioBytes = base64Decode(message.audioData!);

      // Play the audio
      setState(() {
        _currentlyPlayingMessageId = '${message.senderId}_${message.timestamp}';
      });

      if (kIsWeb) {
        // On web, play from bytes directly
        await _audioPlayer.play(BytesSource(audioBytes));
      } else {
        // On mobile, write to temporary file first
        final tempFilePath = await _writeMobilePlaybackFile(audioBytes);
        await _audioPlayer.play(DeviceFileSource(tempFilePath));

        // Clean up after playback
        _audioPlayer.onPlayerComplete.listen((_) async {
          await _deleteMobilePlaybackFile(tempFilePath);
        });
      }

      // Listen for completion to reset UI
      _audioPlayer.onPlayerComplete.listen((_) {
        if (mounted) {
          setState(() {
            _currentlyPlayingMessageId = null;
          });
        }
      });

      Logger.log('🔊 Playing voice message');
    } catch (e) {
      Logger.error('❌ Failed to play voice message: $e');
      if (mounted) {
        setState(() {
          _currentlyPlayingMessageId = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to play voice message: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chat with ${widget.otherUserName}',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFFCF4374),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: Column(
          children: [
            // Messages List
            Expanded(
              child: _messages.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.chat_bubble_outline,
                            size: 80,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No messages yet',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey[600],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Send a message to start the conversation',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(16),
                      itemCount: _messages.length,
                      itemBuilder: (context, index) {
                        final message = _messages[index];
                        return _buildMessageBubble(message);
                      },
                    ),
            ),

            // Message Input Area
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: _isRecording
                    ? Row(
                        children: [
                          // Cancel button
                          GestureDetector(
                            onTap: _cancelRecording,
                            child: Container(
                              width: 50,
                              height: 50,
                              decoration: const BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.close,
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Recording indicator
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 15,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFCE4EC),
                                borderRadius: BorderRadius.circular(25),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 12,
                                    height: 12,
                                    decoration: const BoxDecoration(
                                      color: Colors.red,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  const Text(
                                    'Recording...',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Send button
                          GestureDetector(
                            onTap: _stopRecordingAndSend,
                            child: Container(
                              width: 50,
                              height: 50,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFFF48FB1),
                                    Color(0xFFCF4374),
                                  ],
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.send,
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ],
                      )
                    : Row(
                        children: [
                          // Voice message button
                          GestureDetector(
                            onTap: _startRecording,
                            child: Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: const Color(0xFFFCE4EC),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: const Color(0xFFCF4374),
                                  width: 2,
                                ),
                              ),
                              child: const Icon(
                                Icons.mic,
                                color: Color(0xFFCF4374),
                                size: 24,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Text input
                          Expanded(
                            child: TextField(
                              controller: _messageController,
                              decoration: InputDecoration(
                                hintText: 'Type a message...',
                                filled: true,
                                fillColor: const Color(0xFFFCE4EC),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(25),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20,
                                  vertical: 10,
                                ),
                              ),
                              maxLines: null,
                              textInputAction: TextInputAction.send,
                              onSubmitted: (_) => _sendMessage(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Send text button
                          GestureDetector(
                            onTap: _sendMessage,
                            child: Container(
                              width: 50,
                              height: 50,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFFF48FB1),
                                    Color(0xFFCF4374),
                                  ],
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.send,
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: message.isMe
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: [
          if (!message.isMe) ...[
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Color(0xFFCF4374),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.person, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: message.isMe ? const Color(0xFFCF4374) : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(message.isMe ? 20 : 0),
                  bottomRight: Radius.circular(message.isMe ? 0 : 20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!message.isMe)
                    Text(
                      message.senderName,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  if (!message.isMe) const SizedBox(height: 4),

                  // Voice message or text message
                  if (message.isVoice)
                    GestureDetector(
                      onTap: () => _playVoiceMessage(message),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: message.isMe
                              ? Colors.white.withValues(alpha: 0.2)
                              : const Color(0xFFFCE4EC),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _currentlyPlayingMessageId ==
                                      '${message.senderId}_${message.timestamp}'
                                  ? Icons.pause_circle
                                  : Icons.play_circle,
                              color: message.isMe
                                  ? Colors.white
                                  : const Color(0xFFCF4374),
                              size: 32,
                            ),
                            const SizedBox(width: 8),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Voice Message',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                    color: message.isMe
                                        ? Colors.white
                                        : Colors.black87,
                                  ),
                                ),
                                Text(
                                  '${message.duration ?? 0}s',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: message.isMe
                                        ? Colors.white.withValues(alpha: 0.8)
                                        : Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    Text(
                      message.text,
                      style: TextStyle(
                        fontSize: 16,
                        color: message.isMe ? Colors.white : Colors.black87,
                      ),
                    ),

                  const SizedBox(height: 4),
                  Text(
                    _formatTime(message.timestamp),
                    style: TextStyle(
                      fontSize: 11,
                      color: message.isMe
                          ? Colors.white.withValues(alpha: 0.7)
                          : Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (message.isMe) ...[
            const SizedBox(width: 8),
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Color(0xFFCF4374),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.person, color: Colors.white, size: 24),
            ),
          ],
        ],
      ),
    );
  }

  String _formatTime(DateTime timestamp) {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}

/// Chat Message Model
class ChatMessage {
  final String text;
  final String senderId;
  final String senderName;
  final DateTime timestamp;
  final bool isMe;
  final bool isVoice; // true if this is a voice message
  final String? audioData; // base64 encoded audio data for voice messages
  final int? duration; // duration in seconds for voice messages

  ChatMessage({
    required this.text,
    required this.senderId,
    required this.senderName,
    required this.timestamp,
    required this.isMe,
    this.isVoice = false,
    this.audioData,
    this.duration,
  });
}
