class TripNotification {
  final String id;
  final String type; // RIDE_STARTED, RIDE_COMPLETED, SOS_ALERT
  final String commuterName;
  final String commuterEmail;
  final DateTime timestamp;
  final RideData ride;
  final bool isRead;

  TripNotification({
    required this.id,
    required this.type,
    required this.commuterName,
    required this.commuterEmail,
    required this.timestamp,
    required this.ride,
    this.isRead = false,
  });

  factory TripNotification.fromJson(Map<String, dynamic> json) {
    return TripNotification(
      id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      type: json['type'] ?? '',
      commuterName: json['commuterName'] ?? '',
      commuterEmail: json['commuterEmail'] ?? '',
      timestamp: DateTime.parse(json['timestamp'] ?? DateTime.now().toIso8601String()),
      ride: RideData.fromJson(json['ride'] ?? {}),
      isRead: json['isRead'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'commuterName': commuterName,
      'commuterEmail': commuterEmail,
      'timestamp': timestamp.toIso8601String(),
      'ride': ride.toJson(),
      'isRead': isRead,
    };
  }

  TripNotification copyWith({bool? isRead}) {
    return TripNotification(
      id: id,
      type: type,
      commuterName: commuterName,
      commuterEmail: commuterEmail,
      timestamp: timestamp,
      ride: ride,
      isRead: isRead ?? this.isRead,
    );
  }

  String get title {
    switch (type) {
      case 'RIDE_STARTED':
        return '$commuterName کی سواری شروع ہو رہی ہے';
      case 'RIDE_COMPLETED':
        return '$commuterName کی سواری مکمل ہو گئی';
      case 'SOS_ALERT':
        return '🚨 ایمرجنسی! $commuterName نے SOS دبایا';
      default:
        return 'نئی اطلاع';
    }
  }

  String get description {
    switch (type) {
      case 'RIDE_STARTED':
        return '${ride.source.address} سے ${ride.destination.address}';
      case 'RIDE_COMPLETED':
        return 'سواری محفوظ طریقے سے مکمل ہوئی';
      case 'SOS_ALERT':
        return 'فوری مدد کی ضرورت ہے! ${ride.source.address}';
      default:
        return '';
    }
  }
}

class RideData {
  final String rideId;
  final LocationInfo source;
  final LocationInfo destination;
  final String? driverName;
  final String status;
  final SOSAlert? sosAlert;

  RideData({
    required this.rideId,
    required this.source,
    required this.destination,
    this.driverName,
    required this.status,
    this.sosAlert,
  });

  factory RideData.fromJson(Map<String, dynamic> json) {
    return RideData(
      rideId: json['rideId'] ?? '',
      source: LocationInfo.fromJson(json['source'] ?? {}),
      destination: LocationInfo.fromJson(json['destination'] ?? {}),
      driverName: json['driverName'],
      status: json['status'] ?? '',
      sosAlert: json['sosAlert'] != null ? SOSAlert.fromJson(json['sosAlert']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'rideId': rideId,
      'source': source.toJson(),
      'destination': destination.toJson(),
      'driverName': driverName,
      'status': status,
      'sosAlert': sosAlert?.toJson(),
    };
  }
}

class LocationInfo {
  final String address;
  final Coordinates? coordinates;

  LocationInfo({required this.address, this.coordinates});

  factory LocationInfo.fromJson(Map<String, dynamic> json) {
    return LocationInfo(
      address: json['address'] ?? '',
      coordinates: json['coordinates'] != null
          ? Coordinates.fromJson(json['coordinates'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'coordinates': coordinates?.toJson(),
    };
  }
}

class Coordinates {
  final double lat;
  final double lon;

  Coordinates({required this.lat, required this.lon});

  factory Coordinates.fromJson(Map<String, dynamic> json) {
    return Coordinates(
      lat: (json['lat'] ?? 0).toDouble(),
      lon: (json['lon'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {'lat': lat, 'lon': lon};
  }
}

class SOSAlert {
  final String triggeredBy;
  final String? message;
  final DateTime triggeredAt;

  SOSAlert({
    required this.triggeredBy,
    this.message,
    required this.triggeredAt,
  });

  factory SOSAlert.fromJson(Map<String, dynamic> json) {
    return SOSAlert(
      triggeredBy: json['triggeredBy'] ?? '',
      message: json['message'],
      triggeredAt: DateTime.parse(json['triggeredAt'] ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'triggeredBy': triggeredBy,
      'message': message,
      'triggeredAt': triggeredAt.toIso8601String(),
    };
  }
}
