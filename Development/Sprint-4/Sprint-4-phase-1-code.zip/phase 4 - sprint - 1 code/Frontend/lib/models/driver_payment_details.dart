/// Model for driver payment account details
class DriverPaymentDetails {
  final String easyPaisaAccountTitle;
  final String easyPaisaAccountNumber;
  final String jazzCashAccountTitle;
  final String jazzCashAccountNumber;

  DriverPaymentDetails({
    this.easyPaisaAccountTitle = '',
    this.easyPaisaAccountNumber = '',
    this.jazzCashAccountTitle = '',
    this.jazzCashAccountNumber = '',
  });

  /// Create from JSON received from backend
  factory DriverPaymentDetails.fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return DriverPaymentDetails();
    }

    final easyPaisa = json['easyPaisa'] as Map<String, dynamic>?;
    final jazzCash = json['jazzCash'] as Map<String, dynamic>?;

    return DriverPaymentDetails(
      easyPaisaAccountTitle: easyPaisa?['accountTitle'] as String? ?? '',
      easyPaisaAccountNumber: easyPaisa?['accountNumber'] as String? ?? '',
      jazzCashAccountTitle: jazzCash?['accountTitle'] as String? ?? '',
      jazzCashAccountNumber: jazzCash?['accountNumber'] as String? ?? '',
    );
  }

  /// Check if has any EasyPaisa account details
  bool get hasEasyPaisaAccount =>
      easyPaisaAccountTitle.isNotEmpty && easyPaisaAccountNumber.isNotEmpty;

  /// Check if has any JazzCash account details
  bool get hasJazzCashAccount =>
      jazzCashAccountTitle.isNotEmpty && jazzCashAccountNumber.isNotEmpty;

  /// Check if has any payment account details
  bool get hasAnyAccount => hasEasyPaisaAccount || hasJazzCashAccount;

  @override
  String toString() {
    return 'DriverPaymentDetails(easyPaisa: $easyPaisaAccountTitle/$easyPaisaAccountNumber, jazzCash: $jazzCashAccountTitle/$jazzCashAccountNumber)';
  }
}
