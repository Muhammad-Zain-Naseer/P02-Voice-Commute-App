// Stub for non-web platforms
class JsObject {
  dynamic operator [](String key) => null;
  void operator []=(String key, dynamic value) {}
  dynamic callMethod(String method, [List? args]) => null;
}

final JsObject context = JsObject();