/**
 * Migration Script: Move Payment Accounts from User Model to Driver Model
 *
 * This script migrates paymentAccounts data from the User model to the Driver model.
 * It should be run once after deploying the model changes.
 *
 * Usage: node scripts/migratePaymentAccounts.js
 */

import mongoose from "mongoose";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from parent directory
dotenv.config({ path: path.join(__dirname, "..", ".env") });

import User from "../src/models/User.js";
import Driver from "../src/models/Driver.js";

const migratePaymentAccounts = async () => {
  try {
    console.log("🔄 Starting payment accounts migration...\n");

    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI;
    if (!mongoUri) {
      throw new Error("MONGODB_URI environment variable is not set");
    }

    await mongoose.connect(mongoUri);
    console.log("✅ Connected to MongoDB\n");

    // Find all users with role 'driver' that have payment accounts
    const driversWithPayments = await User.find({
      role: "driver",
      $or: [
        {
          "paymentAccounts.easyPaisa.accountNumber": { $exists: true, $ne: "" }
        },
        { "paymentAccounts.jazzCash.accountNumber": { $exists: true, $ne: "" } }
      ]
    }).lean();

    console.log(
      `📊 Found ${driversWithPayments.length} drivers with payment accounts in User model\n`
    );

    if (driversWithPayments.length === 0) {
      console.log(
        "✅ No drivers with payment accounts to migrate. Migration complete!\n"
      );
      await mongoose.connection.close();
      return;
    }

    let migrated = 0;
    let skipped = 0;
    let errors = 0;

    for (const user of driversWithPayments) {
      try {
        // Find corresponding driver record
        const driver = await Driver.findOne({ userId: user.userId });

        if (!driver) {
          console.log(
            `⚠️  No Driver record found for user: ${user.userId} (${user.email})`
          );
          skipped++;
          continue;
        }

        // Check if driver already has payment accounts (to avoid overwriting)
        const hasExistingAccounts =
          driver.paymentAccounts?.easyPaisa?.accountNumber ||
          driver.paymentAccounts?.jazzCash?.accountNumber;

        if (hasExistingAccounts) {
          console.log(
            `⏭️  Driver ${user.userId} already has payment accounts, skipping...`
          );
          skipped++;
          continue;
        }

        // Migrate payment accounts from User to Driver
        driver.paymentAccounts = {
          easyPaisa: {
            accountTitle: user.paymentAccounts?.easyPaisa?.accountTitle || "",
            accountNumber: user.paymentAccounts?.easyPaisa?.accountNumber || "",
            isVerified: false,
            verifiedAt: null,
            verifiedBy: null
          },
          jazzCash: {
            accountTitle: user.paymentAccounts?.jazzCash?.accountTitle || "",
            accountNumber: user.paymentAccounts?.jazzCash?.accountNumber || "",
            isVerified: false,
            verifiedAt: null,
            verifiedBy: null
          }
        };
        driver.paymentAccountsUpdatedAt = new Date();

        await driver.save();

        // Clear payment accounts from User model
        await User.updateOne(
          { userId: user.userId },
          { $unset: { paymentAccounts: "" } }
        );

        console.log(
          `✅ Migrated payment accounts for driver: ${user.userId} (${user.email})`
        );
        migrated++;
      } catch (error) {
        console.error(
          `❌ Error migrating driver ${user.userId}:`,
          error.message
        );
        errors++;
      }
    }

    console.log("\n" + "=".repeat(60));
    console.log("📋 MIGRATION SUMMARY");
    console.log("=".repeat(60));
    console.log(`✅ Successfully migrated: ${migrated}`);
    console.log(`⏭️  Skipped: ${skipped}`);
    console.log(`❌ Errors: ${errors}`);
    console.log(`📊 Total processed: ${driversWithPayments.length}`);
    console.log("=".repeat(60) + "\n");

    if (migrated > 0) {
      console.log("✅ Migration completed successfully!\n");
      console.log("📝 Next steps:");
      console.log("   1. Verify the migrated data in the Driver collection");
      console.log("   2. Test payment flow with migrated drivers");
      console.log(
        "   3. Restart backend server to ensure changes take effect\n"
      );
    } else {
      console.log("ℹ️  No new data was migrated.\n");
    }

    await mongoose.connection.close();
    console.log("🔌 Disconnected from MongoDB\n");
  } catch (error) {
    console.error("\n❌ Migration failed:", error);
    console.error(error.stack);
    process.exit(1);
  }
};

// Run migration
migratePaymentAccounts();
