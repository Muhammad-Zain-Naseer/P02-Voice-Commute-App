/**
 * HerSafar – Use Case 4: Book a Ride
 * =====================================
 * Route   : POST /api/rides
 * Techniques:
 *   T01 – ECP Valid Class         (source + destination → 201 ride created)
 *   T02 – ECP Invalid Class       (missing source → 400)
 *   T03 – ECP Invalid Class       (missing destination → 400)
 *   T04 – BVA Lower Boundary      (empty-string source → 400)
 *   T05 – Pairwise                (all optional fields + coordinates → 201)
 */

import request from "supertest";
import app from "../src/app/testApp.js";
import Ride from "../src/models/Ride.js";
import mongoose from "mongoose";

const BASE = "/api/rides";

const createdRideIds = [];

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
});

afterAll(async () => {
  // Clean up rides created during tests
  if (createdRideIds.length > 0) {
    await Ride.deleteMany({ rideId: { $in: createdRideIds } });
  }
  await mongoose.connection.close();
});

describe("UC-04 | Book a Ride – POST /api/rides", () => {

  // ── T01 – ECP Valid Class ───────────────────────────────────────────────
  test("T01 [ECP – Valid Class] Valid source + destination → 201 ride created", async () => {
    const res = await request(app)
      .post(BASE)
      .send({
        source                : "NUST H-12, Islamabad",
        destination           : "Blue Area, Islamabad",
        sourceCoordinates     : { type: "Point", coordinates: [73.1356, 33.6428] },
        destinationCoordinates: { type: "Point", coordinates: [73.0479, 33.7088] },
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.ride).toBeDefined();
    expect(res.body.data.ride.id).toBeDefined();
    expect(res.body.data.ride.status).toBe("pending");
    expect(res.body.data.ride.source.address).toBe("NUST H-12, Islamabad");
    expect(res.body.data.ride.destination.address).toBe("Blue Area, Islamabad");

    createdRideIds.push(res.body.data.ride.id);
  });

  // ── T02 – ECP Invalid Class ─────────────────────────────────────────────
  test("T02 [ECP – Invalid Class] Missing source → 400 validation error", async () => {
    const res = await request(app)
      .post(BASE)
      .send({
        destination: { address: "Blue Area, Islamabad" },
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/source and destination are required/i);
  });

  // ── T03 – ECP Invalid Class ─────────────────────────────────────────────
  test("T03 [ECP – Invalid Class] Missing destination → 400 validation error", async () => {
    const res = await request(app)
      .post(BASE)
      .send({
        source: { address: "NUST H-12, Islamabad" },
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/source and destination are required/i);
  });

  // ── T04 – BVA Lower Boundary ────────────────────────────────────────────
  test("T04 [BVA – Lower Boundary] Empty-string source → 400 validation error", async () => {
    const res = await request(app)
      .post(BASE)
      .send({
        source     : "",
        destination: { address: "Blue Area, Islamabad" },
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/source and destination are required/i);
  });

  // ── T05 – Pairwise ──────────────────────────────────────────────────────
  test("T05 [Pairwise] All optional fields + coordinates → 201 ride persisted", async () => {
    const res = await request(app)
      .post(BASE)
      .send({
        userId              : "user_test_001",
        userName            : "Sara Khan",
        userEmail           : "sara@hersafar.test",
        source              : "NUST H-12, Islamabad",
        destination         : "Centaurus Mall, Islamabad",
        sourceCoordinates      : { type: "Point", coordinates: [73.1356, 33.6428] },
        destinationCoordinates : { type: "Point", coordinates: [73.0479, 33.7088] },
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.ride.userId).toBe("user_test_001");
    expect(res.body.data.ride.userName).toBe("Sara Khan");
    expect(res.body.data.ride.status).toBe("pending");

    createdRideIds.push(res.body.data.ride.id);

    // DB: ride persisted
    const dbRide = await Ride.findOne({ rideId: res.body.data.ride.id });
    expect(dbRide).not.toBeNull();
    expect(dbRide.userId).toBe("user_test_001");
  });

});
