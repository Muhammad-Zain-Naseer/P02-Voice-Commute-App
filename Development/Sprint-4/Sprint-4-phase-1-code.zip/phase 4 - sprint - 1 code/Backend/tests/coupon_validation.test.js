/**
 * HerSafar – Use Case 6: Coupon Validation
 * ==========================================
 * Route   : POST /api/coupons/validate  (public)
 * Techniques:
 *   T01 – ECP Valid Class         (active coupon code → 200 + discount data)
 *   T02 – ECP Invalid Class       (non-existent code → 404)
 *   T03 – ECP Invalid Class       (missing code field → 400)
 *   T04 – BVA State Boundary      (inactive coupon → 400)
 *   T05 – BVA State Boundary      (expired coupon → 400)
 */

import request from "supertest";
import app from "../src/app/testApp.js";
import Coupon from "../src/models/Coupon.js";
import mongoose from "mongoose";

const BASE = "/api/coupons";

const TEST_CODES = ["TESTACTIVE10", "TESTINACTIVE20", "TESTEXPIRED30"];

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await Coupon.deleteMany({ code: { $in: TEST_CODES } });

  // Active coupon – valid for T01
  await Coupon.create({
    code: "TESTACTIVE10",
    discountPercentage: 10,
    description: "Test active coupon",
    isActive: true,
  });

  // Inactive coupon – for T04
  await Coupon.create({
    code: "TESTINACTIVE20",
    discountPercentage: 20,
    description: "Test inactive coupon",
    isActive: false,
  });

  // Expired coupon – expiryDate 1 second in the past for T05
  await Coupon.create({
    code: "TESTEXPIRED30",
    discountPercentage: 30,
    description: "Test expired coupon",
    isActive: true,
    expiryDate: new Date(Date.now() - 1000),
  });
});

afterAll(async () => {
  await Coupon.deleteMany({ code: { $in: TEST_CODES } });
  await mongoose.connection.close();
});

describe("UC-06 | Coupon Validation – POST /api/coupons/validate", () => {

  // ── T01 – ECP Valid Class ───────────────────────────────────────────────
  test("T01 [ECP – Valid Class] Active coupon code → 200 with discount data", async () => {
    const res = await request(app)
      .post(`${BASE}/validate`)
      .send({ code: "TESTACTIVE10" });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeDefined();
    expect(res.body.data.code).toBe("TESTACTIVE10");
    expect(res.body.data.discountPercentage).toBe(10);
  });

  // ── T02 – ECP Invalid Class ─────────────────────────────────────────────
  test("T02 [ECP – Invalid Class] Non-existent code → 404 invalid coupon code", async () => {
    const res = await request(app)
      .post(`${BASE}/validate`)
      .send({ code: "DOESNOTEXIST999" });

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/invalid coupon code/i);
  });

  // ── T03 – ECP Invalid Class ─────────────────────────────────────────────
  test("T03 [ECP – Invalid Class] Missing code field → 400 coupon code is required", async () => {
    const res = await request(app)
      .post(`${BASE}/validate`)
      .send({});

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/required/i);
  });

  // ── T04 – BVA State Boundary ────────────────────────────────────────────
  test("T04 [BVA – State Boundary] Inactive coupon → 400 no longer active", async () => {
    const res = await request(app)
      .post(`${BASE}/validate`)
      .send({ code: "TESTINACTIVE20" });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/no longer active/i);
  });

  // ── T05 – BVA State Boundary ────────────────────────────────────────────
  test("T05 [BVA – State Boundary] Expired coupon → 400 coupon has expired", async () => {
    const res = await request(app)
      .post(`${BASE}/validate`)
      .send({ code: "TESTEXPIRED30" });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/expired/i);
  });

});
