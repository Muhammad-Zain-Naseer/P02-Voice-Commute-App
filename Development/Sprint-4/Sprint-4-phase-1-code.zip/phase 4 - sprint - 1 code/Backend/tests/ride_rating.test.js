/**
 * HerSafar – Use Case 7: Ride Rating
 * =====================================
 * Route   : PUT /api/rideHistory/:rideId/rating
 * Techniques:
 *   T01 – ECP Valid Class         (valid rideId + userId + rating:4 → 200)
 *   T02 – ECP Invalid Class       (missing rating field → 400)
 *   T03 – ECP Invalid Class       (non-existent rideId → 404)
 *   T04 – BVA Lower Boundary      (rating = 0 → 400 must be between 1 and 5)
 *   T05 – BVA Upper Boundary      (rating = 6 → 400 must be between 1 and 5)
 */

import request from "supertest";
import app from "../src/app/testApp.js";
import Ride from "../src/models/Ride.js";
import mongoose from "mongoose";

const BASE = "/api/rideHistory";

const COMPLETED_RIDE_ID = "test-completed-ride-rate-001";
const PENDING_RIDE_ID   = "test-pending-ride-rate-001";
const TEST_USER_ID      = "test_user_rate_001";

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await Ride.deleteMany({ rideId: { $in: [COMPLETED_RIDE_ID, PENDING_RIDE_ID] } });

  // Completed ride — used by T01, T04, T05
  await Ride.create({
    rideId     : COMPLETED_RIDE_ID,
    userId     : TEST_USER_ID,
    userName   : "Test Rater",
    status     : "completed",
    source     : { address: "NUST H-12, Islamabad", coordinates: { type: "Point", coordinates: [73.1356, 33.6428] } },
    destination: { address: "Blue Area, Islamabad",  coordinates: { type: "Point", coordinates: [73.0479, 33.7088] } },
    createdAt  : new Date(),
    updatedAt  : new Date(),
  });

  // Pending ride — unused in current tests but available if needed
  await Ride.create({
    rideId     : PENDING_RIDE_ID,
    userId     : TEST_USER_ID,
    userName   : "Test Rater",
    status     : "pending",
    source     : { address: "NUST H-12, Islamabad",   coordinates: { type: "Point", coordinates: [73.1356, 33.6428] } },
    destination: { address: "Centaurus Mall, Islamabad", coordinates: { type: "Point", coordinates: [73.0251, 33.7215] } },
    createdAt  : new Date(),
    updatedAt  : new Date(),
  });
});

afterAll(async () => {
  await Ride.deleteMany({ rideId: { $in: [COMPLETED_RIDE_ID, PENDING_RIDE_ID] } });
  await mongoose.connection.close();
});

describe("UC-07 | Ride Rating – PUT /api/rideHistory/:rideId/rating", () => {

  // ── T01 – ECP Valid Class ───────────────────────────────────────────────
  test("T01 [ECP – Valid Class] Valid rideId + userId + rating:4 on completed ride → 200", async () => {
    const res = await request(app)
      .put(`${BASE}/${COMPLETED_RIDE_ID}/rating`)
      .send({ rating: 4, userId: TEST_USER_ID });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.rating).toBe(4);

    // DB: ride rating updated
    const ride = await Ride.findOne({ rideId: COMPLETED_RIDE_ID });
    expect(ride.rating).toBe(4);
  });

  // ── T02 – ECP Invalid Class ─────────────────────────────────────────────
  test("T02 [ECP – Invalid Class] Missing rating field → 400 required", async () => {
    const res = await request(app)
      .put(`${BASE}/${COMPLETED_RIDE_ID}/rating`)
      .send({ userId: TEST_USER_ID });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/required/i);
  });

  // ── T03 – ECP Invalid Class ─────────────────────────────────────────────
  test("T03 [ECP – Invalid Class] Non-existent rideId → 404 ride not found", async () => {
    const res = await request(app)
      .put(`${BASE}/non-existent-ride-xyz/rating`)
      .send({ rating: 3, userId: TEST_USER_ID });

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/not found/i);
  });

  // ── T04 – BVA Lower Boundary ────────────────────────────────────────────
  // Note: rating=0 is falsy in JS so !rating is true — controller returns the
  // "required" guard before reaching the range check. Status 400 is still correct.
  test("T04 [BVA – Lower Boundary] rating = 0 → 400 (falsy triggers required guard)", async () => {
    const res = await request(app)
      .put(`${BASE}/${COMPLETED_RIDE_ID}/rating`)
      .send({ rating: 0, userId: TEST_USER_ID });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/required/i);
  });

  // ── T05 – BVA Upper Boundary ────────────────────────────────────────────
  test("T05 [BVA – Upper Boundary] rating = 6 → 400 must be between 1 and 5", async () => {
    const res = await request(app)
      .put(`${BASE}/${COMPLETED_RIDE_ID}/rating`)
      .send({ rating: 6, userId: TEST_USER_ID });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/between 1 and 5/i);
  });

});
