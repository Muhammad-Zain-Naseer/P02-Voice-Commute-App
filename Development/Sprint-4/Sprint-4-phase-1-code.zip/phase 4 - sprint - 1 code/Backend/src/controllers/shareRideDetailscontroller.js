import User from "../models/User.js";
import emailService from "../services/emailService.js";

class shareRideDetailsController {
  // Get user's trusted contacts
  async getTrustedContacts(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findById(userId).select("trustedContacts");
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      res.status(200).json({
        success: true,
        trustedContacts: user.trustedContacts || []
      });
    } catch (error) {
      console.error("Error getting trusted contacts:", error);
      res.status(500).json({
        success: false,
        message: "Failed to get trusted contacts"
      });
    }
  }

  // Share ride with selected contacts
  async shareRideDetailsWithSelectedContacts(req, res) {
    try {
      const { userId, rideId, rideDetails, contactEmails } = req.body;

      // Get user with trusted contacts
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      // Check if user has trusted contacts
      if (!user.trustedContacts || user.trustedContacts.length === 0) {
        return res.status(400).json({
          success: false,
          message: "No trusted contacts found"
        });
      }

      // Filter selected contacts from user's trusted contacts
      const selectedContacts = user.trustedContacts.filter((contact) =>
        contactEmails.includes(contact.email)
      );

      if (selectedContacts.length === 0) {
        return res.status(400).json({
          success: false,
          message: "No valid contacts selected"
        });
      }

      // Send email to each selected contact
      const emailPromises = selectedContacts.map((contact) => {
        return emailService.sendRideDetailsEmail(
          contact.email,
          user.name,
          rideDetails,
          contact.name
        );
      });

      await Promise.all(emailPromises);

      res.status(200).json({
        success: true,
        message: `Ride details shared with ${selectedContacts.length} contacts`
      });
    } catch (error) {
      console.error("Error sharing ride:", error);
      res.status(500).json({
        success: false,
        message: "Failed to share ride details"
      });
    }
  }
}
export default new shareRideDetailsController();
