import axios from "axios";
import logger from "../utils/logger.js";

const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
logger.info(
  `🗺️ Google Maps API Key loaded: ${GOOGLE_MAPS_API_KEY ? "Yes" : " No"}`
);

// Helper function to translate to Urdu using Google Translate API
const translateToUrdu = async (text) => {
  try {
    const response = await axios.post(
      `https://translation.googleapis.com/language/translate/v2?key=${GOOGLE_MAPS_API_KEY}`,
      {
        q: text,
        target: "ur",
        format: "text"
      }
    );

    return response.data.data.translations[0].translatedText;
  } catch (error) {
    logger.error(
      `Translation API error: ${error.message} | status=${error.response?.status} | data=${JSON.stringify(error.response?.data ?? null)}`
    );
    return text; // Return original text if translation fails
  }
};

// Translate addresses to Urdu
export const translateAddresses = async (req, res) => {
  try {
    const { source, destination } = req.body;

    logger.info(`Translating addresses: ${source} -> ${destination}`);

    const [sourceTranslation, destTranslation] = await Promise.all([
      translateToUrdu(source),
      translateToUrdu(destination)
    ]);

    logger.info(
      `Translation complete: ${sourceTranslation}, ${destTranslation}`
    );

    res.json({
      source: sourceTranslation,
      destination: destTranslation
    });
  } catch (error) {
    logger.error(`Translation error: ${error.message}`);
    res.status(500).json({ error: "Translation failed" });
  }
};

// Geocode an address
export const geocodeAddress = async (req, res) => {
  try {
    const { address } = req.body;

    logger.info(`Geocoding address: ${address}`);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/geocode/json",
      {
        params: {
          address: address,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.results.length > 0) {
      const location = response.data.results[0].geometry.location;
      logger.info(`Geocoded: ${address} -> ${location.lat}, ${location.lng}`);
      res.json({
        latitude: location.lat,
        longitude: location.lng
      });
    } else {
      logger.error(
        `Geocoding failed for: ${address} | status=${response.data.status} | error_message=${response.data.error_message ?? "none"}`
      );
      res.status(404).json({ error: "Address not found" });
    }
  } catch (error) {
    logger.error("Geocoding error:", error);
    res.status(500).json({ error: "Geocoding failed" });
  }
};

// Calculate route (distance matrix)
export const calculateRoute = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng } = req.body;

    logger.info(
      `Calculating route: (${sourceLat},${sourceLng}) -> (${destLat},${destLng})`
    );

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/distancematrix/json",
      {
        params: {
          origins: `${sourceLat},${sourceLng}`,
          destinations: `${destLat},${destLng}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK") {
      const element = response.data.rows[0].elements[0];
      logger.info(
        `Route calculated: ${element.distance.text}, ${element.duration.text}`
      );
      res.json({
        distance: element.distance.text,
        duration: element.duration.text
      });
    } else {
      logger.error("Route calculation failed:", response.data.status);
      res.status(400).json({ error: "Route calculation failed" });
    }
  } catch (error) {
    logger.error("Route calculation error:", error);
    res.status(500).json({ error: "Route calculation failed" });
  }
};

// Get directions polyline
export const getDirectionsPolyline = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng } = req.body;

    logger.info(
      `Fetching directions polyline: (${sourceLat},${sourceLng}) -> (${destLat},${destLng})`
    );

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/directions/json",
      {
        params: {
          origin: `${sourceLat},${sourceLng}`,
          destination: `${destLat},${destLng}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.routes.length > 0) {
      const polyline = response.data.routes[0].overview_polyline.points;
      logger.info(`Polyline fetched successfully (${polyline.length} chars)`);
      res.json({ polyline });
    } else {
      logger.error("Directions not found:", response.data.status);
      res.status(400).json({ error: "Directions not found" });
    }
  } catch (error) {
    logger.error("Directions error:", error);
    res.status(500).json({ error: "Directions fetch failed" });
  }
};

// Generate static map URL
export const getStaticMapUrl = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng, polyline } = req.body;

    logger.info(`Generating static map URL`);

    let url = `https://maps.googleapis.com/maps/api/staticmap?size=600x400&markers=color:green|label:A|${sourceLat},${sourceLng}&markers=color:red|label:B|${destLat},${destLng}`;

    if (polyline && polyline.length > 0) {
      url += `&path=enc:${polyline}`;
    }

    url += `&key=${GOOGLE_MAPS_API_KEY}`;

    logger.info(`Static map URL generated`);
    res.json({ mapUrl: url });
  } catch (error) {
    logger.error("Static map URL error:", error);
    res.status(500).json({ error: "Failed to generate map URL" });
  }
};

// Reverse geocode coordinates to address
export const reverseGeocode = async (req, res) => {
  try {
    const { latitude, longitude } = req.body;

    logger.info(`Reverse geocoding: ${latitude}, ${longitude}`);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/geocode/json",
      {
        params: {
          latlng: `${latitude},${longitude}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.results.length > 0) {
      const address = response.data.results[0].formatted_address;
      logger.info(`Reverse geocoded: ${latitude}, ${longitude} -> ${address}`);
      res.json({
        address: address
      });
    } else {
      logger.error(`Reverse geocoding failed`);
      res.status(404).json({ error: "Address not found" });
    }
  } catch (error) {
    logger.error("Reverse geocoding error:", error);
    res.status(500).json({ error: "Reverse geocoding failed" });
  }
};
