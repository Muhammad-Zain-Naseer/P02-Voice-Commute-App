import UnsafeArea from "../models/UnsafeArea.js";
import connectionPoolService from "../services/connectionPool.service.js";
import logger from "../utils/logger.js";

class UnsafeAreaController {
  /**
   * Create a new unsafe area
   * POST /api/admin/unsafe-areas
   */
  async createUnsafeArea(req, res, next) {
    try {
      const {
        name,
        description,
        latitude,
        longitude,
        address,
        radius,
        severity,
        reason,
        activeFrom,
        activeTo
      } = req.body;

      const userId = req.user.userId;
      const userName = req.user.name;

      // Validate required fields
      if (
        !name ||
        !description ||
        !latitude ||
        !longitude ||
        !radius ||
        !severity ||
        !reason
      ) {
        return res.status(400).json({
          success: false,
          error:
            "Missing required fields: name, description, latitude, longitude, radius, severity, reason"
        });
      }

      // Validate coordinates
      if (
        latitude < -90 ||
        latitude > 90 ||
        longitude < -180 ||
        longitude > 180
      ) {
        return res.status(400).json({
          success: false,
          error: "Invalid coordinates"
        });
      }

      // Validate radius
      if (radius < 100) {
        return res.status(400).json({
          success: false,
          error: "Radius must be at least 100 meters"
        });
      }

      // Validate severity
      if (!["warning", "blocked"].includes(severity)) {
        return res.status(400).json({
          success: false,
          error: "Severity must be 'warning' or 'blocked'"
        });
      }

      const unsafeArea = await UnsafeArea.create({
        name,
        description,
        location: {
          latitude: parseFloat(latitude),
          longitude: parseFloat(longitude),
          address: address || ""
        },
        radius: parseFloat(radius),
        severity,
        reason,
        createdBy: {
          userId,
          userName
        },
        activeFrom: activeFrom || null,
        activeTo: activeTo || null
      });

      logger.info(`Unsafe area created: ${name} by ${userName} (${userId})`);

      // Broadcast unsafe area update to all connected users
      const io = connectionPoolService.io;
      if (io) {
        io.emit("admin:unsafe_area_update", {
          action: "created",
          area: {
            id: unsafeArea._id,
            name: unsafeArea.name,
            severity: unsafeArea.severity
          }
        });

        logger.info("Unsafe area update broadcasted via Socket.IO");
      }

      res.status(201).json({
        success: true,
        message: "Unsafe area created successfully",
        data: unsafeArea
      });
    } catch (error) {
      logger.error("Error creating unsafe area:", error);
      next(error);
    }
  }

  /**
   * Get all unsafe areas
   * GET /api/admin/unsafe-areas
   */
  async getUnsafeAreas(req, res, next) {
    try {
      const { active } = req.query;

      const query = {};
      if (active === "true") {
        query.isActive = true;
      } else if (active === "false") {
        query.isActive = false;
      }

      const unsafeAreas = await UnsafeArea.find(query).sort({ createdAt: -1 });

      res.status(200).json({
        success: true,
        data: unsafeAreas
      });
    } catch (error) {
      logger.error("Error getting unsafe areas:", error);
      next(error);
    }
  }

  /**
   * Get a specific unsafe area by ID
   * GET /api/admin/unsafe-areas/:id
   */
  async getUnsafeAreaById(req, res, next) {
    try {
      const { id } = req.params;

      const unsafeArea = await UnsafeArea.findById(id);

      if (!unsafeArea) {
        return res.status(404).json({
          success: false,
          error: "Unsafe area not found"
        });
      }

      res.status(200).json({
        success: true,
        data: unsafeArea
      });
    } catch (error) {
      logger.error("Error getting unsafe area:", error);
      next(error);
    }
  }

  /**
   * Update an unsafe area
   * PUT /api/admin/unsafe-areas/:id
   */
  async updateUnsafeArea(req, res, next) {
    try {
      const { id } = req.params;
      const updateData = req.body;

      logger.info(`📝 Updating unsafe area ${id} with data:`, updateData);

      // Validate coordinates if provided
      if (updateData.latitude || updateData.longitude) {
        const lat = updateData.latitude || 0;
        const lon = updateData.longitude || 0;
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
          return res.status(400).json({
            success: false,
            error: "Invalid coordinates"
          });
        }
      }

      // Validate radius if provided
      if (updateData.radius && updateData.radius < 100) {
        return res.status(400).json({
          success: false,
          error: "Radius must be at least 100 meters"
        });
      }

      // Validate severity if provided
      if (
        updateData.severity &&
        !["warning", "blocked"].includes(updateData.severity)
      ) {
        return res.status(400).json({
          success: false,
          error: "Severity must be 'warning' or 'blocked'"
        });
      }

      // Build update object
      const update = {};
      if (updateData.name) update.name = updateData.name;
      if (updateData.description) update.description = updateData.description;
      if (updateData.reason) update.reason = updateData.reason;
      if (updateData.severity) update.severity = updateData.severity;
      if (updateData.radius) update.radius = parseFloat(updateData.radius);
      if (updateData.isActive !== undefined)
        update.isActive = updateData.isActive;
      if (updateData.activeFrom !== undefined)
        update.activeFrom = updateData.activeFrom;
      if (updateData.activeTo !== undefined)
        update.activeTo = updateData.activeTo;

      if (updateData.latitude || updateData.longitude || updateData.address) {
        update.location = {};
        if (updateData.latitude)
          update.location.latitude = parseFloat(updateData.latitude);
        if (updateData.longitude)
          update.location.longitude = parseFloat(updateData.longitude);
        if (updateData.address) update.location.address = updateData.address;
      }

      const unsafeArea = await UnsafeArea.findByIdAndUpdate(id, update, {
        new: true,
        runValidators: true
      });

      if (!unsafeArea) {
        return res.status(404).json({
          success: false,
          error: "Unsafe area not found"
        });
      }

      logger.info(`Unsafe area updated: ${unsafeArea.name}`);

      // Broadcast update
      const io = connectionPoolService.io;
      if (io) {
        io.emit("admin:unsafe_area_update", {
          action: "updated",
          area: {
            id: unsafeArea._id,
            name: unsafeArea.name,
            severity: unsafeArea.severity,
            isActive: unsafeArea.isActive
          }
        });
      }

      res.status(200).json({
        success: true,
        message: "Unsafe area updated successfully",
        data: unsafeArea
      });
    } catch (error) {
      logger.error("Error updating unsafe area:", error);
      next(error);
    }
  }

  /**
   * Delete an unsafe area
   * DELETE /api/admin/unsafe-areas/:id
   */
  async deleteUnsafeArea(req, res, next) {
    try {
      const { id } = req.params;

      const unsafeArea = await UnsafeArea.findByIdAndDelete(id);

      if (!unsafeArea) {
        return res.status(404).json({
          success: false,
          error: "Unsafe area not found"
        });
      }

      logger.info(`Unsafe area deleted: ${unsafeArea.name}`);

      // Broadcast deletion
      const io = connectionPoolService.io;
      if (io) {
        io.emit("admin:unsafe_area_update", {
          action: "deleted",
          area: {
            id: unsafeArea._id,
            name: unsafeArea.name
          }
        });
      }

      res.status(200).json({
        success: true,
        message: "Unsafe area deleted successfully"
      });
    } catch (error) {
      logger.error("Error deleting unsafe area:", error);
      next(error);
    }
  }

  /**
   * Check if a location is in any unsafe area (Public API)
   * POST /api/unsafe-areas/check
   */
  async checkLocation(req, res, next) {
    try {
      const { latitude, longitude } = req.body;

      logger.info(`🔍 Checking location: ${latitude}, ${longitude}`);

      if (!latitude || !longitude) {
        return res.status(400).json({
          success: false,
          error: "Latitude and longitude are required"
        });
      }

      const unsafeAreas = await UnsafeArea.checkLocation(
        parseFloat(latitude),
        parseFloat(longitude)
      );

      logger.info(`⚠️ Unsafe areas found: ${unsafeAreas.length}`);
      if (unsafeAreas.length > 0) {
        logger.info(`Areas: ${unsafeAreas.map((a) => a.name).join(", ")}`);
      }

      res.status(200).json({
        success: true,
        data: {
          isUnsafe: unsafeAreas.length > 0,
          areas: unsafeAreas
        }
      });
    } catch (error) {
      logger.error("Error checking location:", error);
      next(error);
    }
  }
}

export default new UnsafeAreaController();
