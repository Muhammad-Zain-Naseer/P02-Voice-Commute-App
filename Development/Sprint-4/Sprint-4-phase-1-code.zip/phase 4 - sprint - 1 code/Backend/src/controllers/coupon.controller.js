/**
 * Coupon Controller
 * Handles coupon validation and admin management
 */

import Coupon from "../models/Coupon.js";
import logger from "../utils/logger.js";

class CouponController {
  /**
   * Validate a coupon code (public endpoint — users call this before payment)
   * POST /api/coupons/validate
   * Body: { code }
   */
  async validateCoupon(req, res, next) {
    try {
      const { code } = req.body;

      if (!code || !code.trim()) {
        return res.status(400).json({
          success: false,
          error: "Coupon code is required"
        });
      }

      const coupon = await Coupon.findOne({
        code: code.toString().trim().toUpperCase()
      });

      if (!coupon) {
        return res.status(404).json({
          success: false,
          error: "Invalid coupon code"
        });
      }

      if (!coupon.isActive) {
        return res.status(400).json({
          success: false,
          error: "This coupon is no longer active"
        });
      }

      if (coupon.expiryDate && new Date() > coupon.expiryDate) {
        return res.status(400).json({
          success: false,
          error: "This coupon has expired"
        });
      }

      if (coupon.maxUses !== null && coupon.usedCount >= coupon.maxUses) {
        return res.status(400).json({
          success: false,
          error: "This coupon has reached its usage limit"
        });
      }

      logger.info(`[COUPON] Valid coupon applied: ${coupon.code} (${coupon.discountPercentage}% off)`);

      return res.status(200).json({
        success: true,
        message: "Coupon is valid",
        data: {
          code: coupon.code,
          discountPercentage: coupon.discountPercentage,
          description: coupon.description
        }
      });
    } catch (error) {
      logger.error(`[COUPON] Error in validateCoupon: ${error.message}`);
      next(error);
    }
  }

  /**
   * Create a new coupon (admin)
   * POST /api/coupons
   * Body: { code, discountPercentage, description?, maxUses?, expiryDate? }
   */
  async createCoupon(req, res, next) {
    try {
      const { code, discountPercentage, description, maxUses, expiryDate } =
        req.body;

      if (!code || !discountPercentage) {
        return res.status(400).json({
          success: false,
          error: "code and discountPercentage are required"
        });
      }

      if (discountPercentage < 1 || discountPercentage > 100) {
        return res.status(400).json({
          success: false,
          error: "discountPercentage must be between 1 and 100"
        });
      }

      const coupon = new Coupon({
        code: code.toString().trim().toUpperCase(),
        discountPercentage: Number(discountPercentage),
        description: description || "",
        maxUses: maxUses ? Number(maxUses) : null,
        expiryDate: expiryDate ? new Date(expiryDate) : null
      });

      await coupon.save();

      logger.info(`[COUPON] Created coupon: ${coupon.code}`);

      return res.status(201).json({
        success: true,
        message: "Coupon created successfully",
        data: { coupon }
      });
    } catch (error) {
      if (error.code === 11000) {
        return res.status(409).json({
          success: false,
          error: "A coupon with this code already exists"
        });
      }
      logger.error(`[COUPON] Error in createCoupon: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get all coupons (admin)
   * GET /api/coupons
   */
  async getCoupons(req, res, next) {
    try {
      const coupons = await Coupon.find().sort({ createdAt: -1 });

      return res.status(200).json({
        success: true,
        data: { coupons, count: coupons.length }
      });
    } catch (error) {
      logger.error(`[COUPON] Error in getCoupons: ${error.message}`);
      next(error);
    }
  }

  /**
   * Toggle coupon active/inactive (admin)
   * PATCH /api/coupons/:id/toggle
   */
  async toggleCoupon(req, res, next) {
    try {
      const { id } = req.params;

      const coupon = await Coupon.findById(id.toString());

      if (!coupon) {
        return res.status(404).json({
          success: false,
          error: "Coupon not found"
        });
      }

      coupon.isActive = !coupon.isActive;
      await coupon.save();

      logger.info(
        `[COUPON] Toggled coupon ${coupon.code}: isActive=${coupon.isActive}`
      );

      return res.status(200).json({
        success: true,
        message: `Coupon ${coupon.isActive ? "activated" : "deactivated"} successfully`,
        data: { coupon }
      });
    } catch (error) {
      logger.error(`[COUPON] Error in toggleCoupon: ${error.message}`);
      next(error);
    }
  }

  /**
   * Delete a coupon (admin)
   * DELETE /api/coupons/:id
   */
  async deleteCoupon(req, res, next) {
    try {
      const { id } = req.params;

      const coupon = await Coupon.findByIdAndDelete(id.toString());

      if (!coupon) {
        return res.status(404).json({
          success: false,
          error: "Coupon not found"
        });
      }

      logger.info(`[COUPON] Deleted coupon: ${coupon.code}`);

      return res.status(200).json({
        success: true,
        message: "Coupon deleted successfully"
      });
    } catch (error) {
      logger.error(`[COUPON] Error in deleteCoupon: ${error.message}`);
      next(error);
    }
  }
}

export default new CouponController();
