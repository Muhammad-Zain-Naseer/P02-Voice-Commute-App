import SupportTicket from "../models/SupportTicket.js";
import logger from "../utils/logger.js";

class SupportController {
    // Create a new ticket 
    async createTicket(req, res, next) {
        try {
            const { category, descriptionText, role } = req.body;
            const userId = req.user.userId;

            if (!category) {
                return res.status(400).json({
                    success: false,
                    error: "Issue category is required"
                });
            }

            let audioUrl = null;
            if (req.file) {
                audioUrl = `/uploads/${req.file.filename}`;
            }

            const ticket = await SupportTicket.create({
                userId,
                role: role || "commuter",
                category,
                descriptionText,
                audioUrl
            });

            logger.info(`New support ticket created by user: ${userId}`);

            res.status(201).json({
                success: true,
                data: ticket
            });
        } catch (error) {
            logger.error(`Error in createTicket: ${error.message}`);
            next(error);
        }
    }

    // Get all tickets for Admin
    async getTickets(req, res, next) {
        try {
            const { status } = req.query;

            const filter = {};
            if (status) filter.status = status;

            const tickets = await SupportTicket.find(filter)
                .sort({ createdAt: -1 })
                .lean();

            res.status(200).json({
                success: true,
                count: tickets.length,
                data: tickets
            });
        } catch (error) {
            logger.error(`Error in getTickets: ${error.message}`);
            next(error);
        }
    }

    // Update status (Admin only)
    async updateTicketStatus(req, res, next) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            const adminId = req.user._id;

            if (!["open", "in_progress", "resolved"].includes(status)) {
                return res.status(400).json({
                    success: false,
                    error: "Invalid status value"
                });
            }

            const updateData = { status };
            if (status === "resolved") {
                updateData.resolvedBy = adminId;
                updateData.resolvedAt = new Date();
            }

            const ticket = await SupportTicket.findByIdAndUpdate(id, updateData, {
                new: true
            });

            if (!ticket) {
                return res.status(404).json({
                    success: false,
                    error: "Ticket not found"
                });
            }

            logger.info(`Support ticket ${id} marked as ${status}`);

            res.status(200).json({
                success: true,
                data: ticket
            });
        } catch (error) {
            logger.error(`Error in updateTicketStatus: ${error.message}`);
            next(error);
        }
    }
}

export default new SupportController();