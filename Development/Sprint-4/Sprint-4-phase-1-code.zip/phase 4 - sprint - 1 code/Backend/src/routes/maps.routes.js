import express from "express";
import {
  translateAddresses,
  geocodeAddress,
  calculateRoute,
  getDirectionsPolyline,
  getStaticMapUrl,
  reverseGeocode
} from "../controllers/maps.controller.js";

const router = express.Router();

/**
 * @route   POST /api/maps/translate
 * @desc    Translate addresses to Urdu
 * @access  Public
 * @body    { source: string, destination: string }
 */
router.post("/translate", translateAddresses);

/**
 * @route   POST /api/maps/geocode
 * @desc    Convert address to coordinates
 * @access  Public
 * @body    { address: string }
 */
router.post("/geocode", geocodeAddress);

/**
 * @route   POST /api/maps/calculate-route
 * @desc    Calculate distance and duration between two points
 * @access  Public
 * @body    { sourceLat: number, sourceLng: number, destLat: number, destLng: number }
 */
router.post("/calculate-route", calculateRoute);

/**
 * @route   POST /api/maps/directions-polyline
 * @desc    Get directions polyline for route
 * @access  Public
 * @body    { sourceLat: number, sourceLng: number, destLat: number, destLng: number }
 */
router.post("/directions-polyline", getDirectionsPolyline);

/**
 * @route   POST /api/maps/static-map-url
 * @desc    Generate static map URL with markers and route
 * @access  Public
 * @body    { sourceLat: number, sourceLng: number, destLat: number, destLng: number, polyline?: string }
 */
router.post("/static-map-url", getStaticMapUrl);

/**
 * @route   POST /api/maps/reverse-geocode
 * @desc    Convert coordinates to address
 * @access  Public
 * @body    { latitude: number, longitude: number }
 */
router.post("/reverse-geocode", reverseGeocode);

export default router;
