import express from 'express';
import axios from 'axios';
import geminiService from '../services/gemini.service.js';

const router = express.Router();

// Text to Speech endpoint
router.post('/tts', async (req, res) => {
    try {
        const { text, language } = req.body;
        // console.log('TTS Request:', { text, language });

        const response = await axios.post(
            `https://texttospeech.googleapis.com/v1/text:synthesize?key=${process.env.GOOGLE_TTS_API_KEY}`,
            {
                input: { text },
                voice: {
                    languageCode: 'ur-IN',
                    name: 'ur-IN-Chirp3-HD-Callirrhoe',
                    ssmlGender: 'FEMALE',
                },
                audioConfig: {
                    audioEncoding: 'MP3',
                    speakingRate: 1.0,
                    pitch: 0.0,
                },
            }
        );

        res.json({
            success: true,
            audioContent: response.data.audioContent,
        });
    } catch (error) {
        console.error('TTS Error full:', error.response?.data);
        res.status(500).json({
            success: false,
            error: error.message,
        });
    }
});

// Speech to Text endpoint
router.post('/stt', async (req, res) => {
    try {
        const { audioBase64 } = req.body;

        const response = await axios.post(
            `https://speech.googleapis.com/v1/speech:recognize?key=${process.env.GOOGLE_STT_API_KEY}`,
            {
                config: {
                    encoding: 'LINEAR16',        // WAV = LINEAR16
                    sampleRateHertz: 16000,      // must match recorder
                    languageCode: 'ur-PK',
                    alternativeLanguageCodes: [
                        'ur-IN',
                        'hi-IN',
                        'en-US',
                    ],
                    model: 'command_and_search',
                    enableAutomaticPunctuation: true,
                },
                audio: {
                    content: audioBase64,
                },
            }
        );

        const transcript =
            response.data.results?.[0]?.alternatives?.[0]?.transcript || '';

        console.log('STT transcript:', transcript);
        console.log('STT full response:', JSON.stringify(response.data));

        res.json({
            success: true,
            transcript,
        });
    } catch (error) {
        console.error('STT Error full:', error.response?.data);
        res.status(500).json({
            success: false,
            error: error.message,
        });
    }
});

// Interpret speech intent using Gemini
router.post('/interpret', async (req, res) => {
    try {
        const { spoken } = req.body;

        if (!spoken || spoken.trim() === '') {
            return res.json({ success: true, matched: -1, reasoning: 'Empty input' });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({
                success: false,
                error: 'Gemini service not available',
            });
        }

        console.log('Interpret Request:', spoken);

        const prompt = `A user is on the welcome screen of a ride-hailing app called HerSafar (a women-only ride service in Pakistan).

The screen has exactly 3 options:
0 = New User (signup, register, new account, naya, jadeed, first time)
1 = Already Registered (login, signin, existing user, pehle se, already, account hai)
2 = Register as Driver (driver, drive, car, chalana, gaari, sawari, DriverSignup)

The user said: "${spoken}"

Rules:
- The user may speak in ANY language: Urdu, Hindi, English, Roman Urdu, or any mix
- Be VERY generous — if there is ANY hint of intent, match it
- "register as driver", "i want to drive", "driver signup", "main driver hoon", "driver banna hai" → 2
- "new user", "signup", "register", "naya account", "naya user" → 0  
- "login", "already registered", "i have an account", "pehle se hoon" → 1
- Only return -1 if the input is completely unrelated to these 3 options (e.g. "what is the weather")

Respond ONLY with valid JSON, no markdown:
{
  "matched": <0, 1, 2, or -1 only if truly unrelated>,
  "confidence": "<high|medium|low>",
  "reasoning": "<one short sentence>"
}`;

        const result = await geminiService.client.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        const text = result.text
            .trim()
            .replace(/```json\n?/g, '')
            .replace(/```\n?/g, '')
            .trim();

        const parsed = JSON.parse(text);
        console.log('Gemini interpret result:', parsed);

        res.json({
            success: true,
            matched: parsed.matched ?? -1,
            confidence: parsed.confidence,
            reasoning: parsed.reasoning,
        });
    } catch (error) {
        console.error('Interpret Error:', error.message);
        res.status(500).json({
            success: false,
            error: error.message,
        });
    }
});

// Extract email from spoken Urdu phonetic transcript using Gemini
router.post('/extract-email', async (req, res) => {
    try {
        const { transcript } = req.body;

        if (!transcript || transcript.trim() === '') {
            return res.json({ success: true, email: null });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({ success: false, error: 'Gemini service not available' });
        }

        const prompt = `A user from Pakistan spoke their email address aloud in Urdu. The speech-to-text engine produced a phonetic Urdu transcript.

Urdu phonetic names for English letters:
اے=A, بی=B, سی=C, ڈی=D, ای=E, ایف=F, جی=G, ایچ=H, آئی=I, جے=J, کے=K, ایل=L, ایم=M, این=N, او=O, پی=P, کیو=Q, آر=R, ایس=S, ٹی=T, یو=U, وی=V, ڈبلیو=W, ایکس=X, وائی=Y, زیڈ=Z

Special characters:
@ symbol: "ایٹ" or "at" or "ایٹ دا ریٹ" or "ایٹ دی ریٹ" or "ایٹ دا ریٹ اف" (all mean "@")
. symbol: "ڈاٹ" or "dot" or "پوائنٹ" or "نقطہ"
- symbol: "ڈیش" or "dash"
_ symbol: "انڈر سکور" or "underscore"

Domain name hints (spoken as words, not spelled):
"جی میل" or "جیمیل" = gmail
"یاہو" = yahoo
"ہاٹ میل" or "ہاٹمیل" = hotmail
"آؤٹ لک" = outlook
"ہر سفر" or "ہرسفر" or "حارث سفر" or "ہیر سفر" = hersafar (this app's domain)
"کام" or "com" = .com
"نیٹ" = .net
"او آر جی" = .org
"پی کے" = .pk

The transcript is: "${transcript}"

Instructions:
1. The user may have spelled letters one by one OR spoken the domain as a word.
2. If "@" appears multiple times in meaning (e.g. "ایٹ" followed by "ایٹ دا ریٹ"), use only one "@".
3. Common Pakistani app domain: hersafar.com (HerSafar ride app).
4. Return null only if completely unrecognizable.

Respond ONLY with valid JSON, no markdown:
{
  "email": "<the email address or null if cannot be determined>"
}`;

        const result = await geminiService.client.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        const text = result.text
            .trim()
            .replace(/```json\n?/g, '')
            .replace(/```\n?/g, '')
            .trim();

        const parsed = JSON.parse(text);
        console.log('Extract email result:', parsed);

        res.json({ success: true, email: parsed.email ?? null });
    } catch (error) {
        console.error('Extract email error:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

export default router;