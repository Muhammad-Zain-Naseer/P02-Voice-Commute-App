import express from "express";
import authController from "../controllers/authController.js";
import { authenticate } from "../middleware/auth.middleware.js";

const router = express.Router();

// Signup
router.post("/signup", (req, res) => authController.signup(req, res));
router.get("/verify-email", (req, res) => authController.verifyEmail(req, res));
router.post("/resend-verification-email", (req, res) =>
  authController.resendVerificationEmail(req, res)
);

// Login
router.post("/login", (req, res) => authController.login(req, res));

// Protected route (test)
router.get("/me", authenticate, (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      user: req.user
    }
  });
});

export default router;
