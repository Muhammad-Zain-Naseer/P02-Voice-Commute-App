import express from "express";
import { createServer } from "node:http";
import { Server } from "socket.io";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";
import dotenv from "dotenv";
import mongoose from "mongoose";
import config from "../config/env.config.js";
import socketConfig from "../config/socket.config.js";
import logger from "../utils/logger.js";
import audioRoutes from "../routes/audio.routes.js";
import rideRoutes from "../routes/ride.routes.js";
import authRoutes from "../routes/authRoutes.js";
import driverAuthRoutes from "../routes/driverAuth.routes.js";
import paymentRoutes from "../routes/payment.routes.js";
import mapsRoutes from "../routes/maps.routes.js";
import commuterRoutes from "../routes/commuter.routes.js";
import adminRoutes from "../routes/admin.routes.js";
import safetyRoutes from "../routes/safety.routes.js";
import tripMonitoringRoutes from "../routes/tripMonitoring.routes.js";
import rideHistoryRoutes from "../routes/rideHistory.routes.js";
import driverRoutes from "../routes/driver.routes.js";
import farePriceRoutes from "../routes/farePrice.routes.js";
import policyRoutes from "../routes/policy.routes.js";
import unsafeAreaRoutes from "../routes/unsafeArea.routes.js";
import supportRoutes from "../routes/support.routes.js";
import couponRoutes from "../routes/coupon.routes.js";
import voiceRoutes from '../routes/voice.routes.js';



import emailService from "../services/emailService.js";
import connectionPoolService from "../services/connectionPool.service.js";
import { handleRideEvents } from "../sockets/ride.socket.js";
import { authenticate } from "../middleware/auth.middleware.js";
import {
  errorHandler,
  notFoundHandler
} from "../middleware/errorHandler.middleware.js";

dotenv.config();

const app = express();

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uploadsPath = path.join(__dirname, "..", "..", "uploads");
const vehicleUploadsDir = path.join(uploadsPath, "vehicle-registrations");

// Create uploads directories if they don't exist
if (!fs.existsSync(vehicleUploadsDir)) {
  fs.mkdirSync(vehicleUploadsDir, { recursive: true });
  logger.info("Created uploads directory for vehicle registrations");
}

// Create HTTP server
const httpServer = createServer(app);

// Initialize Socket.IO with configuration
const io = new Server(httpServer, socketConfig);

app.set("io", io);
connectionPoolService.setIO(io);

// Enable CORS for all origins (for development)
app.use(cors());

// Increase payload limit for payment screenshots (base64 images can be large)
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// serve static files for uploaded images
app.use("/uploads", express.static(uploadsPath));

// Health check endpoint
app.get("/", (req, res) => {
  logger.info("Health check endpoint accessed");
  res.json({
    message: "Server is running!",
    features: [
      "Audio Processing",
      "Real-time Ride Matching",
      "Driver Registration"
    ],
    socketEnabled: true
  });
});

// API Routes
app.use("/api/auth", authRoutes); // Commuter auth
app.use("/api/driver/auth", driverAuthRoutes); // Driver auth
app.use("/api/driver", driverRoutes);
app.use("/api/audio", audioRoutes);
app.use("/api/rides", rideRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/maps", mapsRoutes);
app.use("/api/commuter", commuterRoutes);
app.use("/api/admin/alerts", authenticate, safetyRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/monitoring", tripMonitoringRoutes);
app.use("/api/rideHistory", rideHistoryRoutes);
app.use("/api/fares", farePriceRoutes);
app.use("/api/policies", policyRoutes);
app.use("/api/admin/unsafe-areas", authenticate, unsafeAreaRoutes);
app.use("/api/unsafe-areas", unsafeAreaRoutes);
app.use("/api/support", supportRoutes);
app.use("/api/coupons", couponRoutes);
app.use('/api/voice', voiceRoutes);

// Socket.IO connection handling
io.on("connection", (socket) => {
  logger.info(`Socket connected: ${socket.id}`);

  // Setup ride event handlers
  handleRideEvents(io, socket);

  socket.on("disconnect", (reason) => {
    logger.info(`Socket disconnected: ${socket.id} | Reason: ${reason}`);
  });
});

// 404 handler
app.use(notFoundHandler);

// Error handler
app.use(errorHandler);

// DATABASE CONNECTION
const connectDatabase = async () => {
  try {
    await mongoose.connect(config.mongoUri);
    logger.info("MongoDB connected successfully");
  } catch (error) {
    logger.error("MongoDB connection error:", error);
    process.exit(1);
  }
};

// START SERVER WITH DB
connectDatabase().then(async () => {
  httpServer.listen(config.port, () => {
    logger.info(
      `Server running on port ${config.port} in ${config.nodeEnv} mode`
    );
    logger.info("Socket.IO enabled and ready for connections");
    logger.info(`WebSocket URL: ws://localhost:${config.port}`);
    logger.info(`Uploads path: ${uploadsPath}`);
    logger.info(`Vehicle uploads dir: ${vehicleUploadsDir}`);
  });

  await emailService.verifyConnection();
});

httpServer.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    logger.error(
      `Port ${config.port} is already in use. Stop the conflicting process or set a different PORT.`
    );
  } else {
    logger.error("HTTP server encountered an error:", error);
  }
  process.exit(1);
});
