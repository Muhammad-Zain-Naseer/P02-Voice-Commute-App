import { Resend } from "resend";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

const resend = new Resend(config.resendApiKey);

class EmailService {
  constructor() {
    this.from = config.emailFrom;
  }

  async sendMail({ to, subject, html, text, fromName }) {
    if (!config.resendApiKey) {
      throw new Error(
        "Resend API key is not configured (missing RESEND_API_KEY)"
      );
    }
    if (!this.from) {
      throw new Error("EMAIL_FROM is not configured");
    }

    // If this.from already has a name format "Name <email>", use it as is
    // Otherwise, add fromName if provided
    let from = this.from;
    if (fromName && !this.from.includes("<")) {
      from = `${fromName} <${this.from}>`;
    }

    try {
      const { data, error } = await resend.emails.send({
        from,
        to: Array.isArray(to) ? to : [to],
        subject,
        html,
        text
      });

      if (error) {
        logger.error("[EMAIL] Resend error:", error);
        throw new Error(error.message || "Failed to send email");
      }

      logger.info(`[EMAIL] Sent to ${to} subject="${subject}" id=${data.id}`);
      return { success: true, messageId: data.id };
    } catch (error) {
      logger.error("[EMAIL] Send failed:", error);
      throw error;
    }
  }

  // Send verification email
  async sendVerificationEmail(email, verificationUrl) {
    const subject = "Verify Your Email Address";

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #4CAF50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .button { display: inline-block; padding: 12px 30px; margin: 20px 0; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
          .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header"><h1>Email Verification</h1></div>
          <div class="content">
            <h2>Welcome to ${config.appName}!</h2>
            <p>Thank you for signing up. Please verify your email address to complete your registration.</p>
            <p>Click the button below to verify your email:</p>
            <center><a href="${verificationUrl}" class="button">Verify Email</a></center>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #4CAF50;">${verificationUrl}</p>
            <div class="footer">
              <p>This link will expire in 24 hours.</p>
              <p>If you didn't create an account with ${config.appName}, please ignore this email.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
Welcome to ${config.appName}!

Thank you for signing up. Please verify your email address to complete your registration.

Verify link:
${verificationUrl}

This link will expire in 24 hours.

If you didn't create an account with ${config.appName}, please ignore this email.
    `.trim();

    return this.sendMail({
      to: email,
      subject,
      html,
      text,
      fromName: config.appName
    });
  }

  // Send password reset email
  async sendPasswordResetEmail(email, resetUrl) {
    const subject = "Reset Your PIN";

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #f44336; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .button { display: inline-block; padding: 12px 30px; margin: 20px 0; background-color: #f44336; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; }
          .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header"><h1>PIN Reset Request</h1></div>
          <div class="content">
            <h2>Reset Your PIN</h2>
            <p>You requested to reset your PIN. Click the button below to proceed:</p>
            <center><a href="${resetUrl}" class="button">Reset PIN</a></center>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; color: #f44336;">${resetUrl}</p>
            <div class="footer">
              <p>This link will expire in 1 hour.</p>
              <p>If you didn't request a PIN reset, please ignore this email.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
PIN Reset Request

Reset link:
${resetUrl}

This link will expire in 1 hour.

If you didn't request a PIN reset, please ignore this email.
    `.trim();

    return this.sendMail({
      to: email,
      subject,
      html,
      text,
      fromName: config.appName
    });
  }

  // Send ride details email
  async sendRideDetailsEmail(
    recipientEmail,
    userName,
    rideDetails,
    recipientName
  ) {
    const subject = `${userName} shared their ride details with you - HerSafar`;

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; background-color: #FDEAF0; padding: 20px; }
          .container { max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; }
          h2 { color: #CF4374; }
          .details { background-color: #FAECF1; padding: 20px; border-radius: 8px; margin: 20px 0; }
          .detail-row { margin: 10px 0; }
          .label { font-weight: bold; color: #CF4374; }
          .button { background-color: #CF4374; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px; }
          .footer { color: #666; font-size: 12px; margin-top: 30px; text-align: center; }
        </style>
      </head>
      <body>
        <div class="container">
          <h2>🚗 Ride Details from ${userName}</h2>
          <p>Hi ${recipientName || "there"},</p>
          <p>${userName} has shared their ride details with you for safety:</p>

          <div class="details">
            <div class="detail-row"><span class="label">Pickup Location:</span> ${rideDetails.pickup || "N/A"}</div>
            <div class="detail-row"><span class="label">Drop-off Location:</span> ${rideDetails.dropoff || "N/A"}</div>
            <div class="detail-row"><span class="label">Driver Name:</span> ${rideDetails.driverName || "N/A"}</div>
            <div class="detail-row"><span class="label">Status:</span> ${rideDetails.estimatedArrival || "In Progress"}</div>
          </div>

          ${
            rideDetails.trackingLink
              ? `<div style="text-align:center;"><a href="${rideDetails.trackingLink}" class="button">Track Live Location</a></div>`
              : ""
          }

          <p class="footer">This is an automated message from HerSafar for safety purposes.</p>
        </div>
      </body>
      </html>
    `;

    const text = `
Ride Details from ${userName}

Pickup: ${rideDetails.pickup || "N/A"}
Drop-off: ${rideDetails.dropoff || "N/A"}
Driver: ${rideDetails.driverName || "N/A"}
Status: ${rideDetails.estimatedArrival || "In Progress"}
${rideDetails.trackingLink ? `Tracking: ${rideDetails.trackingLink}` : ""}
    `.trim();

    return this.sendMail({
      to: recipientEmail,
      subject,
      html,
      text,
      fromName: config.appName
    });
  }

  // Send SOS alert email
  async sendSOSAlert(trustedContactEmail, sosData) {
    const {
      commuterName,
      commuterEmail,
      driverName,
      pickupLocation,
      dropoffLocation,
      triggeredAt,
      sosMessage
    } = sosData;

    const subject = `🚨 EMERGENCY SOS ALERT - ${commuterName}`;

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #d32f2f; color: white; padding: 30px 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #fff3e0; padding: 30px; border: 3px solid #d32f2f; border-radius: 0 0 5px 5px; }
          .info-box { background-color: white; padding: 15px; margin: 15px 0; border-left: 4px solid #d32f2f; border-radius: 3px; }
          .label { font-weight: bold; color: #d32f2f; margin-bottom: 5px; }
          .emergency-note { background-color: #ffebee; padding: 20px; margin: 20px 0; border-radius: 5px; border: 2px solid #d32f2f; }
          .footer { margin-top: 20px; padding-top: 20px; border-top: 2px solid #d32f2f; font-size: 12px; color: #666; text-align: center; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1 style="margin:0;">EMERGENCY SOS ALERT</h1>
            <p style="margin:10px 0 0 0;">Immediate Attention Required</p>
          </div>
          <div class="content">
            <div class="emergency-note">
              <h2 style="color:#d32f2f;margin-top:0;">SOS Alert Triggered</h2>
              <p><strong>${commuterName}</strong> has activated an SOS alert during their ride.</p>
            </div>

            <div class="info-box">
              <div class="label">📅 Triggered At:</div>
              <div>${new Date(triggeredAt).toLocaleString()}</div>
            </div>

            <div class="info-box">
              <div class="label">👤 Commuter Details:</div>
              <div><strong>Name:</strong> ${commuterName}<br><strong>Email:</strong> ${commuterEmail}</div>
            </div>

            ${
              driverName
                ? `<div class="info-box"><div class="label">🚗 Driver:</div><div><strong>${driverName}</strong></div></div>`
                : ""
            }

            <div class="info-box">
              <div class="label">📍 Ride Details:</div>
              <div><strong>Pickup:</strong> ${pickupLocation}<br><strong>Drop-off:</strong> ${dropoffLocation}</div>
            </div>

            ${
              sosMessage
                ? `<div class="info-box"><div class="label">💬 Message:</div><div>${sosMessage}</div></div>`
                : ""
            }

            <div class="emergency-note">
              <h3 style="color:#d32f2f;margin-top:0;">Recommended Actions</h3>
              <ol style="margin:10px 0; padding-left: 20px;">
                <li>Try to contact ${commuterName} immediately</li>
                <li>If unreachable, consider contacting local authorities</li>
                <li>Keep this information ready for emergency services</li>
              </ol>
            </div>

            <div class="footer">
              <p><strong>This is an automated emergency alert from ${config.appName}</strong></p>
              <p>You received this because you are listed as a trusted contact.</p>
              <p style="color:#d32f2f;font-weight:bold;">DO NOT IGNORE THIS MESSAGE</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    const text = `
EMERGENCY SOS ALERT

Commuter: ${commuterName} (${commuterEmail})
Triggered At: ${new Date(triggeredAt).toLocaleString()}
${driverName ? `Driver: ${driverName}\n` : ""}
Pickup: ${pickupLocation}
Drop-off: ${dropoffLocation}
${sosMessage ? `Message: ${sosMessage}\n` : ""}

Recommended Actions:
1) Contact commuter immediately
2) If unreachable, contact local authorities
    `.trim();

    return this.sendMail({
      to: trustedContactEmail,
      subject,
      html,
      text,
      fromName: `${config.appName} - Emergency Alert`
    });
  }

  // Verify email configuration
  async verifyConnection() {
    try {
      logger.info("[EMAIL CONFIG] Verifying Resend configuration...");
      logger.info(`[EMAIL CONFIG] From: ${this.from}`);
      logger.info(
        `[EMAIL CONFIG] API Key configured: ${config.resendApiKey ? "Yes" : "No"}`
      );

      if (!config.resendApiKey) {
        throw new Error("Resend API key is not configured");
      }

      logger.info("[EMAIL CONFIG] Resend email service is ready!");
      return true;
    } catch (error) {
      logger.error("[EMAIL CONFIG] Resend connection FAILED!");
      logger.error(` [EMAIL CONFIG] Error: ${error.message}`);
      return false;
    }
  }

  // Send OTP email
  async sendOTP(email, otp) {
    const subject = "Your Driver Registration OTP";

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #4CAF50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background-color: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .otp-box { background-color: white; border: 2px dashed #4CAF50; padding: 20px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #4CAF50; margin: 20px 0; border-radius: 5px; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
          .warning { background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 10px; margin: 15px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header"><h1>Driver Registration</h1></div>
          <div class="content">
            <h2>Welcome to ${config.appName}!</h2>
            <p>Use the OTP below to verify your email address:</p>
            <div class="otp-box">${otp}</div>
            <div class="warning"><strong>Important:</strong> This OTP is valid for 10 minutes only.</div>
            <p>If you didn't request this OTP, please ignore this email.</p>
          </div>
          <div class="footer"><p>This is an automated email. Please do not reply.</p></div>
        </div>
      </body>
      </html>
    `;

    const text = `Your OTP for driver registration is: ${otp}. This OTP is valid for 10 minutes.`;

    const res = await this.sendMail({
      to: email,
      subject,
      html,
      text,
      fromName: config.appName
    });
    logger.info(`OTP email sent successfully to ${email}`);
    return !!res?.success;
  }
}

export default new EmailService();
