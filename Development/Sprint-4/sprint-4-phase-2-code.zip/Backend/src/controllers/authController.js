import User from "../models/User.js";
import Driver from "../models/Driver.js";
import emailService from "../services/emailService.js";
import jwt from "jsonwebtoken";
import crypto from "node:crypto";
import { v4 as uuidv4 } from "uuid";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

// Parse email from req.body, normalize it, look up user. Returns { email, user } or sends 400 and returns null.
async function resolveEmail(email, res) {
  if (!email) {
    res.status(400).json({ success: false, message: "Email is required" });
    return null;
  }
  const normalized = email.toLowerCase().trim();
  const user = await User.findOne({ email: normalized });
  return { email: normalized, user };
}

function formatDriverForResubmission(driver) {
  return {
    id: driver._id,
    userId: driver.userId,
    name: driver.name,
    email: driver.email,
    cnic: driver.cnic,
    drivingLicense: driver.drivingLicense,
    vehicle: driver.vehicle,
    status: driver.status,
    adminMessage: driver.resubmissionNotes || "براہ کرم اپنی دستاویزات درست کریں"
  };
}

class AuthController {
  // Generate JWT
  generateToken(userId) {
    return jwt.sign({ userId }, config.jwtSecret, {
      expiresIn: config.jwtExpire
    });
  }

  // Request OTP for signup
  async signup(req, res) {
    try {
      let { name, email, pin, role, trustedContactEmail, trustedContactName } =
        req.body;

      if (!name) {
        return res.status(400).json({
          success: false,
          message: "Name is required"
        });
      }

      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({
          success: false,
          message: "Invalid email format"
        });
      }

      email = email.toLowerCase().trim();

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: "User already exists. Please login."
        });
      }

      if (!/^\d{4}$/.test(pin)) {
        return res.status(400).json({
          success: false,
          message: "PIN must be exactly 4 digits"
        });
      }

      // Validate trusted contact email if provided
      if (trustedContactEmail) {
        const trustedEmail = trustedContactEmail.toLowerCase().trim();

        if (!emailRegex.test(trustedEmail)) {
          return res.status(400).json({
            success: false,
            message: "Invalid trusted contact email format"
          });
        }

        if (trustedEmail === email) {
          return res.status(400).json({
            success: false,
            message: "Trusted contact email cannot be the same as your email"
          });
        }
      }

      // Generate verification token
      const verificationToken = crypto.randomBytes(32).toString("hex");
      const verificationTokenExpiry = new Date(
        Date.now() + 24 * 60 * 60 * 1000
      ); // 24 hours

      const userData = new User({
        userId: uuidv4(),
        name: name.trim(),
        email,
        pin,
        role: role || "commuter",
        isVerified: false,
        verificationToken,
        verificationTokenExpiry
      });

      // Add trusted contact if provided
      if (trustedContactEmail) {
        userData.trustedContacts = [
          {
            email: trustedContactEmail.toLowerCase().trim(),
            name: trustedContactName?.trim() || undefined
          }
        ];
      }

      const user = new User(userData);
      await user.save();

      // Send verification email
      const verificationUrl = `${config.frontendUrl}/verify-email?token=${verificationToken}`;
      await emailService.sendVerificationEmail(email, verificationUrl);

      res.status(201).json({
        success: true,
        message:
          "Account created successfully. Please check your email to verify your account.",
        data: {
          email: user.email
        }
      });
    } catch (error) {
      logger.error("Error in signup:", error);
      res.status(500).json({
        success: false,
        message: "Failed to create account"
      });
    }
  }

  // Verify email
  async verifyEmail(req, res) {
    try {
      const { token } = req.query;

      if (!token) {
        return res.status(400).json({
          success: false,
          message: "Verification token is required"
        });
      }

      const user = await User.findOne({
        verificationToken: String(token),
        verificationTokenExpiry: { $gt: Date.now() }
      });

      if (!user) {
        return res.status(400).json({
          success: false,
          message: "Invalid or expired verification token"
        });
      }

      user.isVerified = true;
      user.verificationToken = undefined;
      user.verificationTokenExpiry = undefined;
      await user.save();

      const authToken = this.generateToken(user._id);

      res.status(200).json({
        success: true,
        message: "Email verified successfully",
        data: {
          user: {
            id: user._id,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified
          },
          token: authToken
        }
      });
    } catch (error) {
      logger.error("Error in verifyEmail:", error);
      res.status(500).json({
        success: false,
        message: "Email verification failed"
      });
    }
  }

  // Resend verification email
  async resendVerificationEmail(req, res) {
    try {
      const resolved = await resolveEmail(req.body.email, res);
      if (!resolved) return;
      const { email, user } = resolved;

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      if (user.isVerified) {
        return res.status(400).json({
          success: false,
          message: "Email is already verified"
        });
      }

      // Generate new verification token
      const verificationToken = crypto.randomBytes(32).toString("hex");
      const verificationTokenExpiry = new Date(
        Date.now() + 24 * 60 * 60 * 1000
      );

      user.verificationToken = verificationToken;
      user.verificationTokenExpiry = verificationTokenExpiry;
      await user.save();

      // Send verification email
      const verificationUrl = `${config.frontendUrl}/verify-email?token=${verificationToken}`;
      await emailService.sendVerificationEmail(email, verificationUrl);

      res.status(200).json({
        success: true,
        message: "Verification email sent successfully"
      });
    } catch (error) {
      logger.error("Error in resendVerificationEmail:", error);
      res.status(500).json({
        success: false,
        message: "Failed to resend verification email"
      });
    }
  }

  // Check if email is registered (used by frontend before showing PIN screen)
  async checkEmail(req, res) {
    try {
      const resolved = await resolveEmail(req.body.email, res);
      if (!resolved) return;
      return res.status(200).json({ success: true, exists: !!resolved.user });
    } catch (err) {
      logger.error("Error in checkEmail:", err);
      return res.status(500).json({ success: false, message: "Server error" });
    }
  }

  // Login
  async login(req, res) {
    try {
      let { email, pin } = req.body;

      if (!email || !pin) {
        return res.status(400).json({
          success: false,
          message: "Email and PIN are required"
        });
      }

      email = email.toLowerCase().trim();

      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: "Invalid email or PIN"
        });
      }

      if (!user.isVerified) {
        return res.status(403).json({
          success: false,
          message: "Please verify your email before logging in"
        });
      }

      // Check if account is suspended
      if (user.isSuspended) {
        return res.status(403).json({
          success: false,
          message:
            "Your account has been suspended by an administrator. Please contact support for more information.",
          accountStatus: "suspended",
          reason: user.suspensionReason
        });
      }

      // Check if account is deactivated
      if (user.isActive === false) {
        return res.status(403).json({
          success: false,
          message:
            "Your account has been deactivated by an administrator. Please contact support to reactivate your account.",
          accountStatus: "deactivated",
          reason: user.deactivationReason
        });
      }

      // Driver-specific checks
      if (user.role === "driver") {
        const driver = await Driver.findOne({ userId: user.userId });

        if (!driver) {
          return res.status(403).json({
            success: false,
            message: "Driver profile not found"
          });
        }

        if (driver.status === "resubmission_required") {
          const token = this.generateToken(user._id);
          return res.status(200).json({
            success: false,
            message: "Please resubmit your documents as requested by the administrator.",
            requiresResubmission: true,
            data: {
              driver: formatDriverForResubmission(driver),
              token,
              user: { id: user._id, userId: user.userId, role: user.role }
            }
          });
        }

        // other driver statuses
        if (driver.status !== "approved") {
          const statusMessages = {
            pending: "Please wait for admin to verify your account",
            rejected: "Your account has been rejected",
            suspended: "Your account has been suspended"
          };

          return res.status(403).json({
            success: false,
            message:
              statusMessages[driver.status] ||
              "Your driver account is not approved yet"
          });
        }
      }
      const isPinValid = await user.comparePin(pin);
      if (!isPinValid) {
        return res.status(401).json({
          success: false,
          message: "Invalid email or PIN"
        });
      }

      user.lastLogin = new Date();
      await user.save();

      const token = this.generateToken(user._id);

      res.status(200).json({
        success: true,
        message: "Login successful",
        data: {
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            role: user.role
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in login:", error);
      res.status(500).json({
        success: false,
        message: "Login failed"
      });
    }
  }
}

export default new AuthController();
