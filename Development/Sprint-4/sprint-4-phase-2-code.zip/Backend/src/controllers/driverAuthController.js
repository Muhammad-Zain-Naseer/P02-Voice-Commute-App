import Driver from "../models/Driver.js";
import User from "../models/User.js";
import OTP from "../models/OTP.js";
import AuditLog from "../models/AuditLog.js";
import emailService from "../services/emailService.js";
import jwt from "jsonwebtoken";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";
import { v4 as uuidv4 } from "uuid";
import { AppError } from "../utils/appError.js";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { existsSync, unlinkSync } from "node:fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class DriverAuthController {
  stripJwtMeta(data) {
    if (!data) return data;
    const { exp, iat, nbf, jti, ...clean } = data;
    return clean;
  }

  generateRegistrationToken(data) {
    return jwt.sign(
      { ...data, role: "driver_registration" },
      config.jwtSecret,
      {
        expiresIn: "1h"
      }
    );
  }

  generateToken(driverId) {
    return jwt.sign({ driverId, role: "driver" }, config.jwtSecret, {
      expiresIn: config.jwtExpire
    });
  }

  _formatDriverData(driver) {
    return {
      id: driver._id,
      userId: driver.userId,
      name: driver.name,
      email: driver.email,
      cnic: driver.cnic,
      drivingLicense: driver.drivingLicense,
      vehicle: driver.vehicle,
      status: driver.status
    };
  }

  generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  async requestOTP(req, res) {
    try {
      let { email } = req.body;

      if (!email)
        return res
          .status(400)
          .json({ success: false, message: "Email is required" });

      email = email.toLowerCase().trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email))
        return res
          .status(400)
          .json({ success: false, message: "Invalid email format" });

      const existingDriver = await Driver.findOne({ email, isVerified: true });
      if (existingDriver) {
        return res.status(400).json({
          success: false,
          message: "Driver account already exists. Please login."
        });
      }

      const otp = this.generateOTP();

      await OTP.deleteMany({ email, type: "driver_registration" });

      await OTP.create({
        email,
        otp,
        type: "driver_registration"
      });

      await emailService.sendOTP(email, otp);

      res.status(200).json({
        success: true,
        message: "OTP sent successfully",
        data: { email }
      });
    } catch (error) {
      logger.error("Error in requestOTP:", error);
      res.status(500).json({ success: false, message: "Failed to send OTP" });
    }
  }

  async verifyOTP(req, res) {
    try {
      let { email, otp } = req.body;
      if (!email || !otp)
        return res
          .status(400)
          .json({ success: false, message: "Email and OTP are required" });

      email = email.toLowerCase().trim();

      const otpRecord = await OTP.findOne({
        email: String(email),
        otp: String(otp),
        type: "driver_registration"
      });

      if (!otpRecord)
        return res
          .status(400)
          .json({ success: false, message: "Invalid or expired OTP" });

      await OTP.deleteOne({ _id: otpRecord._id });

      const tempToken = this.generateRegistrationToken({ email });

      res.status(200).json({
        success: true,
        message: "OTP verified successfully",
        data: {
          email,
          token: tempToken
        }
      });
    } catch (error) {
      logger.error("Error in verifyOTP:", error);
      res
        .status(500)
        .json({ success: false, message: "OTP verification failed" });
    }
  }

  async submitName(req, res) {
    try {
      const { name } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!name || name.trim().length < 2)
        return res
          .status(400)
          .json({ success: false, message: "Valid name is required" });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        name: name.trim()
      });

      res.status(200).json({
        success: true,
        message: "Name saved successfully",
        data: {
          name: name.trim(),
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitName:", error);
      res.status(500).json({ success: false, message: "Failed to save name" });
    }
  }

  async submitCNIC(req, res) {
    try {
      const { cnic } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!cnic)
        return res
          .status(400)
          .json({ success: false, message: "CNIC is required" });

      const cleanCNIC = cnic.replaceAll("-", "").replaceAll(" ", "");
      if (!/^\d{13}$/.test(cleanCNIC))
        return res
          .status(400)
          .json({ success: false, message: "CNIC must be 13 digits" });

      const existingDriver = await Driver.findOne({ cnic: cleanCNIC });
      if (existingDriver)
        return res
          .status(400)
          .json({ success: false, message: "This CNIC is already registered" });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        cnic: cleanCNIC
      });

      res.status(200).json({
        success: true,
        message: "CNIC saved successfully",
        data: {
          cnic: cleanCNIC,
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitCNIC:", error);
      res.status(500).json({ success: false, message: "Failed to save CNIC" });
    }
  }

  async submitDrivingLicense(req, res) {
    try {
      const { drivingLicense } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!drivingLicense)
        return res.status(400).json({
          success: false,
          message: "Driving license number is required"
        });

      const cleanLicense = drivingLicense.trim().toUpperCase();

      const licensePattern = /^[A-Z]{3}-?\d{7}$/;
      if (!licensePattern.test(cleanLicense.replaceAll("-", ""))) {
        return res.status(400).json({
          success: false,
          message: "Invalid license format. Expected format: LHR-1234567"
        });
      }

      const existingDriver = await Driver.findOne({
        drivingLicense: cleanLicense
      });
      if (existingDriver)
        return res.status(400).json({
          success: false,
          message: "This driving license is already registered"
        });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        drivingLicense: cleanLicense
      });

      res.status(200).json({
        success: true,
        message: "Driving license saved successfully",
        data: {
          drivingLicense: cleanLicense,
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitDrivingLicense:", error);
      res
        .status(500)
        .json({ success: false, message: "Failed to save driving license" });
    }
  }

  async submitVehicleRegistration(req, res) {
    try {
      const registrationData = this.stripJwtMeta(req.driver);
      const { registrationNumber, color, model, year } = req.body;

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "Vehicle registration photo is required"
        });
      }

      if (!registrationNumber) {
        return res.status(400).json({
          success: false,
          message: "Vehicle registration number is required"
        });
      }
      if (!color) {
        return res
          .status(400)
          .json({ success: false, message: "Vehicle color is required" });
      }
      if (!model) {
        return res
          .status(400)
          .json({ success: false, message: "Vehicle model is required" });
      }
      if (!year) {
        return res
          .status(400)
          .json({ success: false, message: "Vehicle year is required" });
      }

      if (!registrationData.name) {
        return res.status(400).json({
          success: false,
          message: "Please complete the name step first"
        });
      }
      if (!registrationData.cnic) {
        return res.status(400).json({
          success: false,
          message: "Please complete the CNIC step first"
        });
      }
      if (!registrationData.drivingLicense) {
        return res.status(400).json({
          success: false,
          message: "Please complete the driving license step first"
        });
      }

      const cleanRegNumber = registrationNumber
        .toUpperCase()
        .replaceAll(" ", "")
        .replaceAll("-", "");

      const existingVehicle = await Driver.findOne({
        "vehicle.registrationNumber": cleanRegNumber
      });
      if (existingVehicle) {
        return res.status(400).json({
          success: false,
          message: "This vehicle is already registered"
        });
      }

      const registrationPhotoUrlPath = `/uploads/vehicle-registrations/${req.file.filename}`;

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        vehicle: {
          registrationNumber: cleanRegNumber,
          color: color.trim(),
          model: model.trim(),
          year: year.trim(),
          registrationPhoto: registrationPhotoUrlPath
        }
      });

      res.status(200).json({
        success: true,
        message:
          "Vehicle registration saved successfully. Please set up your PIN.",
        data: {
          vehicle: {
            registrationNumber: cleanRegNumber,
            color: color.trim(),
            model: model.trim(),
            year: year.trim(),
            registrationPhoto: registrationPhotoUrlPath
          },
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitVehicleRegistration:", error);
      res.status(500).json({
        success: false,
        message: "Failed to save vehicle registration"
      });
    }
  }

  async submitPIN(req, res) {
    try {
      const registrationData = this.stripJwtMeta(req.driver);
      const { pin } = req.body;

      if (!pin)
        return res
          .status(400)
          .json({ success: false, message: "PIN is required" });

      const cleanPin = pin.toString().trim();
      if (!/^\d{4}$/.test(cleanPin))
        return res
          .status(400)
          .json({ success: false, message: "PIN must be exactly 4 digits" });

      if (!registrationData.email)
        return res.status(400).json({
          success: false,
          message: "Invalid registration session"
        });
      if (!registrationData.name)
        return res.status(400).json({
          success: false,
          message: "Please complete the name step first"
        });
      if (!registrationData.cnic)
        return res.status(400).json({
          success: false,
          message: "Please complete the CNIC step first"
        });
      if (!registrationData.drivingLicense)
        return res.status(400).json({
          success: false,
          message: "Please complete the driving license step first"
        });

      if (!registrationData.vehicle?.registrationPhoto)
        return res.status(400).json({
          success: false,
          message: "Please complete the vehicle registration step first"
        });

      const existingDriver = await Driver.findOne({
        email: registrationData.email
      });
      if (existingDriver) {
        return res.status(400).json({
          success: false,
          message: "Driver account already exists"
        });
      }

      const userId = uuidv4();

      const user = new User({
        userId,
        name: registrationData.name,
        email: registrationData.email,
        pin: cleanPin,
        role: "driver",
        isVerified: true
      });
      await user.save();

      const driver = new Driver({
        userId,
        email: registrationData.email,
        name: registrationData.name,
        cnic: registrationData.cnic,
        drivingLicense: registrationData.drivingLicense,
        vehicle: registrationData.vehicle,
        isVerified: true,
        status: "pending"
      });
      await driver.save();

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Registration completed successfully",
        data: { driver: this._formatDriverData(driver), token }
      });
    } catch (error) {
      logger.error("Error in submitPIN:", error);
      res
        .status(500)
        .json({ success: false, message: "Failed to complete registration" });
    }
  }

  async login(req, res) {
    try {
      let { email } = req.body;
      if (!email)
        return res
          .status(400)
          .json({ success: false, message: "Email is required" });
      email = email.toLowerCase().trim();

      const driver = await Driver.findOne({ email });
      if (!driver)
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });

      const user = await User.findOne({ userId: driver.userId });
      if (!user)
        return res
          .status(401)
          .json({ success: false, message: "User account not found" });

      if (user.isSuspended) {
        return res.status(403).json({
          success: false,
          message:
            "Your account has been suspended by an administrator. Please contact support for more information.",
          accountStatus: "suspended",
          reason: user.suspensionReason
        });
      }

      if (user.isActive === false) {
        return res.status(403).json({
          success: false,
          message:
            "Your account has been deactivated by an administrator. Please contact support to reactivate your account.",
          accountStatus: "deactivated",
          reason: user.deactivationReason
        });
      }

      if (!driver.isVerified)
        return res.status(403).json({
          success: false,
          message: "Please complete your registration"
        });

      if (driver.status === "resubmission_required") {
        const token = this.generateToken(driver._id);
        return res.status(200).json({
          success: false,
          message: "Please resubmit your documents as requested by the administrator.",
          requiresResubmission: true,
          data: { driver: this._formatDriverData(driver), token }
        });
      }

      if (driver.status === "rejected")
        return res
          .status(403)
          .json({ success: false, message: "Your account has been rejected." });

      if (driver.status === "suspended")
        return res.status(403).json({
          success: false,
          message: "Your driver account has been suspended by an administrator."
        });

      if (driver.status === "pending")
        return res.status(403).json({
          success: false,
          message: "Please wait for admin to verify your documents."
        });

      driver.lastLogin = new Date();
      await driver.save();

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Login successful",
        data: {
          driver: { ...this._formatDriverData(driver), averageRating: driver.averageRating },
          token
        }
      });
    } catch (error) {
      logger.error("Error in driver login:", error);
      res.status(500).json({ success: false, message: "Login failed" });
    }
  }

  async resubmitDocuments(req, res) {
    try {
      const {
        name,
        cnic,
        drivingLicense,
        registrationNumber,
        model,
        year,
        color
      } = req.body;

      const driver = req.driver;

      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver not found"
        });
      }

      if (driver.status !== "resubmission_required") {
        return res.status(400).json({
          success: false,
          message: "Resubmission is only allowed when admin has requested it"
        });
      }

      await this._logResubmissionAttempt(req, driver, {
        name,
        cnic,
        drivingLicense,
        registrationNumber,
        model,
        year,
        color
      });

      this._updateDriverFields(driver, {
        name,
        cnic,
        drivingLicense,
        registrationNumber,
        model,
        year,
        color
      });

      if (req.file) {
        await this._handleFileUpdate(driver, req.file);
      }

      this._resetVerificationStatus(driver);

      await driver.save();

      await AuditLog.create({
        timestamp: new Date(),
        action: "RESUBMISSION_SUCCESS",
        driverId: driver._id,
        email: driver.email,
        ipAddress: req.ip
      });

      res.status(200).json({
        success: true,
        message: "Documents resubmitted successfully. Awaiting admin review.",
        data: {
          driver: {
            name: driver.name,
            status: driver.status,
            email: driver.email
          }
        }
      });
    } catch (error) {
      await AuditLog.create({
        timestamp: new Date(),
        action: "RESUBMISSION_FAILURE",
        driverId: req.driver?._id,
        email: req.driver?.email,
        ipAddress: req.ip,
        error: error.message
      }).catch(() => {});

      logger.error("Error in resubmitDocuments:", error);
      res.status(500).json({
        success: false,
        message: "Failed to resubmit documents"
      });
    }
  }

  async _logResubmissionAttempt(req, driver, fields) {
    const auditLog = {
      timestamp: new Date(),
      action: "RESUBMISSION_ATTEMPT",
      driverId: driver._id,
      email: driver.email,
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
      changedFields: {
        name: { old: driver.name, new: fields.name || driver.name },
        cnic: { old: driver.cnic, new: fields.cnic || driver.cnic },
        drivingLicense: {
          old: driver.drivingLicense,
          new: fields.drivingLicense || driver.drivingLicense
        },
        vehicle: {
          registrationNumber: {
            old: driver.vehicle?.registrationNumber,
            new: fields.registrationNumber || driver.vehicle?.registrationNumber
          },
          model: {
            old: driver.vehicle?.model,
            new: fields.model || driver.vehicle?.model
          },
          year: {
            old: driver.vehicle?.year,
            new: fields.year || driver.vehicle?.year
          },
          color: {
            old: driver.vehicle?.color,
            new: fields.color || driver.vehicle?.color
          }
        }
      },
      fileUploaded: !!req.file,
      fileHash: req.fileHash || null
    };

    await AuditLog.create(auditLog);
  }

  _updateDriverFields(driver, fields) {
    const {
      name,
      cnic,
      drivingLicense,
      registrationNumber,
      model,
      year,
      color
    } = fields;

    if (name?.trim()) driver.name = name.trim();
    if (cnic) driver.cnic = cnic;
    if (drivingLicense) driver.drivingLicense = drivingLicense;

    if (registrationNumber)
      driver.vehicle.registrationNumber = registrationNumber;
    if (model?.trim()) driver.vehicle.model = model.trim();
    if (year) driver.vehicle.year = year;
    if (color?.trim()) driver.vehicle.color = color.trim();
  }

  async _handleFileUpdate(driver, file) {
    if (driver.vehicle?.registrationPhoto) {
      const oldPhotoPath = join(
        process.cwd(),
        "public",
        driver.vehicle.registrationPhoto
      );

      if (existsSync(oldPhotoPath)) {
        try {
          unlinkSync(oldPhotoPath);
        } catch (err) {
          logger.error("Could not delete old photo:", err.message);
        }
      }
    }

    driver.vehicle.registrationPhoto = `/uploads/vehicle-registrations/${file.filename}`;
  }

  _resetVerificationStatus(driver) {
    driver.status = "pending";
    driver.resubmissionNotes = undefined;
    driver.rejectionReason = undefined;
    driver.verifiedBy = undefined;
    driver.verifiedAt = undefined;

    driver.verificationHistory.push({
      action: "resubmission_required",
      timestamp: new Date(),
      reason: "Documents resubmitted by driver"
    });
  }

  async getResubmissionStatus(req, res) {
    try {
      const user = await User.findById(req.driver.userId);

      if (!user) {
        throw new AppError("User not found", 404);
      }

      const driver = await Driver.findOne({ userId: user.userId });

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      const needsResubmission = driver.status === "resubmission_required";

      res.status(200).json({
        success: true,
        data: {
          needsResubmission,
          status: driver.status,
          adminMessage: driver.resubmissionNotes || null,
          driver: {
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle
          }
        }
      });
    } catch (error) {
      logger.error("Error in getResubmissionStatus:", error);
      if (error instanceof AppError) {
        return res
          .status(error.statusCode)
          .json({ success: false, message: error.message });
      }
      res
        .status(500)
        .json({ success: false, message: "Failed to get resubmission status" });
    }
  }
}

export default new DriverAuthController();
