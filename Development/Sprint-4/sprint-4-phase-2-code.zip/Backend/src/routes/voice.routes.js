import express from 'express';
import axios from 'axios';
import geminiService from '../services/gemini.service.js';

const router = express.Router();

// ── Text to Speech ────────────────────────────────────────────────────────────
// POST /api/voice/tts
// Body: { text: string }
router.post('/tts', async (req, res) => {
    try {
        const { text } = req.body;

        const response = await axios.post(
            `https://texttospeech.googleapis.com/v1/text:synthesize?key=${process.env.GOOGLE_TTS_API_KEY}`,
            {
                input: { text },
                voice: {
                    languageCode: 'ur-IN',
                    name: 'ur-IN-Chirp3-HD-Callirrhoe',
                    ssmlGender: 'FEMALE',
                },
                audioConfig: {
                    audioEncoding: 'MP3',
                    speakingRate: 1,
                    pitch: 0,
                },
            }
        );

        res.json({ success: true, audioContent: response.data.audioContent });
    } catch (error) {
        console.error('TTS Error:', error.response?.data);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ── Interpret speech intent (welcome screen) ──────────────────────────────────
// POST /api/voice/interpret
// Body: { audioBase64: string, mimeType: string }
// Returns: { matched: 0|1|2|-1 }
router.post('/interpret', async (req, res) => {
    try {
        const { audioBase64, mimeType = 'audio/wav' } = req.body;

        if (!audioBase64) {
            return res.json({ success: true, matched: -1 });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({ success: false, error: 'Gemini service not available' });
        }

        const matched = await geminiService.interpretAudio(audioBase64, mimeType);
        res.json({ success: true, matched });
    } catch (error) {
        console.error('Interpret Error:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ── Extract email from audio (login/signup email screens) ─────────────────────
// POST /api/voice/extract-email
// Body: { audioBase64: string, mimeType: string }
// Returns: { email: string|null }
router.post('/extract-email', async (req, res) => {
    try {
        const { audioBase64, mimeType = 'audio/wav' } = req.body;

        if (!audioBase64) {
            return res.json({ success: true, email: null });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({ success: false, error: 'Gemini service not available' });
        }

        const email = await geminiService.extractEmailFromAudio(audioBase64, mimeType);
        res.json({ success: true, email });
    } catch (error) {
        console.error('Extract email error:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ── Extract name from audio (signup name screens) ────────────────────────────
// POST /api/voice/extract-name
// Body: { audioBase64: string, mimeType: string }
// Returns: { name: string|null }
router.post('/extract-name', async (req, res) => {
    try {
        const { audioBase64, mimeType = 'audio/wav' } = req.body;

        if (!audioBase64) {
            return res.json({ success: true, name: null });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({ success: false, error: 'Gemini service not available' });
        }

        const name = await geminiService.extractNameFromAudio(audioBase64, mimeType);
        res.json({ success: true, name });
    } catch (error) {
        console.error('Extract name error:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

// ── Extract PIN from audio (login/signup PIN screens) ─────────────────────────
// POST /api/voice/extract-pin
// Body: { audioBase64: string, mimeType: string }
// Returns: { pin: string|null }
router.post('/extract-pin', async (req, res) => {
    try {
        const { audioBase64, mimeType = 'audio/mp4' } = req.body;

        if (!audioBase64) {
            return res.json({ success: true, pin: null });
        }

        if (!geminiService.isAvailable()) {
            return res.status(503).json({ success: false, error: 'Gemini service not available' });
        }

        const pin = await geminiService.extractPinFromAudio(audioBase64, mimeType);
        res.json({ success: true, pin });
    } catch (error) {
        console.error('Extract PIN error:', error.message);
        res.status(500).json({ success: false, error: error.message });
    }
});

export default router;
