import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'screens/home_screen.dart';
import 'screens/admin/admin_home_screen.dart';
import 'screens/driver/driver_dashboard.dart';
import 'services/storage_service.dart';
import 'services/audio_player_service.dart';
import 'screens/landing_page.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  runApp(const HerSafarApp());
}

class HerSafarApp extends StatefulWidget {
  const HerSafarApp({super.key});

  @override
  State<HerSafarApp> createState() => _HerSafarAppState();
}

class _HerSafarAppState extends State<HerSafarApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden ||
        state == AppLifecycleState.inactive) {
      AudioPlayerService.onAppPaused();
    } else if (state == AppLifecycleState.resumed) {
      AudioPlayerService.onAppResumed();
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HerSafar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
        fontFamily: 'Urdu',
      ),
      home: const _AuthCheck(),
    );
  }
}

class _AuthCheck extends StatefulWidget {
  const _AuthCheck();

  @override
  State<_AuthCheck> createState() => _AuthCheckState();
}

class _AuthCheckState extends State<_AuthCheck> {
  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    final token = await StorageService.getToken();

    if (!mounted) return;

    if (token == null || token.isEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LandingPage()),
      );
      return;
    }

    final role = await StorageService.getUserRole() ?? 'commuter';
    final userName = await StorageService.getUserName() ?? 'User';
    final userEmail = await StorageService.getUserEmail() ?? '';
    final userId = await StorageService.getUserId() ?? '';

    if (!mounted) return;

    Widget destination;
    if (role == 'driver') {
      destination = const DriverDashboard();
    } else if (role == 'admin') {
      destination = AdminHomeScreen(
        userName: userName,
        userEmail: userEmail,
        token: token,
      );
    } else {
      destination = HomeScreen(
        userName: userName,
        userEmail: userEmail,
        userId: userId,
      );
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => destination),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      ),
    );
  }
}