import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../../widgets/sound_wave.dart';
import '../../../services/driver_auth_service.dart';
import 'driver_signup_vehicle_screen.dart';

class DriverSignupLicenseScreen extends StatefulWidget {
  final String email;
  final String token;

  const DriverSignupLicenseScreen({
    super.key,
    required this.email,
    required this.token,
  });

  @override
  State<DriverSignupLicenseScreen> createState() =>
      _DriverSignupLicenseScreenState();
}

class _DriverSignupLicenseScreenState
    extends State<DriverSignupLicenseScreen> {
  final TextEditingController _licenseController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _licenseController.dispose();
    super.dispose();
  }

  /// FORMAT: LHR-1234567
  String _formatLicense(String input) {
    String clean = input.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();

    if (clean.length > 3 && clean.length <= 10) {
      return "${clean.substring(0, 3)}-${clean.substring(3)}";
    } else if (clean.length > 10) {
      return "${clean.substring(0, 3)}-${clean.substring(3, 10)}";
    }

    return clean;
  }

  Future<void> _continue() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      try {
        // Call API to submit driving license
        final result = await DriverAuthService.submitDrivingLicense(
          _licenseController.text.trim().toUpperCase(),
          widget.token,
        );

        if (!mounted) return;

        if (result['success']) {

          final newToken = result['token'];
          
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DriverSignupVehicleScreen(
                email: widget.email,
                token: newToken,  
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(result['message'] ?? 'Failed to save license'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        if (mounted) {
          setState(() => _isLoading = false);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                // Top Row
                SizedBox(
                  height: 70,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const SizedBox(width: 48),
                      SvgPicture.asset(
                        'assets/icons/car_icon.svg',
                        width: 70,
                        height: 70,
                      ),
                      SizedBox(
                        width: 48,
                        child: IconButton(
                          icon: const Icon(
                            Icons.arrow_forward_ios,
                            color: Color(0xFFCF4374),
                            size: 24,
                          ),
                          onPressed: () => Navigator.pop(context),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),
                const SoundWave(),
                const SizedBox(height: 40),

                const Text(
                  'ڈرائیونگ لائسنس نمبر درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 30),

                // FORM FIELD
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _licenseController,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                    textCapitalization: TextCapitalization.characters,
                    enabled: !_isLoading,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Color(0xFFCF4374),
                      letterSpacing: 1.5,
                    ),
                    onChanged: (value) {
                      final formatted = _formatLicense(value);
                      if (formatted != value) {
                        _licenseController.value = TextEditingValue(
                          text: formatted,
                          selection: TextSelection.collapsed(
                              offset: formatted.length),
                        );
                      }
                    },
                    decoration: InputDecoration(
                      hintText: 'LHR-1234567',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.4),
                        fontSize: 18,
                      ),
                      filled: true,
                      fillColor: Colors.white.withValues(alpha: 0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFCF4374), width: 2),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 1.5,
                        ),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 2,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 18,
                      ),
                      errorStyle: const TextStyle(fontSize: 11),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'لائسنس نمبر درج کریں';
                      }

                      final clean =
                          value.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');

                      if (clean.length != 10) {
                        return 'لائسنس نمبر 10 حروف کا ہونا چاہیے';
                      }

                      if (!RegExp(r'^[A-Z]{3}[0-9]{7}$').hasMatch(clean)) {
                        return 'غلط فارمیٹ (مثال: LHR-1234567)';
                      }

                      return null;
                    },
                  ),
                ),

                const Spacer(),

                // BUTTON
                GestureDetector(
                  onTap: _isLoading ? null : _continue,
                  child: Container(
                    width: 200,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (_isLoading)
                          const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        else ...[
                          const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                            size: 24,
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'اگلا',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}