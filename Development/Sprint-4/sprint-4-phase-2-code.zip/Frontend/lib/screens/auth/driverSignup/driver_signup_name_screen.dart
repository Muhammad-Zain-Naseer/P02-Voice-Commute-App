import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import '../../../widgets/sound_wave.dart';
import 'package:hersafar/constants/app_config.dart';
import 'driver_signup_cnic_screen.dart';

class DriverSignupNameScreen extends StatefulWidget {
  final String email;
  final String token;

  const DriverSignupNameScreen({
    super.key,
    required this.email,
    required this.token,
  });

  @override
  State<DriverSignupNameScreen> createState() => _DriverSignupNameScreenState();
}

class _DriverSignupNameScreenState extends State<DriverSignupNameScreen> {
  final TextEditingController _nameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: isError ? Colors.red : Colors.green),
    );
  }

  void _navigateToCnic(String newToken) {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        Navigator.push(context, MaterialPageRoute(builder: (context) => DriverSignupCnicScreen(email: widget.email, token: newToken)));
      }
    });
  }

  Future<void> _submitName() async {
    final url = Uri.parse('${AppConfig.apiBaseUrl}/api/driver/auth/submit-name');
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json", "Authorization": "Bearer ${widget.token}"},
      body: jsonEncode({"name": _nameController.text.trim()}),
    );
    if (!mounted) return;
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success'] == true) {
        _showSnack('نام محفوظ ہو گیا');
        _navigateToCnic(data['data']['token']);
      } else {
        _showSnack(data['message'] ?? 'نام محفوظ کرنے میں ناکام', isError: true);
      }
    } else {
      _showSnack('سرور میں خرابی: ${response.statusCode}', isError: true);
    }
  }

  Future<void> _continue() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    try {
      await _submitName();
    } catch (e) {
      _showSnack('نیٹ ورک میں خرابی: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Widget _buildNameField() {
    return Form(
      key: _formKey,
      child: TextFormField(
        controller: _nameController,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.center,
        enabled: !_isLoading,
        style: const TextStyle(fontSize: 16, color: Color(0xFFCF4374)),
        decoration: InputDecoration(
          hintText: 'نام',
          hintStyle: TextStyle(color: const Color(0xFFCF4374).withValues(alpha: 0.4), fontSize: 16),
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.8),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFF682AA), width: 1.5)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFF682AA), width: 1.5)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFCF4374), width: 2)),
          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red, width: 1.5)),
          focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red, width: 2)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          errorStyle: const TextStyle(height: 0),
        ),
        validator: (value) {
          if (value == null || value.trim().isEmpty) return '';
          if (value.trim().length < 2) return '';
          return null;
        },
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _continue,
      child: Container(
        width: 200,
        height: 56,
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFCF4374), Color(0xFF69223B)]),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: const Color(0xFFCF4374).withValues(alpha: 0.3), blurRadius: 10, spreadRadius: 2)],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isLoading)
              const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            else ...[
              const Icon(Icons.arrow_back, color: Colors.white, size: 24),
              const SizedBox(width: 8),
              const Text('اگلا', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)]),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                SizedBox(
                  height: 70,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const SizedBox(width: 48),
                      SvgPicture.asset('assets/icons/car_icon.svg', width: 70, height: 70),
                      SizedBox(
                        width: 48,
                        child: IconButton(
                          icon: const Icon(Icons.arrow_forward_ios, color: Color(0xFFCF4374), size: 24),
                          onPressed: () => Navigator.pop(context),
                          padding: EdgeInsets.zero,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                const SoundWave(),
                const SizedBox(height: 40),
                const Text('اپنا نام درج کریں', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFCF4374))),
                const SizedBox(height: 30),
                _buildNameField(),
                const Spacer(),
                _buildContinueButton(),
                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}