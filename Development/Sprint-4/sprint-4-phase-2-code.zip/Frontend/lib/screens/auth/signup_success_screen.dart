import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';

class SignupSuccessScreen extends StatefulWidget {
  final String email;
  final String name;

  const SignupSuccessScreen({
    super.key,
    required this.email,
    required this.name,
  });

  @override
  State<SignupSuccessScreen> createState() => _SignupSuccessScreenState();
}

class _SignupSuccessScreenState extends State<SignupSuccessScreen> {
  bool _isMuted = false;
  bool _isPromptPlaying = false;
  bool _speechCancelled = false;
  Timer? _replayTimer;

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 8), () async {
      if (!_isMuted && !_speechCancelled && !_isPromptPlaying && mounted) {
        await _speakPrompt();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();
    await _speakAndWait('رجسٹریشن کامیاب!');
    if (_speechCancelled || _isMuted) {
      _isPromptPlaying = false;
      return;
    }
    await _speakAndWait('مکمل بٹن دبائیں');
    _isPromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPrompt();
    });
  }

  @override
  void dispose() {
    _speechCancelled = true;
    _cancelReplayTimer();
    AudioPlayerService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              // Mute button top-right
              Positioned(
                top: 8,
                right: 8,
                child: GestureDetector(
                  onTap: _toggleMute,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.5),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                      color: const Color(0xFFCF4374),
                      size: 24,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Car Logo
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 100,
                      height: 100,
                    ),

                    const SizedBox(height: 30),

                    // Sound Wave
                    const SoundWave(),

                    const SizedBox(height: 40),

                    // Success Title
                    const Text(
                      'رجسٹریشن کامیاب',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),

                    const SizedBox(height: 30),

                    // Success Icon
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFFCF4374),
                            Color(0xFF69223B),
                          ],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 60,
                      ),
                    ),

                    const SizedBox(height: 40),

                    // User Details Box
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFAECF1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: const Color(0xFFF682AA),
                          width: 2,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            'رجسٹریشن کی معلومات',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Name
                          RichText(
                            textDirection: TextDirection.rtl,
                            text: TextSpan(
                              style: const TextStyle(
                                fontSize: 16,
                                color: Color(0xFFCF4374),
                              ),
                              children: [
                                const TextSpan(
                                  text: 'نام: ',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                TextSpan(text: widget.name),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Email
                          RichText(
                            textDirection: TextDirection.rtl,
                            text: TextSpan(
                              style: const TextStyle(
                                fontSize: 16,
                                color: Color(0xFFCF4374),
                              ),
                              children: [
                                const TextSpan(
                                  text: 'ای میل: ',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                TextSpan(text: widget.email),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Verification Message
                          Text(
                            'براہ کرم اپنی ای میل چیک کریں اور اکاؤنٹ کی تصدیق کریں',
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 14,
                              color: const Color(0xFFCF4374).withValues(alpha: 0.8),
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Done Button
                    GestureDetector(
                      onTap: () {
                        _speechCancelled = true;
                        _cancelReplayTimer();
                        AudioPlayerService.stop();
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      child: Container(
                        width: 200,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFFCF4374),
                              Color(0xFF69223B),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                              blurRadius: 10,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            'مکمل',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
