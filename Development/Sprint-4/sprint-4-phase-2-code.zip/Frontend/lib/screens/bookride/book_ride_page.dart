import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:record/record.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path_provider/path_provider.dart';
import 'dart:async';

import '../../services/audio_api_service.dart';
import '../../services/location_service.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../services/admin_service.dart';
import '../../utils/logger.dart';

import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import '../../widgets/mic_button.dart';
import '../../widgets/sound_wave.dart';

// Local page imports
import 'ride_waiting_page.dart';
import 'ride_started_page.dart';

class BookRidePage extends StatefulWidget {
  final String userId;
  final String userName;
  final String userEmail;

  const BookRidePage({
    super.key,
    required this.userId,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<BookRidePage> createState() => _BookRidePageState();
}

class _BookRidePageState extends State<BookRidePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _pulseAnimation;

  final AudioRecorder _audioRecorder = AudioRecorder();

  // Voice output states
  bool _isSpeaking = false;
  bool _isPromptPlaying = false; // mutex — prevents concurrent _speakPrompt instances
  bool _speechCancelled = false;
  bool _isMuted = false;
  Timer? _replayTimer;

  // Voice input states
  bool _isListening = false;
  bool _isProcessing = false;
  bool _isPublishing = false;

  // Intermediate stops
  final List<TextEditingController> _stopControllers = [];
  final List<Map<String, double>?> _stopCoordinates = [];

  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  String? _currentRideId;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.18).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _loadCurrentLocation();
    _initializeSocket();

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPrompt();
    });
  }

  // ── Voice Prompt Logic ───

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 10), () {
      if (!_isSpeaking &&
          !_isListening &&
          !_isProcessing &&
          !_isMuted &&
          !_isPromptPlaying &&
          mounted) {
        _speakPrompt();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakPrompt() async {
    if (_speechCancelled || _isMuted || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();

    if (mounted) setState(() => _isSpeaking = true);

    await _speakAndWait('آپ کہاں جانا چاہتے ہیں؟');
    await Future.delayed(const Duration(milliseconds: 400));

    if (!mounted || _speechCancelled || _isMuted) {
      if (mounted) setState(() => _isSpeaking = false);
      _isPromptPlaying = false;
      return;
    }

    await _speakAndWait('بولنے کے لیے مائیکروفون دبائیں');

    if (mounted) setState(() => _isSpeaking = false);
    _isPromptPlaying = false;

    if (!_speechCancelled && !_isMuted && mounted) {
      _startReplayTimer();
    }
  }

  // ── Socket ───

  void _onRideCreated(dynamic data) {
    Logger.log('✅ Ride created confirmation: $data');
    if (!mounted) return;

    setState(() {
      _isPublishing = false;
      _currentRideId = data['ride']['id'] as String?;
    });

    if (_currentRideId == null) return;

    final stopsForWaiting = <Map<String, dynamic>>[];
    for (int i = 0; i < _stopControllers.length; i++) {
      final addr = _stopControllers[i].text.trim();
      if (addr.isEmpty) continue;
      final coords = _stopCoordinates.length > i ? _stopCoordinates[i] : null;
      stopsForWaiting.add({
        'address': addr,
        'coordinates': coords != null
            ? {'lat': coords['lat'], 'lng': coords['lng']}
            : null,
      });
    }

    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => RideWaitingPage(
        rideId: _currentRideId!,
        source: _sourceController.text,
        destination: _destinationController.text,
        stops: stopsForWaiting,
      ),
    ));
  }

  void _onRideError(String message) {
    Logger.error('🔴 Ride error: $message');
    if (!mounted) return;

    setState(() => _isPublishing = false);
    if (Navigator.canPop(context)) Navigator.of(context).pop();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: $message'), backgroundColor: Colors.red),
    );
  }

  Future<void> _initializeSocket() async {
    try {
      await SocketService.connect(
        userId: widget.userId,
        userName: widget.userName,
        userEmail: widget.userEmail,
        userType: 'commuter',
      );

      SocketService.onRideCreated(_onRideCreated);

      SocketService.onRideMatched((ride, role) {
        Logger.log('🎉 Ride matched! Role: $role');
        if (mounted) {
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => RideStartedPage(ride: ride, role: role),
          ));
        }
      });

      SocketService.onRideError(_onRideError);
    } catch (e) {
      Logger.error('Failed to initialize socket: $e');
    }
  }

  // ── Location ────

  Future<void> _loadCurrentLocation() async {
    try {
      final location = await LocationService.getCurrentLocationAddress();
      if (location != null && mounted) {
        setState(() => _sourceController.text = location);
      }
    } catch (e) {
      Logger.error('❌ Error loading current location: $e');
    }
  }

  // ── Lifecycle ───

  @override
  void dispose() {
    _cancelReplayTimer();
    _speechCancelled = true;
    AudioPlayerService.stop();
    _animationController.dispose();
    _audioRecorder.dispose();
    _sourceController.dispose();
    _destinationController.dispose();
    for (final c in _stopControllers) {
      c.dispose();
    }
    SocketService.removeAllListeners();
    SocketService.disconnect();
    super.dispose();
  }

  // ── Stops management ───

  void _addStop() {
    if (_stopControllers.length >= 3) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'زیادہ سے زیادہ 3 اسٹاپ شامل کیے جا سکتے ہیں',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    setState(() {
      _stopControllers.add(TextEditingController());
      _stopCoordinates.add(null);
    });
  }

  void _removeStop(int index) {
    setState(() {
      _stopControllers[index].dispose();
      _stopControllers.removeAt(index);
      _stopCoordinates.removeAt(index);
    });
  }

  // ── Ride publishing ──

  bool _validateRideInput(String source, String destination) {
    if (source.isEmpty || destination.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('براہ کرم شروعاتی جگہ اور منزل دونوں درج کریں',
            textDirection: TextDirection.rtl),
        backgroundColor: Colors.orange,
      ));
      return false;
    }
    if (source == destination) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('شروعاتی جگہ اور منزل ایک جیسی نہیں ہو سکتی',
            textDirection: TextDirection.rtl),
        backgroundColor: Colors.orange,
      ));
      return false;
    }
    return true;
  }

  Future<List<Map<String, dynamic>>> _geocodeStops() async {
    final List<Map<String, dynamic>> stopsPayload = [];
    for (int i = 0; i < _stopControllers.length; i++) {
      final stopAddr = _stopControllers[i].text.trim();
      if (stopAddr.isEmpty) continue;

      final stopCoords = await MapService.geocodeAddress(stopAddr);
      if (stopCoords != null) {
        stopsPayload.add({
          'address': stopAddr,
          'coordinates': {
            'lat': stopCoords['latitude'],
            'lng': stopCoords['longitude'],
          },
        });
        if (i < _stopCoordinates.length) {
          _stopCoordinates[i] = {
            'lat': stopCoords['latitude'] as double,
            'lng': stopCoords['longitude'] as double,
          };
        }
      }
    }
    return stopsPayload;
  }

  Future<List<Map<String, dynamic>>> _checkUnsafeAreas(
    Map<String, dynamic> sourceCoords,
    Map<String, dynamic> destCoords,
  ) async {
    final adminService = AdminService();
    final sourceCheck = await adminService.checkUnsafeLocation(
      latitude: sourceCoords['latitude'] as double,
      longitude: sourceCoords['longitude'] as double,
    );
    final destCheck = await adminService.checkUnsafeLocation(
      latitude: destCoords['latitude'] as double,
      longitude: destCoords['longitude'] as double,
    );

    final unsafeAreas = <Map<String, dynamic>>[];
    if (sourceCheck['isUnsafe'] == true) {
      for (var area in sourceCheck['areas']) {
        unsafeAreas.add({...area, 'locationType': 'pickup'});
      }
    }
    if (destCheck['isUnsafe'] == true) {
      for (var area in destCheck['areas']) {
        unsafeAreas.add({...area, 'locationType': 'destination'});
      }
    }
    return unsafeAreas;
  }

  Future<void> _publishRide() async {
    _cancelReplayTimer();
    _speechCancelled = true;
    AudioPlayerService.stop();

    final source = _sourceController.text.trim();
    final destination = _destinationController.text.trim();

    if (!_validateRideInput(source, destination)) {
      _startReplayTimer();
      return;
    }

    if (!SocketService.isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('سرور سے منسلک نہیں۔ دوبارہ کوشش کریں۔',
            textDirection: TextDirection.rtl),
        backgroundColor: Colors.red,
      ));
      await _initializeSocket();
      _startReplayTimer();
      return;
    }

    setState(() => _isPublishing = true);

    try {
      final sourceCoords = await MapService.geocodeAddress(source);
      final destCoords = await MapService.geocodeAddress(destination);

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Failed to geocode addresses');
      }

      final unsafeAreas = await _checkUnsafeAreas(sourceCoords, destCoords);

      if (unsafeAreas.isNotEmpty && mounted) {
        setState(() => _isPublishing = false);
        final shouldContinue = await _showUnsafeAreaWarning(unsafeAreas);
        if (shouldContinue != true) {
          _startReplayTimer();
          return;
        }
        setState(() => _isPublishing = true);
      }

      final stopsPayload = await _geocodeStops();

      SocketService.emitRideRequest(
        source: source,
        destination: destination,
        sourceCoordinates: sourceCoords,
        destinationCoordinates: destCoords,
        stops: stopsPayload,
      );
    } catch (e) {
      Logger.error('💥 Failed to publish ride: $e');
      setState(() => _isPublishing = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
      _startReplayTimer();
    }
  }

  // ── Unsafe area warning dialog ───

  Widget _buildUnsafeAreaCard(Map<String, dynamic> area) {
    final locationType = area['locationType'] ?? 'location';
    final severity = area['severity'] ?? 'warning';
    final isBlocked = severity == 'blocked';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isBlocked
            ? Colors.red.withValues(alpha: 0.1)
            : Colors.orange.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: isBlocked ? Colors.red : Colors.orange, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: isBlocked ? Colors.red : Colors.orange,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  severity.toUpperCase(),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  area['name'] ?? 'Unsafe Area',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Location: ${locationType == 'pickup' ? 'Pickup' : 'Destination'}',
            style: TextStyle(
                fontSize: 12,
                color: Colors.grey[700],
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 4),
          Text(
            'Reason: ${area['reason'] ?? 'Not specified'}',
            style: TextStyle(fontSize: 12, color: Colors.grey[700]),
          ),
        ],
      ),
    );
  }

  Future<bool?> _showUnsafeAreaWarning(
      List<Map<String, dynamic>> unsafeAreas) async {
    final hasBlocked = unsafeAreas.any((a) => a['severity'] == 'blocked');

    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'Unsafe Area Warning',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.red),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Your ride involves unsafe areas:',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              ...unsafeAreas.map(_buildUnsafeAreaCard),
              const SizedBox(height: 8),
              if (hasBlocked)
                const Text(
                  '⚠️ Rides are not allowed in blocked areas for your safety.',
                  style: TextStyle(
                      fontSize: 13,
                      color: Colors.red,
                      fontWeight: FontWeight.w600),
                )
              else
                const Text(
                  'You can still proceed, but exercise caution.',
                  style: TextStyle(fontSize: 13, color: Colors.orange),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          if (!hasBlocked)
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white),
              child: const Text('Continue Anyway'),
            )
          else
            ElevatedButton(
              onPressed: () => Navigator.pop(context, false),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  foregroundColor: Colors.white),
              child: const Text('OK'),
            ),
        ],
      ),
    );
  }

  // ── Recording ───

  Future<void> _toggleListening() async {
    if (_isProcessing) return;
    if (_isListening) {
      await _stopRecording();
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    _cancelReplayTimer();
    _speechCancelled = true;
    await AudioPlayerService.stop();
    if (mounted) setState(() => _isSpeaking = false);

    setState(() => _isProcessing = true);

    final hasPermission = await _audioRecorder.hasPermission();
    if (!hasPermission) {
      setState(() => _isProcessing = false);
      _startReplayTimer();
      return;
    }

    try {
      if (kIsWeb) {
        await _audioRecorder.start(
          const RecordConfig(
              encoder: AudioEncoder.wav, numChannels: 1, sampleRate: 16000),
          path: 'audio_recording',
        );
      } else {
        final tempDir = await getTemporaryDirectory();
        final filePath =
            '${tempDir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';
        await _audioRecorder.start(
          const RecordConfig(
              encoder: AudioEncoder.aacLc, numChannels: 1, sampleRate: 16000),
          path: filePath,
        );
      }

      _animationController.repeat(reverse: true);
      setState(() {
        _isListening = true;
        _isProcessing = false;
      });
    } catch (e) {
      Logger.error('💥 ERROR starting recording: $e');
      setState(() => _isProcessing = false);
      _startReplayTimer();
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _audioRecorder.stop();
      _animationController.stop();
      _animationController.reset();
      setState(() => _isListening = false);

      if (path != null && path.isNotEmpty) {
        await _commonAudioProcessing(
            () => AudioApiService.processAudio(path));
      } else {
        _startReplayTimer();
      }
    } catch (e) {
      Logger.error('💥 ERROR stopping recording: $e');
      _startReplayTimer();
    }
  }

  // ── Audio processing (refactored) ───

  /// Resolves the source address: prefers current GPS location,
  /// falls back to whatever the API returned.
  String _resolveSource(String? currentLocation, Map<String, dynamic> result) {
    if (currentLocation != null && currentLocation.isNotEmpty) {
      return currentLocation;
    }
    final apiSource = result['source']?.toString() ?? '';
    return apiSource.isNotEmpty ? apiSource : '';
  }

  /// Extracts and sanitises the stops list returned by the API.
  List<String> _extractVoiceStops(Map<String, dynamic> result) {
    final rawStops = result['stops'];
    if (rawStops is! List) return [];

    return rawStops
        .map((s) => s?.toString().trim() ?? '')
        .where((addr) => addr.isNotEmpty)
        .take(3)
        .toList();
  }

  /// Replaces the current stop fields with the voice-detected addresses
  void _applyVoiceStops(List<String> voiceStops) {
    for (final c in _stopControllers) {
      c.dispose();
    }
    _stopControllers
      ..clear()
      ..addAll(voiceStops.map((addr) => TextEditingController(text: addr)));

    _stopCoordinates
      ..clear()
      ..addAll(List.filled(voiceStops.length, null));
  }

  void _applyAudioResult(
      String? currentLocation, Map<String, dynamic> result) {
    final source = _resolveSource(currentLocation, result);
    final destination = result['destination'] ?? '';
    final voiceStops = _extractVoiceStops(result);

    setState(() {
      _sourceController.text = source;
      _destinationController.text = destination;
      if (voiceStops.isNotEmpty) _applyVoiceStops(voiceStops);
      _isProcessing = false;
    });
  }

  /// Shows a transient error snack-bar and clears the processing flag.
  void _showAudioError(String message) {
    if (!mounted) return;
    setState(() => _isProcessing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  /// Processes audio result and auto-populates source, destination,
  /// and any intermediate stops the commuter mentioned in speech.
  /// Expects the API to optionally return a 'stops' list alongside
  /// 'source' and 'destination'.
  Future<void> _commonAudioProcessing(
    Future<Map<String, dynamic>?> Function() apiCall,
  ) async {
    setState(() => _isProcessing = true);

    try {
      final currentLocation =
          await LocationService.getCurrentLocationAddress();
      final result = await apiCall();

      if (result != null && mounted) {
        _applyAudioResult(currentLocation, result);
      } else if (mounted) {
        _showAudioError('Failed to process audio. Please try again.');
      }
    } catch (e) {
      _showAudioError('Error: $e');
    } finally {
      _startReplayTimer();
    }
  }

  // ── Build ───

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ── Top Bar ──
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24.0, vertical: 6.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isMuted
                              ? Icons.volume_off_rounded
                              : Icons.volume_up_rounded,
                          color: const Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                    SvgPicture.asset(
                      'assets/icons/logo_hersafar.svg',
                      width: 90,
                      height: 50,
                    ),
                    GestureDetector(
                      onTap: () {
                        _cancelReplayTimer();
                        _speechCancelled = true;
                        AudioPlayerService.stop();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.arrow_forward_ios,
                            color: Color(0xFFCF4374), size: 22),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              SoundWave(isAnimating: _isSpeaking),

              const SizedBox(height: 12),

              const Text(
                'آپ کہاں جانا چاہتے ہیں؟',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFCF4374),
                  letterSpacing: 0.5,
                ),
              ),

              const SizedBox(height: 24),

              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: _buildManualInputSection(),
                ),
              ),

              // ── Mic ──
              Padding(
                padding:
                    const EdgeInsets.only(bottom: 18.0, top: 6.0),
                child: Column(
                  children: [
                    MicButton(
                      isListening: _isListening,
                      isInterpreting: _isProcessing,
                      pulseAnimation: _pulseAnimation,
                      onTap: _isProcessing ? null : _toggleListening,
                    ),
                    const SizedBox(height: 10),
                    Builder(builder: (context) {
                      final String micLabel;
                      if (_isProcessing) {
                        micLabel = 'سمجھ رہا ہوں...';
                      } else if (_isListening) {
                        micLabel = 'سننا بند کریں';
                      } else {
                        micLabel = 'بولنے کے لیے دبائیں';
                      }
                      return AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: Text(
                          micLabel,
                          key: ValueKey('$_isListening$_isProcessing'),
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 13,
                            color: (_isListening || _isProcessing)
                                ? const Color(0xFF8B1A4A)
                                : const Color(0xFFCF4374),
                            fontWeight: (_isListening || _isProcessing)
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Widgets ───

  Widget _buildStopRow(int index, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _removeStop(index),
            child: Container(
              width: 36,
              height: 36,
              margin: const EdgeInsets.only(left: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.close_rounded,
                  color: Color(0xFFCF4374), size: 18),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextField(
                controller: controller,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.right,
                style: const TextStyle(
                    fontSize: 15, color: Color(0xFF424242)),
                decoration: InputDecoration(
                  hintText: 'اسٹاپ ${index + 1}',
                  hintTextDirection: TextDirection.rtl,
                  hintStyle: const TextStyle(
                      color: Color(0xFFBDBDBD), fontSize: 15),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 16),
                  suffixIcon: const Icon(Icons.place_rounded,
                      color: Color(0xFFCF4374), size: 20),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildManualInputSection() {
    return Column(
      children: [
        _buildInputField(
          controller: _sourceController,
          hintText: 'شروعاتی جگہ (Source)',
          icon: Icons.location_on,
        ),

        const SizedBox(height: 20),

        ..._stopControllers
            .asMap()
            .entries
            .map((entry) => _buildStopRow(entry.key, entry.value)),

        if (_stopControllers.length < 3)
          Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: GestureDetector(
              onTap: (_isPublishing || _isProcessing) ? null : _addStop,
              child: Container(
                width: double.infinity,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                      color: const Color(0xFFCF4374), width: 1.5),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_location_alt_rounded,
                        color: Color(0xFFCF4374), size: 20),
                    SizedBox(width: 8),
                    Text(
                      'اسٹاپ شامل کریں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        _buildInputField(
          controller: _destinationController,
          hintText: 'منزل (Destination)',
          icon: Icons.flag_rounded,
        ),

        const SizedBox(height: 24),

        GestureDetector(
          onTap: (_isPublishing || _isProcessing) ? null : _publishRide,
          child: Container(
            width: 250,
            height: 54,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFCF4374), Color(0xFF69223B)],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFCF4374).withValues(alpha: 0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isPublishing || _isProcessing)
                  const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2.5),
                  )
                else
                  const Row(children: [
                    Icon(Icons.check_circle_outline,
                        color: Colors.white, size: 24),
                    SizedBox(width: 10),
                    Text(
                      'سواری شائع کریں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ]),
              ],
            ),
          ),
        ),

        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
  }) {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: TextField(
          controller: controller,
          textDirection: TextDirection.rtl,
          textAlign: TextAlign.right,
          style:
              const TextStyle(fontSize: 15, color: Color(0xFF424242)),
          decoration: InputDecoration(
            hintText: hintText,
            hintTextDirection: TextDirection.rtl,
            hintStyle: const TextStyle(
                color: Color(0xFFBDBDBD), fontSize: 15),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 20, vertical: 17),
            suffixIcon:
                Icon(icon, color: const Color(0xFFCF4374), size: 22),
          ),
        ),
      ),
    );
  }
}

