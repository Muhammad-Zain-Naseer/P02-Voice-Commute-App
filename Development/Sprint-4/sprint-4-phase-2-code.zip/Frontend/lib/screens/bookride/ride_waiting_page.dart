import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:async'; // Added for voice timer

import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import '../../services/map_service.dart';
import '../../widgets/sound_wave.dart';
import '../sos/pre_sos_page.dart';

// Added Voice Imports
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';

// Data container class to hold fetched coordinates
class _RouteCoordinates {
  final double sourceLat;
  final double sourceLng;
  final double destLat;
  final double destLng;

  _RouteCoordinates({
    required this.sourceLat,
    required this.sourceLng,
    required this.destLat,
    required this.destLng,
  });
}

class RideWaitingPage extends StatefulWidget {
  final String rideId;
  final String source;
  final String destination;
  final List<Map<String, dynamic>> stops;

  const RideWaitingPage({
    super.key,
    required this.rideId,
    required this.source,
    required this.destination,
    this.stops = const [],
  });

  @override
  State<RideWaitingPage> createState() => _RideWaitingPageState();
}

class _RideWaitingPageState extends State<RideWaitingPage> {
  String _sourceUrdu = '...لوڈ ہو رہا ہے';
  String _destinationUrdu = '...لوڈ ہو رہا ہے';
  String _duration = 'کیلکولیٹ ہو رہا ہے';
  String _distance = 'کیلکولیٹ ہو رہا ہے';
  String _mapUrl = '';
  bool _isLoading = true;
  String _errorMessage = '';
  final List<Map<String, dynamic>> _driverOffers = [];
  bool _showDriverList = false;

  // Voice States
  bool _isSpeaking = false;
  bool _speechCancelled = false;
  bool _isMuted = false;
  bool _isSpeakingPrompt = false;
  Timer? _replayTimer;

  @override
  void initState() {
    super.initState();
    _fetchAndDisplayRoute();
    _setupRideMatchedListener();
    _setupDriverOfferListener();

    // Start voice prompt on page load
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPrompt();
    });
  }

  @override
  void dispose() {
    // Stop audio and timers
    _cancelReplayTimer();
    _speechCancelled = true;
    AudioPlayerService.stop();

    // Remove the ride:matched listener when leaving this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('ride:matched');
      SocketService.socket!.off('ride:driver:offered');
      Logger.log('🗑️ Removed listeners from RideWaitingPage');
    }
    super.dispose();
  }

  // ── Voice Logic ──────────────────────────────────────────

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 10), () {
      // Stop looping the prompt if a driver is found/shown
      if (!_isSpeaking && !_isMuted && !_showDriverList && !_isSpeakingPrompt && mounted) {
        _speakPrompt();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  static const _urduOrdinals = ['پہلا', 'دوسرا', 'تیسرا', 'چوتھا', 'پانچواں'];

  String _ordinalFor(int index) =>
      index < _urduOrdinals.length ? _urduOrdinals[index] : '${index + 1}واں';

  Future<void> _speakDriverAvailable() async {
    if (_isMuted || _isSpeakingPrompt) return;
    _isSpeakingPrompt = true;
    _speechCancelled = false;
    if (mounted) setState(() => _isSpeaking = true);

    await _speakAndWait('ڈرائیور دستیاب ہے۔ ڈرائیور کا انتخاب کریں۔');

    for (int i = 0; i < _driverOffers.length; i++) {
      if (_speechCancelled || _isMuted || !mounted) break;
      final d = _driverOffers[i];
      final name = d['driverName'] as String? ?? 'ڈرائیور';
      final rating = (d['averageRating'] as num?)?.toDouble() ?? 0.0;
      await _speakAndWait(
        '${_ordinalFor(i)} ڈرائیور $name، اس کی ریٹنگ ${rating.toStringAsFixed(1)}',
      );
    }

    if (mounted) setState(() => _isSpeaking = false);
    _isSpeakingPrompt = false;
  }

  Future<void> _speakNewDriver(Map<String, dynamic> driver, int index) async {
    if (_isMuted || _isSpeaking || _isSpeakingPrompt) return;
    _isSpeakingPrompt = true;
    _speechCancelled = false;
    if (mounted) setState(() => _isSpeaking = true);
    final name = driver['driverName'] as String? ?? 'ڈرائیور';
    final rating = (driver['averageRating'] as num?)?.toDouble() ?? 0.0;
    await _speakAndWait(
      '${_ordinalFor(index)} ڈرائیور $name، اس کی ریٹنگ ${rating.toStringAsFixed(1)}',
    );
    if (mounted) setState(() => _isSpeaking = false);
    _isSpeakingPrompt = false;
  }

  Future<void> _speakPrompt() async {
    if (_speechCancelled || _isMuted || _showDriverList || _isSpeakingPrompt) return;
    _isSpeakingPrompt = true;
    _cancelReplayTimer();

    if (mounted) setState(() => _isSpeaking = true);

    await _speakAndWait('ڈرائیور کی تلاش جاری ہے۔ براہ کرم انتظار فرمائیں۔');

    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted || _speechCancelled || _isMuted) {
      _isSpeakingPrompt = false;
      return;
    }

    await _speakAndWait('سواری منسوخ کرنے کے لیے نیچے دیا گیا بٹن دبائیں');

    if (mounted) setState(() => _isSpeaking = false);
    _isSpeakingPrompt = false;

    if (!_speechCancelled && !_isMuted && mounted) _startReplayTimer();
  }

  // ── Original Socket & API Logic ─────

  void _setupRideMatchedListener() {
    Logger.log('👂 Setting up ride:matched listener in RideWaitingPage');

    SocketService.onRideMatched((ride, role) {
      Logger.log('🎉 Ride matched! Role: $role, Ride ID: ${ride.id}');

      if (!mounted) return;

      // Stop speech if navigating away
      _speechCancelled = true;
      AudioPlayerService.stop();

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => PreSOSPage(
            ride: ride,
            userId: ride.userId,
          ),
        ),
      );
    });
  }

  void _setupDriverOfferListener() {
    SocketService.onDriverOffered((data) {
      Logger.log('🚗 Driver offered: $data');
      if (!mounted) return;

      final driver = data['driver'] as Map<String, dynamic>?;
      if (driver == null) return;

      bool firstDriver = false;
      bool isNewDriver = false;
      int newDriverIndex = 0;
      setState(() {
        final alreadyExists = _driverOffers.any(
          (d) => d['driverId'] == driver['driverId'],
        );
        if (!alreadyExists) {
          _driverOffers.add(driver);
          if (_showDriverList) {
            isNewDriver = true;
            newDriverIndex = _driverOffers.length - 1;
          }
        }
        if (!_showDriverList) {
          _showDriverList = true;
          firstDriver = true;
          // Stop audio prompt since drivers are now showing
          _speechCancelled = true;
          AudioPlayerService.stop();
          _cancelReplayTimer();
          _isSpeaking = false;
        }
      });
      if (firstDriver) {
        _speakDriverAvailable();
      } else if (isNewDriver) {
        _speakNewDriver(driver, newDriverIndex);
      }
    });
  }

  void _selectDriver(Map<String, dynamic> driver) {
    final driverId = driver['driverId'] as String;
    Logger.log('✅ Commuter selected driver: $driverId');
    SocketService.selectDriver(rideId: widget.rideId, driverId: driverId);
  }

  Future<void> _fetchAndDisplayRoute() async {
    try {
      final translatedAddresses = await MapService.translateAddresses(
        source: widget.source,
        destination: widget.destination,
      );

      setState(() {
        _sourceUrdu = translatedAddresses['source'] ?? widget.source;
        _destinationUrdu = translatedAddresses['destination'] ?? widget.destination;
      });

      final sourceCoords = await MapService.geocodeAddress(widget.source);
      if (sourceCoords == null) throw Exception('Failed to geocode source');

      final destCoords = await MapService.geocodeAddress(widget.destination);
      if (destCoords == null) throw Exception('Failed to geocode destination');

      final coords = _RouteCoordinates(
        sourceLat: sourceCoords['latitude']!,
        sourceLng: sourceCoords['longitude']!,
        destLat: destCoords['latitude']!,
        destLng: destCoords['longitude']!,
      );

      final stopLatLngs = widget.stops
          .where((s) => s['coordinates'] != null)
          .map((s) {
            final c = s['coordinates'] as Map<String, dynamic>;
            return {'lat': (c['lat'] as num).toDouble(), 'lng': (c['lng'] as num).toDouble()};
          })
          .toList();

      final routeResults = await Future.wait([
        MapService.calculateRoute(
          sourceLat: coords.sourceLat,
          sourceLng: coords.sourceLng,
          destLat: coords.destLat,
          destLng: coords.destLng,
        ),
        MapService.getDirectionsPolylineWithStops(
          sourceLat: coords.sourceLat,
          sourceLng: coords.sourceLng,
          destLat: coords.destLat,
          destLng: coords.destLng,
          stops: stopLatLngs.isEmpty ? null : stopLatLngs,
        ),
      ]);

      final distanceDuration = routeResults[0] as Map<String, String>;
      final polyline = routeResults[1] as String;

      final finalMapUrl = await MapService.getStaticMapUrlWithStops(
        sourceLat: coords.sourceLat,
        sourceLng: coords.sourceLng,
        destLat: coords.destLat,
        destLng: coords.destLng,
        polyline: polyline,
        stops: stopLatLngs.isEmpty ? null : stopLatLngs,
      );

      setState(() {
        _distance = distanceDuration['distance'] ?? 'N/A';
        _duration = distanceDuration['duration'] ?? 'N/A';
        _mapUrl = finalMapUrl;
        _isLoading = false;
      });
    } catch (e) {
      Logger.error('Critical error loading route data: $e');
      if (mounted) {
        setState(() {
          _errorMessage = 'روٹ لوڈ کرنے میں ناکامی';
          _isLoading = false;
        });
      }
    }
  }

  void _showCancelDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFF682AA),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SoundWave(),
                const SizedBox(height: 16),
                const Text(
                  'کیا آپ واقعی سواری منسوخ کرنا چاہتے ہیں؟',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.black54,
                          size: 32,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).pop();
                        _confirmCancelRide();
                      },
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _confirmCancelRide() async {
    _speechCancelled = true;
    AudioPlayerService.stop();
    Logger.log('Canceling ride ${widget.rideId}');
    
    SocketService.cancelRide(widget.rideId);
    Navigator.of(context).pop();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'سواری کی درخواست منسوخ ہو گئی',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Colors.orange,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget mapContent;

    if (_isLoading) {
      mapContent = const Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      );
    } else if (_errorMessage.isNotEmpty) {
      mapContent = Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.warning_amber_outlined, color: Colors.red, size: 50),
            const SizedBox(height: 8),
            Text(
              _errorMessage,
              style: const TextStyle(color: Colors.red, fontSize: 16),
              textDirection: TextDirection.rtl,
            ),
          ],
        ),
      );
    } else {
      mapContent = Image.network(
        _mapUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Center(
            child: CircularProgressIndicator(
              color: const Color(0xFFCF4374),
              value: loadingProgress.expectedTotalBytes != null
                  ? loadingProgress.cumulativeBytesLoaded /
                      (loadingProgress.expectedTotalBytes ?? 1)
                  : null,
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          return const Center(
            child: Icon(Icons.error_outline, size: 60, color: Colors.red),
          );
        },
      );
    }

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ── Top Bar (Mute, Logo, Back) ──
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                          color: const Color(0xFFCF4374),
                          size: 26,
                        ),
                      ),
                    ),
                    
                    SvgPicture.asset(
                      'assets/icons/logo_hersafar.svg',
                      width: 100, 
                      height: 50,
                    ),
                    
                    GestureDetector(
                      onTap: () {
                        _speechCancelled = true;
                        AudioPlayerService.stop();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.arrow_forward_ios,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Header Text & Soundwave ──
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 8.0),
                child: Column(
                  children: [
                    SoundWave(isAnimating: _isSpeaking),
                    const SizedBox(height: 12),
                    const Text(
                      'ڈرائیور کی تلاش جاری ہے،\nبراہ کرم انتظار فرمائیں',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      // ── Extra Spacing Added Here to Move Map Lower ──
                      const SizedBox(height: 30),

                      // ── Map and Info Section ──
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.38,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Expanded(
                                  flex: 7,
                                  child: ClipRRect(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                    ),
                                    child: Container(
                                      color: Colors.grey[200],
                                      child: mapContent,
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          Column(
                                            children: [
                                              Text(
                                                _duration,
                                                style: const TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black87,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              const Text(
                                                'کل وقت',
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  color: Color(0xFFCF4374),
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                textDirection: TextDirection.rtl,
                                              ),
                                            ],
                                          ),
                                          Container(
                                            width: 2,
                                            height: 40,
                                            color: const Color(0xFFF682AA),
                                          ),
                                          Column(
                                            children: [
                                              Text(
                                                _distance,
                                                style: const TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black87,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              const Text(
                                                'کل فاصلہ',
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  color: Color(0xFFCF4374),
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                textDirection: TextDirection.rtl,
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),

                                      const SizedBox(height: 16),

                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        textDirection: TextDirection.rtl,
                                        children: [
                                          Expanded(
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              children: [
                                                Flexible(
                                                  child: Text(
                                                    _sourceUrdu,
                                                    style: const TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.black87,
                                                      fontWeight: FontWeight.w600,
                                                    ),
                                                    textDirection: TextDirection.rtl,
                                                    textAlign: TextAlign.right,
                                                    maxLines: 2,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                Container(
                                                  width: 10,
                                                  height: 10,
                                                  decoration: const BoxDecoration(
                                                    color: Color(0xFFFDEAF9),
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 60,
                                            height: 1,
                                            color: const Color(0xFFF682AA),
                                            margin: const EdgeInsets.symmetric(horizontal: 8),
                                          ),
                                          Expanded(
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: 10,
                                                  height: 10,
                                                  decoration: const BoxDecoration(
                                                    color: Color(0xFFCF4374),
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                Flexible(
                                                  child: Text(
                                                    _destinationUrdu,
                                                    style: const TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.black87,
                                                      fontWeight: FontWeight.w600,
                                                    ),
                                                    textDirection: TextDirection.rtl,
                                                    maxLines: 2,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      // ── Driver Offers Panel ──
                      if (_showDriverList) ...[
                        const SizedBox(height: 16),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0),
                          child: _buildDriverOffersPanel(),
                        ),
                      ],

                      // ── Cancel Button (Moved Lower with increased padding) ──
                      Padding(
                        padding: const EdgeInsets.fromLTRB(24.0, 50.0, 24.0, 40.0),
                        child: GestureDetector(
                          onTap: _isLoading ? null : _showCancelDialog,
                          child: Container(
                            width: 250, 
                            height: 55, 
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xFFCF4374), Color(0xFF69223B)], 
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFCF4374).withValues(alpha: 0.4),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 26,
                                ),
                                SizedBox(width: 12),
                                Text(
                                  'سواری منسوخ کریں',
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDriverOffersPanel() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withValues(alpha: 0.2),
            blurRadius: 12,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '${_driverOffers.length} ڈرائیور دستیاب',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(
              'ڈرائیور کا انتخاب کریں',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF757575),
              ),
            ),
          ),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            itemCount: _driverOffers.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final driver = _driverOffers[index];
              final rating = (driver['averageRating'] as num?)?.toDouble() ?? 0.0;
              final driverName = driver['driverName'] as String? ?? 'ڈرائیور';

              return GestureDetector(
                onTap: () => _selectDriver(driver),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFDEAF0), 
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFCF4374).withValues(alpha: 0.5),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: const Icon(Icons.person, color: Colors.white, size: 26),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              driverName,
                              textDirection: TextDirection.rtl,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFCF4374),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                rating.toStringAsFixed(1),
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFCF4374),
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Icon(Icons.star_rounded, color: Color(0xFFFF8F00), size: 20),
                            ],
                          ),
                          const Text(
                            'ریٹنگ',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(fontSize: 11, color: Color(0xFF9E9E9E)),
                          ),
                        ],
                      ),
                      const SizedBox(width: 10),
                      const Icon(Icons.arrow_back_ios_rounded, color: Color(0xFFCF4374), size: 18),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}