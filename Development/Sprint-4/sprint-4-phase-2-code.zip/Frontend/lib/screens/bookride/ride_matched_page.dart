import 'package:flutter/material.dart';
import 'dart:async';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import '../../utils/logger.dart';
import '../commuter/active_ride_page.dart';

class RideMatchedPage extends StatefulWidget {
  final RideRequest ride;

  const RideMatchedPage({
    super.key,
    required this.ride,
  });

  @override
  State<RideMatchedPage> createState() => _RideMatchedPageState();
}

class _RideMatchedPageState extends State<RideMatchedPage> {
  int _remainingSeconds = 5;
  Timer? _timer;
  bool _isCancelled = false;
  bool _isNavigating = false;

  bool _isMuted = false;
  bool _speechCancelled = false;
  bool _isPromptPlaying = false;

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final bytes = await VoiceService.textToSpeech(text);
    if (bytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(bytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    final driver = widget.ride.matchedWith;
    final driverName = driver?.driverName ?? 'ڈرائیور';
    await _speakAndWait('آپ کا ڈرائیور مقرر ہو گیا ہے');
    if (_speechCancelled || _isMuted) {
      _isPromptPlaying = false;
      return;
    }
    await _speakAndWait('$driverName آپ کو لینے آ رہا ہے');
    _isPromptPlaying = false;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  @override
  void initState() {
    super.initState();
    _startCountdown();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPrompt();
    });
  }

  @override
  void dispose() {
    _speechCancelled = true;
    AudioPlayerService.stop();
    _timer?.cancel();
    super.dispose();
  }

  /// Start countdown timer
  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        timer.cancel();
        if (!_isCancelled && mounted) {
          _navigateToActiveRide();
        }
      }
    });
  }

  /// Navigate to active ride page after countdown
  void _navigateToActiveRide() {
    if (_isNavigating) return;

    setState(() {
      _isNavigating = true;
    });

    Logger.log('⏰ Countdown finished - navigating to active ride page');

    if (!mounted) return;

    // Get driver ID and user ID from the ride
    final driverId = widget.ride.matchedWith?.driverId ?? '';
    final userId = widget.ride.userId;

    // Navigate to the active ride page
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => CommuterActiveRidePage(
          ride: widget.ride,
          userId: userId,
          driverId: driverId,
        ),
      ),
    );
  }

  // Predefined cancellation reasons
  static const List<Map<String, dynamic>> _cancelReasons = [
    {
      'code': 'driver_request',
      'label': 'ڈرائیور نے کہا منسوخ کریں',
      'icon': Icons.warning_amber_rounded,
    },
    {
      'code': 'long_wait',
      'label': 'انتظار بہت طویل ہے',
      'icon': Icons.timer_off_outlined,
    },
    {
      'code': 'plans_changed',
      'label': 'میرے منصوبے بدل گئے',
      'icon': Icons.event_busy_outlined,
    },
    {
      'code': 'wrong_location',
      'label': 'غلط مقام',
      'icon': Icons.location_off_outlined,
    },
    {
      'code': 'other',
      'label': 'دیگر',
      'icon': Icons.more_horiz,
    },
  ];

  Widget _buildCancelReasonChip(
    Map<String, dynamic> reason,
    String? selectedCode,
    void Function(void Function()) setSheetState,
  ) {
    final bool selected = selectedCode == reason['code'];
    return GestureDetector(
      onTap: () => setSheetState(() {}),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFCF4374) : const Color(0xFFFDF0F4),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: selected ? const Color(0xFFCF4374) : const Color(0xFFF48FB1),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          textDirection: TextDirection.rtl,
          children: [
            Text(
              reason['label'] as String,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: selected ? Colors.white : const Color(0xFFCF4374),
              ),
            ),
            const SizedBox(width: 6),
            Icon(
              reason['icon'] as IconData,
              size: 16,
              color: selected ? Colors.white : const Color(0xFFCF4374),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOtherTextField(TextEditingController controller) {
    return Column(
      children: [
        const SizedBox(height: 14),
        TextField(
          controller: controller,
          textDirection: TextDirection.rtl,
          decoration: InputDecoration(
            hintText: 'وجہ لکھیں...',
            hintTextDirection: TextDirection.rtl,
            filled: true,
            fillColor: const Color(0xFFFDF0F4),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildConfirmCancelButton(
    BuildContext sheetContext,
    BuildContext pageContext,
    String? selectedCode,
    TextEditingController otherController,
  ) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: selectedCode == null
            ? null
            : () {
                final reasonText = selectedCode == 'other'
                    ? otherController.text.trim()
                    : null;
                Navigator.of(sheetContext).pop();
                _confirmCancelRide(
                  pageContext,
                  reasonCode: selectedCode,
                  reasonText: reasonText,
                );
              },
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFCF4374),
          disabledBackgroundColor: Colors.grey.shade300,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        child: const Text(
          'سواری منسوخ کریں',
          textDirection: TextDirection.rtl,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
    );
  }

  void _showCancelReasonSheet(BuildContext context) {
    // Pause timer while sheet is open
    _timer?.cancel();

    String? selectedCode;
    final otherController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'منسوخی کی وجہ بتائیں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 16),
                // Reason chips
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  alignment: WrapAlignment.end,
                  children: _cancelReasons.map((reason) {
                    return GestureDetector(
                      onTap: () => setSheetState(() {
                        selectedCode = reason['code'] as String;
                      }),
                      child: _buildCancelReasonChip(reason, selectedCode, setSheetState),
                    );
                  }).toList(),
                ),
                // "Other" text field
                if (selectedCode == 'other') _buildOtherTextField(otherController),
                const SizedBox(height: 20),
                // Confirm button
                _buildConfirmCancelButton(sheetContext, context, selectedCode, otherController),
              ],
            ),
          ),
        ),
      ),
    ).then((_) {
      otherController.dispose();
      // Restart timer if ride wasn't cancelled
      if (!_isCancelled && mounted) {
        _startCountdown();
      }
    });
  }

  Future<void> _confirmCancelRide(
    BuildContext context, {
    required String reasonCode,
    String? reasonText,
  }) async {
    setState(() {
      _isCancelled = true;
    });
    _timer?.cancel();

    SocketService.cancelRide(
      widget.ride.id,
      reasonCode: reasonCode,
      reasonText: reasonText,
    );
    Logger.log('Ride cancelled from Matched Page: ${widget.ride.id}, reason: $reasonCode');

    Navigator.of(context).popUntil((route) => route.isFirst);

    final bool isFraud = reasonCode == 'driver_request';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isFraud
              ? 'آپ کی رپورٹ درج کر لی گئی ہے'
              : 'سواری کی درخواست منسوخ ہو گئی',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: isFraud ? Colors.red.shade600 : Colors.orange,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final driver = widget.ride.matchedWith;

    // Use actual driver data if available, otherwise show defaults
    final String driverName = driver?.driverName ?? 'ڈرائیور صارف';
    final String vehicleModel = driver?.vehicleModel ?? 'نامعلوم ماڈل'; 
    final String vehicleNumber = driver?.vehicleNumber ?? 'N/A';

    return Scaffold(
      body: Container( 
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Back Arrow + Mute
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                          color: const Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Top Section - Logo and Sound Wave
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 8.0),
                child: Column(
                  children: [
                    // Car Icon - using flutter's built-in icon instead
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF682AA),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(
                        Icons.directions_car,
                        size: 50,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Sound wave indicator
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.volume_up, color: Color(0xFFCF4374), size: 28),
                        const SizedBox(width: 8),
                        ...List.generate(20, (index) {
                          final double barHeight;
                          if (index % 3 == 0) {
                            barHeight = 20;
                          } else if (index % 2 == 0) {
                            barHeight = 30;
                          } else {
                            barHeight = 15;
                          }
                          return Container(
                            width: 3,
                            height: barHeight,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFCF4374),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          );
                        }),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'آپ کا ڈرائیور مقرر ہو گیا ہے،\nوہ 5 منٹ کی دوری پر ہے',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Driver Details Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFF682AA),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _buildDetailRow('نام:', driverName),
                      const SizedBox(height: 16),
                      Container(
                        height: 1,
                        color: const Color(0xFFF682AA).withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      _buildDetailRow('گاڑی:', vehicleModel),
                      const SizedBox(height: 16),
                      Container(
                        height: 1,
                        color: const Color(0xFFF682AA).withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      _buildDetailRow('نمبر:', vehicleNumber),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Action Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  textDirection: TextDirection.rtl,
                  children: [
                    _buildActionButton(
                      context,
                      label: 'کال کریں',
                      icon: Icons.call,
                      onTap: () {
                        Logger.log('Call button pressed for driver: $driverName');
                      },
                    ),
                    const SizedBox(width: 20),
                    _buildActionButton(
                      context,
                      label: 'منسوخ کریں',
                      icon: Icons.close,
                      onTap: () => _showCancelReasonSheet(context),
                      isCancel: true,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Bottom Navigation Bar with timer on bottom-left
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFFDF0F4),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Countdown timer on bottom-left
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: const Color(0xFFCF4374),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            '$_remainingSeconds ثانیوں',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                        ),
                        // Navigation items in center
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _buildNavItem(Icons.home_outlined, 'ہوم', true),
                            const SizedBox(width: 20),
                            _buildNavItem(Icons.notifications_outlined, 'اطلاعات', false),
                            const SizedBox(width: 20),
                            _buildNavItem(Icons.person_outline, 'پروفائل', false),
                          ],
                        ),
                        const SizedBox(width: 40),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      textDirection: TextDirection.rtl,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFFCF4374),
          ),
          textDirection: TextDirection.rtl,
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.left,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isCancel = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 140,
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isCancel
                ? [
                    const Color(0xFFF48FB1),
                    const Color(0xFFCF4374),
                  ]
                : [
                    const Color(0xFFF48FB1).withValues(alpha: 0.8),
                    const Color(0xFFCF4374).withValues(alpha: 0.8),
                  ],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCF4374).withValues(alpha: 0.3),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          textDirection: TextDirection.rtl,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 8),
            Icon(icon, color: Colors.white, size: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? const Color(0xFFCF4374) : Colors.grey,
          size: 28,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isActive ? const Color(0xFFCF4374) : Colors.grey,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}
