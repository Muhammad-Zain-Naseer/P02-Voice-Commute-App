import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/auth_service.dart';
import '../../services/storage_service.dart';
import '../../services/driver_service.dart';
import '../../utils/logger.dart';
import '../welcome_screen.dart';

// ══════════════════════
// DRIVER PROFILE PAGE
// ══════════════════════

class DriverProfilePage extends StatefulWidget {
  const DriverProfilePage({super.key});

  @override
  State<DriverProfilePage> createState() => _DriverProfilePageState();
}

class _DriverProfilePageState extends State<DriverProfilePage> {
  static const String _notProvided = 'Not Provided';
  bool _isLoading = true;
  Map<String, dynamic>? _driverData;
  String _userName  = "Driver";
  String _userEmail = "";
  double _averageRating = 0.0;
  int    _totalRatings  = 0;

  @override
  void initState() {
    super.initState();
    _loadDriverProfile();
  }

  Future<void> _loadDriverProfile() async {
    setState(() => _isLoading = true);
    try {
      _userName  = await StorageService.getUserName()  ?? "Driver";
      _userEmail = await StorageService.getUserEmail() ?? "";
      final profile = await DriverService.getDriverProfile();
      if (mounted) {
        setState(() {
          _driverData    = profile;
          _averageRating = profile['averageRating']?.toDouble() ?? 0.0;
          _totalRatings  = profile['ratings']?.length ?? 0;
          _isLoading     = false;
        });
      }
    } catch (e) {
      Logger.error('Failed to load driver profile: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load profile: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _logout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFFF682AA), width: 2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
              child: const Icon(Icons.logout, color: Color(0xFFCF4374), size: 50),
            ),
            const SizedBox(height: 20),
            const Text('Are you sure you want to logout?',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFCF4374), fontSize: 20, fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFCF4374),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text('Yes, Logout',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.pop(ctx, false),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFCF4374),
                side: const BorderSide(color: Color(0xFFF682AA), width: 2),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text('Cancel',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await AuthService().logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const WelcomeScreen()),
          (route) => false,
        );
      }
    }
  }

  Color  _getStatusColor(String s) {
    switch (s) {
      case 'approved':              return Colors.green;
      case 'pending':               return Colors.orange;
      case 'rejected':              return Colors.red;
      case 'suspended':             return Colors.red.shade900;
      case 'resubmission_required': return Colors.amber.shade700;
      default:                      return Colors.grey;
    }
  }

  String _getStatusText(String s) {
    switch (s) {
      case 'approved':              return 'Approved';
      case 'pending':               return 'Pending';
      case 'rejected':              return 'Rejected';
      case 'suspended':             return 'Suspended';
      case 'resubmission_required': return 'Resubmission Required';
      default:                      return s.toUpperCase();
    }
  }

  IconData _getStatusIcon(String s) {
    switch (s) {
      case 'approved':              return Icons.verified;
      case 'pending':               return Icons.pending;
      case 'rejected':              return Icons.cancel;
      case 'suspended':             return Icons.block;
      case 'resubmission_required': return Icons.refresh;
      default:                      return Icons.help_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFCF4374)))
          : RefreshIndicator(
              onRefresh: _loadDriverProfile,
              color: const Color(0xFFCF4374),
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  _buildSliverAppBar(),
                  SliverToBoxAdapter(
                    child: Column(children: [
                      const SizedBox(height: 20),

                      if (_driverData?['status'] != 'approved')
                        _buildVerificationStatusCard(),

                      _buildSectionTitle('Personal Information'),
                      _buildPersonalInfoCard(),

                      _buildSectionTitle('Payment Accounts'),
                      PaymentAccountsCard(
                        driverData: _driverData,
                        onRefresh: _loadDriverProfile,
                        onSave: (easyPaisa, jazzCash) async {
                          await DriverService.updatePaymentAccounts(
                            easyPaisa: easyPaisa,
                            jazzCash: jazzCash,
                          );
                        },
                        onRequestVerification: (provider) async {
                          await DriverService.requestPaymentVerification(
                            provider: provider,
                          );
                        },
                      ),

                      if (_driverData?['vehicle'] != null) ...[
                        _buildSectionTitle('Vehicle Information'),
                        _buildVehicleInfoCard(),
                      ],

                      _buildSectionTitle('Documents'),
                      _buildDocumentsCard(),

                      const SizedBox(height: 40),
                    ]),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSliverAppBar() {
    final status      = _driverData?['status'] ?? 'pending';
    final statusColor = _getStatusColor(status);
    final statusText  = _getStatusText(status);
    final totalRides  = _driverData?['totalRides'] ?? 0;

    return SliverAppBar(
      expandedHeight: 340,
      pinned: true,
      automaticallyImplyLeading: false,
      backgroundColor: const Color(0xFFCF4374),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _logout(context),
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.logout, color: Color(0xFFCF4374), size: 20),
                    const SizedBox(width: 6),
                    Text('Logout',
                        style: GoogleFonts.poppins(color: const Color(0xFFCF4374), fontSize: 14, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [const Color(0xFFCF4374), const Color(0xFFE91E63), const Color(0xFFCF4374).withValues(alpha: 0.8)],
            ),
          ),
          child: Stack(children: [
            Positioned(top: -30, right: -30,
                child: Container(width: 120, height: 120,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.1)))),
            Positioned(bottom: -20, left: -40,
                child: Container(width: 100, height: 100,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.08)))),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: SafeArea(
                child: SingleChildScrollView(
                  physics: const NeverScrollableScrollPhysics(),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 10, offset: const Offset(0, 4))],
                      ),
                      child: const CircleAvatar(
                        radius: 45, backgroundColor: Colors.white,
                        child: Icon(Icons.person, size: 50, color: Color(0xFFCF4374)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(_userName,
                          style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                          textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
                    ),
                    const SizedBox(height: 4),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(_userEmail,
                          style: GoogleFonts.poppins(fontSize: 13, color: Colors.white.withValues(alpha: 0.9)),
                          textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                    const SizedBox(height: 4),
                    if (status != 'approved')
                      Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: statusColor, borderRadius: BorderRadius.circular(12),
                          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 4, offset: const Offset(0, 2))],
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(_getStatusIcon(status), color: Colors.white, size: 14),
                          const SizedBox(width: 6),
                          Text(statusText,
                              style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.white)),
                        ]),
                      ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Row(children: [
                        _statBadge(icon: Icons.star, iconColor: const Color(0xFFFFB300),
                            value: _averageRating.toStringAsFixed(1),
                            subtitle: '$_totalRatings ${_totalRatings == 1 ? 'review' : 'reviews'}'),
                        const SizedBox(width: 16),
                        _statBadge(icon: Icons.directions_car, iconColor: Colors.white,
                            value: totalRides.toString(), subtitle: 'completed'),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _statBadge({required IconData icon, required Color iconColor, required String value, required String subtitle}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withValues(alpha: 0.3), width: 1),
        ),
        child: Column(children: [
          Icon(icon, color: iconColor, size: 18),
          const SizedBox(height: 3),
          Text(value, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          Text(subtitle,
              style: GoogleFonts.poppins(fontSize: 9, color: Colors.white.withValues(alpha: 0.8)),
              textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
        ]),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 12),
      child: Row(children: [
        Container(width: 4, height: 20,
            decoration: BoxDecoration(color: const Color(0xFFCF4374), borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 12),
        Text(title, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: const Color(0xFF2D3748))),
      ]),
    );
  }

  Widget _buildVerificationStatusCard() {
    final status      = _driverData?['status'] ?? 'pending';
    final statusColor = _getStatusColor(status);
    final statusText  = _getStatusText(status);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withValues(alpha: 0.3), width: 2),
        boxShadow: [BoxShadow(color: statusColor.withValues(alpha: 0.15), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Column(children: [
        Row(children: [
          Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), shape: BoxShape.circle),
              child: Icon(_getStatusIcon(status), color: statusColor, size: 28)),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Account Status',
                style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600], fontWeight: FontWeight.w500)),
            const SizedBox(height: 4),
            Text(statusText,
                style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: statusColor)),
          ])),
        ]),
        if (status == 'rejected' && _driverData?['rejectionReason'] != null) ...[
          const SizedBox(height: 16),
          _statusNote(Icons.info_outline, Colors.red.shade700, Colors.red.shade50,
              _driverData!['rejectionReason'], Colors.red.shade900),
        ],
        if (status == 'resubmission_required' && _driverData?['resubmissionNotes'] != null) ...[
          const SizedBox(height: 16),
          _statusNote(Icons.warning_amber_rounded, Colors.amber.shade700, Colors.amber.shade50,
              _driverData!['resubmissionNotes'], Colors.amber.shade900),
        ],
        if (status == 'suspended' && _driverData?['suspensionReason'] != null) ...[
          const SizedBox(height: 16),
          _statusNote(Icons.block, Colors.red.shade700, Colors.red.shade50,
              _driverData!['suspensionReason'], Colors.red.shade900),
        ],
      ]),
    );
  }

  Widget _statusNote(IconData icon, Color iconColor, Color bg, String text, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
      child: Row(children: [
        Icon(icon, color: iconColor, size: 20), const SizedBox(width: 8),
        Expanded(child: Text(text, style: TextStyle(fontSize: 13, color: textColor))),
      ]),
    );
  }

  Widget _buildPersonalInfoCard() => _cardWrap(Column(children: [
    _infoRow(Icons.person_outline,  'Name',         _driverData?['name']  ?? _userName),
    _divider(),
    _infoRow(Icons.email_outlined,  'Email',        _driverData?['email'] ?? _userEmail),
    _divider(),
    _infoRow(Icons.phone_outlined,  'Phone',        _driverData?['phone'] ?? _notProvided),
    _divider(),
    _infoRow(Icons.cake_outlined,   'Member Since', _formatDate(_driverData?['createdAt'])),
  ]));

  Widget _buildVehicleInfoCard() {
    final v = _driverData?['vehicle'];
    if (v == null) return const SizedBox.shrink();
    return _cardWrap(Column(children: [
      _infoRow(Icons.confirmation_number_outlined, 'Registration', v['registrationNumber'] ?? _notProvided),
      _divider(),
      _infoRow(Icons.directions_car_outlined, 'Model', v['model'] ?? _notProvided),
      _divider(),
      _infoRow(Icons.palette_outlined,        'Color', v['color'] ?? _notProvided),
      _divider(),
      _infoRow(Icons.calendar_today_outlined, 'Year',  v['year']?.toString() ?? _notProvided),
    ]));
  }

  Widget _buildDocumentsCard() => _cardWrap(Column(children: [
    _infoRow(Icons.badge_outlined,       'CNIC',            _driverData?['cnic']           ?? _notProvided),
    _divider(),
    _infoRow(Icons.credit_card_outlined, 'Driving License', _driverData?['drivingLicense'] ?? _notProvided),
  ]));

  Widget _cardWrap(Widget child) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(16),
      boxShadow: [BoxShadow(color: Colors.grey.withValues(alpha: 0.1), blurRadius: 10, offset: const Offset(0, 4))],
    ),
    child: child,
  );

  Widget _infoRow(IconData icon, String label, String value) => Row(children: [
    Icon(icon, color: const Color(0xFFCF4374), size: 22),
    const SizedBox(width: 16),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600], fontWeight: FontWeight.w500)),
      const SizedBox(height: 4),
      Text(value, style: GoogleFonts.poppins(fontSize: 15, color: Colors.grey[800], fontWeight: FontWeight.w500)),
    ])),
  ]);

  Widget _divider() => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: Container(height: 1,
        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Colors.transparent, Colors.grey[300]!, Colors.transparent]))),
  );

  String _formatDate(String? s) {
    if (s == null) return 'N/A';
    try {
      final d = DateTime.parse(s);
      const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return '${m[d.month - 1]} ${d.day}, ${d.year}';
    } catch (_) { return 'N/A'; }
  }
}

// ══════════════════════
// PAYMENT ACCOUNTS CARD
// ══════════════════════

class PaymentAccountsCard extends StatelessWidget {
  final Map<String, dynamic>? driverData;
  final Future<void> Function(Map<String, String>, Map<String, String>)? onSave;
  final Future<void> Function(String provider)? onRequestVerification;
  final VoidCallback? onRefresh;

  const PaymentAccountsCard({
    super.key,
    this.driverData,
    this.onSave,
    this.onRequestVerification,
    this.onRefresh,
  });

  void _open(BuildContext context) {
    final ep = driverData?['paymentAccounts']?['easyPaisa'];
    final jc = driverData?['paymentAccounts']?['jazzCash'];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => PaymentAccountsBottomSheet(
        initialEpNumber: ep?['accountNumber'] ?? '',
        initialEpTitle:  ep?['accountTitle']  ?? '',
        initialJcNumber: jc?['accountNumber'] ?? '',
        initialJcTitle:  jc?['accountTitle']  ?? '',
        epVerified: ep?['isVerified'] == true,
        jcVerified: jc?['isVerified'] == true,
        onSave: onSave,
        onRequestVerification: onRequestVerification,
      ),
    ).then((_) {
      onRefresh?.call();
    });
  }

  @override
  Widget build(BuildContext context) {
    final ep      = driverData?['paymentAccounts']?['easyPaisa'];
    final jc      = driverData?['paymentAccounts']?['jazzCash'];
    final epNum   = ep?['accountNumber']?.toString() ?? '';
    final epTitle = ep?['accountTitle']?.toString()  ?? '';
    final epVer   = ep?['isVerified'] == true;
    final jcNum   = jc?['accountNumber']?.toString() ?? '';
    final jcTitle = jc?['accountTitle']?.toString()  ?? '';
    final jcVer   = jc?['isVerified'] == true;
    final hasAny  = epNum.isNotEmpty || jcNum.isNotEmpty;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.grey.withValues(alpha: 0.1), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 12, 0),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: const Color(0xFFCF4374).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFFCF4374), size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(child: Text('Receiving Accounts',
                style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600, color: const Color(0xFF2D3748)))),
            TextButton.icon(
              onPressed: () => _open(context),
              icon: Icon(hasAny ? Icons.edit_outlined : Icons.add, size: 16, color: const Color(0xFFCF4374)),
              label: Text(hasAny ? 'Edit' : 'Add',
                  style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w600, color: const Color(0xFFCF4374))),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                backgroundColor: const Color(0xFFCF4374).withValues(alpha: 0.08),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ]),
        ),
        if (!hasAny)
          _emptyState(context)
        else
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Column(children: [
              _tile(logo: const EasyPaisaLogo(), label: 'EasyPaisa',
                  number: epNum, title: epTitle, verified: epVer, color: const Color(0xFF00A859)),
              if (epNum.isNotEmpty && jcNum.isNotEmpty)
                Padding(padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Divider(color: Colors.grey[200], height: 1)),
              _tile(logo: const JazzCashLogo(), label: 'JazzCash',
                  number: jcNum, title: jcTitle, verified: jcVer,
                  color: jcVer ? const Color(0xFF00A859) : const Color(0xFFFF6B00)),
            ]),
          ),
      ]),
    );
  }

  Widget _emptyState(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
    child: Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFFFCE4EC), borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Icon(Icons.account_balance_wallet_outlined, size: 48, color: const Color(0xFFCF4374).withValues(alpha: 0.5)),
        const SizedBox(height: 12),
        Text('No payment accounts added',
            style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: const Color(0xFFCF4374))),
        const SizedBox(height: 6),
        Text('Add your EasyPaisa or JazzCash\naccount to receive ride payments',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600], height: 1.5)),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => _open(context),
            icon: const Icon(Icons.add, size: 18),
            label: Text('Add Payment Account',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 14)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFCF4374), foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0,
            ),
          ),
        ),
      ]),
    ),
  );

  Widget _tile({required Widget logo, required String label, required String number,
      required String title, required bool verified, required Color color}) {
    final ok = number.isNotEmpty;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ok ? color.withValues(alpha: 0.04) : Colors.grey[50],
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ok ? color.withValues(alpha: 0.2) : Colors.grey[200]!, width: 1.5),
      ),
      child: Row(children: [
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.grey.withValues(alpha: 0.15), blurRadius: 6)]),
          child: Center(child: logo),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(label, style: GoogleFonts.poppins(fontSize: 14, fontWeight: FontWeight.w600, color: const Color(0xFF2D3748))),
            if (verified) ...[const SizedBox(width: 6), Icon(Icons.verified_rounded, color: color, size: 16)],
          ]),
          const SizedBox(height: 3),
          Text(ok ? number : 'Not configured',
              style: GoogleFonts.poppins(fontSize: 13,
                  fontWeight: ok ? FontWeight.w500 : FontWeight.w400,
                  color: ok ? const Color(0xFF2D3748) : Colors.grey[400],
                  letterSpacing: ok ? 0.5 : 0)),
          if (title.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(title, style: GoogleFonts.poppins(fontSize: 11, color: Colors.grey[500])),
          ],
        ])),
        if (ok && verified)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
            child: Text('Active',
                style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.w600, color: color)),
          )
        else if (ok && !verified)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(8)),
            child: Text('Unverified',
                style: GoogleFonts.poppins(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[500])),
          ),
      ]),
    );
  }
}

// ════════════════════════════════════════════════════════════
// PAYMENT ACCOUNTS
// Save & Verify :
//   1. Save accounts to DB
//   2. Auto-send verification email for the account
//   3. Driver taps the email link -> backend marks isVerified=true in DB
// ════════════════════════════════════════════════════════════

enum _SaveState { idle, saving, verifying, done }

class PaymentAccountsBottomSheet extends StatefulWidget {
  final String initialEpNumber, initialEpTitle, initialJcNumber, initialJcTitle;
  final bool epVerified, jcVerified;
  final Future<void> Function(Map<String, String>, Map<String, String>)? onSave;
  final Future<void> Function(String provider)? onRequestVerification;

  const PaymentAccountsBottomSheet({
    super.key,
    required this.initialEpNumber, required this.initialEpTitle,
    required this.initialJcNumber, required this.initialJcTitle,
    required this.epVerified,      required this.jcVerified,
    this.onSave,
    this.onRequestVerification,
  });

  @override
  State<PaymentAccountsBottomSheet> createState() => _SheetState();
}

class _SheetState extends State<PaymentAccountsBottomSheet>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  _SaveState _saveState = _SaveState.idle;

  late TextEditingController _epNum, _epTitle;
  late TextEditingController _jcNum, _jcTitle;
  final _epKey = GlobalKey<FormState>();
  final _jcKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _tab     = TabController(length: 2, vsync: this);
    _epNum   = TextEditingController(text: widget.initialEpNumber);
    _epTitle = TextEditingController(text: widget.initialEpTitle);
    _jcNum   = TextEditingController(text: widget.initialJcNumber);
    _jcTitle = TextEditingController(text: widget.initialJcTitle);
  }

  @override
  void dispose() {
    _tab.dispose();
    _epNum.dispose(); _epTitle.dispose();
    _jcNum.dispose(); _jcTitle.dispose();
    super.dispose();
  }

  // ─── SAVE + AUTO-VERIFY ─-
  Future<void> _saveAndVerify() async {
    final epOk = _epKey.currentState?.validate() ?? true;
    final jcOk = _jcKey.currentState?.validate() ?? true;
    if (!epOk || !jcOk) return;

    setState(() => _saveState = _SaveState.saving);

    try {
      await widget.onSave?.call(
        {'accountNumber': _epNum.text.trim(), 'accountTitle': _epTitle.text.trim()},
        {'accountNumber': _jcNum.text.trim(), 'accountTitle': _jcTitle.text.trim()},
      );

      setState(() => _saveState = _SaveState.verifying);

      final List<String> emailsSent = [];
      final activeIndex = _tab.index; // 0 = EasyPaisa, 1 = JazzCash

      if (activeIndex == 0 && _epNum.text.trim().isNotEmpty) {
        await widget.onRequestVerification?.call('easypaisa');
        emailsSent.add('EasyPaisa');
      } else if (activeIndex == 1 && _jcNum.text.trim().isNotEmpty) {
        await widget.onRequestVerification?.call('jazzcash');
        emailsSent.add('JazzCash');
      }

      setState(() => _saveState = _SaveState.done);

      if (mounted) {
        Navigator.pop(context);
        final msg = emailsSent.isEmpty
            ? 'Payment accounts saved!'
            : 'Saved! Verification email sent for ${emailsSent.join(' & ')}. '
              'Open the email and tap "✓ Yes, Verify" to complete verification.';
        _snack(msg);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saveState = _SaveState.idle);
        _snack('Failed: $e', err: true);
      }
    }
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(err ? Icons.error_outline : Icons.check_circle, color: Colors.white, size: 20),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: GoogleFonts.poppins(fontWeight: FontWeight.w500))),
      ]),
      backgroundColor: err ? Colors.red : Colors.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 6),
    ));
  }

  bool get _isBusy => _saveState == _SaveState.saving || _saveState == _SaveState.verifying;

  @override
  Widget build(BuildContext context) {
    final inset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.only(bottom: inset),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          // Handle bar
          Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),

          // Title row
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.account_balance_wallet, color: Color(0xFFCF4374), size: 24),
              ),
              const SizedBox(width: 14),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Payment Accounts',
                    style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: const Color(0xFF2D3748))),
                Text('Add & verify your mobile wallets',
                    style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[500])),
              ]),
            ]),
          ),

          const SizedBox(height: 16),

          // Info banner
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF3CD), borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFFFE082)),
              ),
              child: Row(children: [
                const Icon(Icons.info_outline, color: Color(0xFFF59E0B), size: 18),
                const SizedBox(width: 10),
                Expanded(child: Text(
                  'Enter your account details and tap "Save & Verify". '
                  'A verification email will be sent — click the link to confirm.',
                  style: GoogleFonts.poppins(fontSize: 11, color: const Color(0xFF92400E), height: 1.5),
                )),
              ]),
            ),
          ),

          const SizedBox(height: 16),

          // Tab bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(14)),
              padding: const EdgeInsets.all(4),
              child: TabBar(
                controller: _tab,
                indicator: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10),
                  boxShadow: [BoxShadow(color: Colors.grey.withValues(alpha: 0.15), blurRadius: 6, offset: const Offset(0, 2))],
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelPadding: EdgeInsets.zero,
                dividerColor: Colors.transparent,
                labelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 13),
                unselectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w500, fontSize: 13),
                labelColor: const Color(0xFF2D3748),
                unselectedLabelColor: Colors.grey[500],
                tabs: const [
                  Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    EasyPaisaLogo(size: 18), SizedBox(width: 6), Text('EasyPaisa'),
                  ])),
                  Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    JazzCashLogo(size: 18), SizedBox(width: 6), Text('JazzCash'),
                  ])),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          SizedBox(
            height: 200,
            child: TabBarView(
              controller: _tab,
              children: [
                _buildForm(
                  formKey: _epKey, numCtrl: _epNum, titleCtrl: _epTitle,
                  color: const Color(0xFF00A859),
                  verified: widget.epVerified,
                ),
                _buildForm(
                  formKey: _jcKey, numCtrl: _jcNum, titleCtrl: _jcTitle,
                  color: const Color(0xFFFF6B00),
                  verified: widget.jcVerified,
                ),
              ],
            ),
          ),

          // ── SAVE & VERIFY BUTTON ────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isBusy ? null : _saveAndVerify,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: const Color(0xFFCF4374).withValues(alpha: 0.5),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: _buildButtonLabel(),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildButtonLabel() {
    switch (_saveState) {
      case _SaveState.saving:
        return Row(key: const ValueKey('saving'), mainAxisAlignment: MainAxisAlignment.center, children: [
          const SizedBox(height: 20, width: 20,
              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5)),
          const SizedBox(width: 10),
          Text('Saving…', style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 15)),
        ]);
      case _SaveState.verifying:
        return Row(key: const ValueKey('verifying'), mainAxisAlignment: MainAxisAlignment.center, children: [
          const SizedBox(height: 20, width: 20,
              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5)),
          const SizedBox(width: 10),
          Text('Sending email…', style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 15)),
        ]);
      case _SaveState.done:
        return Row(key: const ValueKey('done'), mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.check_circle_outline, size: 20),
          const SizedBox(width: 8),
          Text('Done!', style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 15)),
        ]);
      case _SaveState.idle:
        return Row(key: const ValueKey('idle'), mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.mark_email_read_outlined, size: 20),
          const SizedBox(width: 8),
          Text('Save & Verify Accounts',
              style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 15)),
        ]);
    }
  }

  // ─── FORM - fields + optional verified badge ──
  Widget _buildForm({
    required GlobalKey<FormState> formKey,
    required TextEditingController numCtrl,
    required TextEditingController titleCtrl,
    required Color color,
    required bool verified,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Form(
        key: formKey,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _field(
            ctrl: numCtrl,
            config: _FieldConfig(
              label: 'Account Number', hint: '03XX-XXXXXXX',
              icon: Icons.phone_android_outlined, color: color,
              keyboard: TextInputType.phone,
              formatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d\-]'))],
              suffix: verified
                  ? Icon(Icons.verified_rounded, color: color, size: 20)
                  : null,
              validator: (v) {
                if (v == null || v.isEmpty) return null;
                final d = v.replaceAll('-', '');
                if (d.length < 10 || d.length > 11) return 'Invalid number';
                return null;
              },
            ),
          ),
          const SizedBox(height: 12),
          _field(
            ctrl: titleCtrl,
            config: _FieldConfig(
              label: 'Account Title (Name)', hint: 'e.g. Muhammad Ali',
              icon: Icons.badge_outlined, color: color,
              keyboard: TextInputType.text,
              caps: TextCapitalization.words,
              formatters: [_CapitalizeWordsFormatter()],
            ),
          ),
          const SizedBox(height: 12),
          if (verified)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color.withValues(alpha: 0.3)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.verified_rounded, color: color, size: 16),
                const SizedBox(width: 6),
                Text('Verified', style: GoogleFonts.poppins(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _field({
    required TextEditingController ctrl,
    required _FieldConfig config,
  }) {
    return TextFormField(
      controller: ctrl,
      keyboardType: config.keyboard,
      textCapitalization: config.caps,
      inputFormatters: config.formatters,
      validator: config.validator,
      style: GoogleFonts.poppins(fontSize: 14, color: const Color(0xFF2D3748)),
      decoration: InputDecoration(
        labelText: config.label, hintText: config.hint,
        prefixIcon: Icon(config.icon, color: config.color, size: 20),
        suffixIcon: config.suffix,
        labelStyle: GoogleFonts.poppins(fontSize: 13, color: Colors.grey[600]),
        hintStyle:  GoogleFonts.poppins(fontSize: 13, color: Colors.grey[400]),
        filled: true, fillColor: Colors.grey[50],
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[200]!, width: 1.5)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: config.color, width: 2)),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red, width: 1.5)),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red, width: 2)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}

class _FieldConfig {
  final String label;
  final String hint;
  final IconData icon;
  final Color color;
  final TextInputType keyboard;
  final TextCapitalization caps;
  final List<TextInputFormatter>? formatters;
  final String? Function(String?)? validator;
  final Widget? suffix;

  const _FieldConfig({
    required this.label,
    required this.hint,
    required this.icon,
    required this.color,
    this.keyboard = TextInputType.text,
    this.caps = TextCapitalization.none,
    this.formatters,
    this.validator,
    this.suffix,
  });
}

class _CapitalizeWordsFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;
    if (text.isEmpty) return newValue;

    final buffer = StringBuffer();
    bool capitalizeNext = true;
    for (int i = 0; i < text.length; i++) {
      final char = text[i];
      if (char == ' ') {
        capitalizeNext = true;
        buffer.write(char);
      } else if (capitalizeNext) {
        buffer.write(char.toUpperCase());
        capitalizeNext = false;
      } else {
        buffer.write(char);
      }
    }

    final result = buffer.toString();
    // Keep cursor at the same position
    return newValue.copyWith(
      text: result,
      selection: newValue.selection.copyWith(
        baseOffset: newValue.selection.baseOffset.clamp(0, result.length),
        extentOffset: newValue.selection.extentOffset.clamp(0, result.length),
      ),
    );
  }
}

class EasyPaisaLogo extends StatelessWidget {
  final double size;
  const EasyPaisaLogo({super.key, this.size = 28});

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/icons/easypaisa.png',
        width: size, height: size, fit: BoxFit.contain,
      );
}

class JazzCashLogo extends StatelessWidget {
  final double size;
  const JazzCashLogo({super.key, this.size = 28});

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/icons/jazzcash.png',
        width: size, height: size, fit: BoxFit.contain,
      );
}