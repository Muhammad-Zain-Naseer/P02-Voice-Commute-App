import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/storage_service.dart';
import '../../services/driver_service.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import 'driver_page.dart';
import 'earnings_page.dart';
import 'driver_profile_page.dart';
import '../safety_alerts_history_page.dart';
import '../../services/safety_service.dart';

class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});

  @override
  State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  String _driverName = "Driver";
  
  // Stats State Variables
  String _earnings = "0";
  String _trips = "0";
  bool _isLoadingStats = true;
  bool _listenerAttached = false;
  bool _hasNewAlerts = false;
  
  // Animation Controller
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    
    // Initialize animations
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic));
    
    _loadDriverName();
    _fetchStats();
    _setupSocketListener();
    _checkForNewAlerts();
    // Start animations
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _setupSocketListener() async {
    if (_listenerAttached) return;

    if (SocketService.socket != null && SocketService.isConnected) {
      Logger.log("📊 Dashboard: Attaching 'ride:completed' listener");
      
      SocketService.socket!.on('ride:completed', (data) {
        Logger.log("📊 Ride completed! Updating dashboard stats directly...");
        
        try {
          final payload = data['ride'] ?? {};
          final newEarnings = payload['driverEarnings'] ?? 0;

          if (mounted) {
            setState(() {
              double current = double.tryParse(_earnings) ?? 0;
              double added = double.tryParse(newEarnings.toString()) ?? 0;
              
              _earnings = (current + added).toStringAsFixed(0);
              
              int currentTrips = int.tryParse(_trips) ?? 0;
              _trips = (currentTrips + 1).toString();
            });
          }
          
          _fetchStats();
          
        } catch (e) {
          Logger.error("Error parsing socket data: $e");
          _fetchStats();
        }
      });

      _listenerAttached = true;
    } else {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) _setupSocketListener();
    }
  }

  Future<void> _checkForNewAlerts() async {
    final alerts = await SafetyService.getRecentAlerts();
    if (alerts.isNotEmpty) {
      final latestAlertTime = DateTime.parse(alerts.first['sentAt']).toLocal();
      final lastViewed = await StorageService.getLastViewedAlertTime();
      if (lastViewed == null || latestAlertTime.isAfter(lastViewed)) {
        if (mounted) setState(() => _hasNewAlerts = true);
      }
    }
  }

  Future<void> _loadDriverName() async {
    final name = await StorageService.getUserName();
    if (mounted && name != null) {
      setState(() {
        _driverName = name;
      });
    }
  }

  Future<void> _fetchStats() async {
    try {
      final stats = await DriverService.getTodayStats();
      if (mounted) {
        setState(() {
          _earnings = stats['earnings'].toString();
          _trips = stats['trips'].toString();
          _isLoadingStats = false;
        });
      }
    } catch (e) {
      Logger.error("Error loading stats: $e");
      if (mounted) {
        setState(() {
          _earnings = "0";
          _trips = "0";
          _isLoadingStats = false;
        });
      }
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    
    if (index == 0) {
      _fetchStats();
      _animationController.forward(from: 0.0);
    }
  }

  void _goToRidesTab() {
    setState(() {
      _selectedIndex = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      _DriverHomeTab(
        driverName: _driverName,
        onFindRidesPressed: _goToRidesTab,
        earnings: _earnings,
        trips: _trips,
        isLoading: _isLoadingStats,
        fadeAnimation: _fadeAnimation,
        slideAnimation: _slideAnimation,
        hasNewAlerts: _hasNewAlerts,

        onAlertsClicked: () async {
          await StorageService.markAlertsAsViewed(); 
          setState(() {
            _hasNewAlerts = false; 
          });
        },
      ),
      const AvailableRidesPage(),
      const EarningsPage(),
      const DriverProfilePage(),
    ];

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;

        if (_selectedIndex != 0) {
          setState(() {
            _selectedIndex = 0;
          });
        } else {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFCE4EC),
        body: IndexedStack(
          index: _selectedIndex,
          children: screens,
        ),
        bottomNavigationBar: _buildBottomNavBar(),
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 30,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: const Color(0xFFCF4374),
          unselectedItemColor: Colors.grey[400],
          type: BottomNavigationBarType.fixed,
          showUnselectedLabels: true,
          selectedLabelStyle: GoogleFonts.poppins(
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: GoogleFonts.poppins(fontSize: 11),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_rounded, size: 24),
              activeIcon: Icon(Icons.dashboard_rounded, size: 28),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.directions_car_filled_rounded, size: 24),
              activeIcon: Icon(Icons.directions_car_filled_rounded, size: 28),
              label: 'Rides',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet_rounded, size: 24),
              activeIcon: Icon(Icons.account_balance_wallet_rounded, size: 28),
              label: 'Earnings',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_rounded, size: 24),
              activeIcon: Icon(Icons.person_rounded, size: 28),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}

class _DriverHomeTab extends StatelessWidget {
  final String driverName;
  final VoidCallback onFindRidesPressed;
  final String earnings;
  final String trips;
  final bool isLoading;
  final Animation<double> fadeAnimation;
  final Animation<Offset> slideAnimation;
  final bool hasNewAlerts;
  final VoidCallback onAlertsClicked;

  const _DriverHomeTab({
    required this.driverName,
    required this.onFindRidesPressed,
    required this.earnings,
    required this.trips,
    required this.fadeAnimation,
    required this.slideAnimation,
    this.isLoading = false,
    required this.hasNewAlerts,
    required this.onAlertsClicked,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            // GRADIENT HEADER
            _buildHeader(context),
            
            // STATUS CARD
            _buildStatusCard(context),
            
            // STATS GRID
            _buildStatsSection(context),
            
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return FadeTransition(
      opacity: fadeAnimation,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFFCF4374),
              const Color(0xFFE91E63),
              const Color(0xFFCF4374).withValues(alpha: 0.8),
            ],
          ),
        ),
        child: Stack(
          children: [
            // Decorative circles
            Positioned(
              top: -50,
              right: -30,
              child: Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.1),
                ),
              ),
            ),
            Positioned(
              top: 100,
              left: -40,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.08),
                ),
              ),
            ),
            
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Good ${_getGreeting()}!',
                              style: GoogleFonts.poppins(
                                color: Colors.white.withValues(alpha: 0.95),
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              driverName,
                              style: GoogleFonts.poppins(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Stack(
                          children: [
                            Container(
                              margin: const EdgeInsets.only(right: 12),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.2),
                                shape: BoxShape.circle,
                              ),
                              child: IconButton(
                                icon: const Icon(Icons.notifications_active_outlined, color: Colors.white),
                                onPressed: () {
                                  onAlertsClicked(); 

                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => const SafetyAlertsHistoryPage()),
                                  );
                                },
                              ),
                            ),
                            if (hasNewAlerts)
                              Positioned(
                                right: 12, 
                                top: 0,
                                child: Container(
                                  width: 12,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color: Colors.red,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFFCF4374), width: 2),
                                  ),
                                ),
                              ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.3),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: const CircleAvatar(
                            radius: 32,
                            backgroundColor: Colors.white,
                            child: Icon(
                              Icons.person,
                              size: 35,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            // Wave decoration at bottom
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: CustomPaint(
                size: const Size(double.infinity, 30),
                painter: WavePainter(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard(BuildContext context) {
    return SlideTransition(
      position: slideAnimation,
      child: FadeTransition(
        opacity: fadeAnimation,
        child: Transform.translate(
          offset: const Offset(0, -20),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.15),
                    blurRadius: 30,
                    offset: const Offset(0, 10),
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Current Status',
                            style: GoogleFonts.poppins(
                              color: Colors.grey[500],
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.grey[400],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                'OFFLINE',
                                style: GoogleFonts.poppins(
                                  color: Colors.grey[700],
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.grey[300]!,
                            width: 2,
                          ),
                        ),
                        child: Icon(
                          Icons.power_settings_new_rounded,
                          color: Colors.grey[600],
                          size: 26,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.grey[300]!,
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: ElevatedButton(
                      onPressed: onFindRidesPressed,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFCF4374),
                        foregroundColor: Colors.white,
                        elevation: 8,
                        shadowColor: const Color(0xFFCF4374).withValues(alpha: 0.4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.power_settings_new_rounded, size: 22),
                          const SizedBox(width: 10),
                          Text(
                            'GO ONLINE',
                            style: GoogleFonts.poppins(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatsSection(BuildContext context) {
    return FadeTransition(
      opacity: fadeAnimation,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 30, 24, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Today's Performance",
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF2D3748),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                _buildStatCard(
                  icon: Icons.account_balance_wallet_rounded,
                  label: 'Earnings',
                  value: isLoading ? '...' : 'Rs $earnings',
                  gradient: const LinearGradient(
                    colors: [Color(0xFFCF4374), Color(0xFFE91E63)],
                  ),
                  iconBg: const Color(0xFFCF4374).withValues(alpha: 0.15),
                ),
                const SizedBox(width: 16),
                _buildStatCard(
                  icon: Icons.directions_car_filled_rounded,
                  label: 'Total Trips',
                  value: isLoading ? '...' : trips,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE91E63), Color(0xFFF06292)],
                  ),
                  iconBg: const Color(0xFFE91E63).withValues(alpha: 0.15),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Gradient gradient,
    required Color iconBg,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 8),
              spreadRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: gradient.colors.first.withValues(alpha: 0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(height: 20),
            Text(
              value,
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF2D3748),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: GoogleFonts.poppins(
                color: Colors.grey[500],
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }
}

class WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFCE4EC)
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(0, size.height * 0.5)
      ..quadraticBezierTo(
        size.width * 0.25,
        0,
        size.width * 0.5,
        size.height * 0.5,
      )
      ..quadraticBezierTo(
        size.width * 0.75,
        size.height,
        size.width,
        size.height * 0.5,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}