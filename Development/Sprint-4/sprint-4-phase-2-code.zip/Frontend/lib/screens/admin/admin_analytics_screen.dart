import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../services/admin_service.dart';
import 'package:intl/intl.dart';
import 'dart:io'; 
import 'package:path_provider/path_provider.dart'; 

class AdminAnalyticsScreen extends StatefulWidget {
  final String token;

  const AdminAnalyticsScreen({super.key, required this.token});

  @override
  State<AdminAnalyticsScreen> createState() => _AdminAnalyticsScreenState();
}

class _AdminAnalyticsScreenState extends State<AdminAnalyticsScreen> {
  late AdminService _adminService;
  bool _isLoading = true;
  String _timeRange = 'week';
  Map<String, dynamic>? _data;

  // Colors
  final Color _primaryPink = const Color(0xFFCF4374);

  @override
  void initState() {
    super.initState();
    _adminService = AdminService();
    _adminService.setToken(widget.token);
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() => _isLoading = true);
    final data = await _adminService.getAnalyticsDashboard(_timeRange);
    
    if (mounted) {
      setState(() {
        _data = data;
        _isLoading = false;
      });
    }
  }

  Future<void> _exportData(String type) async {
    try {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Downloading report...')),
      );

      // Fetch CSV text from backend
      final csvString = await _adminService.exportAnalyticsReport(type);
      
      if (csvString == null || csvString.isEmpty) {
        throw "No data received from server";
      }

      final directory = await getApplicationDocumentsDirectory();
      final fileName = 'hersafar_${type}_${DateTime.now().millisecondsSinceEpoch}.csv';
      final filePath = '${directory.path}/$fileName';

      // Create file and write CSV data to it
      final file = File(filePath);
      await file.writeAsString(csvString);

      // Notify the user
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ Report saved to: $fileName'),
            duration: const Duration(seconds: 4),
            action: SnackBarAction(
              label: 'OK',
              onPressed: () {},
            ),
          ),
        );
      }
      
      debugPrint("File successfully saved at: $filePath");

    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('❌ Export failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('System Analytics', style: TextStyle(color: Colors.white)),
        backgroundColor: _primaryPink,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          DropdownButton<String>(
            dropdownColor: _primaryPink,
            value: _timeRange,
            icon: const Icon(Icons.filter_list, color: Colors.white),
            style: const TextStyle(color: Colors.white),
            underline: Container(),
            onChanged: (val) {
              if (val != null) {
                setState(() => _timeRange = val);
                _fetchData();
              }
            },
            items: ['week', 'month', 'year']
                .map((e) => DropdownMenuItem(value: e, child: Text(e.toUpperCase())))
                .toList(),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: _primaryPink))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Stat Cards
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatCard(
                          "New Users",
                          "${_data?['newUsers'] ?? 0}",
                          Icons.person_add_rounded,
                          Colors.blue,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildStatCard(
                          "Safety Alerts",
                          "${_data?['totalSafetyIncidents'] ?? 0}",
                          Icons.warning_amber_rounded,
                          Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Revenue Graph 
                  Text("Revenue Trends",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800])),
                  const SizedBox(height: 16),
                  Container(
                    height: 250,
                    padding: const EdgeInsets.fromLTRB(16, 24, 24, 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey.withValues(alpha: 0.1),
                            blurRadius: 15,
                            offset: const Offset(0, 5))
                      ],
                      border: Border.all(color: Colors.grey.withValues(alpha: 0.1)),
                    ),
                    child: _buildRevenueChart(), 
                  ),
                  const SizedBox(height: 24),

                  // Ride Status Pie Chart
                  Text("Ride Status Distribution",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800])),
                  const SizedBox(height: 16),
                  Container(
                    height: 250,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey.withValues(alpha: 0.1),
                            blurRadius: 15,
                            offset: const Offset(0, 5))
                      ],
                      border: Border.all(color: Colors.grey.withValues(alpha: 0.1)),
                    ),
                    child: _buildRideStatusPieChart(), 
                  ),
                  const SizedBox(height: 24),

                  // Export Buttons
                  const Text("Export Reports",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF333333))),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildExportButton(
                          "Financials",
                          Icons.download_rounded,
                          Colors.green,
                          () => _exportData('financial'),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildExportButton(
                          "Safety Logs",
                          Icons.security_rounded,
                          Colors.orange,
                          () => _exportData('safety'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
    );
  }

  // Helper to parse API data into Chart Spots
  List<FlSpot> _generateSpots() {
    if (_data == null || _data!['revenueChart'] == null) return [];

    final List<dynamic> rawData = _data!['revenueChart'];
    
    return List.generate(rawData.length, (index) {
      final entry = rawData[index];
      final double y = (entry['total'] as num).toDouble();
      return FlSpot(index.toDouble(), y);
    });
  }

  // Helper to get Date Labels for X-Axis
  String _getDateLabel(double value) {
    if (_data == null || _data!['revenueChart'] == null) return '';
    final List<dynamic> rawData = _data!['revenueChart'];
    
    int index = value.toInt();
    if (index < 0 || index >= rawData.length) return '';

    String dateStr = rawData[index]['_id']; 
    
    try {
      //  handle Year view 
      if (dateStr.length == 7) { 
        DateTime date = DateFormat("yyyy-MM").parse(dateStr);
        return DateFormat("MMM").format(date); 
      } 
      
      // Handle Week/Month view 
      DateTime date = DateTime.parse(dateStr);
      return DateFormat("d MMM").format(date); 
    } catch (e) {
      return '';
    }
  }

  //  The Real Chart Widget
  Widget _buildRevenueChart() {
    final spots = _generateSpots();
    
    // Handle empty data case
    if (spots.isEmpty) {
      return const Center(child: Text("No revenue data for this period"));
    }

    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 1000, 
          getDrawingHorizontalLine: (value) {
            return FlLine(
              color: Colors.grey.withValues(alpha: 0.1),
              strokeWidth: 1,
            );
          },
        ),
        titlesData: FlTitlesData(
          show: true,
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              interval: 1, // Show label for every point
              getTitlesWidget: (value, meta) {
                return Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    _getDateLabel(value), 
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                if (value == 0) return const Text('');
                return Text('${(value / 1000).toStringAsFixed(1)}k',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12));
              },
            ),
          ),
        ),
        borderData: FlBorderData(show: false),
        // Dynamic X-Axis range
        minX: 0,
        maxX: (spots.length - 1).toDouble(), 
        minY: 0,
        // Dynamic Y-Axis Max 
        maxY: (spots.map((e) => e.y).reduce((a, b) => a > b ? a : b)) * 1.2,
        lineBarsData: [
          LineChartBarData(
            spots: spots, 
            isCurved: true,
            color: const Color(0xFFCF4374),
            barWidth: 4,
            isStrokeCapRound: true,
            dotData: const FlDotData(show: true), 
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                colors: [
                  const Color(0xFFCF4374).withValues(alpha: 0.3),
                  const Color(0xFFCF4374).withValues(alpha: 0.0),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ],
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            getTooltipColor: (_) => Colors.blueGrey.withValues(alpha: 0.8),
            getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
              return touchedBarSpots.map((barSpot) {
                String dateLabel = _getDateLabel(barSpot.x);
                return LineTooltipItem(
                  '$dateLabel\nRs. ${barSpot.y.toInt()}',
                  const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                );
              }).toList();
            },
          ),
        ),
      ),
    );
  }

 Widget _buildRideStatusPieChart() {
    
    if (_data == null || _data!['rideStatusChart'] == null) {
      return const Center(child: Text("No ride data"));
    }

    final List<dynamic> stats = _data!['rideStatusChart'];
    
    int getCount(String status) {
      final item = stats.firstWhere(
        (element) => element['_id'] == status, 
        orElse: () => {'count': 0}
      );
      return item['count'];
    }

    int completed = getCount('completed');
    int cancelled = getCount('cancelled');
    int active = getCount('active') + getCount('started') + getCount('arrived'); 
    
    int total = completed + cancelled + active;
    if (total == 0) return const Center(child: Text("No rides yet"));

    String getPercent(int val) => ((val / total) * 100).toStringAsFixed(0);

    return Row(
      children: [
        Expanded(
          flex: 2,
          child: PieChart(
            PieChartData(
              sectionsSpace: 2,
              centerSpaceRadius: 40,
              sections: [
                if (completed > 0)
                  PieChartSectionData(
                    color: const Color(0xFF4CAF50),
                    value: completed.toDouble(),
                    title: '${getPercent(completed)}%',
                    radius: 50,
                    titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                if (cancelled > 0)
                  PieChartSectionData(
                    color: const Color(0xFFF44336),
                    value: cancelled.toDouble(),
                    title: '${getPercent(cancelled)}%',
                    radius: 50,
                    titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                if (active > 0)
                  PieChartSectionData(
                    color: Colors.amber,
                    value: active.toDouble(),
                    title: '${getPercent(active)}%',
                    radius: 50,
                    titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 20),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _LegendItem(color: const Color(0xFF4CAF50), text: "Completed ($completed)"),
              const SizedBox(height: 8),
              _LegendItem(color: Colors.amber, text: "Active ($active)"),
              const SizedBox(height: 8),
              _LegendItem(color: const Color(0xFFF44336), text: "Cancelled ($cancelled)"),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 16),
          Text(
            value,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          Text(
            title,
            style: TextStyle(color: Colors.grey[500], fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildExportButton(
      String label, IconData icon, Color color, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, color: Colors.white, size: 18),
      label: Text(label, style: const TextStyle(color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String text;

  const _LegendItem({required this.color, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text(text, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
      ],
    );
  }
}