import 'package:flutter/material.dart';
import '../../services/admin_service.dart';

class AdminFraudScreen extends StatefulWidget {
  final String token;

  const AdminFraudScreen({super.key, required this.token});

  @override
  State<AdminFraudScreen> createState() => _AdminFraudScreenState();
}

class _AdminFraudScreenState extends State<AdminFraudScreen> {
  final AdminService _adminService = AdminService();
  bool _isLoading = true;
  String? _error;
  List<dynamic> _drivers = [];
  int _total = 0;

  @override
  void initState() {
    super.initState();
    _adminService.setToken(widget.token);
    _loadFraudDrivers();
  }

  Future<void> _loadFraudDrivers() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final data = await _adminService.getFraudDrivers();
      if (data != null) {
        setState(() {
          _drivers = data['drivers'] ?? [];
          _total = data['total'] ?? 0;
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load fraud data.';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text(
          'Fraud Reports',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFCF4374),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
            onPressed: _loadFraudDrivers,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFFCF4374)));
    }
    if (_error != null) {
      return _buildErrorView();
    }
    return RefreshIndicator(
      color: const Color(0xFFCF4374),
      onRefresh: _loadFraudDrivers,
      child: _drivers.isEmpty ? _buildEmptyView() : _buildDriverList(),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: Colors.red)),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadFraudDrivers,
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFCF4374)),
            child: const Text('Retry', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyView() {
    return ListView(
      children: const [
        SizedBox(height: 120),
        Center(
          child: Column(
            children: [
              Icon(Icons.verified_user_outlined, size: 64, color: Colors.green),
              SizedBox(height: 16),
              Text(
                'No fraud flags detected',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black54),
              ),
              SizedBox(height: 8),
              Text('All drivers are operating normally.', style: TextStyle(color: Colors.black38)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryBanner() {
    final redAlertCount = _drivers.where((d) => d['redAlert'] == true).length;
    final driverSuffix = _total == 1 ? '' : 's';
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFCF4374), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.flag_rounded, color: Color(0xFFCF4374), size: 28),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$_total Flagged Driver$driverSuffix',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFCF4374),
                ),
              ),
              Text(
                '$redAlertCount with Red Alert (3+ flags)',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDriverList() {
    return Column(
      children: [
        _buildSummaryBanner(),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            itemCount: _drivers.length,
            itemBuilder: (context, index) => _buildDriverCard(_drivers[index]),
          ),
        ),
      ],
    );
  }

  Widget _buildDriverCard(dynamic driver) {
    final isRedAlert = driver['redAlert'] == true;
    final flagCount = driver['fraudFlagCount'] ?? 0;
    final recentFlags = driver['recentFlags'] as List<dynamic>? ?? [];
    final borderColor = isRedAlert
        ? Colors.red
        : const Color(0xFFCF4374).withValues(alpha: 0.3);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: isRedAlert ? 2 : 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildDriverHeader(driver, isRedAlert),
          _buildFlagCount(flagCount, isRedAlert),
          if (recentFlags.isNotEmpty) _buildRecentFlags(recentFlags),
        ],
      ),
    );
  }

  Widget _buildDriverHeader(dynamic driver, bool isRedAlert) {
    final headerBg = isRedAlert
        ? Colors.red.withValues(alpha: 0.08)
        : const Color(0xFFFAECF1);
    final avatarColor = isRedAlert ? Colors.red : const Color(0xFFCF4374);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: headerBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: avatarColor, shape: BoxShape.circle),
            child: const Icon(Icons.person, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        driver['name'] ?? 'Unknown Driver',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                    ),
                    if (isRedAlert) _buildRedAlertBadge(),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  driver['email'] ?? '',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRedAlertBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.red,
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.warning_amber_rounded, color: Colors.white, size: 12),
          SizedBox(width: 4),
          Text(
            'RED ALERT',
            style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildFlagCount(int flagCount, bool isRedAlert) {
    final flagColor = isRedAlert ? Colors.red : const Color(0xFFCF4374);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          Icon(Icons.flag_rounded, color: flagColor, size: 18),
          const SizedBox(width: 6),
          Text(
            'Total Fraud Flags: $flagCount',
            style: TextStyle(fontWeight: FontWeight.bold, color: flagColor, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentFlags(List<dynamic> recentFlags) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Recent Flags:',
            style: TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          ...recentFlags.map((flag) => _buildFlagItem(flag)),
        ],
      ),
    );
  }

  Widget _buildFlagItem(dynamic flag) {
    final reportedAt = flag['reportedAt'] != null
        ? _formatDate(flag['reportedAt'].toString())
        : 'Unknown date';
    final reasonText = flag['reasonText']?.toString() ?? '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.circle, size: 6, color: Colors.grey),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Ride: ${flag['rideId'] ?? 'N/A'}',
                  style: const TextStyle(fontSize: 11, color: Colors.black54),
                ),
                Text(reportedAt, style: const TextStyle(fontSize: 11, color: Colors.black38)),
                if (reasonText.isNotEmpty)
                  Text(
                    reasonText,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Colors.black54,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String isoString) {
    try {
      final dt = DateTime.parse(isoString).toLocal();
      return '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return isoString;
    }
  }
}
