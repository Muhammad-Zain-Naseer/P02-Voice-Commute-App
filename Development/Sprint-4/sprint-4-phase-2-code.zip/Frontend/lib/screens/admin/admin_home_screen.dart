import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import 'admin_dashboard_screen.dart';
import 'send_alert_page.dart';
import 'policy_broadcast_page.dart';
import 'fare_price_update_page.dart';
import 'unsafe_area_management_page.dart';
import 'user_management_screen.dart';
import 'admin_trip_monitor_screen.dart';
import 'admin_analytics_screen.dart';
import 'admin_support_tickets_page.dart';
import 'admin_coupon_management_page.dart';
import 'admin_fraud_screen.dart';
import '../../services/auth_service.dart';
import '../landing_page.dart';

class AdminHomeScreen extends StatelessWidget {
  final String userName;
  final String userEmail;
  final String token;

  const AdminHomeScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.token,
  });

  @override
  Widget build(BuildContext context) {
    final actions = _buildActions(context);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(
              horizontal: 24.0,
              vertical: 32.0,
            ),
            child: Column(
              children: [
                // ── Header ──────────────────────────────────────
                const SizedBox(height: 8),
                SvgPicture.asset(
                  'assets/icons/car_icon.svg',
                  width: 90,
                  height: 90,
                ),
                const SizedBox(height: 32),
                const SoundWave(),
                const SizedBox(height: 28),
                const Text(
                  'Admin Panel',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Welcome, $userName',
                  style: const TextStyle(
                    fontSize: 17,
                    color: Color(0xFFCF4374),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  userEmail,
                  style: TextStyle(
                    fontSize: 13,
                    color: const Color(0xFFCF4374).withValues(alpha: 0.65),
                  ),
                ),

                const SizedBox(height: 36),

                // ── Uniform 2-column grid ────────────────────────
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: actions.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 1.15,
                  ),
                  itemBuilder: (context, i) => _buildCard(actions[i]),
                ),

                const SizedBox(height: 24),

                // ── Logout ───────────────────────────────────────
                GestureDetector(
                  onTap: () async {
                    await AuthService().logout();

                    if (context.mounted) {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LandingPage(),
                        ),
                        (route) => false,
                      );
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    height: 54,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: const Color(0xFFCF4374),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.15),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.logout_rounded, color: Color(0xFFCF4374)),
                        SizedBox(width: 8),
                        Text(
                          'Logout',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Data ──────────────────────────────────────────────────────
  List<_ActionItem> _buildActions(BuildContext context) => [
        _ActionItem(
          icon: Icons.dashboard_rounded,
          label: 'Dashboard',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AdminDashboardScreen(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.people_rounded,
          label: 'Users',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => UserManagementScreen(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.map_rounded,
          label: 'Trips Monitor',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AdminTripMonitorScreen(
                token: token,
                adminName: userName,
                adminEmail: userEmail,
              ),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.analytics_outlined,
          label: 'Analytics',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AdminAnalyticsScreen(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.warning_amber_rounded,
          label: 'Send Alert',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => SendAlertPage(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.policy_rounded,
          label: 'Policy',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PolicyBroadcastPage(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.attach_money_rounded,
          label: 'Fare Price',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => FarePriceUpdatePage(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.location_off_rounded,
          label: 'Unsafe Areas',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => UnsafeAreaManagementPage(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.support_agent_rounded,
          label: 'Support',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AdminSupportTicketsPage(),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.local_offer_rounded,
          label: 'Coupons',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AdminCouponManagementPage(token: token),
            ),
          ),
        ),
        _ActionItem(
          icon: Icons.flag_rounded,
          label: 'Fraud Reports',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AdminFraudScreen(token: token),
            ),
          ),
        ),
      ];

  // ── Card widget ───────────────────────────────────────────────
  Widget _buildCard(_ActionItem item) {
    return GestureDetector(
      onTap: item.onTap,
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFCF4374), Color(0xFFB8305F)],
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCF4374).withValues(alpha: 0.35),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: item.onTap,
            borderRadius: BorderRadius.circular(18),
            splashColor: Colors.white.withValues(alpha: 0.2),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(item.icon, color: Colors.white, size: 28),
                ),
                const SizedBox(height: 10),
                Text(
                  item.label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionItem {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });
}
