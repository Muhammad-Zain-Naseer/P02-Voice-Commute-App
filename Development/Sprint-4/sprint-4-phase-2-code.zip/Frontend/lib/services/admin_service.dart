import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';

class UnsafeAreaParams {
  final String? name;
  final String? description;
  final double? latitude;
  final double? longitude;
  final String? address;
  final double? radius;
  final String? severity;
  final String? reason;
  final DateTime? activeFrom;
  final DateTime? activeTo;
  final bool? isActive;

  const UnsafeAreaParams({
    this.name,
    this.description,
    this.latitude,
    this.longitude,
    this.address,
    this.radius,
    this.severity,
    this.reason,
    this.activeFrom,
    this.activeTo,
    this.isActive,
  });
}

class AdminService {
  final String baseUrl = AppConfig.apiBaseUrl;
  String? _token;

  void setToken(String token) {
    _token = token;
  }

  Map<String, String> _getHeaders() {
    return {
      'Content-Type': 'application/json',
      if (_token != null) 'Authorization': 'Bearer $_token',
    };
  }

  // Get overview statistics
  Future<Map<String, dynamic>?> getOverviewStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/overview'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching overview stats: $e');
      return null;
    }
  }

  // Get user statistics
  Future<Map<String, dynamic>?> getUserStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/users'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching user stats: $e');
      return null;
    }
  }

  // Get driver statistics
  Future<Map<String, dynamic>?> getDriverStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/drivers'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching driver stats: $e');
      return null;
    }
  }

  // Get ride statistics
  Future<Map<String, dynamic>?> getRideStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/rides'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching ride stats: $e');
      return null;
    }
  }

  // Get payment statistics
  Future<Map<String, dynamic>?> getPaymentStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/payments'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching payment stats: $e');
      return null;
    }
  }

  // Get active trips for monitoring
  Future<Map<String, dynamic>?> getActiveTrips() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/trips/active'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching active trips: $e');
      return null;
    }
  }

  // ==================== USER MANAGEMENT METHODS ====================

  // Get users
  Future<Map<String, dynamic>?> getUsers({
    String? role,
    bool? isVerified,
    int page = 1,
    int limit = 50,
  }) async {
    try {
      String url = '$baseUrl/api/admin/users?page=$page&limit=$limit';
      if (role != null) url += '&role=$role';
      if (isVerified != null) url += '&isVerified=$isVerified';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching users: $e');
      return null;
    }
  }

  // Search users
  Future<Map<String, dynamic>?> searchUsers({
    required String query,
    int page = 1,
    int limit = 20,
  }) async {
    try {
      String url =
          '$baseUrl/api/admin/users/search?query=$query&page=$page&limit=$limit';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error searching users: $e');
      return null;
    }
  }

  // Get user details
  Future<Map<String, dynamic>?> getUserDetails(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/users/$userId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching user details: $e');
      return null;
    }
  }

  // Get user activity (rides, payments, driver info)
  Future<Map<String, dynamic>?> getUserActivity(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/users/$userId/activity'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching user activity: $e');
      return null;
    }
  }

  // Verify user
  Future<bool> verifyUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/verify'),
        headers: _getHeaders(),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error verifying user: $e');
      return false;
    }
  }

  // Activate user
  Future<bool> activateUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/activate'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to activate user: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error activating user: $e');
      return false;
    }
  }

  // Deactivate user
  Future<bool> deactivateUser(String userId, {String? reason}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/deactivate'),
        headers: _getHeaders(),
        body: jsonEncode({if (reason != null) 'reason': reason}),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to deactivate user: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error deactivating user: $e');
      return false;
    }
  }

  // Suspend user
  Future<bool> suspendUser(String userId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/suspend'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to suspend user: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error suspending user: $e');
      return false;
    }
  }

  // Unsuspend user
  Future<bool> unsuspendUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/unsuspend'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to unsuspend user: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error unsuspending user: $e');
      return false;
    }
  }

  // Update user role
  Future<bool> updateUserRole(String userId, String role) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/role'),
        headers: _getHeaders(),
        body: jsonEncode({'role': role}),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to update user role: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error updating user role: $e');
      return false;
    }
  }

  // Delete user
  Future<bool> deleteUser(String userId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/api/admin/users/$userId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      debugPrint('Failed to delete user: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error deleting user: $e');
      return false;
    }
  }

  // Get drivers (supports search)
  Future<Map<String, dynamic>?> getDrivers({
    String? status,
    String? search,
    int page = 1,
    int limit = 20,
  }) async {
    try {
      String url = '$baseUrl/api/admin/drivers?page=$page&limit=$limit';
      if (status != null) url += '&status=$status';
      if (search != null && search.isNotEmpty) url += '&search=$search';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching drivers: $e');
      return null;
    }
  }

  // Update driver status
  Future<bool> updateDriverStatus(
    String driverId,
    String status, {
    String? rejectionReason,
  }) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/status'),
        headers: _getHeaders(),
        body: jsonEncode({
          'status': status,
          if (rejectionReason != null) 'rejectionReason': rejectionReason,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error updating driver status: $e');
      return false;
    }
  }

  // Get pending payments
  Future<Map<String, dynamic>?> getPendingPayments({int page = 1}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/payments/pending?page=$page'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching pending payments: $e');
      return null;
    }
  }

  // Verify payment
  Future<bool> verifyPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/verify'),
        headers: _getHeaders(),
        body: jsonEncode({if (notes != null) 'notes': notes}),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error verifying payment: $e');
      return false;
    }
  }

  // Reject payment
  Future<bool> rejectPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/reject'),
        headers: _getHeaders(),
        body: jsonEncode({if (notes != null) 'notes': notes}),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error rejecting payment: $e');
      return false;
    }
  }

  // Send safety alert
  Future<bool> sendSafetyAlert({
    required String message,
    required String severity,
    String targetAudience = 'all',
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/admin/alerts/alerts'),
        headers: _getHeaders(),
        body: jsonEncode({
          'message': message,
          'severity': severity,
          'targetAudience': targetAudience,
        }),
      );

      return response.statusCode == 201;
    } catch (e) {
      debugPrint('Error sending safety alert: $e');
      return false;
    }
  }

  // Get current fare price
  Future<Map<String, dynamic>> getCurrentFarePrice() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/fares/current'));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      } else {
        throw Exception('Failed to fetch fare price');
      }
    } catch (e) {
      debugPrint('Error fetching fare price: $e');
      rethrow;
    }
  }

  // Update fare price (admin only)
  Future<bool> updateFarePrice({
    required double ratePerKm,
    String? notes,
  }) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/api/fares/update'),
        headers: _getHeaders(),
        body: jsonEncode({'ratePerKm': ratePerKm, 'notes': notes ?? ''}),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error updating fare price: $e');
      return false;
    }
  }

  // Broadcast policy update to users
  Future<bool> sendPolicyUpdate({
    required String title,
    required String message,
    required String category,
    required String severity,
    required String targetAudience,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/policies/send'),
        headers: _getHeaders(),
        body: jsonEncode({
          'title': title,
          'message': message,
          'category': category,
          'severity': severity,
          'targetAudience': targetAudience,
        }),
      );

      return response.statusCode == 201;
    } catch (e) {
      debugPrint('Error sending policy update: $e');
      return false;
    }
  }

  // ==================== UNSAFE AREA METHODS ====================

  // Create a new unsafe area
  Future<Map<String, dynamic>?> createUnsafeArea({
    required UnsafeAreaParams params,
  }) async {
    try {
      final url = '$baseUrl/api/admin/unsafe-areas';
      final body = jsonEncode({
        'name': params.name,
        'description': params.description,
        'latitude': params.latitude,
        'longitude': params.longitude,
        'address': params.address ?? '',
        'radius': params.radius,
        'severity': params.severity,
        'reason': params.reason,
        'activeFrom': params.activeFrom?.toIso8601String(),
        'activeTo': params.activeTo?.toIso8601String(),
      });

      debugPrint('🌐 POST $url');
      debugPrint('📦 Body: $body');
      debugPrint('🔑 Headers: ${_getHeaders()}');

      final response = await http.post(
        Uri.parse(url),
        headers: _getHeaders(),
        body: body,
      );

      debugPrint('📡 Response Status: ${response.statusCode}');
      debugPrint('📡 Response Body: ${response.body}');

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return data['data'];
      } else {
        debugPrint('❌ Failed with status ${response.statusCode}: ${response.body}');
        return null;
      }
    } catch (e, stackTrace) {
      debugPrint('❌ Error creating unsafe area: $e');
      debugPrint('Stack: $stackTrace');
      return null;
    }
  }

  // Get all unsafe areas
  Future<List<Map<String, dynamic>>> getUnsafeAreas({bool? activeOnly}) async {
    try {
      String url = '$baseUrl/api/admin/unsafe-areas';
      if (activeOnly != null) {
        url += '?active=${activeOnly.toString()}';
      }

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['data']);
      }
      return [];
    } catch (e) {
      debugPrint('Error fetching unsafe areas: $e');
      return [];
    }
  }

  // Get a specific unsafe area by ID
  Future<Map<String, dynamic>?> getUnsafeAreaById(String id) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching unsafe area: $e');
      return null;
    }
  }

  // Update an unsafe area
  Future<bool> updateUnsafeArea({
    required String id,
    UnsafeAreaParams? params,
  }) async {
    try {
      final Map<String, dynamic> body = {};
      if (params?.name != null) body['name'] = params!.name;
      if (params?.description != null) body['description'] = params!.description;
      if (params?.latitude != null) body['latitude'] = params!.latitude;
      if (params?.longitude != null) body['longitude'] = params!.longitude;
      if (params?.address != null) body['address'] = params!.address;
      if (params?.radius != null) body['radius'] = params!.radius;
      if (params?.severity != null) body['severity'] = params!.severity;
      if (params?.reason != null) body['reason'] = params!.reason;
      if (params?.isActive != null) body['isActive'] = params!.isActive;
      if (params?.activeFrom != null) body['activeFrom'] = params!.activeFrom!.toIso8601String();
      if (params?.activeTo != null) body['activeTo'] = params!.activeTo!.toIso8601String();

      debugPrint('📝 Updating unsafe area $id');
      debugPrint('Body: ${jsonEncode(body)}');
      debugPrint('Headers: ${_getHeaders()}');

      final response = await http.put(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
        body: jsonEncode(body),
      );

      debugPrint('Response: ${response.statusCode} - ${response.body}');
      return response.statusCode == 200;
    } catch (e) {
      debugPrint('❌ Error updating unsafe area: $e');
      return false;
    }
  }

  // Delete an unsafe area
  Future<bool> deleteUnsafeArea(String id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
      );

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error deleting unsafe area: $e');
      return false;
    }
  }

  // Check if a location is in any unsafe area (Public API)
  Future<Map<String, dynamic>> checkUnsafeLocation({
    required double latitude,
    required double longitude,
  }) async {
    try {
      debugPrint('🔍 Checking unsafe location: $latitude, $longitude');

      final response = await http.post(
        Uri.parse('$baseUrl/api/unsafe-areas/check'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'latitude': latitude, 'longitude': longitude}),
      );

      debugPrint('📡 Response: ${response.statusCode} - ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        debugPrint('✅ Unsafe check result: ${data['data']}');
        return data['data'];
      }

      return {'isUnsafe': false, 'areas': []};
    } catch (e) {
      debugPrint('❌ Error checking unsafe location: $e');
      return {'isUnsafe': false, 'areas': []};
    }
  }

  // ==================== DRIVER VERIFICATION METHODS ====================

  // Get single driver details
  Future<Map<String, dynamic>?> getDriverDetails(String driverId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching driver details: $e');
      return null;
    }
  }

  // Approve driver
  Future<bool> approveDriver(String driverId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/approve'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;

      debugPrint('Failed to approve driver: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error approving driver: $e');
      return false;
    }
  }

  // Reject driver
  Future<bool> rejectDriver(String driverId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/reject'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;

      debugPrint('Failed to reject driver: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error rejecting driver: $e');
      return false;
    }
  }

  // Request resubmission
  Future<bool> requestResubmission(String driverId, String notes) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/resubmission'),
        headers: _getHeaders(),
        body: jsonEncode({'notes': notes}),
      );

      if (response.statusCode == 200) return true;

      debugPrint('Failed to request resubmission: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error requesting resubmission: $e');
      return false;
    }
  }

  // Suspend driver
  Future<bool> suspendDriver(String driverId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/suspend'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;

      debugPrint('Failed to suspend driver: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error suspending driver: $e');
      return false;
    }
  }

  // Reactivate suspended driver
  Future<bool> reactivateDriver(String driverId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/reactivate'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;

      debugPrint('Failed to reactivate driver: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('Error reactivating driver: $e');
      return false;
    }
  }

  // Get Analytics Dashboard Data
  Future<Map<String, dynamic>?> getAnalyticsDashboard(String timeRange) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/analytics/dashboard?timeRange=$timeRange'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      debugPrint('Failed to load analytics: ${response.body}');
      return null;
    } catch (e) {
      debugPrint('Error fetching analytics: $e');
      return null;
    }
  }

  //  Trigger Export 
  Future<String?> exportAnalyticsReport(String type) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/analytics/export?type=$type'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        return response.body;
      }
      debugPrint('Failed to export: ${response.body}');
      return null;
    } catch (e) {
      debugPrint('Error exporting report: $e');
      return null;
    }
  }

  // Get drivers flagged for ride-cancellation fraud
  Future<Map<String, dynamic>?> getFraudDrivers() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/fraud/drivers'),
        headers: _getHeaders(),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      debugPrint('Failed to fetch fraud drivers: ${response.body}');
      return null;
    } catch (e) {
      debugPrint('Error fetching fraud drivers: $e');
      return null;
    }
  }
}
