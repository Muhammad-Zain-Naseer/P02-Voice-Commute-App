import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import '../utils/logger.dart';

/// Service for admin coupon management
class CouponService {
  static final String _baseUrl = '${AppConfig.apiBaseUrl}/api/coupons';
  static const Duration _timeout = Duration(seconds: 30);

  final String? _token;

  CouponService({String? token}) : _token = token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  /// Get all coupons (admin)
  Future<List<Map<String, dynamic>>> getCoupons() async {
    try {
      Logger.log('🎟️ Fetching all coupons');
      final response =
          await http.get(Uri.parse(_baseUrl), headers: _headers).timeout(_timeout);

      Logger.log('📥 getCoupons status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List list = data['data']['coupons'] as List;
        return list.cast<Map<String, dynamic>>();
      }
      return [];
    } catch (e) {
      Logger.error('💥 getCoupons error: $e');
      return [];
    }
  }

  /// Create a new coupon (admin)
  Future<Map<String, dynamic>> createCoupon({
    required String code,
    required double discountPercentage,
    String description = '',
    int? maxUses,
    DateTime? expiryDate,
  }) async {
    try {
      Logger.log('🎟️ Creating coupon: $code ($discountPercentage% off)');

      final body = <String, dynamic>{
        'code': code.trim().toUpperCase(),
        'discountPercentage': discountPercentage,
        'description': description,
      };
      if (maxUses != null) body['maxUses'] = maxUses;
      if (expiryDate != null) body['expiryDate'] = expiryDate.toIso8601String();

      final response = await http
          .post(Uri.parse(_baseUrl), headers: _headers, body: jsonEncode(body))
          .timeout(_timeout);

      Logger.log('📥 createCoupon status: ${response.statusCode}');

      final data = jsonDecode(response.body);

      if (response.statusCode == 201) {
        return {'success': true, 'coupon': data['data']['coupon']};
      } else {
        return {
          'success': false,
          'message': data['error'] ?? 'Failed to create coupon'
        };
      }
    } catch (e) {
      Logger.error('💥 createCoupon error: $e');
      return {'success': false, 'message': 'Network error. Please try again.'};
    }
  }

  /// Toggle coupon active/inactive (admin)
  Future<bool> toggleCoupon(String id) async {
    try {
      Logger.log('🎟️ Toggling coupon: $id');
      final response = await http
          .patch(Uri.parse('$_baseUrl/$id/toggle'), headers: _headers)
          .timeout(_timeout);

      Logger.log('📥 toggleCoupon status: ${response.statusCode}');
      return response.statusCode == 200;
    } catch (e) {
      Logger.error('💥 toggleCoupon error: $e');
      return false;
    }
  }

  /// Delete a coupon (admin)
  Future<bool> deleteCoupon(String id) async {
    try {
      Logger.log('🎟️ Deleting coupon: $id');
      final response = await http
          .delete(Uri.parse('$_baseUrl/$id'), headers: _headers)
          .timeout(_timeout);

      Logger.log('📥 deleteCoupon status: ${response.statusCode}');
      return response.statusCode == 200;
    } catch (e) {
      Logger.error('💥 deleteCoupon error: $e');
      return false;
    }
  }
}
