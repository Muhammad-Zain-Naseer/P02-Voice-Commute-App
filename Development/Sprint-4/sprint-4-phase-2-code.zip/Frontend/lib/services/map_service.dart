import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/logger.dart';
import '../constants/app_config.dart';

class MapService {
  static const String _contentType = 'Content-Type';
  static const String _applicationJson = 'application/json';
  static String get baseUrl => '${AppConfig.apiBaseUrl}/api/maps';

  static Future<Map<String, String>> translateAddresses({
    required String source,
    required String destination,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/translate'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({
          'source': source,
          'destination': destination,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log('✅ Translated: $source -> ${data['source']}');
        Logger.log('✅ Translated: $destination -> ${data['destination']}');
        return {
          'source': data['source'],
          'destination': data['destination'],
        };
      }
    } catch (e) {
      Logger.error('❌ Translation error: $e');
    }

    return {'source': source, 'destination': destination};
  }

  /// Geocode an address using backend Google Maps API
  static Future<Map<String, double>?> geocodeAddress(String address) async {
    try {
      Logger.log('📍 Geocoding address via backend: $address');
      Logger.log('📍 Using baseUrl: $baseUrl');

      // Ensure address has proper location context
      String fullAddress = address;
      if (!address.toLowerCase().contains('lahore') &&
          !address.toLowerCase().contains('pakistan')) {
        fullAddress = '$address, Lahore, Pakistan';
        Logger.log('📍 Enhanced address: $fullAddress');
      }

      final url = Uri.parse('$baseUrl/geocode');
      Logger.log('📍 Geocoding URL: $url');

      final response = await http
          .post(
            url,
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'address': fullAddress,
            }),
          )
          .timeout(
            const Duration(seconds: 30),
            onTimeout: () {
              Logger.error('❌ Geocoding request timed out after 30 seconds');
              throw Exception('Geocoding request timed out');
            },
          );

      Logger.log('📍 Geocoding response status: ${response.statusCode}');
      Logger.log('📍 Geocoding response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log(
            '✅ Geocoded: $fullAddress -> (${data['latitude']}, ${data['longitude']})');
        return {
          'latitude': (data['latitude'] as num).toDouble(),
          'longitude': (data['longitude'] as num).toDouble(),
        };
      } else {
        Logger.error(
            '❌ Geocoding failed with status ${response.statusCode}: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Geocoding error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return null;
  }

  static Future<Map<String, String>> calculateRoute({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
  }) async {
    try {
      Logger.log('🗺️ Calculating route: ($sourceLat, $sourceLng) -> ($destLat, $destLng)');
      final response = await http
          .post(
            Uri.parse('$baseUrl/calculate-route'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🗺️ Route response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log('✅ Route calculated: ${data['distance']}, ${data['duration']}');
        return {
          'distance': data['distance'],
          'duration': data['duration'],
        };
      } else {
        Logger.error('❌ Route calculation failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Route calculation error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return {'distance': 'N/A', 'duration': 'N/A'};
  }

  /// Calculate total distance/duration through multiple stops.
  /// Falls back to [calculateRoute] when stops is null/empty.
  static Future<Map<String, dynamic>> calculateRouteWithStops({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
    List<Map<String, double>>? stops,
  }) async {
    if (stops == null || stops.isEmpty) {
      final result = await calculateRoute(
        sourceLat: sourceLat,
        sourceLng: sourceLng,
        destLat: destLat,
        destLng: destLng,
      );
      final distanceStr = result['distance'] ?? '0 km';
      final distanceKm = double.tryParse(distanceStr.split(' ')[0]) ?? 0.0;
      return {'distance': result['distance'], 'duration': result['duration'], 'distanceKm': distanceKm};
    }

    try {
      Logger.log('🗺️ Calculating route with ${stops.length} stop(s)...');
      final response = await http
          .post(
            Uri.parse('$baseUrl/calculate-route-with-stops'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
              'waypoints': stops.map((s) => {'lat': s['lat'], 'lng': s['lng']}).toList(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Logger.log('✅ Route with stops: ${data['distance']}, ${data['duration']}');
        return {
          'distance': data['distance'] as String,
          'duration': data['duration'] as String,
          'distanceKm': (data['distanceKm'] as num).toDouble(),
        };
      }
    } catch (e) {
      Logger.error('❌ calculateRouteWithStops error: $e');
    }

    return {'distance': 'N/A', 'duration': 'N/A', 'distanceKm': 0.0};
  }

  static Future<String> getDirectionsPolyline({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
  }) async {
    try {
      Logger.log('🛣️ Fetching directions polyline...');
      final response = await http
          .post(
            Uri.parse('$baseUrl/directions-polyline'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🛣️ Polyline response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final polyline = data['polyline'] ?? '';
        Logger.log('✅ Polyline fetched (${polyline.length} chars)');
        return polyline;
      } else {
        Logger.error('❌ Polyline fetch failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Polyline error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return '';
  }

  static Future<String> getStaticMapUrl({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
    required String polyline,
  }) async {
    try {
      Logger.log('🗺️ Fetching static map URL from backend...');
      Logger.log('🗺️ Coordinates: ($sourceLat, $sourceLng) -> ($destLat, $destLng)');
      Logger.log('🗺️ Polyline length: ${polyline.length}');

      final response = await http
          .post(
            Uri.parse('$baseUrl/static-map-url'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
              'polyline': polyline,
            }),
          )
          .timeout(const Duration(seconds: 30));

      Logger.log('🗺️ Map URL response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final mapUrl = data['mapUrl'] ?? '';
        Logger.log('✅ Static map URL received (${mapUrl.length} chars)');
        Logger.log('🗺️ Map URL: $mapUrl');
        return mapUrl;
      } else {
        Logger.error('❌ Map URL fetch failed: ${response.body}');
      }
    } catch (e, stackTrace) {
      Logger.error('❌ Static map URL error: $e');
      Logger.error('❌ Stack trace: $stackTrace');
    }

    return '';
  }

  /// Get directions polyline with intermediate stop waypoints
  static Future<String> getDirectionsPolylineWithStops({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
    List<Map<String, double>>? stops,
  }) async {
    if (stops == null || stops.isEmpty) {
      return getDirectionsPolyline(
        sourceLat: sourceLat,
        sourceLng: sourceLng,
        destLat: destLat,
        destLng: destLng,
      );
    }

    try {
      Logger.log('🛣️ Fetching polyline with ${stops.length} stop(s)...');
      final response = await http
          .post(
            Uri.parse('$baseUrl/directions-polyline-with-stops'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
              'waypoints': stops
                  .map((s) => {'lat': s['lat'], 'lng': s['lng']})
                  .toList(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final polyline = data['polyline'] ?? '';
        Logger.log('✅ Polyline with stops fetched (${polyline.length} chars)');
        return polyline;
      }
    } catch (e) {
      Logger.error('❌ Polyline with stops error: $e');
    }
    return '';
  }

  /// Get static map URL with stop markers
  static Future<String> getStaticMapUrlWithStops({
    required double sourceLat,
    required double sourceLng,
    required double destLat,
    required double destLng,
    required String polyline,
    List<Map<String, double>>? stops,
  }) async {
    if (stops == null || stops.isEmpty) {
      return getStaticMapUrl(
        sourceLat: sourceLat,
        sourceLng: sourceLng,
        destLat: destLat,
        destLng: destLng,
        polyline: polyline,
      );
    }

    try {
      Logger.log('🗺️ Fetching static map URL with ${stops.length} stop(s)...');
      final response = await http
          .post(
            Uri.parse('$baseUrl/static-map-url-with-stops'),
            headers: {_contentType: _applicationJson},
            body: jsonEncode({
              'sourceLat': sourceLat,
              'sourceLng': sourceLng,
              'destLat': destLat,
              'destLng': destLng,
              'polyline': polyline,
              'stops': stops
                  .map((s) => {'lat': s['lat'], 'lng': s['lng']})
                  .toList(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['mapUrl'] ?? '';
      }
    } catch (e) {
      Logger.error('❌ Static map with stops error: $e');
    }
    return '';
  }
}