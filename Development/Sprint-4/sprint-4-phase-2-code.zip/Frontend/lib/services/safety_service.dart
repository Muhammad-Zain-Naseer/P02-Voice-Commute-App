import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart'; 
import 'storage_service.dart';

class SafetyService {
  
  // Fetch alerts from the last 7 days
  static Future<List<Map<String, dynamic>>> getRecentAlerts() async {
    try {
      final token = await StorageService.getToken();
      final url = Uri.parse('${AppConfig.apiBaseUrl}/api/admin/alerts/history');

      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['data']);
      } else {
        return [];
      }
    } catch (e) {
      debugPrint('Error fetching safety history: $e');
      return [];
    }
  }
}