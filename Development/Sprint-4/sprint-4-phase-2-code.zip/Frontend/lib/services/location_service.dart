import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../utils/logger.dart';

class LocationService {
  static const String _currentLocation = 'Current Location';
  static String? _cachedLocation;
  static DateTime? _cacheTime;
  static const Duration _cacheDuration = Duration(
    minutes: 2,
  ); // Reduced from 5 to 2 minutes for better accuracy

  /// Check that location services are enabled; opens settings if needed. Returns false if still disabled.
  static Future<bool> _ensureLocationServicesEnabled() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      Logger.log('📍 LocationService: Location services disabled, opening settings...');
      await Geolocator.openLocationSettings();
      serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        Logger.error('📍 LocationService: Location services are still disabled');
        return false;
      }
    }
    return true;
  }

  /// Check and request location permission. Returns false if denied.
  static Future<bool> _ensureLocationPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      Logger.log('📍 LocationService: Requesting location permission...');
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Logger.error('📍 LocationService: Location permissions denied');
        return false;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      Logger.error('📍 LocationService: Location permissions permanently denied');
      return false;
    }
    return true;
  }

  /// Acquire current position with progressive accuracy fallback.
  static Future<Position> _acquirePosition() async {
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 30),
        ),
      );
      Logger.log('📍 LocationService: High accuracy position acquired: ${pos.latitude}, ${pos.longitude}');
      return pos;
    } catch (_) {
      Logger.log('📍 LocationService: High accuracy timeout, trying medium accuracy...');
    }
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 15),
        ),
      );
      Logger.log('📍 LocationService: Medium accuracy position acquired: ${pos.latitude}, ${pos.longitude}');
      return pos;
    } catch (e) {
      Logger.log('📍 LocationService: Medium accuracy timeout, using last known position...');
      final pos = await Geolocator.getLastKnownPosition() ??
          (throw Exception('Unable to get location: $e'));
      Logger.log('📍 LocationService: Last known position: ${pos.latitude}, ${pos.longitude}');
      return pos;
    }
  }

  /// Get current location and convert to address
  /// Returns formatted address string or null if failed
  static Future<String?> getCurrentLocationAddress() async {
    try {
      // Check cache first
      if (_cachedLocation != null && _cacheTime != null) {
        final age = DateTime.now().difference(_cacheTime!);
        if (age < _cacheDuration) {
          Logger.log('📍 LocationService: Using cached location: $_cachedLocation');
          return _cachedLocation;
        }
      }

      Logger.log('📍 LocationService: Checking location permissions...');

      if (!await _ensureLocationServicesEnabled()) return null;
      if (!await _ensureLocationPermission()) return null;

      Logger.log('📍 LocationService: Permission granted, getting position...');

      final position = await _acquirePosition();
      Logger.log('📍 LocationService: Final Position: ${position.latitude}, ${position.longitude}');

      final address = kIsWeb
          ? await _reverseGeocodeWeb(position.latitude, position.longitude)
          : await _reverseGeocodeMobile(position.latitude, position.longitude);

      _cachedLocation = address;
      _cacheTime = DateTime.now();

      Logger.log('📍 LocationService: ✅ Current location: $address');
      return address;
    } catch (e) {
      Logger.error('📍 LocationService: ❌ Error getting location: $e');
      return null;
    }
  }

  /// Reverse geocode using OpenStreetMap Nominatim API (for web)
  static Future<String> _reverseGeocodeWeb(double lat, double lon) async {
    try {
      Logger.log('📍 LocationService: Reverse geocoding via Nominatim API...');
      final url =
          'https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lon&zoom=18&addressdetails=1';

      final response = await http.get(
        Uri.parse(url),
        headers: {'User-Agent': 'RideBookingApp/1.0'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final address = data['address'];

        List<String> parts = [];

        // Add road/street
        if (address['road'] != null) {
          parts.add(address['road']);
        } else if (address['suburb'] != null) {
          parts.add(address['suburb']);
        }

        // Add city
        if (address['city'] != null) {
          parts.add(address['city']);
        } else if (address['town'] != null) {
          parts.add(address['town']);
        } else if (address['village'] != null) {
          parts.add(address['village']);
        }

        if (parts.isNotEmpty) {
          return parts.join(', ');
        }

        // Fallback to display_name
        return data['display_name']?.toString().split(',').take(3).join(', ') ??
            _currentLocation;
      }

      return _currentLocation;
    } catch (e) {
      Logger.error('📍 LocationService: Nominatim API error: $e');
      return _currentLocation;
    }
  }

  /// Reverse geocode using geocoding package (for mobile)
  static Future<String> _reverseGeocodeMobile(double lat, double lon) async {
    try {
      Logger.log(
        '📍 LocationService: Reverse geocoding via geocoding package...',
      );
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lon);

      if (placemarks.isEmpty) {
        return _currentLocation;
      }

      Placemark place = placemarks[0];
      return _formatAddress(place);
    } catch (e) {
      Logger.error('📍 LocationService: Geocoding package error: $e');
      return _currentLocation;
    }
  }

  static String? _pickStreetPart(Placemark place) {
    if (place.street != null && place.street!.isNotEmpty) return place.street;
    if (place.subLocality != null && place.subLocality!.isNotEmpty) return place.subLocality;
    return null;
  }

  static String? _pickCityPart(Placemark place) {
    if (place.locality != null && place.locality!.isNotEmpty) return place.locality;
    if (place.subAdministrativeArea != null && place.subAdministrativeArea!.isNotEmpty) {
      return place.subAdministrativeArea;
    }
    return null;
  }

  /// Format placemark into readable address
  static String _formatAddress(Placemark place) {
    final List<String> parts = [];

    final street = _pickStreetPart(place);
    if (street != null) parts.add(street);

    final city = _pickCityPart(place);
    if (city != null) parts.add(city);

    // Add administrative area only if not already represented
    if (place.administrativeArea != null && place.administrativeArea!.isNotEmpty) {
      if (!parts.any((p) => p.contains(place.administrativeArea!))) {
        parts.add(place.administrativeArea!);
      }
    }

    if (parts.isEmpty) {
      if (place.name != null && place.name!.isNotEmpty) return place.name!;
      return _currentLocation;
    }

    return parts.join(', ');
  }

  /// Geocode an address to coordinates
  /// Returns a Coordinates object with latitude and longitude
  static Future<Coordinates> geocodeAddress(String address) async {
    try {
      Logger.log('📍 LocationService: Geocoding address: $address');

      if (kIsWeb) {
        // Use OpenStreetMap Nominatim API for web
        return await _geocodeWeb(address);
      } else {
        // Use geocoding package for mobile
        return await _geocodeMobile(address);
      }
    } catch (e) {
      Logger.error('📍 LocationService: ❌ Error geocoding address: $e');
      rethrow;
    }
  }

  /// Geocode using OpenStreetMap Nominatim API (for web)
  static Future<Coordinates> _geocodeWeb(String address) async {
    try {
      Logger.log('📍 LocationService: Geocoding via Nominatim API...');
      final encodedAddress = Uri.encodeComponent(address);
      final url =
          'https://nominatim.openstreetmap.org/search?format=json&q=$encodedAddress&limit=1';

      final response = await http.get(
        Uri.parse(url),
        headers: {'User-Agent': 'RideBookingApp/1.0'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.isEmpty) {
          throw Exception('Address not found');
        }

        final lat = double.parse(data[0]['lat']);
        final lon = double.parse(data[0]['lon']);

        Logger.log('📍 LocationService: ✅ Geocoded: $lat, $lon');
        return Coordinates(latitude: lat, longitude: lon);
      }

      throw Exception('Failed to geocode address: ${response.statusCode}');
    } catch (e) {
      Logger.error('📍 LocationService: Nominatim geocoding error: $e');
      rethrow;
    }
  }

  /// Geocode using geocoding package (for mobile)
  static Future<Coordinates> _geocodeMobile(String address) async {
    try {
      Logger.log('📍 LocationService: Geocoding via geocoding package...');
      List<Location> locations = await locationFromAddress(address);

      if (locations.isEmpty) {
        throw Exception('Address not found');
      }

      final location = locations[0];
      Logger.log('📍 LocationService: ✅ Geocoded: ${location.latitude}, ${location.longitude}');

      return Coordinates(latitude: location.latitude, longitude: location.longitude);
    } catch (e) {
      Logger.error('📍 LocationService: Geocoding package error: $e');
      rethrow;
    }
  }
}

/// Coordinates class for latitude and longitude
class Coordinates {
  final double latitude;
  final double longitude;

  Coordinates({required this.latitude, required this.longitude});
}
