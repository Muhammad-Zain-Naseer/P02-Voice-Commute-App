import 'package:flutter/material.dart';
import '../models/trip_notification.dart';
import '../utils/logger.dart';
import 'socket_service.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final List<TripNotification> _notifications = [];
  final _notificationController = ValueNotifier<List<TripNotification>>([]);
  
  bool _isInitialized = false;
  String? _userEmail;

  ValueNotifier<List<TripNotification>> get notificationStream =>
      _notificationController;

  int get unreadCount =>
      _notifications.where((n) => !n.isRead).length;

  List<TripNotification> get allNotifications => List.from(_notifications);

  /// Initialize notification listener
  void initialize(String userEmail) {
    if (_isInitialized) {
      Logger.log('⚠️ NotificationService already initialized');
      return;
    }

    _userEmail = userEmail;
    Logger.log('📱 NotificationService ready for: $userEmail');
    Logger.log('⏳ Will set up listeners after socket connection');

    _isInitialized = true;
    Logger.log('NotificationService initialized');
  }

  /// Register as trusted contact
  void registerWhenConnected() {
    if (_userEmail != null && SocketService.isConnected) {
      _setupListenersAndRegister();
    }
  }

  void _setupListenersAndRegister() {
    if (_userEmail == null) {
      Logger.error('❌ Cannot register: userEmail is null');
      return;
    }

    if (!SocketService.isConnected) {
      Logger.error('❌ Cannot register: Socket not connected');
      return;
    }

    Logger.log('Setting up trip notification listener');
    Logger.log('Socket ID: ${SocketService.socket?.id}');
    Logger.log('Socket connected: ${SocketService.socket?.connected}');
    
    // Set up the trip notification listener AFTER socket is connected
    SocketService.onTripNotification(_handleNotification);
    
    Logger.log('✅ Trip notification listener registered');
    
    // Listen for registration confirmation
    SocketService.onTrustedContactRegistered((data) {
      Logger.log('✅ Trusted contact registered successfully: $data');
    });

    Logger.log('Registering as trusted contact: $_userEmail');
    SocketService.registerAsTrustedContact(_userEmail!);
    
    // Wait a bit and log status
    Future.delayed(const Duration(seconds: 1), () {
      Logger.log('Notification service status:');
      Logger.log('   - Email: $_userEmail');
      Logger.log('   - Socket connected: ${SocketService.isConnected}');
      Logger.log('   - Notifications count: ${_notifications.length}');
    });
  }

  /// Handle incoming notification
  void _handleNotification(Map<String, dynamic> data) {
    try {
      Logger.log('📬 New notification received: ${data['type']}');
      Logger.log('📬 Raw data: $data');

      final notification = TripNotification.fromJson(data);
      
      Logger.log('✅ Notification parsed successfully');
      Logger.log('   Title: ${notification.title}');
      Logger.log('   Description: ${notification.description}');
      Logger.log('   Commuter: ${notification.commuterName}');
      
      // Add to list
      _notifications.insert(0, notification);
      
      Logger.log('Current notifications count: ${_notifications.length}');
      
      // Keep only last 50 notifications
      if (_notifications.length > 50) {
        _notifications.removeLast();
      }

      // Notify listeners
      _notificationController.value = List.from(_notifications);
      
      Logger.log('🔔 Listeners notified, unread count: $unreadCount');

      // Show popup for SOS alerts
      if (notification.type == 'SOS_ALERT') {
        _showSOSPopup(notification);
      }

      Logger.log('✅ Notification added: ${notification.title}');
    } catch (e, stackTrace) {
      Logger.error('❌ Error handling notification: $e');
      Logger.error('Stack trace: $stackTrace');
      Logger.error('Raw data that failed: $data');
    }
  }

  /// Show SOS emergency popup
  void _showSOSPopup(TripNotification notification) {
    Logger.log('🚨 SOS ALERT popup triggered');
  }

  /// Mark notification as read
  void markAsRead(String notificationId) {
    final index = _notifications.indexWhere((n) => n.id == notificationId);
    if (index != -1) {
      _notifications[index] = _notifications[index].copyWith(isRead: true);
      _notificationController.value = List.from(_notifications);
      Logger.log('✅ Notification marked as read: $notificationId');
    }
  }

  /// Mark all notifications as read
  void markAllAsRead() {
    for (int i = 0; i < _notifications.length; i++) {
      _notifications[i] = _notifications[i].copyWith(isRead: true);
    }
    _notificationController.value = List.from(_notifications);
    Logger.log('All notifications marked as read');
  }

  /// Clear all notifications
  void clearAll() {
    _notifications.clear();
    _notificationController.value = [];
    Logger.log('All notifications cleared');
  }

  /// Dispose
  void dispose() {
    _notificationController.dispose();
  }
}