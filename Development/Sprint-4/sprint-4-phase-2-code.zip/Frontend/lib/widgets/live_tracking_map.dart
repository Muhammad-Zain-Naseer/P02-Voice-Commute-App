/// Live Tracking Map Widget
/// Shows real-time driver location on Google Maps with route polyline
library;

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../utils/logger.dart';
import '../services/map_service.dart';

class LiveTrackingMap extends StatefulWidget {
  final double driverLat;
  final double driverLng;
  final double passengerLat;
  final double passengerLng;
  final String? polylineEncoded;
  final Function(GoogleMapController)? onMapCreated;
  final bool showRoute;
  final List<LatLng> stops;

  const LiveTrackingMap({
    super.key,
    required this.driverLat,
    required this.driverLng,
    required this.passengerLat,
    required this.passengerLng,
    this.polylineEncoded,
    this.onMapCreated,
    this.showRoute = true,
    this.stops = const [],
  });

  @override
  State<LiveTrackingMap> createState() => LiveTrackingMapState();
}

class LiveTrackingMapState extends State<LiveTrackingMap> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  // Web fallback state
  String? _staticMapUrl;
  bool _isLoadingStaticMap = false;

  @override
  void initState() {
    super.initState();
    _updateMarkers();
    if (widget.showRoute && widget.polylineEncoded != null) {
      _updatePolyline();
    }
    // Load static map for web platform
    if (kIsWeb) {
      _loadStaticMap();
    }
  }

  @override
  void didUpdateWidget(LiveTrackingMap oldWidget) {
    super.didUpdateWidget(oldWidget);

    bool locationChanged = false;

    // Update markers if location changed
    if (oldWidget.driverLat != widget.driverLat ||
        oldWidget.driverLng != widget.driverLng ||
        oldWidget.passengerLat != widget.passengerLat ||
        oldWidget.passengerLng != widget.passengerLng ||
        oldWidget.stops.length != widget.stops.length) {
      Logger.log('📍 Map: Location changed, updating markers');
      _updateMarkers();
      locationChanged = true;
    }

    // Update polyline if route changed
    if (widget.showRoute &&
        oldWidget.polylineEncoded != widget.polylineEncoded) {
      Logger.log('🗺️ Map: Polyline changed, updating route');
      _updatePolyline();
    }

    // Animate camera after markers are updated (native only)
    if (locationChanged && !kIsWeb) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _animateToDriverLocation();
      });
    }

    // Reload static map on web when locations or polyline changes
    if (kIsWeb && (locationChanged || oldWidget.polylineEncoded != widget.polylineEncoded)) {
      _loadStaticMap();
    }
  }

  /// Load static map image for web platform fallback
  Future<void> _loadStaticMap() async {
    if (_isLoadingStaticMap) return;

    setState(() {
      _isLoadingStaticMap = true;
    });

    try {
      final stopLatLngs = widget.stops
          .map((s) => {'lat': s.latitude, 'lng': s.longitude})
          .toList();

      // Get polyline if not already available
      String polyline = widget.polylineEncoded ?? '';
      if (polyline.isEmpty) {
        polyline = await MapService.getDirectionsPolylineWithStops(
          sourceLat: widget.driverLat,
          sourceLng: widget.driverLng,
          destLat: widget.passengerLat,
          destLng: widget.passengerLng,
          stops: stopLatLngs.isEmpty ? null : stopLatLngs,
        );
      }

      final mapUrl = await MapService.getStaticMapUrlWithStops(
        sourceLat: widget.driverLat,
        sourceLng: widget.driverLng,
        destLat: widget.passengerLat,
        destLng: widget.passengerLng,
        polyline: polyline,
        stops: stopLatLngs.isEmpty ? null : stopLatLngs,
      );

      if (mounted) {
        setState(() {
          _staticMapUrl = mapUrl;
          _isLoadingStaticMap = false;
        });
        Logger.log('🗺️ Static map loaded for web');
      }
    } catch (e) {
      Logger.error('❌ Failed to load static map: $e');
      if (mounted) {
        setState(() {
          _isLoadingStaticMap = false;
        });
      }
    }
  }

  void _updateMarkers() {
    setState(() {
      _markers.clear();

      // Driver marker (moving) - Cyan/Azure color for car
      _markers.add(
        Marker(
          markerId: const MarkerId('driver'),
          position: LatLng(widget.driverLat, widget.driverLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueAzure, // Cyan/light blue - represents car
          ),
          infoWindow: const InfoWindow(
            title: '🚗 Driver',
            snippet: 'Moving to pickup',
          ),
        ),
      );

      // Passenger marker (waiting) - Orange color for person
      _markers.add(
        Marker(
          markerId: const MarkerId('passenger'),
          position: LatLng(widget.passengerLat, widget.passengerLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueOrange, // Orange - represents person waiting
          ),
          infoWindow: const InfoWindow(
            title: '👤 Pickup Location',
            snippet: 'Waiting for driver',
          ),
        ),
      );

      // Stop markers - Violet color for intermediate stops
      for (int i = 0; i < widget.stops.length; i++) {
        _markers.add(
          Marker(
            markerId: MarkerId('stop_$i'),
            position: widget.stops[i],
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueViolet,
            ),
            infoWindow: InfoWindow(
              title: 'Stop ${i + 1}',
              snippet: 'Intermediate stop',
            ),
          ),
        );
      }
    });
  }

  void _updatePolyline() {
    if (widget.polylineEncoded == null) return;

    try {
      final points = _decodePolyline(widget.polylineEncoded!);
      setState(() {
        _polylines.clear();
        _polylines.add(
          Polyline(
            polylineId: const PolylineId('route'),
            points: points,
            color: Colors.blue,
            width: 5,
          ),
        );
      });
    } catch (e) {
      Logger.error('Error decoding polyline: $e');
    }
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0;
    int len = encoded.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int b;
      int shift = 0;
      int result = 0;

      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;

      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }

  void _animateToDriverLocation() {
    if (_mapController == null) return;

    _mapController!.animateCamera(
      CameraUpdate.newLatLng(
        LatLng(widget.driverLat, widget.driverLng),
      ),
    );
  }

  /// Update driver location (called from parent)
  void updateDriverLocation(double lat, double lng) {
    if (!mounted) return;
    // Parent will update widget properties, which triggers didUpdateWidget
  }

  /// Fit map bounds to show both driver and passenger
  Future<void> fitBounds() async {
    if (_mapController == null) return;

    final bounds = LatLngBounds(
      southwest: LatLng(
        widget.driverLat < widget.passengerLat
            ? widget.driverLat
            : widget.passengerLat,
        widget.driverLng < widget.passengerLng
            ? widget.driverLng
            : widget.passengerLng,
      ),
      northeast: LatLng(
        widget.driverLat > widget.passengerLat
            ? widget.driverLat
            : widget.passengerLat,
        widget.driverLng > widget.passengerLng
            ? widget.driverLng
            : widget.passengerLng,
      ),
    );

    await _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 100),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Use static map image on web for better compatibility
    if (kIsWeb) {
      return _buildWebMap();
    }
    return _buildNativeMap();
  }

  /// Build static map for web platform
  Widget _buildWebMap() {
    return Stack(
      children: [
        // Static map image
        if (_isLoadingStaticMap || _staticMapUrl == null || _staticMapUrl!.isEmpty)
          Container(
            color: Colors.grey[200],
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Color(0xFFCF4374)),
                  SizedBox(height: 16),
                  Text(
                    'Loading map...',
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                ],
              ),
            ),
          )
        else
          Image.network(
            _staticMapUrl!,
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            loadingBuilder: (context, child, loadingProgress) {
              if (loadingProgress == null) return child;
              return Container(
                color: Colors.grey[200],
                child: Center(
                  child: CircularProgressIndicator(
                    color: const Color(0xFFCF4374),
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded /
                            (loadingProgress.expectedTotalBytes ?? 1)
                        : null,
                  ),
                ),
              );
            },
            errorBuilder: (context, error, stackTrace) {
              Logger.error('Map image failed to load: $error');
              return Container(
                color: Colors.grey[200],
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.map, size: 60, color: Colors.grey),
                      SizedBox(height: 8),
                      Text(
                        'Map unavailable',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

        // Refresh button for web
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            mini: true,
            backgroundColor: Colors.white,
            onPressed: _loadStaticMap,
            child: const Icon(
              Icons.refresh,
              color: Color(0xFFCF4374),
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  /// Build interactive Google Map for native platforms
  Widget _buildNativeMap() {
    return Stack(
      children: [
        // Google Map
        GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(widget.driverLat, widget.driverLng),
            zoom: 14,
          ),
          markers: _markers,
          polylines: _polylines,
          myLocationEnabled: false,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false, // Custom controls
          mapToolbarEnabled: false,
          compassEnabled: true,
          rotateGesturesEnabled: true,
          scrollGesturesEnabled: true,
          tiltGesturesEnabled: true,
          zoomGesturesEnabled: true,
          mapType: MapType.normal,
          onMapCreated: (controller) {
            _mapController = controller;
            widget.onMapCreated?.call(controller);
            // Fit bounds after map is created
            Future.delayed(const Duration(milliseconds: 500), () {
              fitBounds();
            });
          },
        ),

        // Custom zoom controls
        Positioned(
          right: 16,
          bottom: 80,
          child: Column(
            children: [
              // Zoom in
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(8),
                    topRight: Radius.circular(8),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  icon: const Icon(Icons.add, size: 20),
                  onPressed: () {
                    _mapController?.animateCamera(CameraUpdate.zoomIn());
                  },
                ),
              ),
              Container(
                height: 1,
                width: 40,
                color: Colors.grey.shade300,
              ),
              // Zoom out
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(8),
                    bottomRight: Radius.circular(8),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  icon: const Icon(Icons.remove, size: 20),
                  onPressed: () {
                    _mapController?.animateCamera(CameraUpdate.zoomOut());
                  },
                ),
              ),
            ],
          ),
        ),

        // Center on driver button
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            mini: true,
            backgroundColor: Colors.white,
            onPressed: () => _animateToDriverLocation(),
            child: const Icon(
              Icons.my_location,
              color: Color(0xFFCF4374),
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
