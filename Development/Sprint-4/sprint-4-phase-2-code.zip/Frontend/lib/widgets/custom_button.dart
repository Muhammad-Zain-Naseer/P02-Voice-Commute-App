import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool isPrimary;
  final Color? borderColor;
  final Color? backgroundColor;
  final Color? textColor;
  final double? height;
  final double? fontSize;
  final bool isGradient;

  const CustomButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.isPrimary = true,
    this.borderColor,
    this.backgroundColor,
    this.textColor,
    this.height,
    this.fontSize,
    this.isGradient = false,
  });

  @override
  Widget build(BuildContext context) {
    final defaultBgColor = isPrimary
        ? Colors.white.withValues(alpha: 0.8)
        : const Color(0xFFCF4374);
    final defaultTextColor =
        isPrimary ? const Color(0xFFCF4374) : Colors.white;
    final button = Container(
      width: double.infinity,
      height: height ?? 56,
      decoration: isGradient
          ? BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFFCF4374),
                  Color(0xFF69223B),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: borderColor ?? const Color(0xFFCF4374),
                width: 0.92,
              ),
            )
          : BoxDecoration(
              color: backgroundColor ?? defaultBgColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: borderColor ?? const Color(0xFFCF4374),
                width: 0.92,
              ),
            ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(12),
          child: Center(
            child: Text(
              text,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontSize: fontSize ?? 18,
                fontWeight: FontWeight.w600,
                color: textColor ?? defaultTextColor,
              ),
            ),
          ),
        ),
      ),
    );

    return button;
  }
}