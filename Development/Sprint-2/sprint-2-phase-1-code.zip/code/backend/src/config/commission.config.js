/**
 * Commission Configuration
 * Defines how the platform earns revenue from rides
 */

export default {
  // Commission rate (percentage)
  commissionRate: 0.20, // 20% commission

  // Minimum commission amount (in rupees)
  minimumCommission: 30, // At least Rs 30 per ride

  // Maximum commission amount (optional cap)
  maximumCommission: null, // No maximum

  // Calculate commission for a ride
  calculateCommission(rideAmount) {
    if (!rideAmount || rideAmount <= 0) {
      return {
        rideAmount: 0,
        commission: 0,
        driverEarnings: 0
      };
    }

    // Calculate percentage-based commission
    let commission = Math.round(rideAmount * this.commissionRate);

    // Apply minimum commission
    if (commission < this.minimumCommission) {
      commission = this.minimumCommission;
    }

    // Apply maximum commission (if set)
    if (this.maximumCommission && commission > this.maximumCommission) {
      commission = this.maximumCommission;
    }

    // Calculate driver earnings
    const driverEarnings = rideAmount - commission;

    return {
      rideAmount,
      commission,
      driverEarnings,
      commissionRate: this.commissionRate,
      appliedRule: commission === this.minimumCommission ? 'minimum' : 'percentage'
    };
  }
};
