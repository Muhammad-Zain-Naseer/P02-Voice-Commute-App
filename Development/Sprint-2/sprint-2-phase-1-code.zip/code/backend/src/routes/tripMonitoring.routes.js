/**
 * Trip Monitoring Routes for Trusted Contacts
 */

import express from "express";
import tripMonitoringController from "../controllers/tripMonitoring.controller.js";

const router = express.Router();

// get trusted contacts for a user
router.get(
  "/trusted-contacts/:userIdOrEmail",
  tripMonitoringController.getTrustedContacts
);

// get active trips for a trusted contact
router.get(
  "/active-trips/:contactEmail",
  tripMonitoringController.getActiveTripsForContact
);

// get specific trip details
router.get(
  "/trip/:rideId",
  tripMonitoringController.getTripDetails
);

export default router;