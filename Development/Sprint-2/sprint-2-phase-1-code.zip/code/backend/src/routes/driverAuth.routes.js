import express from "express";
import driverAuthController from "../controllers/driverAuthController.js";
import { authenticateDriver } from "../middleware/driverAuth.middleware.js";
import vehicleUpload from "../middleware/vehicleUpload.middleware.js";

import multer from "multer";
import path from "path";

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/vehicle-registrations/");
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, "reg-" + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(
      path.extname(file.originalname).toLowerCase()
    );
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error("Only images (JPEG, PNG) and PDF files are allowed"));
    }
  }
});

router.post("/request-otp", (req, res) =>
  driverAuthController.requestOTP(req, res)
);

router.post("/verify-otp", (req, res) =>
  driverAuthController.verifyOTP(req, res)
);

router.post("/submit-name", authenticateDriver, (req, res) =>
  driverAuthController.submitName(req, res)
);

router.post("/submit-cnic", authenticateDriver, (req, res) =>
  driverAuthController.submitCNIC(req, res)
);

router.post("/submit-license", authenticateDriver, (req, res) =>
  driverAuthController.submitDrivingLicense(req, res)
);

router.post(
  "/submit-vehicle",
  authenticateDriver,
  vehicleUpload.single("registrationPhoto"),
  (req, res) => driverAuthController.submitVehicleRegistration(req, res)
);


router.post("/submit-pin", authenticateDriver, (req, res) =>
  driverAuthController.submitPIN(req, res)
);

router.get("/registration-status", authenticateDriver, (req, res) =>
  driverAuthController.getRegistrationStatus(req, res)
);

router.post("/login", (req, res) => driverAuthController.login(req, res));

router.get("/me", authenticateDriver, (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      driver: req.driver
    }
  });
});

export default router;
