import express from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { getTodayStats } from "../controllers/driver.controller.js";

const router = express.Router();

// Protected Route
router.get(
  "/stats/today",
  authenticate,
  authorize("driver"),
  getTodayStats
);

export default router;