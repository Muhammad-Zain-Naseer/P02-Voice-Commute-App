import Driver from "../models/Driver.js";
import User from "../models/User.js";
import OTP from "../models/OTP.js";
import emailService from "../services/emailService.js";
import jwt from "jsonwebtoken";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";
import { v4 as uuidv4 } from "uuid";

class DriverAuthController {
  stripJwtMeta(data) {
    if (!data) return data;
    const { exp, iat, nbf, jti, ...clean } = data;
    return clean;
  }

  generateRegistrationToken(data) {
    return jwt.sign({ ...data, role: "driver_registration" }, config.jwtSecret, {
      expiresIn: "1h"
    });
  }

  generateToken(driverId) {
    return jwt.sign({ driverId, role: "driver" }, config.jwtSecret, {
      expiresIn: config.jwtExpire
    });
  }

  // 6-digit OTP
  generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  // Step 1: Request OTP (Email)
  async requestOTP(req, res) {
    try {
      let { email } = req.body;

      if (!email)
        return res
          .status(400)
          .json({ success: false, message: "Email is required" });

      email = email.toLowerCase().trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email))
        return res
          .status(400)
          .json({ success: false, message: "Invalid email format" });

      const existingDriver = await Driver.findOne({ email, isVerified: true });
      if (existingDriver) {
        return res.status(400).json({
          success: false,
          message: "Driver account already exists. Please login."
        });
      }

      const otp = this.generateOTP();

      await OTP.deleteMany({ email, type: "driver_registration" });

      await OTP.create({
        email,
        otp,
        type: "driver_registration"
      });

      await emailService.sendOTP(email, otp);

      res.status(200).json({
        success: true,
        message: "OTP sent successfully",
        data: { email }
      });
    } catch (error) {
      logger.error("Error in requestOTP:", error);
      res.status(500).json({ success: false, message: "Failed to send OTP" });
    }
  }

  // Step 2: Verify OTP
  async verifyOTP(req, res) {
    try {
      let { email, otp } = req.body;
      if (!email || !otp)
        return res
          .status(400)
          .json({ success: false, message: "Email and OTP are required" });

      email = email.toLowerCase().trim();

      const otpRecord = await OTP.findOne({
        email,
        otp,
        type: "driver_registration"
      });

      if (!otpRecord)
        return res
          .status(400)
          .json({ success: false, message: "Invalid or expired OTP" });

      await OTP.deleteOne({ _id: otpRecord._id });

      const tempToken = this.generateRegistrationToken({ email });

      res.status(200).json({
        success: true,
        message: "OTP verified successfully",
        data: {
          email,
          token: tempToken
        }
      });
    } catch (error) {
      logger.error("Error in verifyOTP:", error);
      res
        .status(500)
        .json({ success: false, message: "OTP verification failed" });
    }
  }

  // Step 3: Submit Name
  async submitName(req, res) {
    try {
      const { name } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!name || name.trim().length < 2)
        return res
          .status(400)
          .json({ success: false, message: "Valid name is required" });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        name: name.trim()
      });

      logger.info(`Name submitted for email: ${registrationData.email}`);

      res.status(200).json({
        success: true,
        message: "Name saved successfully",
        data: {
          name: name.trim(),
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitName:", error);
      res.status(500).json({ success: false, message: "Failed to save name" });
    }
  }

  // Step 4: Submit CNIC
  async submitCNIC(req, res) {
    try {
      const { cnic } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!cnic)
        return res
          .status(400)
          .json({ success: false, message: "CNIC is required" });

      const cleanCNIC = cnic.replace(/[-\s]/g, "");
      if (!/^\d{13}$/.test(cleanCNIC))
        return res
          .status(400)
          .json({ success: false, message: "CNIC must be 13 digits" });

      const existingDriver = await Driver.findOne({ cnic: cleanCNIC });
      if (existingDriver)
        return res
          .status(400)
          .json({ success: false, message: "This CNIC is already registered" });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        cnic: cleanCNIC
      });

      logger.info(`CNIC submitted for email: ${registrationData.email}`);

      res.status(200).json({
        success: true,
        message: "CNIC saved successfully",
        data: {
          cnic: cleanCNIC,
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitCNIC:", error);
      res.status(500).json({ success: false, message: "Failed to save CNIC" });
    }
  }

  // Step 5: Submit Driving License
  async submitDrivingLicense(req, res) {
    try {
      const { drivingLicense } = req.body;
      const registrationData = this.stripJwtMeta(req.driver);

      if (!drivingLicense)
        return res.status(400).json({
          success: false,
          message: "Driving license number is required"
        });

      const cleanLicense = drivingLicense.trim().toUpperCase();

      const licensePattern = /^[A-Z]{3}-?\d{7}$/;
      if (!licensePattern.test(cleanLicense.replace(/-/g, ""))) {
        return res.status(400).json({
          success: false,
          message: "Invalid license format. Expected format: LHR-1234567"
        });
      }

      const existingDriver = await Driver.findOne({ drivingLicense: cleanLicense });
      if (existingDriver)
        return res.status(400).json({
          success: false,
          message: "This driving license is already registered"
        });

      const updatedToken = this.generateRegistrationToken({
        ...registrationData,
        drivingLicense: cleanLicense
      });

      logger.info(`Driving license submitted for email: ${registrationData.email}`);

      res.status(200).json({
        success: true,
        message: "Driving license saved successfully",
        data: {
          drivingLicense: cleanLicense,
          token: updatedToken
        }
      });
    } catch (error) {
      logger.error("Error in submitDrivingLicense:", error);
      res
        .status(500)
        .json({ success: false, message: "Failed to save driving license" });
    }
  }

  // Step 6: Submit Vehicle Registration
async submitVehicleRegistration(req, res) {
  try {
    const registrationData = this.stripJwtMeta(req.driver);
    const { registrationNumber, color, model, year } = req.body;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Vehicle registration photo is required",
      });
    }

    if (!registrationNumber) {
      return res.status(400).json({
        success: false,
        message: "Vehicle registration number is required",
      });
    }
    if (!color) {
      return res.status(400).json({ success: false, message: "Vehicle color is required" });
    }
    if (!model) {
      return res.status(400).json({ success: false, message: "Vehicle model is required" });
    }
    if (!year) {
      return res.status(400).json({ success: false, message: "Vehicle year is required" });
    }

    if (!registrationData.name) {
      return res.status(400).json({ success: false, message: "Please complete the name step first" });
    }
    if (!registrationData.cnic) {
      return res.status(400).json({ success: false, message: "Please complete the CNIC step first" });
    }
    if (!registrationData.drivingLicense) {
      return res.status(400).json({ success: false, message: "Please complete the driving license step first" });
    }

    const cleanRegNumber = registrationNumber.toUpperCase().replace(/[\s-]/g, "");

    const existingVehicle = await Driver.findOne({
      "vehicle.registrationNumber": cleanRegNumber,
    });
    if (existingVehicle) {
      return res.status(400).json({
        success: false,
        message: "This vehicle is already registered",
      });
    }

    // ✅ IMPORTANT: store a URL path (NOT an absolute file system path)
    const registrationPhotoUrlPath = `/uploads/vehicle-registrations/${req.file.filename}`;

    const updatedToken = this.generateRegistrationToken({
      ...registrationData,
      vehicle: {
        registrationNumber: cleanRegNumber,
        color: color.trim(),
        model: model.trim(),
        year: year.trim(),
        registrationPhoto: registrationPhotoUrlPath,
      },
    });

    logger.info(`Vehicle registration submitted for email: ${registrationData.email}`);

    res.status(200).json({
      success: true,
      message: "Vehicle registration saved successfully. Please set up your PIN.",
      data: {
        vehicle: {
          registrationNumber: cleanRegNumber,
          color: color.trim(),
          model: model.trim(),
          year: year.trim(),
          registrationPhoto: registrationPhotoUrlPath, // optional but useful
        },
        token: updatedToken,
      },
    });
  } catch (error) {
    logger.error("Error in submitVehicleRegistration:", error);
    res.status(500).json({
      success: false,
      message: "Failed to save vehicle registration",
    });
  }
}


  // Step 7: Submit PIN and Complete Registration
  async submitPIN(req, res) {
    try {
      const registrationData = this.stripJwtMeta(req.driver);
      const { pin } = req.body;

      if (!pin)
        return res
          .status(400)
          .json({ success: false, message: "PIN is required" });

      const cleanPin = pin.toString().trim();
      if (!/^\d{4}$/.test(cleanPin))
        return res
          .status(400)
          .json({ success: false, message: "PIN must be exactly 4 digits" });

      if (!registrationData.email)
        return res.status(400).json({
          success: false,
          message: "Invalid registration session"
        });
      if (!registrationData.name)
        return res.status(400).json({
          success: false,
          message: "Please complete the name step first"
        });
      if (!registrationData.cnic)
        return res.status(400).json({
          success: false,
          message: "Please complete the CNIC step first"
        });
      if (!registrationData.drivingLicense)
        return res.status(400).json({
          success: false,
          message: "Please complete the driving license step first"
        });
      if (!registrationData.vehicle || !registrationData.vehicle.registrationPhoto)
        return res.status(400).json({
          success: false,
          message: "Please complete the vehicle registration step first"
        });

      const existingDriver = await Driver.findOne({ email: registrationData.email });
      if (existingDriver) {
        return res.status(400).json({
          success: false,
          message: "Driver account already exists"
        });
      }

      const userId = uuidv4();

      const user = new User({
        userId,
        name: registrationData.name,
        email: registrationData.email,
        pin: cleanPin,
        role: "driver",
        isVerified: true
      });
      await user.save();
      logger.info(`Created User for driver: ${registrationData.email}`);

      const driver = new Driver({
        userId,
        email: registrationData.email,
        name: registrationData.name,
        cnic: registrationData.cnic,
        drivingLicense: registrationData.drivingLicense,
        vehicle: registrationData.vehicle,
        isVerified: true,
        status: "pending"
      });
      await driver.save();

      logger.info(`Driver registration completed: ${registrationData.email}`);

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Registration completed successfully",
        data: {
          driver: {
            id: driver._id,
            userId: driver.userId,
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle,
            status: driver.status
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in submitPIN:", error);
      res
        .status(500)
        .json({ success: false, message: "Failed to complete registration" });
    }
  }

  // Login
  async login(req, res) {
    try {
      let { email } = req.body;
      if (!email)
        return res
          .status(400)
          .json({ success: false, message: "Email is required" });
      email = email.toLowerCase().trim();

      const driver = await Driver.findOne({ email });
      if (!driver)
        return res
          .status(401)
          .json({ success: false, message: "Invalid credentials" });

      // Check User account status
      const user = await User.findOne({ userId: driver.userId });
      if (!user)
        return res
          .status(401)
          .json({ success: false, message: "User account not found" });

      // Check if user account is suspended
      if (user.isSuspended) {
        return res.status(403).json({
          success: false,
          message: "Your account has been suspended by an administrator. Please contact support for more information.",
          accountStatus: "suspended",
          reason: user.suspensionReason
        });
      }

      // Check if user account is deactivated
      if (user.isActive === false) {
        return res.status(403).json({
          success: false,
          message: "Your account has been deactivated by an administrator. Please contact support to reactivate your account.",
          accountStatus: "deactivated",
          reason: user.deactivationReason
        });
      }

      if (!driver.isVerified)
        return res.status(403).json({
          success: false,
          message: "Please complete your registration"
        });
      if (driver.status === "rejected")
        return res
          .status(403)
          .json({ success: false, message: "Your account has been rejected." });
      if (driver.status === "suspended")
        return res.status(403).json({
          success: false,
          message: "Your driver account has been suspended by an administrator."
        });

      driver.lastLogin = new Date();
      await driver.save();

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Login successful",
        data: {
          driver: {
            id: driver._id,
            userId: driver.userId,
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle,
            status: driver.status,
            averageRating: driver.averageRating
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in driver login:", error);
      res.status(500).json({ success: false, message: "Login failed" });
    }
  }

  // Registration Status
  async getRegistrationStatus(req, res) {
    try {
      const registrationData = this.stripJwtMeta(req.driver);

      res.status(200).json({
        success: true,
        data: {
          registration: {
            email: registrationData.email || null,
            name: registrationData.name || null,
            cnic: registrationData.cnic || null,
            drivingLicense: registrationData.drivingLicense || null,
            vehicle: registrationData.vehicle || null,
            completed: false
          }
        }
      });
    } catch (error) {
      logger.error("Error in getRegistrationStatus:", error);
      res
        .status(500)
        .json({ success: false, message: "Failed to get registration status" });
    }
  }
}

export default new DriverAuthController();
