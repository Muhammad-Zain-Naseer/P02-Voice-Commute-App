import Ride from "../models/Ride.js";
import logger from "../utils/logger.js";

/**
 * Get driver's statistics for today 
 * GET /api/driver/stats/today
 */
export const getTodayStats = async (req, res) => {
  try {
    const driverId = req.user.id; // From auth middleware

    // Calculate the start of the current day 
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    // Run Aggregation Pipeline
    const stats = await Ride.aggregate([
      {
        $match: {
          driverId: driverId,           
          status: "completed",          
          createdAt: { $gte: startOfDay } 
        }
      },
      {
        $group: {
          _id: null,
          totalEarnings: { $sum: "$fare" }, 
          totalTrips: { $sum: 1 }           
        }
      }
    ]);

    // If no rides found, return 0
    const result = stats[0] || { totalEarnings: 0, totalTrips: 0 };

    res.status(200).json({
      success: true,
      data: {
        earnings: result.totalEarnings,
        trips: result.totalTrips
      }
    });

  } catch (error) {
    logger.error("Error fetching driver stats:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch driver statistics"
    });
  }
};