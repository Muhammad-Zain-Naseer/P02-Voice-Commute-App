// /**
//  * Ride Model (Database)
//  * Stores historical ride data for analytics, history, and records
//  */

// import mongoose from "mongoose";

// const rideSchema = new mongoose.Schema(
//   {
//     rideId: {
//       type: String,
//       required: true,
//       unique: true,
//       index: true
//     },
//     userId: {
//       type: String,
//       required: true,
//       index: true
//     },
//     userType: {
//       type: String,
//       enum: ["commuter", "driver"],
//       default: "commuter"
//     },
//     userName: {
//       type: String,
//       required: true
//     },
//     userEmail: {
//       type: String,
//       trim: true,
//       lowercase: true
//     },
//     source: {
//       address: {
//         type: String,
//         required: true
//       },
//       coordinates: {
//         type: {
//           type: String,
//           enum: ["Point"],
//           default: "Point"
//         },
//         coordinates: {
//           type: [Number], // [longitude, latitude]
//           default: undefined
//         }
//       }
//     },
//     destination: {
//       address: {
//         type: String,
//         required: true
//       },
//       coordinates: {
//         type: {
//           type: String,
//           enum: ["Point"],
//           default: "Point"
//         },
//         coordinates: {
//           type: [Number], // [longitude, latitude]
//           default: undefined
//         }
//       }
//     },
//     status: {
//       type: String,
//       enum: ["pending", "matched", "cancelled", "completed"],
//       required: true,
//       index: true
//     },
//     matchedWith: {
//       driverId: String,
//       driverName: String,
//       socketId: String,
//       matchedAt: Date
//     },
//     sosAlert: {
//       triggeredAt: Date,
//       triggeredBy: String,
//       location: mongoose.Schema.Types.Mixed,
//       message: String
//     },
//     completedAt: {
//       type: Date
//     },
//     rating: {
//       type: Number,
//       min: 1,
//       max: 5,
//       default: null
//     },
//     createdAt: {
//       type: Date,
//       required: true
//     },
//     updatedAt: {
//       type: Date,
//       required: true
//     }
//   },
//   {
//     timestamps: false // We'll manage timestamps manually to match in-memory data
//   }
// );

// // Index for geospatial queries (optional, for future location-based queries)
// rideSchema.index({ "source.coordinates": "2dsphere" });
// rideSchema.index({ "destination.coordinates": "2dsphere" });

// // Index for date-based queries
// rideSchema.index({ createdAt: -1 });
// rideSchema.index({ completedAt: -1 });

// // Compound index for user ride history
// rideSchema.index({ userId: 1, createdAt: -1 });

// export default mongoose.model("Ride", rideSchema);


/**
 * Updated Ride Model (Database)
 * Stores historical ride data for analytics, history, and records
 */

import mongoose from "mongoose";

const rideSchema = new mongoose.Schema(
  {
    rideId: {
      type: String,
      required: true,
      unique: true,
      index: true
    },
    userId: {
      type: String,
      required: true,
      index: true
    },
    userType: {
      type: String,
      enum: ["commuter", "driver"],
      default: "commuter"
    },
    userName: {
      type: String,
      required: true
    },
    userEmail: {
      type: String,
      trim: true,
      lowercase: true
    },
    source: {
      address: {
        type: String,
        required: true
      },
      coordinates: {
        type: {
          type: String,
          enum: ["Point"],
          default: "Point"
        },
        coordinates: {
          type: [Number], // [longitude, latitude]
          default: undefined
        }
      }
    },
    destination: {
      address: {
        type: String,
        required: true
      },
      coordinates: {
        type: {
          type: String,
          enum: ["Point"],
          default: "Point"
        },
        coordinates: {
          type: [Number], // [longitude, latitude]
          default: undefined
        }
      }
    },
    status: {
      type: String,
      enum: ["pending", "matched", "cancelled", "completed"],
      required: true,
      index: true
    },
    matchedWith: {
      driverId: String,
      driverName: String,
      socketId: String,
      matchedAt: Date
    },
    
    // NEW FIELDS FOR RIDE HISTORY
    fare: {
      type: Number,
      default: 0,
      min: 0
    },
    distance: {
      type: Number, // in kilometers
      default: 0,
      min: 0
    },
    duration: {
      type: Number, // in minutes
      default: 0,
      min: 0
    },
    vehicle: {
      make: {
        type: String,
        default: 'N/A'
      },
      model: {
        type: String,
        default: ''
      },
      number: {
        type: String,
        default: 'N/A'
      },
      color: {
        type: String,
        default: ''
      }
    },
    
    sosAlert: {
      triggeredAt: Date,
      triggeredBy: String,
      location: mongoose.Schema.Types.Mixed,
      message: String
    },
    completedAt: {
      type: Date
    },
    rating: {
      type: Number,
      min: 1,
      max: 5,
      default: null
    },
    feedback: {
      type: String,
      default: ''
    },
    createdAt: {
      type: Date,
      required: true
    },
    updatedAt: {
      type: Date,
      required: true
    }
  },
  {
    timestamps: false // We'll manage timestamps manually to match in-memory data
  }
);

// Index for geospatial queries (optional, for future location-based queries)
rideSchema.index({ "source.coordinates": "2dsphere" });
rideSchema.index({ "destination.coordinates": "2dsphere" });

// Index for date-based queries
rideSchema.index({ createdAt: -1 });
rideSchema.index({ completedAt: -1 });

// Compound index for user ride history
rideSchema.index({ userId: 1, createdAt: -1 });

// Index for driver ride history
rideSchema.index({ "matchedWith.driverId": 1, createdAt: -1 });

export default mongoose.model("Ride", rideSchema);