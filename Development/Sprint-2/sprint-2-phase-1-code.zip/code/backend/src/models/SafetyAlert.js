import mongoose from "mongoose";

const safetyAlertSchema = new mongoose.Schema({
    message: {
        type: String,
        required: true,
        trim: true
    },
    severity: {
        type: String,
        enum: ['low', 'medium', 'high', 'critical'],
        default: 'medium',
        required: true
    },
    senderId: {
        type: String,
        required: true,
        index: true
    },
    senderName: {
        type: String,
        required: true
    },
    sentAt: {
        type: Date,
        default: Date.now,
        required: true
    },
    targetAudience: {
        type: String,
        enum: ['all', 'drivers', 'commuters'],
        default: 'all'
    }
});

safetyAlertSchema.index({ sentAt: -1 });

export default mongoose.model("SafetyAlert", safetyAlertSchema);