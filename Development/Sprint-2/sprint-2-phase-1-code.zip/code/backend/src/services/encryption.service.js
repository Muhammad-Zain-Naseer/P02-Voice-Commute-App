import crypto from "crypto";
import logger from "../utils/logger.js";

/**
 * Encryption Service for secure message transmission
 * Uses AES-256-GCM for symmetric encryption
 */
class EncryptionService {
  constructor() {
    // Generate a server-side encryption key from environment or create one
    // In production, this should be stored securely (e.g., environment variable)
    this.serverKey = process.env.ENCRYPTION_KEY || this.generateKey();
    this.algorithm = "aes-256-gcm";
    this.ivLength = 16;
    this.authTagLength = 16;
  }

  /**
   * Generate a random 256-bit key
   */
  generateKey() {
    return crypto.randomBytes(32).toString("hex");
  }

  /**
   * Generate a unique session key for a ride
   * This key is shared between driver and commuter for E2E encryption
   */
  generateSessionKey() {
    return crypto.randomBytes(32).toString("hex");
  }

  /**
   * Encrypt a message using AES-256-GCM
   * @param {string} plaintext - The message to encrypt
   * @param {string} key - The encryption key (hex string)
   * @returns {object} - { encrypted, iv, authTag }
   */
  encrypt(plaintext, key = this.serverKey) {
    try {
      const iv = crypto.randomBytes(this.ivLength);
      const keyBuffer = Buffer.from(key, "hex");

      const cipher = crypto.createCipheriv(this.algorithm, keyBuffer, iv, {
        authTagLength: this.authTagLength
      });

      let encrypted = cipher.update(plaintext, "utf8", "base64");
      encrypted += cipher.final("base64");
      const authTag = cipher.getAuthTag();

      return {
        encrypted,
        iv: iv.toString("base64"),
        authTag: authTag.toString("base64")
      };
    } catch (error) {
      logger.error(`Encryption error: ${error.message}`);
      throw new Error("Failed to encrypt message");
    }
  }

  /**
   * Decrypt a message using AES-256-GCM
   * @param {string} encrypted - The encrypted message (base64)
   * @param {string} iv - The initialization vector (base64)
   * @param {string} authTag - The authentication tag (base64)
   * @param {string} key - The decryption key (hex string)
   * @returns {string} - The decrypted plaintext
   */
  decrypt(encrypted, iv, authTag, key = this.serverKey) {
    try {
      const keyBuffer = Buffer.from(key, "hex");
      const ivBuffer = Buffer.from(iv, "base64");
      const authTagBuffer = Buffer.from(authTag, "base64");

      const decipher = crypto.createDecipheriv(this.algorithm, keyBuffer, ivBuffer, {
        authTagLength: this.authTagLength
      });
      decipher.setAuthTag(authTagBuffer);

      let decrypted = decipher.update(encrypted, "base64", "utf8");
      decrypted += decipher.final("utf8");

      return decrypted;
    } catch (error) {
      logger.error(`Decryption error: ${error.message}`);
      throw new Error("Failed to decrypt message");
    }
  }

  /**
   * Encrypt binary data (for voice messages)
   * @param {Buffer|string} data - The data to encrypt (Buffer or base64 string)
   * @param {string} key - The encryption key (hex string)
   * @returns {object} - { encrypted, iv, authTag }
   */
  encryptBinary(data, key = this.serverKey) {
    try {
      const iv = crypto.randomBytes(this.ivLength);
      const keyBuffer = Buffer.from(key, "hex");

      // Convert to Buffer if it's a base64 string
      const dataBuffer = Buffer.isBuffer(data) ? data : Buffer.from(data, "base64");

      const cipher = crypto.createCipheriv(this.algorithm, keyBuffer, iv, {
        authTagLength: this.authTagLength
      });

      const encrypted = Buffer.concat([
        cipher.update(dataBuffer),
        cipher.final()
      ]);
      const authTag = cipher.getAuthTag();

      return {
        encrypted: encrypted.toString("base64"),
        iv: iv.toString("base64"),
        authTag: authTag.toString("base64")
      };
    } catch (error) {
      logger.error(`Binary encryption error: ${error.message}`);
      throw new Error("Failed to encrypt binary data");
    }
  }

  /**
   * Decrypt binary data (for voice messages)
   * @param {string} encrypted - The encrypted data (base64)
   * @param {string} iv - The initialization vector (base64)
   * @param {string} authTag - The authentication tag (base64)
   * @param {string} key - The decryption key (hex string)
   * @returns {string} - The decrypted data as base64
   */
  decryptBinary(encrypted, iv, authTag, key = this.serverKey) {
    try {
      const keyBuffer = Buffer.from(key, "hex");
      const ivBuffer = Buffer.from(iv, "base64");
      const authTagBuffer = Buffer.from(authTag, "base64");
      const encryptedBuffer = Buffer.from(encrypted, "base64");

      const decipher = crypto.createDecipheriv(this.algorithm, keyBuffer, ivBuffer, {
        authTagLength: this.authTagLength
      });
      decipher.setAuthTag(authTagBuffer);

      const decrypted = Buffer.concat([
        decipher.update(encryptedBuffer),
        decipher.final()
      ]);

      return decrypted.toString("base64");
    } catch (error) {
      logger.error(`Binary decryption error: ${error.message}`);
      throw new Error("Failed to decrypt binary data");
    }
  }

  /**
   * Hash sensitive data (e.g., for logging without exposing content)
   * @param {string} data - Data to hash
   * @returns {string} - SHA-256 hash
   */
  hash(data) {
    return crypto.createHash("sha256").update(data).digest("hex").substring(0, 16);
  }
}

export default new EncryptionService();
