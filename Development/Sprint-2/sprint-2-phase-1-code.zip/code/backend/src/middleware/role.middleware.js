import logger from "../utils/logger.js";

/**
 * Middleware to ensure the user has a specific role
 * @param {string[]} allowedRoles 
 */
export const authorize = (...allowedRoles) => {
    return (req, res, next) => {
        if (!req.user) {
            logger.warn("[AUTH] User not authenticated for protected route");
            return res.status(401).json({ success: false, error: "Not authorized" });
        }

        if (!allowedRoles.includes(req.user.role)) {
            logger.warn(`[AUTH] Access denied. User role ${req.user.role} attempted to access ${req.originalUrl}`);
            return res.status(403).json({
                success: false,
                error: `Access denied. Requires one of: ${allowedRoles.join(", ")}`
            });
        }

        next();
    };
};