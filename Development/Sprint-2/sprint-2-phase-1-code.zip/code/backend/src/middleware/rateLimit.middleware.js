import rateLimit from 'express-rate-limit';

export const alertRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 min
    max: 5000, // limit each ip to 5 alert requests per window
    message: {
        success: false,
        error: "Too many alerts sent from this IP, please try again after 15 minutes"
    },
    standardHeaders: true,
    legacyHeaders: false,
});