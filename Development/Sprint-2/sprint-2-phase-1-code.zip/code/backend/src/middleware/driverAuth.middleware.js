import jwt from "jsonwebtoken";
import Driver from "../models/Driver.js";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

export const authenticateDriver = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Authentication required"
      });
    }

    const decoded = jwt.verify(token, config.jwtSecret);
    console.log("DECODED TOKEN:", decoded);

    if (decoded.role === "driver_registration") {
      req.driver = decoded;
      logger.info(`Registration token validated for: ${decoded.email}`);
      return next();
    }

    if (decoded.role === "driver" && decoded.driverId) {
      const driver = await Driver.findById(decoded.driverId).select(
        "-verificationOTP -verificationOTPExpiry"
      );

      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver not found"
        });
      }

      req.driver = driver;
      logger.info(`Driver authenticated: ${driver.email}`);
      return next();
    }

    // Invalid token role
    return res.status(403).json({
      success: false,
      message: "Access denied. Invalid token type."
    });

  } catch (error) {
    logger.error("Driver authentication error:", error);

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        success: false,
        message: "Invalid token"
      });
    }

    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expired. Please start registration again."
      });
    }

    return res.status(500).json({
      success: false,
      message: "Authentication failed"
    });
  }
};
