import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/storage_service.dart';
import '../../services/driver_service.dart'; 
import 'driver_page.dart'; 
import 'earnings_page.dart';
import 'driver_profile_page.dart';

class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});

  @override
  State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> {
  int _selectedIndex = 0;
  String _driverName = "Driver";
  
  // Stats State Variables
  String _earnings = "0";
  String _trips = "0";
  bool _isLoadingStats = true;

  @override
  void initState() {
    super.initState();
    _loadDriverName();
    _fetchStats(); 
  }

  Future<void> _loadDriverName() async {
    final name = await StorageService.getUserName();
    if (mounted && name != null) {
      setState(() {
        _driverName = name;
      });
    }
  }

  Future<void> _fetchStats() async {
    try {
      final stats = await DriverService.getTodayStats();
      if (mounted) {
        setState(() {
          _earnings = stats['earnings'].toString();
          _trips = stats['trips'].toString();
          _isLoadingStats = false;
        });
      }
    } catch (e) {
      debugPrint("Error loading stats: $e");
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    
    if (index == 0) {
      _fetchStats();
    }
  }

  void _goToRidesTab() {
    setState(() {
      _selectedIndex = 1; 
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      _DriverHomeTab(
        driverName: _driverName, 
        onFindRidesPressed: _goToRidesTab,
        earnings: _earnings, 
        trips: _trips,       
        isLoading: _isLoadingStats,
      ),
      const AvailableRidesPage(),
      const EarningsPage(),
      const DriverProfilePage(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC), 
      body: IndexedStack(
        index: _selectedIndex,
        children: screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCF4374).withOpacity(0.15),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: const Color(0xFFCF4374),
          unselectedItemColor: Colors.grey[400],
          type: BottomNavigationBarType.fixed,
          showUnselectedLabels: true,
          selectedLabelStyle: GoogleFonts.notoNastaliqUrdu(fontSize: 12, fontWeight: FontWeight.bold),
          unselectedLabelStyle: GoogleFonts.notoNastaliqUrdu(fontSize: 12),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: 'Dashboard'),
            BottomNavigationBarItem(icon: Icon(Icons.directions_car_filled_rounded), label: 'Rides'),
            BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet_rounded), label: 'Earnings'),
            BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}

class _DriverHomeTab extends StatelessWidget {
  final String driverName;
  final VoidCallback onFindRidesPressed;
  final String earnings;
  final String trips;
  final bool isLoading;

  const _DriverHomeTab({
    required this.driverName,
    required this.onFindRidesPressed,
    required this.earnings,
    required this.trips,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // HEADER SECTION 
            Container(
              width: double.infinity,
              height: 280,
              decoration: const BoxDecoration(
                color: Color(0xFFCF4374), 
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(40),
                  bottomRight: Radius.circular(40),
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Profile Avatar
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
                        ),
                        child: const CircleAvatar(
                          radius: 35,
                          backgroundColor: Colors.white,
                          child: Icon(Icons.person, size: 40, color: Color(0xFFCF4374)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Welcome Back,',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 16,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        driverName,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.notoNastaliqUrdu(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // STATUS CARD
            Transform.translate(
              offset: const Offset(0, -30),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Container(
                  padding: const EdgeInsets.all(25),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFCF4374).withOpacity(0.2),
                        blurRadius: 25,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Current Status',
                                style: TextStyle(
                                  color: Colors.grey[500],
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'OFFLINE',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.power_settings_new, color: Colors.grey),
                          ),
                        ],
                      ),
                      const SizedBox(height: 25),
                      const Divider(height: 1),
                      const SizedBox(height: 25),
                      SizedBox(
                        width: double.infinity,
                        height: 55,
                        child: ElevatedButton(
                          onPressed: onFindRidesPressed,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFCF4374),
                            foregroundColor: Colors.white,
                            elevation: 5,
                            shadowColor: const Color(0xFFCF4374).withOpacity(0.5),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          child: const Text(
                            'GO ONLINE',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            //  STATS GRID
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Today's Overview",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF4A4A4A),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Row(
                    children: [
                      _buildStatCard(
                        icon: Icons.account_balance_wallet_rounded,
                        label: 'Earnings',
                        value: isLoading ? '...' : 'Rs $earnings', 
                        color: Colors.green,
                        iconBg: Colors.green.withOpacity(0.1),
                      ),
                      const SizedBox(width: 15),
                      _buildStatCard(
                        icon: Icons.directions_car_filled_rounded,
                        label: 'Total Trips',
                        value: isLoading ? '...' : trips, 
                        color: Colors.orange,
                        iconBg: Colors.orange.withOpacity(0.1),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    required Color iconBg,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.08),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 20),
            Text(
              value,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}