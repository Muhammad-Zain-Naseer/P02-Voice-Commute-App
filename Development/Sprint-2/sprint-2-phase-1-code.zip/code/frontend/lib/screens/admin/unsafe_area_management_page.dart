import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../services/admin_service.dart';
import '../../services/map_service.dart';

class UnsafeAreaManagementPage extends StatefulWidget {
  final String token;

  const UnsafeAreaManagementPage({super.key, required this.token});

  @override
  State<UnsafeAreaManagementPage> createState() => _UnsafeAreaManagementPageState();
}

class _UnsafeAreaManagementPageState extends State<UnsafeAreaManagementPage> {
  final AdminService _adminService = AdminService();
  List<Map<String, dynamic>> _unsafeAreas = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _adminService.setToken(widget.token);
    _loadUnsafeAreas();
  }

  Future<void> _loadUnsafeAreas() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final areas = await _adminService.getUnsafeAreas();
      setState(() {
        _unsafeAreas = areas;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading unsafe areas: $e')),
        );
      }
    }
  }

  void _showAddUnsafeAreaDialog() {
    showDialog(
      context: context,
      builder: (context) => _AddUnsafeAreaDialog(
        onAreaAdded: _loadUnsafeAreas,
        token: widget.token,
      ),
    );
  }

  void _toggleAreaStatus(String id, bool currentStatus) async {
    final success = await _adminService.updateUnsafeArea(
      id: id,
      isActive: !currentStatus,
    );

    if (success) {
      _loadUnsafeAreas();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Area status updated')),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update area status')),
        );
      }
    }
  }

  void _deleteArea(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Unsafe Area'),
        content: const Text('Are you sure you want to delete this unsafe area?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final success = await _adminService.deleteUnsafeArea(id);
      if (success) {
        _loadUnsafeAreas();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Unsafe area deleted')),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to delete area')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE5EC),
      appBar: AppBar(
        title: Text(
          'Manage Unsafe Areas',
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0xFFCF4374),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFCF4374)))
          : _unsafeAreas.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.location_off,
                        size: 80,
                        color: Color(0xFFCF4374),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No unsafe areas defined',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          color: const Color(0xFFCF4374),
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _unsafeAreas.length,
                  itemBuilder: (context, index) {
                    final area = _unsafeAreas[index];
                    final isActive = area['isActive'] ?? true;
                    final severity = area['severity'] ?? 'warning';

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: severity == 'blocked' ? Colors.red : Colors.orange,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    severity.toUpperCase(),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    area['name'] ?? 'Unnamed Area',
                                    style: GoogleFonts.poppins(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: const Color(0xFFCF4374),
                                    ),
                                  ),
                                ),
                                Switch(
                                  value: isActive,
                                  onChanged: (value) => _toggleAreaStatus(area['_id'], isActive),
                                  activeTrackColor: const Color(0xFFCF4374),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              area['description'] ?? '',
                              style: GoogleFonts.poppins(fontSize: 14),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Reason: ${area['reason'] ?? 'Not specified'}',
                              style: GoogleFonts.poppins(
                                fontSize: 12,
                                fontStyle: FontStyle.italic,
                                color: Colors.grey[600],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.location_on, size: 16, color: Colors.grey[600]),
                                const SizedBox(width: 4),
                                Text(
                                  'Radius: ${area['radius']}m',
                                  style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600]),
                                ),
                                const SizedBox(width: 16),
                                Text(
                                  '${area['location']?['latitude']?.toStringAsFixed(4)}, ${area['location']?['longitude']?.toStringAsFixed(4)}',
                                  style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600]),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton.icon(
                                onPressed: () => _deleteArea(area['_id']),
                                icon: const Icon(Icons.delete, size: 18),
                                label: const Text('Delete'),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.red,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddUnsafeAreaDialog,
        backgroundColor: const Color(0xFFCF4374),
        icon: const Icon(Icons.add_location_alt),
        label: const Text('Add Unsafe Area'),
      ),
    );
  }
}

class _AddUnsafeAreaDialog extends StatefulWidget {
  final VoidCallback onAreaAdded;
  final String token;

  const _AddUnsafeAreaDialog({required this.onAreaAdded, required this.token});

  @override
  State<_AddUnsafeAreaDialog> createState() => _AddUnsafeAreaDialogState();
}

class _AddUnsafeAreaDialogState extends State<_AddUnsafeAreaDialog> {
  final _formKey = GlobalKey<FormState>();
  final AdminService _adminService = AdminService();

  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _radiusController = TextEditingController(text: '500');
  final _reasonController = TextEditingController();

  String _selectedSeverity = 'warning';
  bool _isSubmitting = false;
  bool _isGeocoding = false;

  double? _latitude;
  double? _longitude;
  GoogleMapController? _mapController;
  Set<Circle> _circles = {};

  @override
  void initState() {
    super.initState();
    _adminService.setToken(widget.token);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _addressController.dispose();
    _radiusController.dispose();
    _reasonController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _searchLocation() async {
    final address = _addressController.text.trim();
    if (address.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter an address')),
      );
      return;
    }

    setState(() {
      _isGeocoding = true;
    });

    try {
      final coords = await MapService.geocodeAddress(address);
      if (coords != null) {
        setState(() {
          _latitude = coords['latitude'] as double;
          _longitude = coords['longitude'] as double;
          _isGeocoding = false;
          _updateCircle();
        });

        // Animate camera to location
        _mapController?.animateCamera(
          CameraUpdate.newLatLngZoom(
            LatLng(_latitude!, _longitude!),
            14,
          ),
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Location found!')),
          );
        }
      } else {
        setState(() {
          _isGeocoding = false;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Location not found. Try a different address.')),
          );
        }
      }
    } catch (e) {
      setState(() {
        _isGeocoding = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _updateCircle() {
    if (_latitude == null || _longitude == null) return;

    final radius = double.tryParse(_radiusController.text) ?? 500;

    setState(() {
      _circles = {
        Circle(
          circleId: const CircleId('unsafe_area'),
          center: LatLng(_latitude!, _longitude!),
          radius: radius,
          fillColor: (_selectedSeverity == 'blocked' ? Colors.red : Colors.orange).withValues(alpha: 0.3),
          strokeColor: _selectedSeverity == 'blocked' ? Colors.red : Colors.orange,
          strokeWidth: 2,
        ),
      };
    });
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    if (_latitude == null || _longitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please search for the location first')),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      print('📍 Creating unsafe area:');
      print('  Name: ${_nameController.text}');
      print('  Address: ${_addressController.text}');
      print('  Lat/Lng: $_latitude, $_longitude');
      print('  Radius: ${_radiusController.text}m');
      print('  Severity: $_selectedSeverity');

      final result = await _adminService.createUnsafeArea(
        name: _nameController.text,
        description: _reasonController.text,
        latitude: _latitude!,
        longitude: _longitude!,
        address: _addressController.text,
        radius: double.parse(_radiusController.text),
        severity: _selectedSeverity,
        reason: _reasonController.text,
      );

      setState(() {
        _isSubmitting = false;
      });

      print('✅ Result: $result');

      if (result != null && mounted) {
        Navigator.pop(context);
        widget.onAreaAdded();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Unsafe area added successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to add unsafe area. Check backend logs.'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 5),
          ),
        );
      }
    } catch (e, stackTrace) {
      print('❌ Error creating unsafe area: $e');
      print('Stack trace: $stackTrace');

      setState(() {
        _isSubmitting = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.85,
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: Color(0xFFCF4374),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_off, color: Colors.white, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Add Unsafe Area',
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
            ),

            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Area Name
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Area Name',
                          hintText: 'e.g., Gulberg Area',
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) => value == null || value.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 16),

                      // Address Search
                      TextFormField(
                        controller: _addressController,
                        decoration: InputDecoration(
                          labelText: 'Address / Location',
                          hintText: 'e.g., Main Boulevard, Gulberg, Lahore',
                          border: const OutlineInputBorder(),
                          suffixIcon: _isGeocoding
                              ? const Padding(
                                  padding: EdgeInsets.all(12),
                                  child: SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  ),
                                )
                              : IconButton(
                                  icon: const Icon(Icons.search),
                                  onPressed: _searchLocation,
                                  tooltip: 'Search Location',
                                ),
                        ),
                        validator: (value) => value == null || value.isEmpty ? 'Required' : null,
                        onFieldSubmitted: (_) => _searchLocation(),
                      ),
                      const SizedBox(height: 16),

                      // Map Preview
                      if (_latitude != null && _longitude != null) ...[
                        Text(
                          'Location Preview:',
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          height: 250,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey[300]!),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: GoogleMap(
                              initialCameraPosition: CameraPosition(
                                target: LatLng(_latitude!, _longitude!),
                                zoom: 14,
                              ),
                              circles: _circles,
                              markers: {
                                Marker(
                                  markerId: const MarkerId('center'),
                                  position: LatLng(_latitude!, _longitude!),
                                ),
                              },
                              onMapCreated: (controller) {
                                _mapController = controller;
                              },
                              myLocationButtonEnabled: false,
                              zoomControlsEnabled: true,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Lat: ${_latitude!.toStringAsFixed(6)}, Lng: ${_longitude!.toStringAsFixed(6)}',
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // Reason
                      TextFormField(
                        controller: _reasonController,
                        decoration: const InputDecoration(
                          labelText: 'Reason',
                          hintText: 'Why is this area unsafe?',
                          border: OutlineInputBorder(),
                        ),
                        maxLines: 2,
                        validator: (value) => value == null || value.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 16),

                      // Radius
                      TextFormField(
                        controller: _radiusController,
                        decoration: const InputDecoration(
                          labelText: 'Radius (meters)',
                          hintText: '500',
                          border: OutlineInputBorder(),
                          helperText: 'Minimum 100 meters',
                        ),
                        keyboardType: TextInputType.number,
                        validator: (value) {
                          if (value == null || value.isEmpty) return 'Required';
                          final val = double.tryParse(value);
                          if (val == null || val < 100) return 'Min 100m';
                          return null;
                        },
                        onChanged: (_) => _updateCircle(),
                      ),
                      const SizedBox(height: 16),

                      // Severity
                      DropdownButtonFormField<String>(
                        initialValue: _selectedSeverity,
                        decoration: const InputDecoration(
                          labelText: 'Severity',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'warning',
                            child: Row(
                              children: [
                                Icon(Icons.warning_amber, color: Colors.orange, size: 20),
                                SizedBox(width: 8),
                                Text('Warning'),
                              ],
                            ),
                          ),
                          DropdownMenuItem(
                            value: 'blocked',
                            child: Row(
                              children: [
                                Icon(Icons.block, color: Colors.red, size: 20),
                                SizedBox(width: 8),
                                Text('Blocked'),
                              ],
                            ),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setState(() {
                              _selectedSeverity = value;
                              _updateCircle();
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Actions
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _isSubmitting ? null : () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    onPressed: _isSubmitting ? null : _submitForm,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFCF4374),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    ),
                    icon: _isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.add_location_alt),
                    label: Text(_isSubmitting ? 'Adding...' : 'Add Area'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
