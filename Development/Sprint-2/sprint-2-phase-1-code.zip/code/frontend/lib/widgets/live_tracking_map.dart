/// Live Tracking Map Widget
/// Shows real-time driver location on Google Maps with route polyline
library;

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../utils/logger.dart';

class LiveTrackingMap extends StatefulWidget {
  final double driverLat;
  final double driverLng;
  final double passengerLat;
  final double passengerLng;
  final String? polylineEncoded;
  final Function(GoogleMapController)? onMapCreated;
  final bool showRoute;

  const LiveTrackingMap({
    super.key,
    required this.driverLat,
    required this.driverLng,
    required this.passengerLat,
    required this.passengerLng,
    this.polylineEncoded,
    this.onMapCreated,
    this.showRoute = true,
  });

  @override
  State<LiveTrackingMap> createState() => LiveTrackingMapState();
}

class LiveTrackingMapState extends State<LiveTrackingMap> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();
    _updateMarkers();
    if (widget.showRoute && widget.polylineEncoded != null) {
      _updatePolyline();
    }
  }

  @override
  void didUpdateWidget(LiveTrackingMap oldWidget) {
    super.didUpdateWidget(oldWidget);

    bool locationChanged = false;

    // Update markers if location changed
    if (oldWidget.driverLat != widget.driverLat ||
        oldWidget.driverLng != widget.driverLng ||
        oldWidget.passengerLat != widget.passengerLat ||
        oldWidget.passengerLng != widget.passengerLng) {
      Logger.log('📍 Map: Location changed, updating markers');
      _updateMarkers();
      locationChanged = true;
    }

    // Update polyline if route changed
    if (widget.showRoute &&
        oldWidget.polylineEncoded != widget.polylineEncoded) {
      Logger.log('🗺️ Map: Polyline changed, updating route');
      _updatePolyline();
    }

    // Animate camera after markers are updated
    if (locationChanged) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _animateToDriverLocation();
      });
    }
  }

  void _updateMarkers() {
    setState(() {
      _markers.clear();

      // Driver marker (moving) - Cyan/Azure color for car
      _markers.add(
        Marker(
          markerId: const MarkerId('driver'),
          position: LatLng(widget.driverLat, widget.driverLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueAzure, // Cyan/light blue - represents car
          ),
          infoWindow: const InfoWindow(
            title: '🚗 Driver',
            snippet: 'Moving to pickup',
          ),
        ),
      );

      // Passenger marker (waiting) - Orange color for person
      _markers.add(
        Marker(
          markerId: const MarkerId('passenger'),
          position: LatLng(widget.passengerLat, widget.passengerLng),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueOrange, // Orange - represents person waiting
          ),
          infoWindow: const InfoWindow(
            title: '👤 Pickup Location',
            snippet: 'Waiting for driver',
          ),
        ),
      );
    });
  }

  void _updatePolyline() {
    if (widget.polylineEncoded == null) return;

    try {
      final points = _decodePolyline(widget.polylineEncoded!);
      setState(() {
        _polylines.clear();
        _polylines.add(
          Polyline(
            polylineId: const PolylineId('route'),
            points: points,
            color: Colors.blue,
            width: 5,
          ),
        );
      });
    } catch (e) {
      Logger.error('Error decoding polyline: $e');
    }
  }

  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0;
    int len = encoded.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int b;
      int shift = 0;
      int result = 0;

      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;

      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }

  void _animateToDriverLocation() {
    if (_mapController == null) return;

    _mapController!.animateCamera(
      CameraUpdate.newLatLng(
        LatLng(widget.driverLat, widget.driverLng),
      ),
    );
  }

  /// Update driver location (called from parent)
  void updateDriverLocation(double lat, double lng) {
    if (!mounted) return;
    // Parent will update widget properties, which triggers didUpdateWidget
  }

  /// Fit map bounds to show both driver and passenger
  Future<void> fitBounds() async {
    if (_mapController == null) return;

    final bounds = LatLngBounds(
      southwest: LatLng(
        widget.driverLat < widget.passengerLat
            ? widget.driverLat
            : widget.passengerLat,
        widget.driverLng < widget.passengerLng
            ? widget.driverLng
            : widget.passengerLng,
      ),
      northeast: LatLng(
        widget.driverLat > widget.passengerLat
            ? widget.driverLat
            : widget.passengerLat,
        widget.driverLng > widget.passengerLng
            ? widget.driverLng
            : widget.passengerLng,
      ),
    );

    await _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 100),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Google Map
        GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(widget.driverLat, widget.driverLng),
            zoom: 14,
          ),
          markers: _markers,
          polylines: _polylines,
          myLocationEnabled: false,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false, // Custom controls
          mapToolbarEnabled: false,
          compassEnabled: true,
          rotateGesturesEnabled: true,
          scrollGesturesEnabled: true,
          tiltGesturesEnabled: true,
          zoomGesturesEnabled: true,
          mapType: MapType.normal,
          onMapCreated: (controller) {
            _mapController = controller;
            widget.onMapCreated?.call(controller);
            // Fit bounds after map is created
            Future.delayed(const Duration(milliseconds: 500), () {
              fitBounds();
            });
          },
        ),

        // Custom zoom controls
        Positioned(
          right: 16,
          bottom: 80,
          child: Column(
            children: [
              // Zoom in
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(8),
                    topRight: Radius.circular(8),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  icon: const Icon(Icons.add, size: 20),
                  onPressed: () {
                    _mapController?.animateCamera(CameraUpdate.zoomIn());
                  },
                ),
              ),
              Container(
                height: 1,
                width: 40,
                color: Colors.grey.shade300,
              ),
              // Zoom out
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(8),
                    bottomRight: Radius.circular(8),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  icon: const Icon(Icons.remove, size: 20),
                  onPressed: () {
                    _mapController?.animateCamera(CameraUpdate.zoomOut());
                  },
                ),
              ),
            ],
          ),
        ),

        // Center on driver button
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            mini: true,
            backgroundColor: Colors.white,
            onPressed: () => _animateToDriverLocation(),
            child: const Icon(
              Icons.my_location,
              color: Color(0xFFCF4374),
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
