import 'package:flutter/material.dart';
import '../../constants/app_config.dart';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import 'active_ride_page.dart';
import '../../services/storage_service.dart';
import '../../widgets/safety_alert_dialog.dart';

/// Driver Dashboard
class AvailableRidesPage extends StatefulWidget {
  const AvailableRidesPage({super.key});

  @override
  State<AvailableRidesPage> createState() => _AvailableRidesPageState();
}

class _AvailableRidesPageState extends State<AvailableRidesPage> {
  List<RideRequest> _availableRides = [];
  bool _isConnected = false;
  String? _userId;

  //  ADD USERNAME AND EMAIL
  String? _userName;
  String? _userEmail;

  @override
  void initState() {
    super.initState();
    _initializeDriverSocket();
  }

  /// Initialize socket connection as DRIVER
  Future<void> _initializeDriverSocket() async {
    try {
      _userId = await StorageService.getUserId();
      _userName = await StorageService.getUserName();
      _userEmail = await StorageService.getUserEmail();

      if (_userId == null || _userId!.isEmpty) {
        Logger.error('Driver is not logged in. Aborting socket connection.');
        // TODO: Handle this error, maybe send user back to Welcome Screen
        if (mounted) {
          setState(() {
            _isConnected = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Error: You are not logged in. Please restart the app.',
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      Logger.log(
        '🚗 Initializing driver socket connection for $_userName ($_userId)...',
      );

      await SocketService.connect(
        userId: _userId!,
        userName: _userName ?? 'Driver',
        userEmail: _userEmail ?? 'no-email',
        userType: 'driver',
      );

      await Future.delayed(const Duration(milliseconds: 500));

      if (mounted) {
        setState(() {
          _isConnected = SocketService.isConnected;
        });
      }

      Logger.log('🚗 Driver socket connected: ${SocketService.isConnected}');

      // Listen for initial ride list
      SocketService.onRideList((rides) {
        Logger.log('📥 Received initial ride list: ${rides.length} rides');
        if (mounted) {
          setState(() {
            _availableRides = rides;
          });
        }
      });

      // Listen for new rides
      SocketService.onNewRide((ride) {
        Logger.log('🆕 New ride available: ${ride.id}');
        if (mounted) {
          setState(() {
            // Add ride if not already in list
            if (!_availableRides.any((r) => r.id == ride.id)) {
              _availableRides.add(ride);
            }
          });

          // Show notification
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('New ride available: ${ride.source.address}'),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 3),
            ),
          );
        }
      });

      // Listen for ride list updates
      SocketService.onRideListUpdated((rides) {
        Logger.log('🔄 Ride list updated: ${rides.length} rides');
        if (mounted) {
          setState(() {
            _availableRides = rides;
          });
        }
      });

      // Listen for ride matched event
      SocketService.onRideMatched((ride, role) {
        Logger.log('🎉 Ride matched! Role: $role');
        if (mounted && role == 'driver') {
          // Remove from available rides
          setState(() {
            _availableRides.removeWhere((r) => r.id == ride.id);
          });

          // Show success dialog
          _showMatchedDialog(ride);
        }
      });

      // Listen for ride unavailable (another driver accepted it)
      SocketService.onRideUnavailable((rideId) {
        Logger.log('⚠️ Ride $rideId is no longer available');
        if (mounted) {
          setState(() {
            _availableRides.removeWhere((r) => r.id == rideId);
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Ride is no longer available'),
              backgroundColor: Colors.orange,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      });

      // Listen for ride errors
      SocketService.onRideError((message) {
        Logger.error('🔴 Ride error: $message');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $message'),
              backgroundColor: Colors.red,
            ),
          );
        }
      });

      // Listen for ride cancelled
      SocketService.onRideCancelled((rideId) {
        Logger.log('🚫 Ride cancelled: $rideId');
        if (mounted) {
          setState(() {
            _availableRides.removeWhere((r) => r.id == rideId);
          });
        }
      });

      Logger.log('✅ Driver socket initialized successfully');
    } catch (e) {
      Logger.error('💥 Failed to initialize driver socket: $e');
      if (mounted) {
        setState(() {
          _isConnected = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to connect to server at ${AppConfig.apiBaseUrl}',
            ),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: () {
                _initializeDriverSocket();
              },
            ),
          ),
        );
      }
    }

    // Listen for Safety Alerts
    SocketService.onSafetyAlert((data) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false, // User MUST tap button to close
          builder: (context) => SafetyAlertDialog(
            message: data['message'] ?? 'Unknown Alert',
            severity: data['severity'] ?? 'medium',
            sentAt: data['sentAt'] ?? DateTime.now().toIso8601String(),
          ),
        );
      }
    });

    // Listen for Policy Updates
    SocketService.onPolicyUpdate((data) {
      if (mounted) {
        // Check target audience
        final targetAudience = data['targetAudience'] ?? 'all';
        if (targetAudience == 'all' || targetAudience == 'drivers') {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Row(
                children: [
                  const Icon(Icons.policy, color: Color(0xFFCF4374), size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      data['title'] ?? 'Policy Update',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (data['category'] != null) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          data['category'].toString().toUpperCase(),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    Text(
                      data['message'] ?? '',
                      style: const TextStyle(
                        fontSize: 15,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xFFCF4374),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                  child: const Text(
                    'Got it',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
      }
    });

    // Listen for Fare Price Updates
    SocketService.onFareUpdate((data) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Row(
              children: [
                const Icon(Icons.attach_money, color: Color(0xFFCF4374), size: 28),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'Fare Rate Updated',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                    ),
                  ),
                ),
              ],
            ),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  data['message'] ?? 'Fare price has been updated',
                  style: const TextStyle(
                    fontSize: 15,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'New Rate: ',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                        ),
                      ),
                      Text(
                        '${data['ratePerKm']} ${data['currency'] ?? 'PKR'} / km',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                child: const Text(
                  'Got it',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );
      }
    });
  }

  /// Show dialog when driver successfully matches with a ride
  void _showMatchedDialog(RideRequest ride) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text(
          '🎉 Ride Accepted!',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFCF4374),
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'You have successfully accepted this ride!',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'Passenger: ${ride.userName}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'From: ${ride.source.address}',
              style: const TextStyle(fontSize: 12),
            ),
            Text(
              'To: ${ride.destination.address}',
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Logger.log(
                '🚗 Navigating to active ride page - socket will stay connected',
              );
              // Navigate to active ride page
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) =>
                      DriverActiveRidePage(ride: ride, driverId: _userId!),
                ),
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFCF4374),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text('Start Navigation'),
          ),
        ],
      ),
    );
  }

  /// Accept a ride
  void _acceptRide(RideRequest ride) {
    if (_userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Driver ID not available'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    Logger.log('📤 Accepting ride: ${ride.id}');

    // Emit match ride event
    SocketService.matchRide(
      rideId: ride.id,
      driverId: _userId!,
      driverName: _userName ?? 'Driver',
    );

    // Show loading indicator
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Accepting ride...'),
        backgroundColor: Colors.blue,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    Logger.log('🗑️ Disposing AvailableRidesPage - keeping socket connected');

    // Remove only the listeners that were set up in this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('ride:list');
      SocketService.socket!.off('ride:new');
      SocketService.socket!.off('ride:list:updated');
      SocketService.socket!.off('admin:safety_alert');
      Logger.log('✅ Removed available rides listeners, socket still connected');
    }

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text('Available Rides'),
        backgroundColor: const Color(0xFFCF4374),
        
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Connection status
            Container(
              padding: const EdgeInsets.all(16),
              color: _isConnected || true ? Colors.green[50] : Colors.red[50],
              child: Row(
                children: [
                  Icon(
                    _isConnected || true? Icons.check_circle : Icons.error,
                    color: _isConnected || true ? Colors.green : Colors.red,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _isConnected || true
                        ? 'Connected - Listening for rides...'
                        : 'Not connected. Please restart app.',
                    style: TextStyle(
                      color: _isConnected || true ? Colors.green[900] : Colors.red[900],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Rides list
            Expanded(
              child: _availableRides.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.local_taxi,
                            size: 80,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No rides available',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey[600],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Waiting for ride requests...',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _availableRides.length,
                      itemBuilder: (context, index) {
                        final ride = _availableRides[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 16),
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.person,
                                      color: Color(0xFFCF4374),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      ride.userName,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(height: 24),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on,
                                      size: 20,
                                      color: Colors.green,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'From: ${ride.source.address}',
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.flag,
                                      size: 20,
                                      color: Colors.red,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'To: ${ride.destination.address}',
                                        style: const TextStyle(fontSize: 14),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () => _acceptRide(ride),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFFCF4374),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 12,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                    child: const Text(
                                      'Accept Ride',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
