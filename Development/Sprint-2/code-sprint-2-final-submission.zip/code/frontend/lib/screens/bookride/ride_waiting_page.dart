import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import '../../services/map_service.dart';
import '../../widgets/sound_wave.dart';
import '../sos/pre_sos_page.dart';

// Data container class to hold fetched coordinates
class _RouteCoordinates {
  final double sourceLat;
  final double sourceLng;
  final double destLat;
  final double destLng;

  _RouteCoordinates({
    required this.sourceLat,
    required this.sourceLng,
    required this.destLat,
    required this.destLng,
  });
}

class RideWaitingPage extends StatefulWidget {
  final String rideId;
  final String source;
  final String destination;

  const RideWaitingPage({
    super.key,
    required this.rideId,
    required this.source,
    required this.destination,
  });

  @override
  State<RideWaitingPage> createState() => _RideWaitingPageState();
}

class _RideWaitingPageState extends State<RideWaitingPage> {
  String _sourceUrdu = '...لوڈ ہو رہا ہے';
  String _destinationUrdu = '...لوڈ ہو رہا ہے';
  String _duration = 'کیلکولیٹ ہو رہا ہے';
  String _distance = 'کیلکولیٹ ہو رہا ہے';
  String _mapUrl = '';
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchAndDisplayRoute();
    _setupRideMatchedListener();
  }

  @override
  void dispose() {
    // Remove the ride:matched listener when leaving this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('ride:matched');
      Logger.log('🗑️ Removed ride:matched listener from RideWaitingPage');
    }
    super.dispose();
  }

  /// Listen for ride:matched event and navigate to PreSOSPage
  void _setupRideMatchedListener() {
    Logger.log('👂 Setting up ride:matched listener in RideWaitingPage');

    SocketService.onRideMatched((ride, role) {
      Logger.log('🎉 Ride matched! Role: $role, Ride ID: ${ride.id}');

      if (!mounted) {
        Logger.log('⚠️ Widget not mounted, skipping navigation');
        return;
      }

      // Navigate to PreSOSPage (waiting page with driver info and countdown)
      Logger.log('🚗 Navigating to PreSOSPage for 5-second countdown');
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => PreSOSPage(
            ride: ride,
            userId: ride.userId ?? '',
          ),
        ),
      );
    });

    Logger.log('✅ Ride:matched listener setup complete');
  }

  Future<void> _fetchAndDisplayRoute() async {
    try {
      Logger.log('🗺️ Starting route fetch for: ${widget.source} -> ${widget.destination}');

      // Translate addresses to Urdu for display
      final translatedAddresses = await MapService.translateAddresses(
        source: widget.source,
        destination: widget.destination,
      );

      setState(() {
        _sourceUrdu = translatedAddresses['source'] ?? widget.source;
        _destinationUrdu = translatedAddresses['destination'] ?? widget.destination;
      });

      // Geocode using backend Google Maps API
      Logger.log('📍 Geocoding source: ${widget.source}');
      final sourceCoords = await MapService.geocodeAddress(widget.source);

      if (sourceCoords == null) {
        throw Exception('Failed to geocode source address: ${widget.source}');
      }

      Logger.log('📍 Geocoding destination: ${widget.destination}');
      final destCoords = await MapService.geocodeAddress(widget.destination);

      if (destCoords == null) {
        throw Exception('Failed to geocode destination address: ${widget.destination}');
      }

      final coords = _RouteCoordinates(
        sourceLat: sourceCoords['latitude']!,
        sourceLng: sourceCoords['longitude']!,
        destLat: destCoords['latitude']!,
        destLng: destCoords['longitude']!,
      );

      Logger.log('✅ Coordinates obtained: (${coords.sourceLat}, ${coords.sourceLng}) -> (${coords.destLat}, ${coords.destLng})');

      final routeResults = await Future.wait([
        MapService.calculateRoute(
          sourceLat: coords.sourceLat,
          sourceLng: coords.sourceLng,
          destLat: coords.destLat,
          destLng: coords.destLng,
        ),
        MapService.getDirectionsPolyline(
          sourceLat: coords.sourceLat,
          sourceLng: coords.sourceLng,
          destLat: coords.destLat,
          destLng: coords.destLng,
        ),
      ]);

      final distanceDuration = routeResults[0] as Map<String, String>;
      final polyline = routeResults[1] as String;

      final finalMapUrl = await MapService.getStaticMapUrl(
        sourceLat: coords.sourceLat,
        sourceLng: coords.sourceLng,
        destLat: coords.destLat,
        destLng: coords.destLng,
        polyline: polyline,
      );

      setState(() {
        _distance = distanceDuration['distance'] ?? 'N/A';
        _duration = distanceDuration['duration'] ?? 'N/A';
        _mapUrl = finalMapUrl;
        _isLoading = false;
      });
      Logger.log('✅ Route data and map URL updated successfully.');
    } catch (e) {
      Logger.error('Critical error loading route data: $e');
      if (mounted) {
        setState(() {
          _errorMessage = 'روٹ لوڈ کرنے میں ناکامی';
          _isLoading = false;
        });
      }
    }
  }

  void _showCancelDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFF682AA),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SoundWave(),
                const SizedBox(height: 16),
                const Text(
                  'کیا آپ واقعی سواری منسوخ کرنا چاہتے ہیں؟',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Cancel (Cross) Button
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.black54,
                          size: 32,
                        ),
                      ),
                    ),
                    // Confirm (Tick) Button
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).pop();
                        _confirmCancelRide();
                      },
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFFF48FB1),
                              Color(0xFFCF4374),
                            ],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _confirmCancelRide() async {
    Logger.log('Canceling ride ${widget.rideId}');
    SocketService.cancelRide(widget.rideId);
    Navigator.of(context).pop();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'سواری کی درخواست منسوخ ہو گئی',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Colors.orange,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget mapContent;

    if (_isLoading) {
      mapContent = const Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      );
    } else if (_errorMessage.isNotEmpty) {
      mapContent = Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.warning_amber_outlined, color: Colors.red, size: 50),
            const SizedBox(height: 8),
            Text(
              _errorMessage,
              style: const TextStyle(color: Colors.red, fontSize: 16),
              textDirection: TextDirection.rtl,
            ),
          ],
        ),
      );
    } else {
      mapContent = Image.network(
        _mapUrl,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Center(
            child: CircularProgressIndicator(
              color: const Color(0xFFCF4374),
              value: loadingProgress.expectedTotalBytes != null
                  ? loadingProgress.cumulativeBytesLoaded /
                      (loadingProgress.expectedTotalBytes ?? 1)
                  : null,
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          Logger.error('Map image failed to load: $error');
          return const Center(
            child: Icon(Icons.error_outline, size: 60, color: Colors.red),
          );
        },
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Back Arrow
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Top Section - Logo and Sound Wave
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 8.0),
                child: Column(
                  children: [
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 80,
                      height: 80,
                    ),
                    const SizedBox(height: 8),
                    const SoundWave(),
                    const SizedBox(height: 5),
                    const Text(
                      'ڈرائیور کی تلاش جاری ہے،\nبراہ کرم انتظار فرمائیں',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 29,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ),

              // Map and Info Section
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        // Map Area
                        Expanded(
                          flex: 7,
                          child: ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                            child: Container(
                              color: Colors.grey[200],
                              child: mapContent,
                            ),
                          ),
                        ),

                        // Info Section
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            children: [
                              // Distance and Duration - Moved to top
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Column(
                                    children: [
                                      Text(
                                        _duration,
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        'کل وقت',
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Color(0xFFCF4374),
                                          fontWeight: FontWeight.w500,
                                        ),
                                        textDirection: TextDirection.rtl,
                                      ),
                                    ],
                                  ),
                                  Container(
                                    width: 2,
                                    height: 40,
                                    color: const Color(0xFFF682AA),
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        _distance,
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        'کل فاصلہ',
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Color(0xFFCF4374),
                                          fontWeight: FontWeight.w500,
                                        ),
                                        textDirection: TextDirection.rtl,
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              const SizedBox(height: 16),

                              // Locations - Single Line (Source and Destination swapped)
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                textDirection: TextDirection.rtl,
                                children: [
                                  // Source (now on right)
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Flexible(
                                          child: Text(
                                            _sourceUrdu,
                                            style: const TextStyle(
                                              fontSize: 15,
                                              color: Colors.black87,
                                              fontWeight: FontWeight.w600,
                                            ),
                                            textDirection: TextDirection.rtl,
                                            textAlign: TextAlign.right,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Container(
                                          width: 10,
                                          height: 10,
                                          decoration: const BoxDecoration(
                                            color: Color(0xFFFDEAF9),

                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Line
                                  Container(
                                    width: 60,
                                    height: 1,
                                    color: const Color(0xFFF682AA),
                                    margin: const EdgeInsets.symmetric(horizontal: 8),
                                  ),
                                  // Destination (now on left)
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 10,
                                          height: 10,
                                          decoration: const BoxDecoration(
                                            color: Color(0xFFCF4374),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Flexible(
                                          child: Text(
                                            _destinationUrdu,
                                            style: const TextStyle(
                                              fontSize: 15,
                                              color: Colors.black87,
                                              fontWeight: FontWeight.w600,
                                            ),
                                            textDirection: TextDirection.rtl,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Cancel Button
              Padding(
                padding: const EdgeInsets.fromLTRB(24.0, 12.0, 24.0, 12.0),
                child: GestureDetector(
                  onTap: _isLoading ? null : _showCancelDialog,
                  child: Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFFF48FB1),
                          Color(0xFFCF4374),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 24,
                        ),
                        SizedBox(width: 8),
                        Text(
                          'منسوخ کریں',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Bottom Navigation Bar
              Container(
                decoration: BoxDecoration(
color: const Color(0xFFFDF0F4),


                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildNavItem(Icons.home_outlined, 'ہوم', true),
                        _buildNavItem(Icons.notifications_outlined, 'اطلاعات', true),
                        _buildNavItem(Icons.person_outline, 'پروفائل', true),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? const Color(0xFFCF4374) : Colors.grey,
          size: 28,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isActive ? const Color(0xFFCF4374) : Colors.grey,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}