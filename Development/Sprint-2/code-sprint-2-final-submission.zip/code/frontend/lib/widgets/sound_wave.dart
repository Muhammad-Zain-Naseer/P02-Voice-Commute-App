import 'package:flutter/material.dart';
import 'dart:math' as math;

class SoundWave extends StatefulWidget {
  const SoundWave({super.key});

  @override
  State<SoundWave> createState() => _SoundWaveState();
}

class _SoundWaveState extends State<SoundWave> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          size: const Size(200, 60),
          painter: SoundWavePainter(
            animationValue: _controller.value,
          ),
        );
      },
    );
  }
}

class SoundWavePainter extends CustomPainter {
  final double animationValue;

  SoundWavePainter({required this.animationValue});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFCF4374)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final centerY = size.height / 2;
    final barWidth = 4.0;
    final barSpacing = 8.0;
    final numBars = 15;

    for (int i = 0; i < numBars; i++) {
      final x = i * (barWidth + barSpacing) + (size.width - (numBars * (barWidth + barSpacing))) / 2;
      
      // Create wave effect with different heights
      final heightFactor = math.sin((i / numBars * math.pi * 2) + (animationValue * math.pi * 2));
      final barHeight = (size.height / 2) * (0.3 + (heightFactor.abs() * 0.7));

      canvas.drawLine(
        Offset(x + barWidth / 2, centerY - barHeight / 2),
        Offset(x + barWidth / 2, centerY + barHeight / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(SoundWavePainter oldDelegate) {
    return oldDelegate.animationValue != animationValue;
  }
}