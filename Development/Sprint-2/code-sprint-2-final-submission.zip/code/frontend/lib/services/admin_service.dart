import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';

class AdminService {
  final String baseUrl = AppConfig.apiBaseUrl;
  String? _token;

  void setToken(String token) {
    _token = token;
  }

  Map<String, String> _getHeaders() {
    return {
      'Content-Type': 'application/json',
      if (_token != null) 'Authorization': 'Bearer $_token',
    };
  }

  // Get overview statistics
  Future<Map<String, dynamic>?> getOverviewStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/overview'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching overview stats: $e');
      return null;
    }
  }

  // Get user statistics
  Future<Map<String, dynamic>?> getUserStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/users'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching user stats: $e');
      return null;
    }
  }

  // Get driver statistics
  Future<Map<String, dynamic>?> getDriverStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/drivers'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching driver stats: $e');
      return null;
    }
  }

  // Get ride statistics
  Future<Map<String, dynamic>?> getRideStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/rides'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching ride stats: $e');
      return null;
    }
  }

  // Get payment statistics
  Future<Map<String, dynamic>?> getPaymentStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/payments'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching payment stats: $e');
      return null;
    }
  }

  // Get active trips for monitoring
  Future<Map<String, dynamic>?> getActiveTrips() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/trips/active'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching active trips: $e');
      return null;
    }
  }

  // ==================== USER MANAGEMENT METHODS ====================

  // Get users
  Future<Map<String, dynamic>?> getUsers({
    String? role,
    bool? isVerified,
    int page = 1,
    int limit = 50,
  }) async {
    try {
      String url = '$baseUrl/api/admin/users?page=$page&limit=$limit';
      if (role != null) url += '&role=$role';
      if (isVerified != null) url += '&isVerified=$isVerified';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching users: $e');
      return null;
    }
  }

  // Search users
  Future<Map<String, dynamic>?> searchUsers({
    required String query,
    int page = 1,
    int limit = 20,
  }) async {
    try {
      String url =
          '$baseUrl/api/admin/users/search?query=$query&page=$page&limit=$limit';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error searching users: $e');
      return null;
    }
  }

  // Get user details
  Future<Map<String, dynamic>?> getUserDetails(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/users/$userId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching user details: $e');
      return null;
    }
  }

  // Get user activity (rides, payments, driver info)
  Future<Map<String, dynamic>?> getUserActivity(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/users/$userId/activity'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching user activity: $e');
      return null;
    }
  }

  // Verify user
  Future<bool> verifyUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/verify'),
        headers: _getHeaders(),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error verifying user: $e');
      return false;
    }
  }

  // Activate user
  Future<bool> activateUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/activate'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      print('Failed to activate user: ${response.body}');
      return false;
    } catch (e) {
      print('Error activating user: $e');
      return false;
    }
  }

  // Deactivate user
  Future<bool> deactivateUser(String userId, {String? reason}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/deactivate'),
        headers: _getHeaders(),
        body: jsonEncode({if (reason != null) 'reason': reason}),
      );

      if (response.statusCode == 200) return true;
      print('Failed to deactivate user: ${response.body}');
      return false;
    } catch (e) {
      print('Error deactivating user: $e');
      return false;
    }
  }

  // Suspend user
  Future<bool> suspendUser(String userId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/suspend'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;
      print('Failed to suspend user: ${response.body}');
      return false;
    } catch (e) {
      print('Error suspending user: $e');
      return false;
    }
  }

  // Unsuspend user
  Future<bool> unsuspendUser(String userId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/unsuspend'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      print('Failed to unsuspend user: ${response.body}');
      return false;
    } catch (e) {
      print('Error unsuspending user: $e');
      return false;
    }
  }

  // Update user role
  Future<bool> updateUserRole(String userId, String role) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/users/$userId/role'),
        headers: _getHeaders(),
        body: jsonEncode({'role': role}),
      );

      if (response.statusCode == 200) return true;
      print('Failed to update user role: ${response.body}');
      return false;
    } catch (e) {
      print('Error updating user role: $e');
      return false;
    }
  }

  // Delete user
  Future<bool> deleteUser(String userId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/api/admin/users/$userId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;
      print('Failed to delete user: ${response.body}');
      return false;
    } catch (e) {
      print('Error deleting user: $e');
      return false;
    }
  }

  // Get drivers (supports search)
  Future<Map<String, dynamic>?> getDrivers({
    String? status,
    String? search,
    int page = 1,
    int limit = 20,
  }) async {
    try {
      String url = '$baseUrl/api/admin/drivers?page=$page&limit=$limit';
      if (status != null) url += '&status=$status';
      if (search != null && search.isNotEmpty) url += '&search=$search';

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching drivers: $e');
      return null;
    }
  }

  // Update driver status
  Future<bool> updateDriverStatus(
    String driverId,
    String status, {
    String? rejectionReason,
  }) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/status'),
        headers: _getHeaders(),
        body: jsonEncode({
          'status': status,
          if (rejectionReason != null) 'rejectionReason': rejectionReason,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error updating driver status: $e');
      return false;
    }
  }

  // Get pending payments
  Future<Map<String, dynamic>?> getPendingPayments({int page = 1}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/payments/pending?page=$page'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching pending payments: $e');
      return null;
    }
  }

  // Verify payment
  Future<bool> verifyPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/verify'),
        headers: _getHeaders(),
        body: jsonEncode({if (notes != null) 'notes': notes}),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error verifying payment: $e');
      return false;
    }
  }

  // Reject payment
  Future<bool> rejectPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/reject'),
        headers: _getHeaders(),
        body: jsonEncode({if (notes != null) 'notes': notes}),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error rejecting payment: $e');
      return false;
    }
  }

  // Send safety alert
  Future<bool> sendSafetyAlert({
    required String message,
    required String severity,
    String targetAudience = 'all',
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/admin/alerts/alerts'),
        headers: _getHeaders(),
        body: jsonEncode({
          'message': message,
          'severity': severity,
          'targetAudience': targetAudience,
        }),
      );

      return response.statusCode == 201;
    } catch (e) {
      print('Error sending safety alert: $e');
      return false;
    }
  }

  // Get current fare price
  Future<Map<String, dynamic>> getCurrentFarePrice() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/fares/current'));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      } else {
        throw Exception('Failed to fetch fare price');
      }
    } catch (e) {
      print('Error fetching fare price: $e');
      rethrow;
    }
  }

  // Update fare price (admin only)
  Future<bool> updateFarePrice({
    required double ratePerKm,
    String? notes,
  }) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/api/fares/update'),
        headers: _getHeaders(),
        body: jsonEncode({'ratePerKm': ratePerKm, 'notes': notes ?? ''}),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error updating fare price: $e');
      return false;
    }
  }

  // Broadcast policy update to users
  Future<bool> sendPolicyUpdate({
    required String title,
    required String message,
    required String category,
    required String severity,
    required String targetAudience,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/policies/send'),
        headers: _getHeaders(),
        body: jsonEncode({
          'title': title,
          'message': message,
          'category': category,
          'severity': severity,
          'targetAudience': targetAudience,
        }),
      );

      return response.statusCode == 201;
    } catch (e) {
      print('Error sending policy update: $e');
      return false;
    }
  }

  // ==================== UNSAFE AREA METHODS ====================

  // Create a new unsafe area
  Future<Map<String, dynamic>?> createUnsafeArea({
    required String name,
    required String description,
    required double latitude,
    required double longitude,
    String? address,
    required double radius,
    required String severity,
    required String reason,
    DateTime? activeFrom,
    DateTime? activeTo,
  }) async {
    try {
      final url = '$baseUrl/api/admin/unsafe-areas';
      final body = jsonEncode({
        'name': name,
        'description': description,
        'latitude': latitude,
        'longitude': longitude,
        'address': address ?? '',
        'radius': radius,
        'severity': severity,
        'reason': reason,
        'activeFrom': activeFrom?.toIso8601String(),
        'activeTo': activeTo?.toIso8601String(),
      });

      print('🌐 POST $url');
      print('📦 Body: $body');
      print('🔑 Headers: ${_getHeaders()}');

      final response = await http.post(
        Uri.parse(url),
        headers: _getHeaders(),
        body: body,
      );

      print('📡 Response Status: ${response.statusCode}');
      print('📡 Response Body: ${response.body}');

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return data['data'];
      } else {
        print('❌ Failed with status ${response.statusCode}: ${response.body}');
        return null;
      }
    } catch (e, stackTrace) {
      print('❌ Error creating unsafe area: $e');
      print('Stack: $stackTrace');
      return null;
    }
  }

  // Get all unsafe areas
  Future<List<Map<String, dynamic>>> getUnsafeAreas({bool? activeOnly}) async {
    try {
      String url = '$baseUrl/api/admin/unsafe-areas';
      if (activeOnly != null) {
        url += '?active=${activeOnly.toString()}';
      }

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['data']);
      }
      return [];
    } catch (e) {
      print('Error fetching unsafe areas: $e');
      return [];
    }
  }

  // Get a specific unsafe area by ID
  Future<Map<String, dynamic>?> getUnsafeAreaById(String id) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching unsafe area: $e');
      return null;
    }
  }

  // Update an unsafe area
  Future<bool> updateUnsafeArea({
    required String id,
    String? name,
    String? description,
    double? latitude,
    double? longitude,
    String? address,
    double? radius,
    String? severity,
    String? reason,
    bool? isActive,
    DateTime? activeFrom,
    DateTime? activeTo,
  }) async {
    try {
      final Map<String, dynamic> body = {};
      if (name != null) body['name'] = name;
      if (description != null) body['description'] = description;
      if (latitude != null) body['latitude'] = latitude;
      if (longitude != null) body['longitude'] = longitude;
      if (address != null) body['address'] = address;
      if (radius != null) body['radius'] = radius;
      if (severity != null) body['severity'] = severity;
      if (reason != null) body['reason'] = reason;
      if (isActive != null) body['isActive'] = isActive;
      if (activeFrom != null) body['activeFrom'] = activeFrom.toIso8601String();
      if (activeTo != null) body['activeTo'] = activeTo.toIso8601String();

      print('📝 Updating unsafe area $id');
      print('Body: ${jsonEncode(body)}');
      print('Headers: ${_getHeaders()}');

      final response = await http.put(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
        body: jsonEncode(body),
      );

      print('Response: ${response.statusCode} - ${response.body}');
      return response.statusCode == 200;
    } catch (e) {
      print('❌ Error updating unsafe area: $e');
      return false;
    }
  }

  // Delete an unsafe area
  Future<bool> deleteUnsafeArea(String id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/api/admin/unsafe-areas/$id'),
        headers: _getHeaders(),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error deleting unsafe area: $e');
      return false;
    }
  }

  // Check if a location is in any unsafe area (Public API)
  Future<Map<String, dynamic>> checkUnsafeLocation({
    required double latitude,
    required double longitude,
  }) async {
    try {
      print('🔍 Checking unsafe location: $latitude, $longitude');

      final response = await http.post(
        Uri.parse('$baseUrl/api/unsafe-areas/check'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'latitude': latitude, 'longitude': longitude}),
      );

      print('📡 Response: ${response.statusCode} - ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('✅ Unsafe check result: ${data['data']}');
        return data['data'];
      }

      return {'isUnsafe': false, 'areas': []};
    } catch (e) {
      print('❌ Error checking unsafe location: $e');
      return {'isUnsafe': false, 'areas': []};
    }
  }

  // ==================== DRIVER VERIFICATION METHODS ====================

  // Get single driver details
  Future<Map<String, dynamic>?> getDriverDetails(String driverId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching driver details: $e');
      return null;
    }
  }

  // Approve driver
  Future<bool> approveDriver(String driverId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/approve'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;

      print('Failed to approve driver: ${response.body}');
      return false;
    } catch (e) {
      print('Error approving driver: $e');
      return false;
    }
  }

  // Reject driver
  Future<bool> rejectDriver(String driverId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/reject'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;

      print('Failed to reject driver: ${response.body}');
      return false;
    } catch (e) {
      print('Error rejecting driver: $e');
      return false;
    }
  }

  // Request resubmission
  Future<bool> requestResubmission(String driverId, String notes) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/resubmission'),
        headers: _getHeaders(),
        body: jsonEncode({'notes': notes}),
      );

      if (response.statusCode == 200) return true;

      print('Failed to request resubmission: ${response.body}');
      return false;
    } catch (e) {
      print('Error requesting resubmission: $e');
      return false;
    }
  }

  // Suspend driver
  Future<bool> suspendDriver(String driverId, String reason) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/suspend'),
        headers: _getHeaders(),
        body: jsonEncode({'reason': reason}),
      );

      if (response.statusCode == 200) return true;

      print('Failed to suspend driver: ${response.body}');
      return false;
    } catch (e) {
      print('Error suspending driver: $e');
      return false;
    }
  }

  // Reactivate suspended driver
  Future<bool> reactivateDriver(String driverId) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/reactivate'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) return true;

      print('Failed to reactivate driver: ${response.body}');
      return false;
    } catch (e) {
      print('Error reactivating driver: $e');
      return false;
    }
  }
}
