import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';
import '../utils/logger.dart';

/// Payment Service for handling payment submissions
/// Uses REST API for reliable payment processing
class PaymentService {
  static final String baseUrl = '${AppConfig.apiBaseUrl}/api/payments';
  static const Duration timeout = Duration(seconds: 30);

  /// Submit payment for a completed ride
  static Future<Map<String, dynamic>> submitPayment({
    required String rideId,
    required String userId,
    required String driverId,
    required double amount,
    required String transactionId,
    String paymentMethod = 'cash',
  }) async {
    try {
      Logger.log('💳 Submitting payment for ride: $rideId');
      Logger.log('💳 Amount: \$$amount');
      Logger.log('💳 Transaction ID: $transactionId');
      Logger.log('💳 Payment Method: $paymentMethod');

      final requestBody = {
        'rideId': rideId,
        'userId': userId,
        'driverId': driverId,
        'amount': amount,
        'transactionId': transactionId,
        'paymentMethod': paymentMethod,
      };

      Logger.log('📤 Payment request body: ${jsonEncode(requestBody)}');

      final response = await http
          .post(
            Uri.parse(baseUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(requestBody),
          )
          .timeout(
            timeout,
            onTimeout: () {
              throw Exception('Payment request timed out. Please try again.');
            },
          );

      Logger.log('📥 Payment response status: ${response.statusCode}');
      Logger.log('📥 Payment response body: ${response.body}');

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 201) {
        Logger.log('✅ Payment submitted successfully');
        return {
          'success': true,
          'payment': responseData['data']['payment'],
        };
      } else if (response.statusCode == 409) {
        // Payment already exists or duplicate transaction ID
        Logger.error('⚠️ Payment conflict: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Payment already submitted',
          'existingPayment': responseData['data']?['payment'],
        };
      } else {
        Logger.error('❌ Payment failed: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to submit payment',
        };
      }
    } catch (error) {
      Logger.error('💥 Payment error: $error');
      return {
        'success': false,
        'message': 'Network error. Please check your connection and try again.',
      };
    }
  }

  /// Get payment details for a specific ride
  static Future<Map<String, dynamic>> getPaymentByRide(String rideId) async {
    try {
      Logger.log('🔍 Fetching payment for ride: $rideId');

      final response = await http
          .get(
            Uri.parse('$baseUrl/ride/$rideId'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      Logger.log('📥 Get payment response status: ${response.statusCode}');

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Logger.log('✅ Payment found');
        return {
          'success': true,
          'payment': responseData['data']['payment'],
        };
      } else if (response.statusCode == 404) {
        Logger.log('ℹ️ No payment found for this ride');
        return {
          'success': false,
          'message': 'No payment found for this ride',
        };
      } else {
        Logger.error('❌ Failed to fetch payment: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to fetch payment',
        };
      }
    } catch (error) {
      Logger.error('💥 Error fetching payment: $error');
      return {
        'success': false,
        'message': 'Network error. Please try again.',
      };
    }
  }

  /// Get all payments for a user
  static Future<Map<String, dynamic>> getPaymentsByUser(
    String userId, {
    String? status,
  }) async {
    try {
      Logger.log('🔍 Fetching payments for user: $userId');

      final uri = status != null
          ? Uri.parse('$baseUrl/user/$userId?status=$status')
          : Uri.parse('$baseUrl/user/$userId');

      final response = await http
          .get(
            uri,
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      Logger.log('📥 Get user payments response status: ${response.statusCode}');

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Logger.log('✅ Found ${responseData['data']['count']} payment(s)');
        return {
          'success': true,
          'payments': responseData['data']['payments'],
          'count': responseData['data']['count'],
        };
      } else {
        Logger.error('❌ Failed to fetch payments: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to fetch payments',
        };
      }
    } catch (error) {
      Logger.error('💥 Error fetching user payments: $error');
      return {
        'success': false,
        'message': 'Network error. Please try again.',
      };
    }
  }

  /// Get all payments received by a driver
  static Future<Map<String, dynamic>> getPaymentsByDriver(
    String driverId, {
    String? status,
  }) async {
    try {
      Logger.log('🔍 Fetching payments for driver: $driverId');

      final uri = status != null
          ? Uri.parse('$baseUrl/driver/$driverId?status=$status')
          : Uri.parse('$baseUrl/driver/$driverId');

      final response = await http
          .get(
            uri,
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      Logger.log(
        '📥 Get driver payments response status: ${response.statusCode}',
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Logger.log('✅ Found ${responseData['data']['count']} payment(s)');
        return {
          'success': true,
          'payments': responseData['data']['payments'],
          'count': responseData['data']['count'],
        };
      } else {
        Logger.error('❌ Failed to fetch payments: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to fetch payments',
        };
      }
    } catch (error) {
      Logger.error('💥 Error fetching driver payments: $error');
      return {
        'success': false,
        'message': 'Network error. Please try again.',
      };
    }
  }

  /// Get payment statistics
  static Future<Map<String, dynamic>> getPaymentStats({
    String? userId,
    String? driverId,
  }) async {
    try {
      Logger.log('📊 Fetching payment statistics');

      final queryParams = <String, String>{};
      if (userId != null) queryParams['userId'] = userId;
      if (driverId != null) queryParams['driverId'] = driverId;

      final uri = Uri.parse('$baseUrl/stats').replace(
        queryParameters: queryParams.isNotEmpty ? queryParams : null,
      );

      final response = await http
          .get(
            uri,
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(timeout);

      Logger.log('📥 Get payment stats response status: ${response.statusCode}');

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Logger.log('✅ Payment stats retrieved');
        return {
          'success': true,
          'stats': responseData['data'],
        };
      } else {
        Logger.error('❌ Failed to fetch stats: ${responseData['error']}');
        return {
          'success': false,
          'message': responseData['error'] ?? 'Failed to fetch statistics',
        };
      }
    } catch (error) {
      Logger.error('💥 Error fetching payment stats: $error');
      return {
        'success': false,
        'message': 'Network error. Please try again.',
      };
    }
  }
}
