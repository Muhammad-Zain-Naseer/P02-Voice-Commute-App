# Payment Accounts Migration Guide

## Overview

This guide documents the migration of driver payment accounts from the User model to the Driver model. This architectural change improves data organization and separates concerns between user authentication and driver-specific operational data.

## Changes Made

### 1. Frontend Changes

#### File: `lib/screens/driver/driver_dashboard.dart`
- **Fixed**: Error handling in `_fetchStats()` method
- **Added**: Logger import for proper error logging
- **Fixed**: Loading state now updates correctly even on error
- **Impact**: Dashboard statistics will now display "0" instead of "..." when errors occur

### 2. Backend Model Changes

#### File: `src/models/Driver.js`
- **Changed**: `paymentAccounts` from generic Map to structured schema
- **Added**: Verification fields (isVerified, verifiedAt, verifiedBy)
- **Added**: `paymentAccountsUpdatedAt` timestamp field
- **Structure**:
  ```javascript
  paymentAccounts: {
    easyPaisa: {
      accountTitle: String,
      accountNumber: String,
      isVerified: Boolean,
      verifiedAt: Date,
      verifiedBy: ObjectId
    },
    jazzCash: {
      accountTitle: String,
      accountNumber: String,
      isVerified: Boolean,
      verifiedAt: Date,
      verifiedBy: ObjectId
    }
  }
  ```

#### File: `src/models/User.js`
- **Removed**: `paymentAccounts` field (lines 107-129)
- **Reason**: Driver-specific data should not be in User model

### 3. Backend Controller Changes

#### File: `src/controllers/driver.controller.js`
- **Fixed**: Aggregation query to use `"matchedWith.driverId"` instead of `driverId`
- **Impact**: Dashboard statistics will now correctly query rides

#### New File: `src/controllers/driverPaymentController.js`
- **Added**: `getPaymentAccounts()` - Get driver's payment accounts
- **Added**: `updatePaymentAccounts()` - Update driver's payment accounts
- **Endpoints**:
  - `GET /api/driver/payment-accounts`
  - `PUT /api/driver/payment-accounts`

#### File: `src/controllers/admin.controller.js`
- **Added**: `getDriverPaymentAccounts()` - View driver payment accounts
- **Added**: `verifyPaymentAccount()` - Verify driver payment account
- **Added**: `rejectPaymentAccount()` - Reject/unverify payment account
- **Endpoints**:
  - `GET /api/admin/drivers/:driverId/payment-accounts`
  - `PATCH /api/admin/drivers/:driverId/payment-accounts/verify`
  - `PATCH /api/admin/drivers/:driverId/payment-accounts/reject`

### 4. Backend Route Changes

#### File: `src/routes/driver.routes.js`
- **Added**: Payment account management routes
- **Protected**: All routes require authentication and driver role

#### File: `src/routes/admin.routes.js`
- **Added**: Driver payment account management routes
- **Protected**: All routes require authentication and admin role

### 5. Socket Handler Changes

#### File: `src/sockets/ride.socket.js`
- **Changed**: Now queries Driver model instead of User model
- **Added**: Driver model import
- **Fixed**: Payment account retrieval logic for ride completion

## Migration Steps

### Step 1: Backup Your Database

**IMPORTANT**: Always backup before running migrations!

```bash
# MongoDB backup command
mongodump --uri="your-mongodb-uri" --out=./backup-$(date +%Y%m%d)
```

### Step 2: Deploy Code Changes

1. Pull latest changes from repository
2. Install dependencies (if any new ones were added)
3. Review the changes in this guide

### Step 3: Run Migration Script

```bash
cd D:\github\FYP-Backend
node scripts/migratePaymentAccounts.js
```

**What the script does:**
1. Connects to MongoDB
2. Finds all drivers with payment accounts in User model
3. Copies payment accounts to Driver model
4. Removes payment accounts from User model
5. Provides detailed migration summary

**Expected Output:**
```
🔄 Starting payment accounts migration...

✅ Connected to MongoDB

📊 Found X drivers with payment accounts in User model

✅ Migrated payment accounts for driver: userId1 (email1@example.com)
✅ Migrated payment accounts for driver: userId2 (email2@example.com)
...

============================================================
📋 MIGRATION SUMMARY
============================================================
✅ Successfully migrated: X
⏭️  Skipped: Y
❌ Errors: Z
📊 Total processed: X
============================================================

✅ Migration completed successfully!
```

### Step 4: Restart Backend Server

After successful migration, restart your backend server to ensure all changes take effect:

```bash
# Stop current server (Ctrl+C)
# Then restart
npm start
# or
npm run dev
```

### Step 5: Verify Migration

See "Testing Guide" section below.

## Rollback Plan

If something goes wrong, you can rollback:

1. Restore from backup:
   ```bash
   mongorestore --uri="your-mongodb-uri" ./backup-YYYYMMDD
   ```

2. Checkout previous commit:
   ```bash
   git checkout <previous-commit-hash>
   ```

3. Restart server

## API Changes

### New Driver Endpoints

#### Get Payment Accounts
```http
GET /api/driver/payment-accounts
Authorization: Bearer <driver-token>

Response:
{
  "success": true,
  "data": {
    "easyPaisa": {
      "accountTitle": "John Doe",
      "accountNumber": "03001234567",
      "isVerified": false
    },
    "jazzCash": {
      "accountTitle": "John Doe",
      "accountNumber": "03001234567",
      "isVerified": true
    }
  }
}
```

#### Update Payment Accounts
```http
PUT /api/driver/payment-accounts
Authorization: Bearer <driver-token>
Content-Type: application/json

{
  "easyPaisa": {
    "accountTitle": "John Doe",
    "accountNumber": "03001234567"
  },
  "jazzCash": {
    "accountTitle": "John Doe",
    "accountNumber": "03009876543"
  }
}

Response:
{
  "success": true,
  "message": "Payment accounts updated successfully",
  "data": {
    "easyPaisa": { ... },
    "jazzCash": { ... },
    "updatedAt": "2026-01-22T..."
  }
}
```

### New Admin Endpoints

#### Get Driver Payment Accounts
```http
GET /api/admin/drivers/:driverId/payment-accounts
Authorization: Bearer <admin-token>
```

#### Verify Payment Account
```http
PATCH /api/admin/drivers/:driverId/payment-accounts/verify
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "accountType": "easyPaisa",  // or "jazzCash"
  "notes": "Account verified by checking bank statement"
}
```

#### Reject Payment Account
```http
PATCH /api/admin/drivers/:driverId/payment-accounts/reject
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "accountType": "easyPaisa",  // or "jazzCash"
  "reason": "Invalid account number format"
}
```

## Testing Guide

### Test 1: Driver Dashboard Statistics

**Frontend**: Driver Dashboard

1. Login as a driver
2. Check that earnings and total trips display correctly
3. If no rides today, should show "Rs 0" and "0" trips (not "...")
4. Complete a ride and verify stats update

**Expected Behavior:**
- Stats load within 2-3 seconds
- If error occurs, shows "Rs 0" and "0" instead of infinite loading
- Error logged to console with proper formatting

### Test 2: Payment Account Management

**Driver Side:**

1. Login as driver
2. Navigate to profile/settings
3. Update EasyPaisa/JazzCash account details
4. Verify accounts are saved correctly

**API Test:**
```bash
# Get accounts
curl -X GET http://localhost:3000/api/driver/payment-accounts \
  -H "Authorization: Bearer <driver-token>"

# Update accounts
curl -X PUT http://localhost:3000/api/driver/payment-accounts \
  -H "Authorization: Bearer <driver-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "easyPaisa": {
      "accountTitle": "Test Driver",
      "accountNumber": "03001234567"
    }
  }'
```

### Test 3: Payment Flow After Migration

**Critical Test**: Verify payment request still works

1. Start a ride as commuter
2. Driver completes the ride
3. Commuter should receive payment request with driver's account details
4. Submit payment
5. Verify payment recorded correctly

**Expected Socket Event:**
```javascript
{
  "success": true,
  "ride": { ... },
  "fare": {
    "distanceKm": 5.2,
    "ratePerKm": 30,
    "totalAmount": 156
  },
  "driverPaymentDetails": {
    "easyPaisa": {
      "accountTitle": "Driver Name",
      "accountNumber": "03001234567"
    },
    "jazzCash": {
      "accountTitle": "Driver Name",
      "accountNumber": "03009876543"
    }
  }
}
```

### Test 4: Admin Payment Account Verification

**Admin Dashboard:**

1. Login as admin
2. View driver list
3. Select a driver
4. View payment accounts
5. Verify an account
6. Check verification status updates

**API Test:**
```bash
# View accounts
curl -X GET http://localhost:3000/api/admin/drivers/<driverId>/payment-accounts \
  -H "Authorization: Bearer <admin-token>"

# Verify account
curl -X PATCH http://localhost:3000/api/admin/drivers/<driverId>/payment-accounts/verify \
  -H "Authorization: Bearer <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "accountType": "easyPaisa",
    "notes": "Verified via bank statement"
  }'
```

## Known Issues & Limitations

1. **Existing Drivers**: Drivers who already updated accounts in User model will need their data migrated
2. **Verification Status**: All migrated accounts start as unverified (isVerified: false)
3. **Frontend Updates**: Frontend may need updates to use new endpoints for payment account management

## Support & Troubleshooting

### Issue: Migration script fails with "Driver not found"

**Cause**: Some users with role "driver" don't have corresponding Driver records

**Solution**:
1. Check which users are missing Driver records
2. Create Driver records manually or investigate why they're missing
3. Re-run migration script

### Issue: Dashboard still shows "..."

**Cause**: Backend aggregation query might be incorrect

**Solution**:
1. Check backend logs for errors
2. Verify `matchedWith.driverId` matches auth token `req.user.id`
3. Check Ride model structure
4. Verify `fare` field exists in completed rides

### Issue: Payment flow broken after migration

**Cause**: Socket handler might not find driver payment accounts

**Solution**:
1. Check Driver model has payment accounts
2. Verify socket handler queries Driver model (not User)
3. Check backend logs during ride completion
4. Test driver lookup by userId, email fallbacks

## Contact

For issues or questions, contact the development team or create an issue in the repository.

## Changelog

### 2026-01-22
- Initial migration from User model to Driver model
- Added payment account verification system
- Fixed dashboard statistics query
- Added comprehensive testing guide
