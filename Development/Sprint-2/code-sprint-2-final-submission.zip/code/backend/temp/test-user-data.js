/**
 * Test Script to Check User Data in Database
 * Run this with: node test-user-data.js
 */

import mongoose from "mongoose";
import config from "./src/config/env.config.js";
import User from "./src/models/User.js";
import Driver from "./src/models/Driver.js";
import Ride from "./src/models/Ride.js";
import Payment from "./src/models/Payment.js";

async function testUserData() {
  try {
    // Connect to MongoDB
    await mongoose.connect(config.mongoUri);
    console.log("✅ Connected to MongoDB");

    // Get all users
    const users = await User.find({}).select("userId name email role").limit(5);
    console.log("\n📋 Sample Users:");
    users.forEach(user => {
      console.log(`  - ${user.name} (${user.userId}) - ${user.email} [${user.role}]`);
    });

    // Check specific user if provided
    const testUserId = process.argv[2]; // Get userId from command line
    if (testUserId) {
      console.log(`\n🔍 Checking data for userId: ${testUserId}`);

      const user = await User.findOne({ userId: testUserId });
      if (!user) {
        console.log("❌ User not found");
        return;
      }

      console.log(`✅ User found: ${user.name} (${user.email})`);

      // Check rides
      const rides = await Ride.find({ userId: testUserId });
      console.log(`📍 Rides: ${rides.length} found`);
      if (rides.length > 0) {
        rides.forEach(ride => {
          console.log(`   - ${ride.rideId}: ${ride.status} (${ride.source?.address} → ${ride.destination?.address})`);
        });
      }

      // Check payments
      const payments = await Payment.find({ userId: testUserId });
      console.log(`💰 Payments: ${payments.length} found`);
      if (payments.length > 0) {
        payments.forEach(payment => {
          console.log(`   - ${payment.transactionId || 'No TX ID'}: Rs.${payment.amount} [${payment.status}]`);
        });
      }

      // Check driver info if driver
      if (user.role === "driver") {
        const driver = await Driver.findOne({ userId: testUserId });
        console.log(`🚗 Driver Info: ${driver ? 'Found' : 'Not Found'}`);
        if (driver) {
          console.log(`   - CNIC: ${driver.cnic}`);
          console.log(`   - Status: ${driver.status}`);
          console.log(`   - Total Rides: ${driver.totalRides || 0}`);
        }
      }
    } else {
      console.log("\n💡 Tip: Run with userId to check specific user data");
      console.log("   Example: node test-user-data.js USR-123456");

      // Show counts
      const rideCount = await Ride.countDocuments();
      const paymentCount = await Payment.countDocuments();
      const driverCount = await Driver.countDocuments();

      console.log(`\n📊 Database Totals:`);
      console.log(`   - Total Rides: ${rideCount}`);
      console.log(`   - Total Payments: ${paymentCount}`);
      console.log(`   - Total Drivers: ${driverCount}`);
    }

  } catch (error) {
    console.error("❌ Error:", error.message);
  } finally {
    await mongoose.connection.close();
    console.log("\n✅ Database connection closed");
  }
}

testUserData();
