import emailService from "./src/services/emailService.js";
import dotenv from "dotenv";

dotenv.config();

async function testEmailService() {
  console.log("=== Testing Resend Email Service ===\n");

  try {
    // Test 1: Verify Connection
    console.log("Test 1: Verifying email configuration...");
    const isVerified = await emailService.verifyConnection();
    console.log(`✓ Configuration verified: ${isVerified}\n`);

    // Test 2: Send Verification Email
    console.log("Test 2: Sending verification email...");
    const testEmail = "7726@cch.edu.pk"; // Replace with your test email
    const verificationUrl = "https://yourdomain.com/verify/test123";

    await emailService.sendVerificationEmail(testEmail, verificationUrl);
    console.log(`✓ Verification email sent to ${testEmail}\n`);

    // Test 3: Send OTP Email
    console.log("Test 3: Sending OTP email...");
    const testOTP = "123456";

    await emailService.sendOTP(testEmail, testOTP);
    console.log(`✓ OTP email sent to ${testEmail}\n`);

    // Test 4: Send Password Reset Email
    console.log("Test 4: Sending password reset email...");
    const resetUrl = "https://yourdomain.com/reset/test123";

    await emailService.sendPasswordResetEmail(testEmail, resetUrl);
    console.log(`✓ Password reset email sent to ${testEmail}\n`);

    // Test 5: Send Ride Details Email
    console.log("Test 5: Sending ride details email...");
    const rideDetails = {
      pickup: "123 Main St, City",
      dropoff: "456 Oak Ave, City",
      driverName: "John Doe",
      estimatedArrival: "10 minutes",
      trackingLink: "https://yourdomain.com/track/ride123"
    };

    await emailService.sendRideDetailsEmail(
      testEmail,
      "Jane Smith",
      rideDetails,
      "Trusted Contact"
    );
    console.log(`✓ Ride details email sent to ${testEmail}\n`);

    // Test 6: Send SOS Alert
    console.log("Test 6: Sending SOS alert email...");
    const sosData = {
      commuterName: "Jane Smith",
      commuterEmail: "jane@example.com",
      driverName: "John Doe",
      pickupLocation: "123 Main St, City",
      dropoffLocation: "456 Oak Ave, City",
      triggeredAt: new Date(),
      sosMessage: "Emergency situation - need help immediately!"
    };

    await emailService.sendSOSAlert(testEmail, sosData);
    console.log(`✓ SOS alert email sent to ${testEmail}\n`);

    console.log("=== All Email Tests Completed Successfully! ===");
  } catch (error) {
    console.error("\n❌ Email test failed:");
    console.error("Error:", error.message);
    console.error("\nFull error:", error);
    process.exit(1);
  }
}

// Run the test
testEmailService();
