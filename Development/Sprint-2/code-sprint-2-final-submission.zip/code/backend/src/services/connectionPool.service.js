/**
 * Connection Pool Service
 * Manages active ride requests and connected users in memory
 */

import logger from "../utils/logger.js";
import RideRequest from "../models/RideRequest.js";
import Ride from "../models/Ride.js";

class ConnectionPoolService {
  constructor() {
    // Store all active rides: Map<rideId, RideRequest>
    this.rides = new Map();

    // Store connected users: Map<socketId, userData>
    this.users = new Map();

    logger.info("Connection Pool Service initialized");
  }

  /**
   * Set the Socket.IO instance for broadcasting
   * @param {Server} io - Socket.IO server instance
   */
  setIO(io) {
    this.io = io;
    logger.info("Socket.IO instance attached to ConnectionPoolService");
  }

  /**
   * Add a new ride to the pool
   * @param {Object} rideData - Ride request data
   * @returns {RideRequest} - Created ride request
   */
  addRide(rideData) {
    const ride = new RideRequest(rideData);
    this.rides.set(ride.id, ride);

    logger.info(
      `Ride added to pool: ${ride.id} | From: ${ride.source.address} → To: ${ride.destination.address}`
    );
    logger.info(`Total rides in pool: ${this.rides.size}`);

    return ride;
  }

  /**
   * Remove a ride from the pool
   * @param {string} rideId - Ride ID to remove
   * @returns {boolean} - True if removed, false if not found
   */
  removeRide(rideId) {
    const ride = this.rides.get(rideId);
    if (ride) {
      this.rides.delete(rideId);
      logger.info(`Ride removed from pool: ${rideId}`);
      logger.info(`Total rides in pool: ${this.rides.size}`);
      return true;
    }

    logger.warn(`Attempted to remove non-existent ride: ${rideId}`);
    return false;
  }

  /**
   * Get a specific ride by ID
   * @param {string} rideId - Ride ID
   * @returns {RideRequest|null} - Ride request or null
   */
  getRide(rideId) {
    return this.rides.get(rideId) || null;
  }

  /**
   * Get all rides or filtered rides
   * @param {Object} filters - Optional filters (status, userId, etc.)
   * @returns {Array<RideRequest>} - Array of ride requests
   */
  getRides(filters = {}) {
    let ridesArray = Array.from(this.rides.values());

    // Apply filters
    if (filters.status) {
      ridesArray = ridesArray.filter((ride) => ride.status === filters.status);
    }

    if (filters.userId) {
      ridesArray = ridesArray.filter((ride) => ride.userId === filters.userId);
    }

    // Sort by creation time (newest first)
    ridesArray.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return ridesArray;
  }

  /**
   * Get all pending rides (available for matching)
   * @returns {Array<RideRequest>} - Array of pending ride requests
   */
  getPendingRides() {
    return this.getRides({ status: "pending" });
  }

  /**
   * Match a ride with a driver
   * @param {string} rideId - Ride ID to match
   * @param {Object} driverData - Driver information
   * @returns {RideRequest|null} - Updated ride or null if not found
   */
  matchRide(rideId, driverData) {
    const ride = this.rides.get(rideId);

    if (!ride) {
      logger.warn(`Cannot match non-existent ride: ${rideId}`);
      return null;
    }

    if (ride.status !== "pending") {
      logger.warn(`Cannot match ride ${rideId} with status: ${ride.status}`);
      return null;
    }

    ride.matchWith(driverData);
    logger.info(`Ride matched: ${rideId} with driver: ${driverData.driverId}`);

    return ride;
  }

  /**
   * Save ride to database
   * @param {RideRequest} ride - Ride to save
   * @returns {Promise<void>}
   */
  async saveRideToDatabase(ride) {
    try {
      // Transform coordinates from {latitude, longitude} to [longitude, latitude] for MongoDB
      const transformCoordinates = (coords) => {
        if (!coords) return undefined;

        // If coordinates has latitude/longitude properties (object format)
        if (coords.latitude !== undefined && coords.longitude !== undefined) {
          return {
            type: "Point",
            coordinates: [coords.longitude, coords.latitude] // GeoJSON format: [lng, lat]
          };
        }

        // If it's already an array [lng, lat], wrap it
        if (Array.isArray(coords) && coords.length === 2) {
          return {
            type: "Point",
            coordinates: coords
          };
        }

        return undefined;
      };

      const rideData = {
        rideId: ride.id,
        userId: ride.userId,
        userType: ride.userType,
        userName: ride.userName,
        userEmail: ride.userEmail,
        source: {
          address: ride.source.address,
          coordinates: transformCoordinates(ride.source.coordinates)
        },
        destination: {
          address: ride.destination.address,
          coordinates: transformCoordinates(ride.destination.coordinates)
        },
        status: ride.status,
        matchedWith: ride.matchedWith || undefined,
        sosAlert: ride.sosAlert || undefined,
        completedAt: ride.completedAt || undefined,
        createdAt: ride.createdAt,
        updatedAt: ride.updatedAt
      };

      console.log("\n📦 [DB SAVE] Attempting to save ride to database:");
      console.log("Ride ID:", rideData.rideId);
      console.log("Status:", rideData.status);
      console.log("User:", rideData.userName, `(${rideData.userId})`);
      console.log("Source:", rideData.source.address);
      console.log("Destination:", rideData.destination.address);
      console.log("Full Data:", JSON.stringify(rideData, null, 2));

      const savedRide = await Ride.create(rideData);

      console.log("✅ [DB SAVE] Ride successfully saved!");
      console.log("Saved Ride ID:", savedRide._id);
      console.log("--------------------------------------------\n");

      logger.info(
        `✅ Ride saved to database: ${ride.id} | Status: ${ride.status}`
      );
    } catch (error) {
      console.error("\n❌ [DB SAVE ERROR] Failed to save ride to database!");
      console.error("Ride ID:", ride.id);
      console.error("Error Message:", error.message);
      console.error("Error Stack:", error.stack);
      console.error("--------------------------------------------\n");

      logger.error(`❌ Failed to save ride to database: ${ride.id}`);
      logger.error(`Error: ${error.message}`);
    }
  }

  /**
   * Cancel a ride
   * @param {string} rideId - Ride ID to cancel
   * @returns {RideRequest|null} - Updated ride or null
   */
  cancelRide(rideId) {
    const ride = this.rides.get(rideId);

    if (!ride) {
      logger.warn(`Cannot cancel non-existent ride: ${rideId}`);
      return null;
    }

    ride.updateStatus("cancelled");
    logger.info(`Ride cancelled: ${rideId}`);

    // Save to database before removing from memory
    this.saveRideToDatabase(ride).catch((err) => {
      logger.error(`Error saving cancelled ride to DB: ${err.message}`);
    });

    // Remove from pool after a short delay to allow clients to receive update
    setTimeout(() => {
      this.removeRide(rideId);
    }, 2000);

    return ride;
  }

  /**
   * Complete a ride
   * @param {string} rideId - Ride ID to complete
   * @returns {RideRequest|null} - Updated ride or null
   */
  completeRide(rideId) {
    const ride = this.rides.get(rideId);

    if (!ride) {
      logger.warn(`Cannot complete non-existent ride: ${rideId}`);
      return null;
    }

    if (ride.status !== "matched") {
      logger.warn(`Cannot complete ride ${rideId} with status: ${ride.status}`);
      return null;
    }

    ride.complete();
    logger.info(`Ride completed: ${rideId}`);

    // Save to database before removing from memory
    this.saveRideToDatabase(ride).catch((err) => {
      logger.error(`Error saving completed ride to DB: ${err.message}`);
    });

    // Remove from pool after a short delay to allow clients to receive update
    setTimeout(() => {
      this.removeRide(rideId);
    }, 3000);

    return ride;
  }

  /**
   * Trigger SOS alert for a ride
   * @param {string} rideId - Ride ID
   * @param {Object} sosData - SOS alert data
   * @returns {RideRequest|null} - Updated ride or null
   */
  triggerSOS(rideId, sosData = {}) {
    const ride = this.rides.get(rideId);

    if (!ride) {
      logger.warn(`Cannot trigger SOS for non-existent ride: ${rideId}`);
      return null;
    }

    ride.triggerSOS(sosData);
    logger.warn(`🚨 SOS ALERT triggered for ride: ${rideId}`);
    logger.warn(`SOS Details: ${JSON.stringify(ride.sosAlert, null, 2)}`);

    return ride;
  }

  /**
   * Add a user to the connection pool
   * @param {string} socketId - Socket ID
   * @param {Object} userData - User information
   */
  addUser(socketId, userData) {
    this.users.set(socketId, {
      ...userData,
      socketId,
      connectedAt: new Date().toISOString()
    });

    logger.info(
      `User connected: ${userData.userName || userData.userId} (${socketId})`
    );
    logger.info(`Total connected users: ${this.users.size}`);
  }

  /**
   * Remove a user and their associated rides
   * @param {string} socketId - Socket ID
   */
  removeUser(socketId) {
    const user = this.users.get(socketId);

    if (user) {
      // Find all rides associated with this user
      const userRides = Array.from(this.rides.values()).filter(
        (ride) => ride.socketId === socketId
      );

      // Only cancel PENDING rides when socket disconnects
      // Keep MATCHED rides active so SOS can work via REST API
      const pendingRides = userRides.filter(
        (ride) => ride.status === "pending"
      );
      const activeRides = userRides.filter((ride) => ride.status === "matched");

      pendingRides.forEach((ride) => {
        this.cancelRide(ride.id);
      });

      this.users.delete(socketId);
      logger.info(
        `User disconnected: ${user.userName || user.userId} (${socketId})`
      );
      logger.info(
        `Cancelled ${pendingRides.length} pending ride(s) for disconnected user`
      );
      logger.info(
        `Kept ${activeRides.length} active ride(s) for REST API access`
      );
      logger.info(`Total connected users: ${this.users.size}`);
    }
  }

  /**
   * Get a user by socket ID
   * @param {string} socketId - Socket ID
   * @returns {Object|null} - User data or null
   */
  getUser(socketId) {
    return this.users.get(socketId) || null;
  }

  /**
   * Get statistics about the connection pool
   * @returns {Object} - Pool statistics
   */
  getStats() {
    return {
      totalRides: this.rides.size,
      pendingRides: this.getPendingRides().length,
      matchedRides: this.getRides({ status: "matched" }).length,
      connectedUsers: this.users.size,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Clean up stale rides (rides older than a certain duration)
   * @param {number} maxAgeMinutes - Maximum age in minutes (default: 60)
   * @returns {number} - Number of rides cleaned up
   */
  cleanupStaleRides(maxAgeMinutes = 60) {
    const now = new Date();
    const maxAge = maxAgeMinutes * 60 * 1000; // Convert to milliseconds
    let cleanedCount = 0;

    for (const [rideId, ride] of this.rides) {
      const rideAge = now - new Date(ride.createdAt);

      if (rideAge > maxAge) {
        logger.info(
          `Cleaning up stale ride: ${rideId} (Age: ${Math.round(rideAge / 60000)} minutes)`
        );

        // Save to database if matched/completed
        if (ride.status === "matched" || ride.status === "completed") {
          this.saveRideToDatabase(ride).catch((err) => {
            logger.error(`Error saving stale ride to DB: ${err.message}`);
          });
        }

        this.rides.delete(rideId);
        cleanedCount++;
      }
    }

    if (cleanedCount > 0) {
      logger.info(`Cleaned up ${cleanedCount} stale ride(s)`);
    }

    return cleanedCount;
  }

  /**
   * Clear all rides from the pool (use with caution!)
   * @returns {number} - Number of rides cleared
   */
  clearAllRides() {
    const count = this.rides.size;
    this.rides.clear();
    logger.warn(`⚠️  Cleared all ${count} rides from connection pool`);
    return count;
  }
}

// Export singleton instance
export default new ConnectionPoolService();
