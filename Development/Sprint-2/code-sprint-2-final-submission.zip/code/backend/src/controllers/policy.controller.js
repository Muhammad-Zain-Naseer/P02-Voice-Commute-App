import Policy from "../models/Policy.js";
import logger from "../utils/logger.js";
import connectionPoolService from "../services/connectionPool.service.js";

// Send/broadcast policy update
export const sendPolicyUpdate = async (req, res, next) => {
  try {
    const { title, message, category, severity, targetAudience, expiresAt } = req.body;
    const senderId = req.user.userId;
    const senderName = req.user.name;

    // Validate inputs
    if (!title || !message) {
      return res.status(400).json({
        success: false,
        error: "Title and message are required"
      });
    }

    // Validate and sanitize inputs
    const validSeverities = ['low', 'medium', 'high', 'critical'];
    const safeSeverity = validSeverities.includes(severity) ? severity : 'medium';

    const validAudiences = ['all', 'drivers', 'commuters'];
    const safeAudience = validAudiences.includes(targetAudience) ? targetAudience : 'all';

    const validCategories = ['general', 'safety', 'pricing', 'terms', 'privacy', 'other'];
    const safeCategory = validCategories.includes(category) ? category : 'general';

    // Prepare policy payload
    const policyPayload = {
      title,
      message,
      category: safeCategory,
      severity: safeSeverity,
      senderId,
      senderName,
      targetAudience: safeAudience,
      sentAt: new Date(),
      expiresAt: expiresAt ? new Date(expiresAt) : null
    };

    // Save to database
    const policy = await Policy.create(policyPayload);

    logger.info(`Policy update sent by ${senderName} (${senderId}): ${title}`);

    // Broadcast to users via Socket.IO
    const io = connectionPoolService.io;
    if (io) {
      const broadcastData = {
        _id: policy._id,
        title: policy.title,
        message: policy.message,
        category: policy.category,
        severity: policy.severity,
        targetAudience: policy.targetAudience,
        sentAt: policy.sentAt,
        senderName: policy.senderName,
        expiresAt: policy.expiresAt
      };

      // Broadcast to all or specific audience
      io.emit("admin:policy_update", broadcastData);

      logger.info(`Policy update broadcasted to ${safeAudience} users via Socket.IO`);
    }

    res.status(201).json({
      success: true,
      message: "Policy update broadcasted successfully",
      data: policy
    });
  } catch (error) {
    logger.error("Error sending policy update:", error);
    next(error);
  }
};

// Get policy history (admin only)
export const getPolicyHistory = async (req, res, next) => {
  try {
    const { limit = 50, active = null } = req.query;

    const query = {};
    if (active !== null) {
      query.isActive = active === 'true';
    }

    const policies = await Policy.find(query)
      .sort({ sentAt: -1 })
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: policies.length,
      data: policies
    });
  } catch (error) {
    logger.error("Error getting policy history:", error);
    next(error);
  }
};

// Get active policies (public for users)
export const getActivePolicies = async (req, res, next) => {
  try {
    const now = new Date();

    const policies = await Policy.find({
      isActive: true,
      $or: [
        { expiresAt: null },
        { expiresAt: { $gt: now } }
      ]
    })
    .sort({ sentAt: -1 })
    .limit(20);

    res.status(200).json({
      success: true,
      count: policies.length,
      data: policies
    });
  } catch (error) {
    logger.error("Error getting active policies:", error);
    next(error);
  }
};

// Deactivate a policy (admin only)
export const deactivatePolicy = async (req, res, next) => {
  try {
    const { policyId } = req.params;

    const policy = await Policy.findByIdAndUpdate(
      policyId,
      { isActive: false },
      { new: true }
    );

    if (!policy) {
      return res.status(404).json({
        success: false,
        error: "Policy not found"
      });
    }

    logger.info(`Policy ${policyId} deactivated by ${req.user.name}`);

    res.status(200).json({
      success: true,
      message: "Policy deactivated successfully",
      data: policy
    });
  } catch (error) {
    logger.error("Error deactivating policy:", error);
    next(error);
  }
};
