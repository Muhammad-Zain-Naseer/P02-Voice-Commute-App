import Ride from "../models/Ride.js";
import Payment from "../models/Payment.js";
import User from "../models/User.js";
import { Parser } from "json2csv";
import logger from "../utils/logger.js";

class AnalyticsController {

    /**
     * GET /api/admin/analytics/dashboard
     * Fetches aggregated data for charts.
     */
    async getDashboardStats(req, res, next) {
        try {
            //  Audit Log (Repudiation Mitigation)
            logger.info(`[AUDIT] Admin ${req.user.email} accessed analytics dashboard from IP ${req.ip}`);

            const { timeRange } = req.query; // 'week', 'month', 'year'

            const now = new Date();
            let startDate = new Date();
            let groupFormat = "%Y-%m-%d";

            if (timeRange === 'month') {
                startDate.setMonth(now.getMonth() - 1);
                groupFormat = "%Y-%m-%d";
            }
            else if (timeRange === 'year') {
                startDate.setFullYear(now.getFullYear() - 1);
                groupFormat = "%Y-%m";
            }
            else {
                startDate.setDate(now.getDate() - 7);
                groupFormat = "%Y-%m-%d";
            }

            const matchDate = { $match: { createdAt: { $gte: startDate } } };

            //  Parallel Aggregation
            const [revenueData, rideStats, userGrowth] = await Promise.all([
                Payment.aggregate([
                    { $match: { createdAt: { $gte: startDate }, status: 'verified' } },
                    {
                        $group: {
                            _id: { $dateToString: { format: groupFormat, date: "$createdAt" } },
                            total: { $sum: "$amount" }
                        }
                    },
                    { $sort: { _id: 1 } }
                ]),

                Ride.aggregate([
                    matchDate,
                    { $group: { _id: "$status", count: { $sum: 1 } } }
                ]),

                User.countDocuments({ createdAt: { $gte: startDate } })
            ]);

            res.status(200).json({
                success: true,
                data: {
                    revenueChart: revenueData,
                    rideStatusChart: rideStats,
                    newUsers: userGrowth,
                    timeRange
                }
            });

        } catch (error) {
            logger.error(`[ANALYTICS] Error fetching stats: ${error.message}`);
            next(error);
        }
    }

    /**
     * GET /api/admin/analytics/export
     * Generates CSV.
     */
    async exportReport(req, res, next) {
        try {
            const { type } = req.query; // 'financial', 'rides'

            //  Audit Log
            logger.info(`[AUDIT] Admin ${req.user.email} EXPORTED ${type} report from IP ${req.ip}`);

            let fields = [];
            let data = [];

            if (type === 'financial') {
                fields = ['transactionId', 'amount', 'method', 'status', 'createdAt', 'driverId'];
                data = await Payment.find().sort({ createdAt: -1 }).limit(1000).lean();
            } else if (type === 'rides') {
                fields = ['rideId', 'status', 'source.address', 'destination.address', 'amount', 'createdAt'];
                data = await Ride.find().sort({ createdAt: -1 }).limit(1000).lean();
            } else {
                return res.status(400).json({ error: "Invalid export type" });
            }

            const json2csvParser = new Parser({ fields });
            const csv = json2csvParser.parse(data);

            res.header('Content-Type', 'text/csv');
            res.attachment(`${type}-report-${Date.now()}.csv`);
            return res.send(csv);

        } catch (error) {
            logger.error(`[EXPORT] Failed: ${error.message}`);
            next(error);
        }
    }
}

export default new AnalyticsController();