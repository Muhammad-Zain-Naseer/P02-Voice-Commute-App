import Driver from "../models/Driver.js";
import User from "../models/User.js";
import Ride from "../models/Ride.js";
import Payment from "../models/Payment.js";
import { AppError } from "../utils/appError.js";
import logger from "../utils/logger.js";
import connectionPoolService from "../services/connectionPool.service.js";

const adminController = {
  // ==================== DASHBOARD STATISTICS ====================
  
  async getOverviewStats(req, res) {
    try {
      const poolStats = connectionPoolService.getStats();

      const [
        totalUsers,
        totalDrivers,
        totalRides,
        completedRides,
        revenueStats,
        pendingPayments,
        approvedDrivers,
        pendingDrivers
      ] = await Promise.all([
        User.countDocuments({ role: { $in: ["commuter", "driver"] } }),
        Driver.countDocuments(),
        Ride.countDocuments(),
        Ride.countDocuments({ status: "completed" }),
        Payment.aggregate([
          { $match: { status: "verified" } },
          {
            $group: {
              _id: null,
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" }
            }
          }
        ]),
        Payment.countDocuments({ status: "pending" }),
        Driver.countDocuments({ status: "approved" }),
        Driver.countDocuments({ status: "pending" })
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalUsers,
          totalDrivers,
          totalRides,
          completedRides,
          adminRevenue: revenueStats[0]?.adminRevenue || 0,
          driverEarnings: revenueStats[0]?.driverEarnings || 0,
          pendingPayments,
          approvedDrivers,
          pendingDrivers,
          activeRides: poolStats.totalRides,
          pendingRidesNow: poolStats.pendingRides,
          matchedRidesNow: poolStats.matchedRides,
          connectedUsers: poolStats.connectedUsers,
          timestamp: new Date()
        }
      });
    } catch (error) {
      logger.error("Error in getOverviewStats:", error);
      throw new AppError("Failed to fetch overview statistics", 500);
    }
  },

  async getUserStats(req, res) {
    try {
      const [
        totalUsers,
        verifiedUsers,
        unverifiedUsers,
        commuters,
        driversWithAccount,
        usersWithTrustedContacts,
        recentUsers
      ] = await Promise.all([
        User.countDocuments(),
        User.countDocuments({ isVerified: true }),
        User.countDocuments({ isVerified: false }),
        User.countDocuments({ role: "commuter" }),
        User.countDocuments({ role: "driver" }),
        User.countDocuments({ "trustedContacts.0": { $exists: true } }),
        User.find()
          .sort({ createdAt: -1 })
          .limit(7)
          .select("name email role isVerified createdAt lastLogin")
      ]);

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const userGrowth = await User.aggregate([
        { $match: { createdAt: { $gte: sevenDaysAgo } } },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { _id: 1 } }
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalUsers,
          verifiedUsers,
          unverifiedUsers,
          commuters,
          driversWithAccount,
          usersWithTrustedContacts,
          recentUsers,
          userGrowth
        }
      });
    } catch (error) {
      logger.error("Error in getUserStats:", error);
      throw new AppError("Failed to fetch user statistics", 500);
    }
  },

  async getDriverStats(req, res) {
    try {
      const [
        totalDrivers,
        pendingDrivers,
        approvedDrivers,
        rejectedDrivers,
        suspendedDrivers,
        availableDrivers,
        topDrivers
      ] = await Promise.all([
        Driver.countDocuments(),
        Driver.countDocuments({ status: "pending" }),
        Driver.countDocuments({ status: "approved" }),
        Driver.countDocuments({ status: "rejected" }),
        Driver.countDocuments({ status: "suspended" }),
        Driver.countDocuments({ isAvailable: true, status: "approved" }),
        Driver.find({ status: "approved" })
          .sort({ averageRating: -1, totalRides: -1 })
          .limit(10)
          .select(
            "name email averageRating totalRides isAvailable vehicle.model"
          )
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalDrivers,
          pendingDrivers,
          approvedDrivers,
          rejectedDrivers,
          suspendedDrivers,
          availableDrivers,
          topDrivers
        }
      });
    } catch (error) {
      logger.error("Error in getDriverStats:", error);
      throw new AppError("Failed to fetch driver statistics", 500);
    }
  },

  async getRideStats(req, res) {
    try {
      const poolStats = connectionPoolService.getStats();

      const [
        totalRides,
        completedRides,
        cancelledRides,
        sosIncidents,
        avgRating
      ] = await Promise.all([
        Ride.countDocuments(),
        Ride.countDocuments({ status: "completed" }),
        Ride.countDocuments({ status: "cancelled" }),
        Ride.countDocuments({ "sosAlert.triggeredAt": { $exists: true } }),
        Ride.aggregate([
          { $match: { rating: { $ne: null } } },
          { $group: { _id: null, avg: { $avg: "$rating" } } }
        ])
      ]);

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const rideTrends = await Ride.aggregate([
        { $match: { createdAt: { $gte: sevenDaysAgo } } },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
            total: { $sum: 1 },
            completed: {
              $sum: { $cond: [{ $eq: ["$status", "completed"] }, 1, 0] }
            },
            cancelled: {
              $sum: { $cond: [{ $eq: ["$status", "cancelled"] }, 1, 0] }
            }
          }
        },
        { $sort: { _id: 1 } }
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalRides,
          pendingRides: poolStats.pendingRides,
          matchedRides: poolStats.matchedRides,
          completedRides,
          cancelledRides,
          sosIncidents,
          averageRating: avgRating[0]?.avg || 0,
          rideTrends,
          activeRidesNow: poolStats.totalRides,
          connectedUsers: poolStats.connectedUsers
        }
      });
    } catch (error) {
      logger.error("Error in getRideStats:", error);
      throw new AppError("Failed to fetch ride statistics", 500);
    }
  },

  async getPaymentStats(req, res) {
    try {
      const [
        totalPayments,
        pendingPayments,
        verifiedPayments,
        rejectedPayments,
        revenueStats,
        paymentMethods,
        revenueByDay
      ] = await Promise.all([
        Payment.countDocuments(),
        Payment.countDocuments({ status: "pending" }),
        Payment.countDocuments({ status: "verified" }),
        Payment.countDocuments({ status: "rejected" }),
        Payment.aggregate([
          { $match: { status: "verified" } },
          {
            $group: {
              _id: null,
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" }
            }
          }
        ]),
        Payment.aggregate([
          {
            $group: {
              _id: "$paymentMethod",
              count: { $sum: 1 },
              total: { $sum: "$amount" }
            }
          }
        ]),
        Payment.aggregate([
          {
            $match: {
              status: "verified",
              createdAt: {
                $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
              }
            }
          },
          {
            $group: {
              _id: {
                $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
              },
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" },
              count: { $sum: 1 }
            }
          },
          { $sort: { _id: 1 } }
        ])
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalPayments,
          pendingPayments,
          verifiedPayments,
          rejectedPayments,
          adminRevenue: revenueStats[0]?.adminRevenue || 0,
          driverEarnings: revenueStats[0]?.driverEarnings || 0,
          paymentMethods,
          revenueByDay
        }
      });
    } catch (error) {
      logger.error("Error in getPaymentStats:", error);
      throw new AppError("Failed to fetch payment statistics", 500);
    }
  },

  // ==================== USER MANAGEMENT ====================
  
  async getUsers(req, res) {
    try {
      const { role, isVerified, limit = 50, page = 1 } = req.query;
      const query = {};

      if (role) query.role = role;
      if (isVerified !== undefined) query.isVerified = isVerified === "true";

      const users = await User.find(query)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit))
        .select("-pin -verificationToken -verificationTokenExpiry");

      const total = await User.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          users,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getUsers:", error);
      throw new AppError("Failed to fetch users", 500);
    }
  },

  async getUserDetails(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId }).select(
        "-pin -verificationToken -verificationTokenExpiry"
      );

      if (!user) {
        throw new AppError("User not found", 404);
      }

      res.status(200).json({
        success: true,
        data: user
      });
    } catch (error) {
      logger.error("Error in getUserDetails:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to fetch user details", 500);
    }
  },

  async verifyUser(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOneAndUpdate(
        { userId },
        {
          isVerified: true,
          verificationToken: undefined,
          verificationTokenExpiry: undefined
        },
        { new: true }
      ).select("-pin");

      if (!user) {
        throw new AppError("User not found", 404);
      }

      res.status(200).json({
        success: true,
        message: "User verified successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in verifyUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to verify user", 500);
    }
  },

  /**
   * ACTIVATE USER ACCOUNT
   * Activate a deactivated user account
   */
  async activateUser(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      if (user.isActive !== false) {
        throw new AppError("User is already active", 400);
      }

      user.isActive = true;
      user.deactivationReason = undefined;
      await user.save();

      res.status(200).json({
        success: true,
        message: "User account activated successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in activateUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to activate user", 500);
    }
  },

  /**
   * DEACTIVATE USER ACCOUNT
   * Temporarily deactivate user account
   */
  async deactivateUser(req, res) {
    try {
      const { userId } = req.params;
      const { reason } = req.body;

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      if (user.role === "admin") {
        throw new AppError("Cannot deactivate admin account", 403);
      }

      if (user.isActive === false) {
        throw new AppError("User is already deactivated", 400);
      }

      user.isActive = false;
      user.deactivationReason = reason || "Deactivated by admin";
      await user.save();

      res.status(200).json({
        success: true,
        message: "User account deactivated successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in deactivateUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to deactivate user", 500);
    }
  },

  /**
   * SUSPEND USER ACCOUNT
   * Suspend user account for policy violations
   */
  async suspendUser(req, res) {
    try {
      const { userId } = req.params;
      const { reason } = req.body;
      const adminId = req.user._id;

      if (!reason || reason.trim().length === 0) {
        throw new AppError("Suspension reason is required", 400);
      }

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      if (user.role === "admin") {
        throw new AppError("Cannot suspend admin account", 403);
      }

      if (user.isSuspended) {
        throw new AppError("User is already suspended", 400);
      }

      user.isSuspended = true;
      user.suspensionReason = reason;
      user.suspendedBy = adminId;
      user.suspendedAt = new Date();
      await user.save();

      res.status(200).json({
        success: true,
        message: "User account suspended successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in suspendUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to suspend user", 500);
    }
  },

  /**
   * UNSUSPEND USER ACCOUNT
   * Remove suspension from user account
   */
  async unsuspendUser(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      if (!user.isSuspended) {
        throw new AppError("User is not suspended", 400);
      }

      user.isSuspended = false;
      user.suspensionReason = undefined;
      user.suspendedBy = undefined;
      user.suspendedAt = undefined;
      await user.save();

      res.status(200).json({
        success: true,
        message: "User account unsuspended successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in unsuspendUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to unsuspend user", 500);
    }
  },

  /**
   * DELETE USER ACCOUNT
   * Permanently delete a user account
   */
  async deleteUser(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      if (user.role === "admin") {
        throw new AppError("Cannot delete admin account", 403);
      }

      // If user is a driver, also delete the driver record
      if (user.role === "driver") {
        await Driver.findOneAndDelete({ userId: user.userId });
      }

      // Delete associated data
      await Ride.deleteMany({ userId: user.userId });
      await Payment.deleteMany({ userId: user.userId });

      await User.findOneAndDelete({ userId });

      res.status(200).json({
        success: true,
        message: "User account deleted successfully"
      });
    } catch (error) {
      logger.error("Error in deleteUser:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to delete user", 500);
    }
  },

  /**
   * UPDATE USER ROLE
   * Change user role (commuter, driver, admin)
   */
  async updateUserRole(req, res) {
    try {
      const { userId } = req.params;
      const { role } = req.body;

      if (!["commuter", "driver", "admin"].includes(role)) {
        throw new AppError("Invalid role. Must be one of: commuter, driver, admin", 400);
      }

      const user = await User.findOne({ userId });

      if (!user) {
        throw new AppError("User not found", 404);
      }

      const oldRole = user.role;
      user.role = role;
      await user.save();

      res.status(200).json({
        success: true,
        message: `User role updated from ${oldRole} to ${role}`,
        data: user
      });
    } catch (error) {
      logger.error("Error in updateUserRole:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to update user role", 500);
    }
  },

  /**
   * GET USER ACTIVITY
   * Get user's activity history including rides and payments
   */
  async getUserActivity(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId }).select(
        "-pin -verificationToken -verificationTokenExpiry"
      );

      if (!user) {
        throw new AppError("User not found", 404);
      }

      logger.info(`Fetching activity for userId: ${user.userId}, role: ${user.role}`);

      let rides = [];
      let payments = [];
      let driverInfo = null;

      if (user.role === "driver") {
        // For drivers, query rides where they were the matched driver
        logger.info(`Querying driver rides for userId: ${user.userId}`);

        const driverRides = await Ride.find({
          "matchedWith.driverId": user.userId,
          status: "completed"
        })
          .sort({ completedAt: -1 })
          .limit(20)
          .lean();

        logger.info(`Found ${driverRides.length} completed rides for driver ${user.userId}`);

        // Fetch payment amounts for each ride (same logic as earnings endpoint)
        rides = await Promise.all(
          driverRides.map(async (ride) => {
            const payment = await Payment.findOne({ rideId: ride.rideId }).lean();
            return {
              ...ride,
              amount: payment ? payment.amount : 0,
              paymentMethod: payment ? payment.paymentMethod : "N/A"
            };
          })
        );

        // Get driver payments
        payments = await Payment.find({
          rideId: { $in: driverRides.map(r => r.rideId) }
        })
          .sort({ createdAt: -1 })
          .limit(20)
          .select("transactionId amount status paymentMethod createdAt rideId")
          .lean();

        // Get driver info
        driverInfo = await Driver.findOne({ userId: user.userId }).lean();

      } else {
        // For commuters, query rides where they are the passenger
        logger.info(`Querying commuter rides for userId: ${user.userId}`);

        rides = await Ride.find({ userId: user.userId })
          .sort({ createdAt: -1 })
          .limit(20)
          .select("rideId status source destination fare rating createdAt")
          .lean();

        payments = await Payment.find({ userId: user.userId })
          .sort({ createdAt: -1 })
          .limit(20)
          .select("transactionId amount status paymentMethod createdAt rideId")
          .lean();
      }

      logger.info(`Found ${rides?.length || 0} rides, ${payments?.length || 0} payments for user ${user.userId}`);

      res.status(200).json({
        success: true,
        data: {
          user,
          rides: rides || [],
          payments: payments || [],
          driverInfo: driverInfo || null
        }
      });
    } catch (error) {
      logger.error("Error in getUserActivity:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to fetch user activity", 500);
    }
  },

  /**
   * SEARCH USERS
   * Advanced search for users by email, name, or userId
   */
  async searchUsers(req, res) {
    try {
      const { query, limit = 20, page = 1 } = req.query;

      if (!query || query.trim().length === 0) {
        throw new AppError("Search query is required", 400);
      }

      const searchRegex = { $regex: query, $options: "i" };
      const searchQuery = {
        $or: [
          { name: searchRegex },
          { email: searchRegex },
          { userId: searchRegex }
        ]
      };

      const users = await User.find(searchQuery)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit))
        .select("-pin -verificationToken -verificationTokenExpiry");

      const total = await User.countDocuments(searchQuery);

      res.status(200).json({
        success: true,
        data: {
          users,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in searchUsers:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to search users", 500);
    }
  },

  // ==================== DRIVER VERIFICATION BY ADMIN ====================
  
  /**
   * Get all drivers with filters
   * Supports: status, search, pagination
   */
  async getDrivers(req, res) {
    try {
      const {
        page = 1,
        limit = 20,
        status,
        search
      } = req.query;

      const query = {};

      if (status) {
        query.status = status;
      }

      if (search) {
        query.$or = [
          { name: { $regex: search, $options: "i" } },
          { phone: { $regex: search, $options: "i" } },
          { cnic: { $regex: search, $options: "i" } },
          { drivingLicense: { $regex: search, $options: "i" } },
          { "vehicle.registrationNumber": { $regex: search, $options: "i" } }
        ];
      }

      const skip = (parseInt(page) - 1) * parseInt(limit);

      const drivers = await Driver.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .populate("verifiedBy", "name email");

      const total = await Driver.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          drivers,
          pagination: {
            total,
            page: parseInt(page),
            limit: parseInt(limit),
            pages: Math.ceil(total / parseInt(limit))
          }
        }
      });
    } catch (error) {
      logger.error("Get drivers error:", error);
      throw new AppError("Failed to fetch drivers", 500);
    }
  },

  /**
   * Get single driver details
   */
  async getDriverDetails(req, res) {
    try {
      const { driverId } = req.params;

      const driver = await Driver.findById(driverId)
        .populate("verifiedBy", "name email")
        .populate("verificationHistory.adminId", "name email");

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      res.status(200).json({
        success: true,
        data: { driver }
      });
    } catch (error) {
      logger.error("Get driver details error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to fetch driver details", 500);
    }
  },

  /**
   * APPROVE DRIVER
   * Admin verifies CNIC number, License number, Vehicle Registration number + photo
   */
  async approveDriver(req, res) {
    try {
      const { driverId } = req.params;
      const adminId = req.user._id;

      const driver = await Driver.findById(driverId);

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      if (driver.status === "approved") {
        throw new AppError("Driver is already approved", 400);
      }

      // Validate that all required verification info is present
      if (!driver.cnic || !driver.drivingLicense || 
          !driver.vehicle?.registrationNumber || !driver.vehicle?.registrationPhoto) {
        throw new AppError("Driver has incomplete verification information", 400);
      }

      driver.status = "approved";
      driver.verifiedBy = adminId;
      driver.verifiedAt = new Date();
      driver.approvalDate = new Date();
      driver.rejectionReason = undefined;
      driver.resubmissionNotes = undefined;

      driver.verificationHistory.push({
        action: "approved",
        adminId,
        timestamp: new Date()
      });

      await driver.save();

      res.status(200).json({
        success: true,
        message: "Driver approved successfully",
        data: { driver }
      });
    } catch (error) {
      logger.error("Approve driver error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to approve driver", 500);
    }
  },

  /**
   * REJECT DRIVER
   * Admin finds CNIC/License/Registration invalid and rejects
   */
  async rejectDriver(req, res) {
    try {
      const { driverId } = req.params;
      const { reason } = req.body;
      const adminId = req.user._id;

      if (!reason || reason.trim().length === 0) {
        throw new AppError("Rejection reason is required", 400);
      }

      const driver = await Driver.findById(driverId);

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      driver.status = "rejected";
      driver.verifiedBy = adminId;
      driver.verifiedAt = new Date();
      driver.rejectionReason = reason;

      driver.verificationHistory.push({
        action: "rejected",
        adminId,
        reason,
        timestamp: new Date()
      });

      await driver.save();

      res.status(200).json({
        success: true,
        message: "Driver rejected successfully",
        data: { driver }
      });
    } catch (error) {
      logger.error("Reject driver error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to reject driver", 500);
    }
  },

  /**
   * REQUEST RESUBMISSION (Info unclear/incomplete)
   * Admin requests driver to resubmit information
   */
  async requestResubmission(req, res) {
    try {
      const { driverId } = req.params;
      const { notes } = req.body;
      const adminId = req.user._id;

      if (!notes || notes.trim().length === 0) {
        throw new AppError("Resubmission notes are required", 400);
      }

      const driver = await Driver.findById(driverId);

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      driver.status = "resubmission_required";
      driver.verifiedBy = adminId;
      driver.verifiedAt = new Date();
      driver.resubmissionNotes = notes;

      driver.verificationHistory.push({
        action: "resubmission_required",
        adminId,
        reason: notes,
        timestamp: new Date()
      });

      await driver.save();

      res.status(200).json({
        success: true,
        message: "Resubmission requested successfully",
        data: { driver }
      });
    } catch (error) {
      logger.error("Request resubmission error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to request resubmission", 500);
    }
  },

  /**
   * SUSPEND DRIVER (Forged documents detected)
   * Suspend driver account and flag for investigation
   */
  async suspendDriver(req, res) {
    try {
      const { driverId } = req.params;
      const { reason } = req.body;
      const adminId = req.user._id;

      if (!reason || reason.trim().length === 0) {
        throw new AppError("Suspension reason is required", 400);
      }

      const driver = await Driver.findById(driverId);

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      driver.status = "suspended";
      driver.suspensionReason = reason;

      driver.verificationHistory.push({
        action: "suspended",
        adminId,
        reason,
        timestamp: new Date()
      });

      await driver.save();

      res.status(200).json({
        success: true,
        message: "Driver suspended successfully. Account flagged for investigation.",
        data: { driver }
      });
    } catch (error) {
      logger.error("Suspend driver error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to suspend driver", 500);
    }
  },

  /**
   * REACTIVATE DRIVER
   * Reactivate a suspended driver
   */
  async reactivateDriver(req, res) {
    try {
      const { driverId } = req.params;
      const adminId = req.user._id;

      const driver = await Driver.findById(driverId);

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      if (driver.status !== "suspended") {
        throw new AppError("Driver is not suspended", 400);
      }

      driver.status = "approved";
      driver.suspensionReason = undefined;

      driver.verificationHistory.push({
        action: "reactivated",
        adminId,
        timestamp: new Date()
      });

      await driver.save();

      res.status(200).json({
        success: true,
        message: "Driver reactivated successfully",
        data: { driver }
      });
    } catch (error) {
      logger.error("Reactivate driver error:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to reactivate driver", 500);
    }
  },

  /**
   * Get verification statistics for admin dashboard
   */
  async getVerificationStats(req, res) {
    try {
      const totalDrivers = await Driver.countDocuments();
      const verifiedDrivers = await Driver.countDocuments({ isVerified: true });
      
      const statusStats = await Driver.aggregate([
        {
          $group: {
            _id: "$status",
            count: { $sum: 1 }
          }
        }
      ]);

      const pendingVerification = await Driver.countDocuments({ status: "pending" });
      const awaitingResubmission = await Driver.countDocuments({ status: "resubmission_required" });

      const recentVerifications = await Driver.find({
        isVerified: true
      })
        .sort({ verifiedAt: -1 })
        .limit(10)
        .select("name phone cnic status verifiedAt isVerified")
        .populate("verifiedBy", "name email");

      res.status(200).json({
        success: true,
        data: {
          totalDrivers,
          verifiedDrivers,
          pendingVerification,
          awaitingResubmission,
          statusBreakdown: statusStats,
          recentVerifications
        }
      });
    } catch (error) {
      logger.error("Get verification stats error:", error);
      throw new AppError("Failed to fetch verification statistics", 500);
    }
  },

  /**
   * Legacy method for backward compatibility
   */
  async updateDriverStatus(req, res) {
    try {
      const { driverId } = req.params;
      const { status, rejectionReason } = req.body;

      if (!["pending", "approved", "rejected", "suspended"].includes(status)) {
        throw new AppError("Invalid status", 400);
      }

      const updateData = { status };

      if (status === "approved") {
        updateData.isVerified = true;
        updateData.approvalDate = new Date();
      }

      if (status === "rejected" && rejectionReason) {
        updateData.rejectionReason = rejectionReason;
      }

      const driver = await Driver.findByIdAndUpdate(
        driverId,
        updateData,
        { new: true }
      );

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      res.status(200).json({
        success: true,
        message: "Driver status updated successfully",
        data: driver
      });
    } catch (error) {
      logger.error("Error in updateDriverStatus:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to update driver status", 500);
    }
  },

  // ==================== RIDE MANAGEMENT ====================

  async getActiveTrips(req, res) {
    try {
      const rides = connectionPoolService
        .getRides()
        .filter((ride) => ride.status === "pending" || ride.status === "matched")
        .map((ride) => ride.toJSON());

      res.status(200).json({
        success: true,
        data: {
          trips: rides,
          count: rides.length
        }
      });
    } catch (error) {
      logger.error("Error in getActiveTrips:", error);
      throw new AppError("Failed to fetch active trips", 500);
    }
  },
  
  async getRides(req, res) {
    try {
      const { status, userId, limit = 50, page = 1 } = req.query;
      const query = {};

      if (status) query.status = status;
      if (userId) query.userId = userId;

      const rides = await Ride.find(query)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Ride.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          rides,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getRides:", error);
      throw new AppError("Failed to fetch rides", 500);
    }
  },

  async getRideDetails(req, res) {
    try {
      const { rideId } = req.params;

      const ride = await Ride.findOne({ rideId });

      if (!ride) {
        throw new AppError("Ride not found", 404);
      }

      res.status(200).json({
        success: true,
        data: ride
      });
    } catch (error) {
      logger.error("Error in getRideDetails:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to fetch ride details", 500);
    }
  },

  // ==================== PAYMENT MANAGEMENT ====================
  
  async getPendingPayments(req, res) {
    try {
      const { limit = 50, page = 1 } = req.query;

      const payments = await Payment.find({ status: "pending" })
        .sort({ submittedAt: 1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Payment.countDocuments({ status: "pending" });

      res.status(200).json({
        success: true,
        data: {
          payments,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getPendingPayments:", error);
      throw new AppError("Failed to fetch pending payments", 500);
    }
  },

  async verifyPayment(req, res) {
    try {
      const { paymentId } = req.params;
      const { notes } = req.body;

      const payment = await Payment.findById(paymentId);

      if (!payment) {
        throw new AppError("Payment not found", 404);
      }

// Calculate commission (20% to admin, 80% to driver)
      const commissionRate = 0.2;
      const adminCommission = Math.round(payment.amount * commissionRate);
      const driverEarnings = payment.amount - adminCommission;

      payment.status = "verified";
      payment.verifiedAt = new Date();
      payment.verifiedBy = req.user._id;
      payment.notes = notes;
      payment.adminCommission = adminCommission;
      payment.driverEarnings = driverEarnings;
      payment.commissionRate = commissionRate;

      await payment.save();

      res.status(200).json({
        success: true,
        message: "Payment verified successfully",
        data: payment
      });
    } catch (error) {
      logger.error("Error in verifyPayment:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to verify payment", 500);
    }
  },

  async rejectPayment(req, res) {
    try {
      const { paymentId } = req.params;
      const { notes } = req.body;

      const payment = await Payment.findByIdAndUpdate(
        paymentId,
        {
          status: "rejected",
          verifiedAt: new Date(),
          verifiedBy: req.user._id,
          notes
        },
        { new: true }
      );

      if (!payment) {
        throw new AppError("Payment not found", 404);
      }

      res.status(200).json({
        success: true,
        message: "Payment rejected",
        data: payment
      });
    } catch (error) {
      logger.error("Error in rejectPayment:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to reject payment", 500);
    }
  },

  // ==================== DRIVER PAYMENT ACCOUNT MANAGEMENT ====================

  /**
   * Get driver's payment accounts
   * GET /api/admin/drivers/:driverId/payment-accounts
   */
  async getDriverPaymentAccounts(req, res) {
    try {
      const { driverId } = req.params;

      const driver = await Driver.findOne({ userId: driverId });

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      res.status(200).json({
        success: true,
        data: {
          easyPaisa: driver.paymentAccounts?.easyPaisa || {},
          jazzCash: driver.paymentAccounts?.jazzCash || {},
          updatedAt: driver.paymentAccountsUpdatedAt
        }
      });
    } catch (error) {
      logger.error("Error in getDriverPaymentAccounts:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to fetch driver payment accounts", 500);
    }
  },

  /**
   * Verify driver payment account
   * PATCH /api/admin/drivers/:driverId/payment-accounts/verify
   */
  async verifyPaymentAccount(req, res) {
    try {
      const { driverId } = req.params;
      const { accountType, notes } = req.body;

      if (!["easyPaisa", "jazzCash"].includes(accountType)) {
        throw new AppError("Invalid account type. Must be 'easyPaisa' or 'jazzCash'", 400);
      }

      const driver = await Driver.findOne({ userId: driverId });

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      // Initialize paymentAccounts if not exists
      if (!driver.paymentAccounts) {
        driver.paymentAccounts = { easyPaisa: {}, jazzCash: {} };
      }

      // Verify the specified account
      if (accountType === "easyPaisa") {
        driver.paymentAccounts.easyPaisa.isVerified = true;
        driver.paymentAccounts.easyPaisa.verifiedAt = new Date();
        driver.paymentAccounts.easyPaisa.verifiedBy = req.user._id;
      } else if (accountType === "jazzCash") {
        driver.paymentAccounts.jazzCash.isVerified = true;
        driver.paymentAccounts.jazzCash.verifiedAt = new Date();
        driver.paymentAccounts.jazzCash.verifiedBy = req.user._id;
      }

      await driver.save();

      logger.info(`Admin ${req.user._id} verified ${accountType} account for driver ${driverId}`);

      res.status(200).json({
        success: true,
        message: `${accountType} account verified successfully`,
        data: {
          easyPaisa: driver.paymentAccounts.easyPaisa,
          jazzCash: driver.paymentAccounts.jazzCash
        }
      });
    } catch (error) {
      logger.error("Error in verifyPaymentAccount:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to verify payment account", 500);
    }
  },

  /**
   * Reject/Unverify driver payment account
   * PATCH /api/admin/drivers/:driverId/payment-accounts/reject
   */
  async rejectPaymentAccount(req, res) {
    try {
      const { driverId } = req.params;
      const { accountType, reason } = req.body;

      if (!["easyPaisa", "jazzCash"].includes(accountType)) {
        throw new AppError("Invalid account type. Must be 'easyPaisa' or 'jazzCash'", 400);
      }

      const driver = await Driver.findOne({ userId: driverId });

      if (!driver) {
        throw new AppError("Driver not found", 404);
      }

      // Initialize paymentAccounts if not exists
      if (!driver.paymentAccounts) {
        driver.paymentAccounts = { easyPaisa: {}, jazzCash: {} };
      }

      // Reject/unverify the specified account
      if (accountType === "easyPaisa") {
        driver.paymentAccounts.easyPaisa.isVerified = false;
        driver.paymentAccounts.easyPaisa.verifiedAt = null;
        driver.paymentAccounts.easyPaisa.verifiedBy = null;
      } else if (accountType === "jazzCash") {
        driver.paymentAccounts.jazzCash.isVerified = false;
        driver.paymentAccounts.jazzCash.verifiedAt = null;
        driver.paymentAccounts.jazzCash.verifiedBy = null;
      }

      await driver.save();

      logger.info(`Admin ${req.user._id} rejected ${accountType} account for driver ${driverId}. Reason: ${reason || 'Not provided'}`);

      res.status(200).json({
        success: true,
        message: `${accountType} account verification rejected`,
        data: {
          easyPaisa: driver.paymentAccounts.easyPaisa,
          jazzCash: driver.paymentAccounts.jazzCash
        }
      });
    } catch (error) {
      logger.error("Error in rejectPaymentAccount:", error);
      if (error instanceof AppError) throw error;
      throw new AppError("Failed to reject payment account", 500);
    }
  }
};

export default adminController;
