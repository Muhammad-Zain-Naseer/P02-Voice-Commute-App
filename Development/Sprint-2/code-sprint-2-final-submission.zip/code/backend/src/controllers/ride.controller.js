/**
 * Ride Controller
 * REST API endpoints for ride management (optional fallback to sockets)
 */

import connectionPoolService from "../services/connectionPool.service.js";
import logger from "../utils/logger.js";
import User from "../models/User.js";
import Ride from "../models/Ride.js";
import Payment from "../models/Payment.js";
import mongoose from "mongoose";
import { notifyTrustedContacts } from "../sockets/ride.socket.js";

class RideController {
  /**
   * Create a new ride request
   * POST /api/rides
   */
  async createRide(req, res, next) {
    try {
      const {
        userId,
        userName,
        userEmail,
        source,
        destination,
        sourceCoordinates,
        destinationCoordinates
      } = req.body;

      // Validate input
      if (!source || !destination) {
        return res.status(400).json({
          success: false,
          error: "Source and destination are required"
        });
      }

      // Create ride
      const ride = connectionPoolService.addRide({
        userId: userId || "anonymous",
        userName: userName || "Anonymous User",
        userType: "commuter",
        source,
        destination,
        sourceCoordinates: sourceCoordinates || null,
        destinationCoordinates: destinationCoordinates || null,
        socketId: "rest-api" // Mark as REST API request
      });

      // Save ride to database
      const rideData = ride.toJSON();

      await Ride.create({
        rideId: rideData.id,
        userId: rideData.userId,
        userType: rideData.userType,
        userName: rideData.userName,
        userEmail: rideData.userEmail,
        source: rideData.source,
        destination: rideData.destination,
        status: rideData.status,
        createdAt: rideData.createdAt,
        updatedAt: rideData.updatedAt
      });

      logger.info(`Ride created via REST API: ${ride.id}`);

      res.status(201).json({
        success: true,
        data: {
          ride: ride.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in createRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get all rides (active in-memory + historical from database)
   * GET /api/rides
   */
  async getRides(req, res, next) {
    try {
      const { status, userId, includeHistory } = req.query;

      const filters = {};
      if (status) {
        filters.status = status;
      }
      if (userId) {
        filters.userId = userId;
      }

      // Get active rides from memory
      const activeRides = connectionPoolService.getRides(filters);

      // If includeHistory is true, also fetch from database
      let allRides = activeRides.map((ride) => ride.toJSON());

      if (includeHistory === "true") {
        const dbQuery = {};
        if (status) dbQuery.status = status;
        if (userId) dbQuery.userId = userId;

        const historicalRides = await Ride.find(dbQuery)
          .sort({ createdAt: -1 })
          .lean();

        // Merge and remove duplicates (prefer in-memory data)
        const activeRideIds = new Set(allRides.map((r) => r.id));
        const uniqueHistoricalRides = historicalRides.filter(
          (r) => !activeRideIds.has(r.rideId)
        );

        // Map database format to match in-memory format
        const mappedHistoricalRides = uniqueHistoricalRides.map((r) => ({
          id: r.rideId,
          userId: r.userId,
          userType: r.userType,
          userName: r.userName,
          userEmail: r.userEmail,
          source: r.source,
          destination: r.destination,
          status: r.status,
          matchedWith: r.matchedWith || null,
          sosAlert: r.sosAlert || null,
          completedAt: r.completedAt || null,
          createdAt: r.createdAt,
          updatedAt: r.updatedAt
        }));

        allRides = [...allRides, ...mappedHistoricalRides];
      }

      logger.info(`Retrieved ${allRides.length} rides via REST API`);

      res.status(200).json({
        success: true,
        data: {
          rides: allRides,
          count: allRides.length,
          activeCount: activeRides.length,
          historicalCount: allRides.length - activeRides.length
        }
      });
    } catch (error) {
      logger.error(`Error in getRides: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get pending rides (available for matching)
   * GET /api/rides/pending
   */
  async getPendingRides(req, res, next) {
    try {
      const rides = connectionPoolService.getPendingRides();

      logger.info(`Retrieved ${rides.length} pending rides via REST API`);

      res.status(200).json({
        success: true,
        data: {
          rides: rides.map((ride) => ride.toJSON()),
          count: rides.length
        }
      });
    } catch (error) {
      logger.error(`Error in getPendingRides: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get a specific ride by ID
   * GET /api/rides/:id
   */
  async getRide(req, res, next) {
    try {
      const { id } = req.params;

      const ride = connectionPoolService.getRide(id);

      if (!ride) {
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      res.status(200).json({
        success: true,
        data: {
          ride: ride.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in getRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Match a ride with a driver
   * POST /api/rides/:id/match
   */
  async matchRide(req, res, next) {
    try {
      const { id } = req.params;
      const { driverId, driverName } = req.body;

      if (!driverId) {
        return res.status(400).json({
          success: false,
          error: "Driver ID is required"
        });
      }

      const matchedRide = connectionPoolService.matchRide(id, {
        driverId,
        driverName: driverName || "Driver",
        socketId: "rest-api"
      });

      if (!matchedRide) {
        return res.status(404).json({
          success: false,
          error: "Ride not found or already matched"
        });
      }

      // Update DB
      await Ride.findOneAndUpdate(
        { rideId: id },
        {
          status: "matched",
          matchedWith: matchedRide.matchedWith,
          updatedAt: new Date()
        }
      );

      logger.info(`Ride matched via REST API and updated DB: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: matchedRide.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in matchRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Cancel a ride
   * DELETE /api/rides/:id
   */
  async cancelRide(req, res, next) {
    try {
      const { id } = req.params;

      const cancelledRide = connectionPoolService.cancelRide(id);

      if (!cancelledRide) {
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      // update DB
      await Ride.findOneAndUpdate(
        { rideId: id },
        {
          status: "cancelled",
          updatedAt: new Date()
        }
      );

      logger.info(`Ride cancelled via REST API and DB updated: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: cancelledRide.toJSON()
        }
      });
    } catch (error) {
      logger.error(`Error in cancelRide: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get connection pool statistics
   * GET /api/rides/stats
   */
  async getStats(req, res, next) {
    try {
      const stats = connectionPoolService.getStats();

      res.status(200).json({
        success: true,
        data: stats
      });
    } catch (error) {
      logger.error(`Error in getStats: ${error.message}`);
      next(error);
    }
  }

  /**
   * Rate a ride
   * POST /api/rides/:id/rate
   */
  async rateRide(req, res, next) {
    try {
      const { id } = req.params;
      let { rating } = req.body;

      rating = Number(rating);

      if (!rating || isNaN(rating) || rating < 1 || rating > 5) {
        return res.status(400).json({
          success: false,
          error: "Invalid rating. Must be a number between 1 and 5."
        });
      }

      // Find and update the ride
      const ride = await Ride.findOneAndUpdate(
        { rideId: id },
        { rating: rating },
        { new: true }
      ).lean();

      if (!ride) {
        return res
          .status(404)
          .json({ success: false, error: "Ride not found" });
      }

      //  Get Driver ID
      const driverId = ride.matchedWith?.driverId;

      if (!driverId) {
        logger.warn(`[Rating] Ride ${id} rated, but no driver linked.`);
        return res.status(200).json({
          success: true,
          message: "Rating submitted",
          data: { rideId: ride.rideId, rating: ride.rating }
        });
      }

      //  Find Driver
      let driver = await User.findOne({ userId: driverId });

      if (!driver && mongoose.Types.ObjectId.isValid(driverId)) {
        driver = await User.findById(driverId);
      }

      if (!driver) {
        logger.error(
          `[Rating] Driver not found for ride ${id} (ID: ${driverId})`
        );
        return res.status(200).json({
          success: true,
          message: "Rating submitted (Driver profile not updated)",
          data: { rideId: ride.rideId, rating: ride.rating }
        });
      }

      // Update Driver Stats
      driver.ratings.push(rating);

      const sum = driver.ratings.reduce((a, b) => a + b, 0);
      const newAverage = sum / driver.ratings.length;

      driver.averageRating = parseFloat(newAverage.toFixed(2));

      await driver.save();

      logger.info(
        `[Rating] Driver ${driver.name} rated ${rating} stars. New Avg: ${driver.averageRating}`
      );

      res.status(200).json({
        success: true,
        message: "Rating submitted successfully!",
        data: {
          rideId: ride.rideId,
          rating: ride.rating,
          driverAverageRating: driver.averageRating
        }
      });
    } catch (error) {
      logger.error(`[Rating] Error: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get ride history from database
   * GET /api/rides/history
   */
  async getRideHistory(req, res, next) {
    try {
      const { userId, status, limit = 50, page = 1 } = req.query;

      const query = {};
      if (userId) query.userId = userId;
      if (status) query.status = status;

      const skip = (parseInt(page) - 1) * parseInt(limit);

      const [rides, totalCount] = await Promise.all([
        Ride.find(query)
          .sort({ createdAt: -1 })
          .limit(parseInt(limit))
          .skip(skip)
          .lean(),
        Ride.countDocuments(query)
      ]);

      const mappedRides = rides.map((r) => ({
        id: r.rideId,
        userId: r.userId,
        userType: r.userType,
        userName: r.userName,
        userEmail: r.userEmail,
        source: r.source,
        destination: r.destination,
        status: r.status,
        matchedWith: r.matchedWith || null,
        sosAlert: r.sosAlert || null,
        completedAt: r.completedAt || null,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt
      }));

      logger.info(`Retrieved ${rides.length} historical rides from database`);

      res.status(200).json({
        success: true,
        data: {
          rides: mappedRides,
          count: rides.length,
          totalCount,
          page: parseInt(page),
          totalPages: Math.ceil(totalCount / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error(`Error in getRideHistory: ${error.message}`);
      next(error);
    }
  }

  /**
   * Trigger SOS alert for a ride
   * POST /api/rides/:id/sos
   */
  async triggerSOS(req, res, next) {
    try {
      const { id } = req.params;
      const { location, message } = req.body;

      logger.warn(`🚨 [SOS API] SOS alert request for ride: ${id}`);

      const ride = connectionPoolService.getRide(id);

      if (!ride) {
        logger.error(`[SOS API] Ride not found: ${id}`);
        return res.status(404).json({
          success: false,
          error: "Ride not found"
        });
      }

      logger.warn(`[SOS API] Ride found. Status: ${ride.status}`);

      // Trigger SOS
      const sosData = {
        triggeredBy: ride.userId,
        location: location || null,
        message: message || "Emergency SOS triggered by commuter"
      };

      const updatedRide = connectionPoolService.triggerSOS(id, sosData);

      if (!updatedRide) {
        logger.error(`[SOS API] Failed to trigger SOS for ride: ${id}`);
        return res.status(500).json({
          success: false,
          error: "Failed to trigger SOS"
        });
      }

      logger.warn(`🚨 SOS ALERT triggered for ride: ${id}`);
      logger.warn(`SOS Details:`, sosData);
      logger.warn(`[SOS API] SOS triggered successfully for ride: ${id}`);

      logger.warn(
        `📱 [SOS API] Sending socket notifications to trusted contacts`
      );

      // Get the io instance from the app
      const io = req.app.get("io");

      if (io) {
        await notifyTrustedContacts(io, updatedRide.userEmail, "SOS_ALERT", {
          rideId: updatedRide.id,
          source: updatedRide.source,
          destination: updatedRide.destination,
          driverName: updatedRide.matchedWith?.driverName,
          sosAlert: updatedRide.sosAlert,
          status: "emergency"
        });
        logger.warn(`✅ [SOS API] Socket notifications sent`);
      } else {
        logger.error(
          `❌ [SOS API] io instance not found - socket notifications not sent`
        );
      }

      // Send email to trusted contacts
      try {
        logger.warn(
          `[SOS API] Fetching user from database by email: ${ride.userEmail}`
        );

        const user = await User.findOne({ email: ride.userEmail }).select(
          "name email trustedContacts"
        );

        logger.warn(`[SOS API] User found: ${!!user}`);

        if (!user) {
          logger.error(`[SOS API] User not found in database: ${ride.userId}`);
        } else {
          logger.warn(`👤 [SOS API] User: ${user.name}, Email: ${user.email}`);
          logger.warn(
            `📋 [SOS API] Trusted contacts: ${user.trustedContacts?.length || 0}`
          );
        }

        if (user && user.trustedContacts && user.trustedContacts.length > 0) {
          logger.warn(
            `📧 [SOS API] Sending emails to ${user.trustedContacts.length} trusted contact(s)`
          );

          const emailService = (await import("../services/emailService.js"))
            .default;

          // Prepare email data
          const sosEmailData = {
            commuterName: user.name || ride.userName,
            commuterEmail: user.email,
            driverName: updatedRide.matchedWith?.driverName || null,
            pickupLocation: updatedRide.source.address,
            dropoffLocation: updatedRide.destination.address,
            triggeredAt: updatedRide.sosAlert.triggeredAt,
            sosMessage: updatedRide.sosAlert.message
          };

          logger.warn(`📦 [SOS API] Email data:`, sosEmailData);

          // Send emails
          const emailPromises = user.trustedContacts.map(
            async (contact, index) => {
              try {
                logger.warn(
                  `📨 [SOS API] Sending email ${index + 1}/${user.trustedContacts.length} to ${contact.email}`
                );
                await emailService.sendSOSAlert(contact.email, sosEmailData);
                logger.warn(`[SOS API] Email sent to ${contact.email}`);
              } catch (emailError) {
                logger.error(
                  `❌ [SOS API] Failed to send email to ${contact.email}: ${emailError.message}`
                );
              }
            }
          );

          // Wait for all emails
          await Promise.all(emailPromises);
          logger.warn(`[SOS API] All SOS emails sent!`);
        } else {
          logger.warn(`[SOS API] No trusted contacts for user ${ride.userId}`);
        }
      } catch (dbError) {
        logger.error(`❌ [SOS API] Database error: ${dbError.message}`);
        logger.error(`Stack: ${dbError.stack}`);
      }

      logger.warn(`🚨 [SOS API] SOS alert completed for ride: ${id}`);

      res.status(200).json({
        success: true,
        data: {
          ride: updatedRide.toJSON(),
          sosAlert: updatedRide.sosAlert
        }
      });
    } catch (error) {
      logger.error(`❌ [SOS API] Error in triggerSOS: ${error.message}`);
      logger.error(`Stack: ${error.stack}`);
      next(error);
    }
  }

  /**
   * Get earnings and ride history for a specific driver
   * GET /api/drivers/:driverId/earnings
   */
  async getEarningsHistory(req, res, next) {
    try {
      const { driverId } = req.params;

      if (!driverId) {
        return res.status(400).json({
          success: false,
          error: "Driver ID is required"
        });
      }

      logger.info(`Fetching earnings history for driver: ${driverId}`);

      // 1. Find all completed rides for the driver
      const rides = await Ride.find({
        "matchedWith.driverId": driverId,
        status: "completed"
      })
        .sort({ completedAt: -1 })
        .lean();

      // Get the start of the current month
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      let totalThisMonth = 0;

      // 2. Create a new list of rides that also includes the payment amount
      const ridesWithFares = await Promise.all(
        rides.map(async (ride) => {
          // Find the matching payment for this ride
          const payment = await Payment.findOne({ rideId: ride.rideId }).lean();

          const rideAmount = payment
            ? payment.driverEarnings ?? payment.amount
            : 0;
          const ridePaymentMethod = payment ? payment.paymentMethod : "N/A";

          // 3. Add to monthly total if the ride is from this month
          // We check 'completedAt' or 'createdAt' as a fallback
          const rideDate = ride.completedAt || ride.createdAt;
          if (rideDate >= startOfMonth) {
            totalThisMonth += rideAmount;
          }

          return {
            ...ride,
            amount: rideAmount,
            paymentMethod: ridePaymentMethod
          };
        })
      );

      logger.info(
        `Found ${ridesWithFares.length} completed rides for driver ${driverId}`
      );
      logger.info(`Total earnings this month: ${totalThisMonth}`);

      res.status(200).json({
        success: true,
        data: {
          rides: ridesWithFares,
          count: ridesWithFares.length,
          totalEarningsThisMonth: totalThisMonth // ✅ Send the new total
        }
      });
    } catch (error) {
      logger.error(`Error in getEarningsHistory: ${error.message}`);
      next(error);
    }
  }
}

export default new RideController();
