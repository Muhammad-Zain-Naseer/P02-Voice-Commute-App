import FarePrice from "../models/FarePrice.js";
import logger from "../utils/logger.js";
import connectionPoolService from "../services/connectionPool.service.js";

// Get current active fare price
export const getCurrentFarePrice = async (req, res, next) => {
  try {
    const currentFare = await FarePrice.findOne({ isActive: true })
      .sort({ effectiveFrom: -1 })
      .limit(1);

    if (!currentFare) {
      return res.status(200).json({
        success: true,
        data: {
          ratePerKm: 18,
          currency: "PKR",
          isDefault: true
        }
      });
    }

    res.status(200).json({
      success: true,
      data: currentFare
    });
  } catch (error) {
    logger.error("Error getting current fare price:", error);
    next(error);
  }
};

// Get fare price history (admin only)
export const getFarePriceHistory = async (req, res, next) => {
  try {
    const history = await FarePrice.find()
      .sort({ effectiveFrom: -1 })
      .limit(50);

    res.status(200).json({
      success: true,
      data: history
    });
  } catch (error) {
    logger.error("Error getting fare price history:", error);
    next(error);
  }
};

// Update fare price (admin only)
export const updateFarePrice = async (req, res, next) => {
  try {
    const { ratePerKm, notes } = req.body;
    const userId = req.user.userId;
    const userName = req.user.name;

    // Validate input
    if (!ratePerKm || ratePerKm <= 0) {
      return res.status(400).json({
        success: false,
        error: "Rate per km must be a positive number"
      });
    }

    // Deactivate all previous fare prices
    await FarePrice.updateMany(
      { isActive: true },
      { isActive: false }
    );

    // Create new fare price
    const newFarePrice = await FarePrice.create({
      ratePerKm: parseFloat(ratePerKm),
      updatedBy: {
        userId,
        userName
      },
      effectiveFrom: new Date(),
      notes: notes || ""
    });

    logger.info(`Fare price updated to ${ratePerKm} PKR/km by ${userName} (${userId})`);

    // Broadcast fare price update to all connected users via Socket.IO
    const io = connectionPoolService.io;
    if (io) {
      io.emit("admin:fare_update", {
        ratePerKm: newFarePrice.ratePerKm,
        currency: newFarePrice.currency,
        effectiveFrom: newFarePrice.effectiveFrom,
        updatedBy: userName,
        message: `Fare price has been updated to ${newFarePrice.ratePerKm} ${newFarePrice.currency} per km`
      });

      logger.info("Fare price update broadcasted to all users via Socket.IO");
    }

    res.status(200).json({
      success: true,
      message: "Fare price updated successfully",
      data: newFarePrice
    });
  } catch (error) {
    logger.error("Error updating fare price:", error);
    next(error);
  }
};
