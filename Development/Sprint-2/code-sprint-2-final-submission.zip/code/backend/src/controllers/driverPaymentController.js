import Driver from "../models/Driver.js";
import logger from "../utils/logger.js";

/**
 * Get driver's payment accounts
 * GET /api/driver/payment-accounts
 */
export const getPaymentAccounts = async (req, res) => {
  try {
    const driverId = req.user.id; // From auth middleware

    const driver = await Driver.findOne({ userId: driverId });

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found"
      });
    }

    res.status(200).json({
      success: true,
      data: {
        easyPaisa: driver.paymentAccounts?.easyPaisa || {
          accountTitle: "",
          accountNumber: "",
          isVerified: false
        },
        jazzCash: driver.paymentAccounts?.jazzCash || {
          accountTitle: "",
          accountNumber: "",
          isVerified: false
        }
      }
    });
  } catch (error) {
    logger.error("Error fetching payment accounts:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch payment accounts"
    });
  }
};

/**
 * Update driver's payment accounts
 * PUT /api/driver/payment-accounts
 */
export const updatePaymentAccounts = async (req, res) => {
  try {
    const driverId = req.user.id;
    const { easyPaisa, jazzCash } = req.body;

    const driver = await Driver.findOne({ userId: driverId });

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found"
      });
    }

    // Update EasyPaisa account if provided
    if (easyPaisa) {
      if (!driver.paymentAccounts) {
        driver.paymentAccounts = { easyPaisa: {}, jazzCash: {} };
      }
      driver.paymentAccounts.easyPaisa = {
        accountTitle: easyPaisa.accountTitle?.trim() || "",
        accountNumber: easyPaisa.accountNumber?.trim() || "",
        isVerified: false, // Reset verification on update
        verifiedAt: null,
        verifiedBy: null
      };
    }

    // Update JazzCash account if provided
    if (jazzCash) {
      if (!driver.paymentAccounts) {
        driver.paymentAccounts = { easyPaisa: {}, jazzCash: {} };
      }
      driver.paymentAccounts.jazzCash = {
        accountTitle: jazzCash.accountTitle?.trim() || "",
        accountNumber: jazzCash.accountNumber?.trim() || "",
        isVerified: false, // Reset verification on update
        verifiedAt: null,
        verifiedBy: null
      };
    }

    driver.paymentAccountsUpdatedAt = new Date();
    await driver.save();

    logger.info(`Driver ${driverId} updated payment accounts`);

    res.status(200).json({
      success: true,
      message: "Payment accounts updated successfully",
      data: {
        easyPaisa: driver.paymentAccounts.easyPaisa,
        jazzCash: driver.paymentAccounts.jazzCash,
        updatedAt: driver.paymentAccountsUpdatedAt
      }
    });
  } catch (error) {
    logger.error("Error updating payment accounts:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update payment accounts"
    });
  }
};
