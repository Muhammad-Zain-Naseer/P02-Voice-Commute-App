/**
 * Trip Monitoring Controller
 * Handles trusted contact notifications and trip monitoring
 */

import User from "../models/User.js";
import Ride from "../models/Ride.js";
import logger from "../utils/logger.js";

class TripMonitoringController {
  /**
   * Get trusted contacts for a user
   * GET /api/monitoring/trusted-contacts/:userIdOrEmail
   */
  async getTrustedContacts(req, res, next) {
    try {
      const { userIdOrEmail } = req.params;

      let user = null;

      // search by email first
      if (userIdOrEmail.includes("@")) {
        user = await User.findOne({ email: userIdOrEmail }).select(
          "trustedContacts name email"
        );
      }
      // search by MongoDB _id
      else if (/^[0-9a-fA-F]{24}$/.test(userIdOrEmail)) {
        user = await User.findById(userIdOrEmail).select(
          "trustedContacts name email"
        );
      }
      // search by userId field
      else {
        user = await User.findOne({ userId: userIdOrEmail }).select(
          "trustedContacts name email"
        );
      }

      if (!user) {
        return res.status(404).json({
          success: false,
          error: "User not found"
        });
      }

      res.status(200).json({
        success: true,
        data: {
          trustedContacts: user.trustedContacts || [],
          commuterName: user.name,
          commuterEmail: user.email
        }
      });
    } catch (error) {
      logger.error(`Error in getTrustedContacts: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get active trips for a trusted contact
   * GET /api/monitoring/active-trips/:contactEmail
   */
  async getActiveTripsForContact(req, res, next) {
    try {
      const { contactEmail } = req.params;

      // find all users who have this email as a trusted contact
      const users = await User.find({
        "trustedContacts.email": contactEmail
      }).select("userId name email");

      if (!users || users.length === 0) {
        return res.status(200).json({
          success: true,
          data: {
            trips: [],
            count: 0
          }
        });
      }

      // get both userId and _id for ride lookups
      const userIdentifiers = users.map((u) => ({
        userId: u.userId,
        _id: u._id.toString(),
        email: u.email,
        name: u.name
      }));

      const userIds = userIdentifiers.map((u) => u.userId).filter(Boolean);
      const userEmails = userIdentifiers.map((u) => u.email);

      // find active rides by userId OR email
      const activeRides = await Ride.find({
        $or: [{ userId: { $in: userIds } }, { userEmail: { $in: userEmails } }],
        status: { $in: ["matched", "pending"] }
      }).sort({ createdAt: -1 });

      // Enrich with user info
      const tripsWithUserInfo = activeRides.map((ride) => {
        const user = userIdentifiers.find(
          (u) => u.userId === ride.userId || u.email === ride.userEmail
        );
        return {
          ...ride.toObject(),
          commuterName: user?.name || ride.userName,
          commuterEmail: user?.email || ride.userEmail
        };
      });

      logger.info(
        `Found ${tripsWithUserInfo.length} active trips for contact: ${contactEmail}`
      );

      res.status(200).json({
        success: true,
        data: {
          trips: tripsWithUserInfo,
          count: tripsWithUserInfo.length
        }
      });
    } catch (error) {
      logger.error(`Error in getActiveTripsForContact: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get trip details for monitoring
   * GET /api/monitoring/trip/:rideId
   */
  async getTripDetails(req, res, next) {
    try {
      const { rideId } = req.params;

      const ride = await Ride.findOne({ rideId }).lean();

      if (!ride) {
        return res.status(404).json({
          success: false,
          error: "Trip not found"
        });
      }

      // get commuter details by email
      let commuter = null;

      if (ride.userEmail) {
        commuter = await User.findOne({ email: ride.userEmail }).select(
          "name email trustedContacts"
        );
      }

      if (!commuter && ride.userId) {
        commuter = await User.findOne({ userId: ride.userId }).select(
          "name email trustedContacts"
        );
      }

      res.status(200).json({
        success: true,
        data: {
          trip: {
            ...ride,
            commuterName: commuter?.name || ride.userName,
            commuterEmail: commuter?.email || ride.userEmail
          }
        }
      });
    } catch (error) {
      logger.error(`Error in getTripDetails: ${error.message}`);
      next(error);
    }
  }
}

export default new TripMonitoringController();
