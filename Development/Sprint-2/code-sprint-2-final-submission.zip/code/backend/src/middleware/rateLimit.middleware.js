import rateLimit from "express-rate-limit";

export const alertRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 5000, // limit each ip to 5000 requests per window
  message: {
    success: false,
    error: "Too many alerts sent from this IP, please try again after 15 minutes"
  },
  standardHeaders: true,
  legacyHeaders: false
});

export const analyticsRateLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute window
  max: 5, // Limit each IP to 5 requests per minute
  message: {
    success: false,
    error: "Analytics rate limit exceeded. Please wait a moment."
  },
  standardHeaders: true,
  legacyHeaders: false
});