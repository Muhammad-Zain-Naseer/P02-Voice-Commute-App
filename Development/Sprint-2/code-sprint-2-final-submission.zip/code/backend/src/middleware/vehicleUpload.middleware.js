// src/middleware/vehicleUpload.middleware.js
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// find project root by walking up until package.json is found
function findProjectRoot(startPath) {
  let currentPath = startPath;

  while (currentPath !== path.parse(currentPath).root) {
    if (fs.existsSync(path.join(currentPath, "package.json"))) {
      return currentPath;
    }
    currentPath = path.dirname(currentPath);
  }

  throw new Error("Could not find project root (package.json not found)");
}

const projectRoot = findProjectRoot(__dirname);

// Store vehicle registrations under: <projectRoot>/uploads/vehicle-registrations
const vehicleUploadsDir = path.join(projectRoot, "uploads", "vehicle-registrations");

// Ensure directory exists
if (!fs.existsSync(vehicleUploadsDir)) {
  fs.mkdirSync(vehicleUploadsDir, { recursive: true });
}

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, vehicleUploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `reg-${uniqueSuffix}${ext}`);
  },
});

// Accept only JPG/JPEG/PNG/PDF
const fileFilter = (req, file, cb) => {
  const allowedMimeTypes = [
    "image/jpeg", 
    "image/jpg",  
    "image/png",
    "application/pdf",
  ];

  const allowedExtensions = [".jpg", ".jpeg", ".png", ".pdf"];

  const ext = path.extname(file.originalname).toLowerCase();

  const mimeOk = allowedMimeTypes.includes(file.mimetype);
  const extOk = allowedExtensions.includes(ext);

  if (mimeOk && extOk) {
    cb(null, true);
  } else {
    cb(
      new Error(
        `Invalid file type. Allowed: JPG, JPEG, PNG, PDF. Received mimetype=${file.mimetype}, ext=${ext}`
      ),
      false
    );
  }
};

// Multer instance
const vehicleUpload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
});

export default vehicleUpload;
