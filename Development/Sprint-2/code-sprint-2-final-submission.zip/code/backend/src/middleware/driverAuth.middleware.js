import jwt from "jsonwebtoken";
import Driver from "../models/Driver.js";
import User from "../models/User.js";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

export const authenticateDriver = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Authentication required"
      });
    }

    const decoded = jwt.verify(token, config.jwtSecret);
    console.log("🔍 [DRIVER AUTH] DECODED TOKEN:", decoded);

    // CASE 1: Registration flow token
    if (decoded.role === "driver_registration") {
      req.driver = decoded;
      logger.info(`Registration token validated for: ${decoded.email}`);
      return next();
    }

    // CASE 2: Driver-specific token (from driverAuthController.login)
    if (decoded.role === "driver" && decoded.driverId) {
      const driver = await Driver.findById(decoded.driverId).select(
        "-verificationOTP -verificationOTPExpiry"
      );

      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver not found"
        });
      }

      req.driver = driver;
      logger.info(`Driver authenticated: ${driver.email}`);
      return next();
    }

    // CASE 3: Regular auth token (from AuthController.login)
    if (decoded.userId && !decoded.role) {
      console.log("🔍 [DRIVER AUTH] Regular auth token detected, userId:", decoded.userId);
      
      const user = await User.findById(decoded.userId);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      // Check if user is a driver
      if (user.role !== "driver") {
        return res.status(403).json({
          success: false,
          message: "Access denied. Not a driver account."
        });
      }

      // Find the driver profile using user.userId
      const driver = await Driver.findOne({ userId: user.userId }).select(
        "-verificationOTP -verificationOTPExpiry"
      );
      
      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver profile not found"
        });
      }
      req.user = user;
      req.driver = driver;
      logger.info(`Driver authenticated via user token: ${driver.email}`);
      return next();
    }

    // Invalid token - no matching case
    return res.status(403).json({
      success: false,
      message: "Access denied. Invalid token type."
    });
  } catch (error) {
    logger.error("Driver authentication error:", error);

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        success: false,
        message: "Invalid token"
      });
    }

    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expired. Please login again."
      });
    }

    return res.status(500).json({
      success: false,
      message: "Authentication failed"
    });
  }
};