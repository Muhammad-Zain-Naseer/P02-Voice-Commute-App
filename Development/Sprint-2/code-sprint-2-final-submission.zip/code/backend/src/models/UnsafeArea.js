import mongoose from "mongoose";

const unsafeAreaSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  // Center point of the unsafe area
  location: {
    latitude: {
      type: Number,
      required: true,
      min: -90,
      max: 90
    },
    longitude: {
      type: Number,
      required: true,
      min: -180,
      max: 180
    },
    address: {
      type: String,
      default: ""
    }
  },
  // Radius in meters
  radius: {
    type: Number,
    required: true,
    min: 100, // Minimum 100 meters
    default: 500
  },
  severity: {
    type: String,
    enum: ['warning', 'blocked'],
    default: 'warning',
    required: true
  },
  reason: {
    type: String,
    required: true,
    trim: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdBy: {
    userId: {
      type: String,
      required: true
    },
    userName: {
      type: String,
      required: true
    }
  },
  // Optional: Time-based restrictions
  activeFrom: {
    type: Date,
    default: null
  },
  activeTo: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// Index for geospatial queries
unsafeAreaSchema.index({
  "location.latitude": 1,
  "location.longitude": 1
});

// Index for active areas
unsafeAreaSchema.index({ isActive: 1, createdAt: -1 });

// Static method to check if a location is in any unsafe area
unsafeAreaSchema.statics.checkLocation = async function(latitude, longitude) {
  const activeAreas = await this.find({ isActive: true });

  const unsafeAreas = [];

  for (const area of activeAreas) {
    // Check if time-based restriction applies
    if (area.activeFrom || area.activeTo) {
      const now = new Date();
      if (area.activeFrom && now < area.activeFrom) continue;
      if (area.activeTo && now > area.activeTo) continue;
    }

    // Calculate distance using Haversine formula
    const distance = calculateDistance(
      latitude,
      longitude,
      area.location.latitude,
      area.location.longitude
    );

    if (distance <= area.radius) {
      unsafeAreas.push({
        id: area._id,
        name: area.name,
        description: area.description,
        reason: area.reason,
        severity: area.severity,
        distance: Math.round(distance)
      });
    }
  }

  return unsafeAreas;
};

// Haversine formula to calculate distance between two coordinates in meters
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // Distance in meters
}

const UnsafeArea = mongoose.model("UnsafeArea", unsafeAreaSchema);

export default UnsafeArea;
