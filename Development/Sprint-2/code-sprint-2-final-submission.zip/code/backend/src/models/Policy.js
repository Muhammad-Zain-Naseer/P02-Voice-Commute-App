import mongoose from "mongoose";

const policySchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  message: {
    type: String,
    required: true
  },
  category: {
    type: String,
    enum: ['general', 'safety', 'pricing', 'terms', 'privacy', 'other'],
    default: 'general'
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium'
  },
  senderId: {
    type: String,
    required: true,
    index: true
  },
  senderName: {
    type: String,
    required: true
  },
  targetAudience: {
    type: String,
    enum: ['all', 'drivers', 'commuters'],
    default: 'all'
  },
  sentAt: {
    type: Date,
    default: Date.now,
    index: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  expiresAt: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// Index for efficient querying
policySchema.index({ sentAt: -1 });
policySchema.index({ isActive: 1, sentAt: -1 });

const Policy = mongoose.model("Policy", policySchema);

export default Policy;
