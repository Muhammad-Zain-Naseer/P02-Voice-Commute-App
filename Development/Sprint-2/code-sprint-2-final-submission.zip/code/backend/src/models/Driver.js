import mongoose from "mongoose";

const driverSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      ref: "User",
      required: false,
      unique: true,
      index: true
    },

    name: {
      type: String,
      required: true,
      trim: true
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true
    },
    phone: {
      type: String,
      sparse: true,
      trim: true
    },
    
    // CNIC - NUMBER ONLY (no photo)
    cnic: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true
    },
    
    // Driving License - NUMBER ONLY (no photo)
    drivingLicense: {
      type: String,
      required: false,
      unique: true,
      sparse: true,
      trim: true,
      index: true
    },
    
    isVerified: {
      type: Boolean,
      default: false
    },
    verificationOTP: String,
    verificationOTPExpiry: Date,

    // Vehicle Information
    vehicle: {
      registrationNumber: {
        type: String,
        required: false,
        unique: true,
        uppercase: true,
        trim: true,
        sparse: true,
        index: true
      },
      // ONLY vehicle registration has photo submission
      registrationPhoto: {
        type: String,
        default: null
      },
      color: {
        type: String,
        trim: true
      },
      model: {
        type: String,
        trim: true
      },
      year: { type: String }
    },

    // Driver Status (combines verification + operational status)
    status: {
      type: String,
      enum: ["pending", "approved", "rejected", "resubmission_required", "suspended"],
      default: "pending",
      index: true
    },

    approvalDate: Date,
    rejectionReason: String,
    resubmissionNotes: String,
    suspensionReason: String,

    // Admin verification tracking
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },
    verifiedAt: {
      type: Date,
      default: null
    },

    // Verification History (audit trail)
    verificationHistory: [{
      action: {
        type: String,
        enum: ["approved", "rejected", "resubmission_required", "suspended", "reactivated"]
      },
      adminId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      },
      reason: String,
      timestamp: {
        type: Date,
        default: Date.now
      }
    }],

    // Ratings
    averageRating: {
      type: Number,
      default: 0
    },
    totalRides: {
      type: Number,
      default: 0
    },

    // Activity
    isAvailable: {
      type: Boolean,
      default: false
    },
    lastLogin: Date,

    // Payment account details
    paymentAccounts: {
      easyPaisa: {
        accountTitle: { type: String, default: "", trim: true },
        accountNumber: { type: String, default: "", trim: true },
        isVerified: { type: Boolean, default: false },
        verifiedAt: { type: Date },
        verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
      },
      jazzCash: {
        accountTitle: { type: String, default: "", trim: true },
        accountNumber: { type: String, default: "", trim: true },
        isVerified: { type: Boolean, default: false },
        verifiedAt: { type: Date },
        verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
      }
    },
    paymentAccountsUpdatedAt: { type: Date }
  },
  {
    timestamps: true
  }
);

// Virtual populate
driverSchema.virtual("user", {
  ref: "User",
  localField: "userId",
  foreignField: "userId",
  justOne: true
});

driverSchema.set("toJSON", { virtuals: true });
driverSchema.set("toObject", { virtuals: true });

export default mongoose.model("Driver", driverSchema);