import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    index: true,
    unique: true
  },
  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
    maxlength: 100
  },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Please enter a valid email address"]
  },
  pin: {
    type: String,
    required: true,
    minlength: 4
  },
  role: {
    type: String,
    enum: ["commuter", "driver", "admin"],
    default: "commuter"
  },
  trustedContacts: [
    {
      email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        match: [
          /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
          "Please enter a valid email address"
        ]
      },
      name: {
        type: String,
        trim: true
      },
      addedAt: {
        type: Date,
        default: Date.now
      }
    }
  ],

  isVerified: {
    type: Boolean,
    default: false
  },
  verificationToken: {
    type: String
  },
  verificationTokenExpiry: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastLogin: {
    type: Date
  },
  ratings: {
    type: [Number],
    default: []
  },
  averageRating: {
    type: Number,
    default: 0
  },

  // Account status fields
  isActive: {
    type: Boolean,
    default: true
  },
  deactivationReason: {
    type: String
  },
  isSuspended: {
    type: Boolean,
    default: false
  },
  suspensionReason: {
    type: String
  },
  suspendedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  suspendedAt: {
    type: Date
  }
});

// Hash PIN before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("pin")) return next();
  const salt = await bcrypt.genSalt(10);
  this.pin = await bcrypt.hash(this.pin, salt);
  next();
});

// Compare PIN method
userSchema.methods.comparePin = async function (candidatePin) {
  return await bcrypt.compare(candidatePin, this.pin);
};

// Index for faster email lookups
userSchema.index({ email: 1 });

// Index for verification token lookups
userSchema.index({ verificationToken: 1 });

export default mongoose.model("User", userSchema);
