/**
 * Payment Model
 * Represents a payment transaction for a completed ride
 */

import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    rideId: {
      type: String,
      required: true,
      index: true
    },
    userId: {
      type: String,
      required: true,
      index: true
    },
    driverId: {
      type: String,
      required: true,
      index: true
    },
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    // Commission breakdown (calculated when payment is verified)
    adminCommission: {
      type: Number,
      default: 0,
      min: 0
    },
    driverEarnings: {
      type: Number,
      default: 0,
      min: 0
    },
    commissionRate: {
      type: Number,
      default: 0.2 // 20% commission
    },
    transactionId: {
      type: String,
      required: false, // Optional - not needed for cash payments
      unique: true,
      sparse: true, // Allows multiple null values
      index: true
    },
    paymentScreenshot: {
      type: String, // URL or base64 encoded image
      required: false // Optional - not needed for cash payments
    },
    paymentMethod: {
      type: String,
      enum: ["easypaisa", "jazzcash", "cash"],
      default: "cash"
    },
    status: {
      type: String,
      enum: ["pending", "verified", "rejected"],
      default: "verified" // Auto-verified on submission
    },
    rideDetails: {
      source: {
        address: String,
        coordinates: {
          lat: Number,
          lng: Number
        }
      },
      destination: {
        address: String,
        coordinates: {
          lat: Number,
          lng: Number
        }
      }
    },
    submittedAt: {
      type: Date,
      default: Date.now
    },
    verifiedAt: {
      type: Date
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    notes: {
      type: String
    }
  },
  {
    timestamps: true
  }
);

// Compound indexes for querying payments by user/driver with date sorting
paymentSchema.index({ userId: 1, createdAt: -1 });
paymentSchema.index({ driverId: 1, createdAt: -1 });

const Payment = mongoose.model("Payment", paymentSchema);

export default Payment;
