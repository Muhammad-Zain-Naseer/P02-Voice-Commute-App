import express from "express";
import safetyController from "../controllers/safety.controller.js";
import { authorize } from "../middleware/role.middleware.js";
import { alertRateLimiter } from "../middleware/rateLimit.middleware.js";

const router = express.Router();

/**
 * @route   POST /api/admin/alerts
 * @desc    Broadcast a safety alert
 * @access  Admin only
 */
router.post(
  "/alerts",
  authorize("admin"),
  alertRateLimiter,
  safetyController.sendSafetyAlert
);

/**
 * @route   GET /api/admin/alerts
 * @desc    View alert history
 * @access  Admin only
 */
router.get("/alerts", authorize("admin"), safetyController.getAlertHistory);

export default router;
