import express from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { getTodayStats } from "../controllers/driver.controller.js";
import {
  getPaymentAccounts,
  updatePaymentAccounts
} from "../controllers/driverPaymentController.js";

const router = express.Router();

// Protected Routes
router.get(
  "/stats/today",
  authenticate,
  authorize("driver"),
  getTodayStats
);

// Payment Account Management
router.get(
  "/payment-accounts",
  authenticate,
  authorize("driver"),
  getPaymentAccounts
);

router.put(
  "/payment-accounts",
  authenticate,
  authorize("driver"),
  updatePaymentAccounts
);

export default router;