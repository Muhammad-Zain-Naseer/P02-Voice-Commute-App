import express from "express";
import {
  sendPolicyUpdate,
  getPolicyHistory,
  getActivePolicies,
  deactivatePolicy
} from "../controllers/policy.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorize } from "../middleware/role.middleware.js";
import { alertRateLimiter } from "../middleware/rateLimit.middleware.js";

const router = express.Router();

// Public route - Get active policies
router.get("/active", getActivePolicies);

// Admin routes - Protected
router.post(
  "/send",
  authenticate,
  authorize("admin"),
  alertRateLimiter, // 5 per 15 min
  sendPolicyUpdate
);

router.get(
  "/history",
  authenticate,
  authorize("admin"),
  getPolicyHistory
);

router.patch(
  "/:policyId/deactivate",
  authenticate,
  authorize("admin"),
  deactivatePolicy
);

export default router;
