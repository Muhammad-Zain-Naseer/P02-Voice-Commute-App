import express from "express";
import unsafeAreaController from "../controllers/unsafeArea.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorize } from "../middleware/role.middleware.js";
import { alertRateLimiter } from "../middleware/rateLimit.middleware.js";

const router = express.Router();

// Public route - Check if location is unsafe
router.post("/check", unsafeAreaController.checkLocation.bind(unsafeAreaController));

// Admin routes - Protected
router.post(
  "/",
  authenticate,
  authorize("admin"),
  alertRateLimiter,
  unsafeAreaController.createUnsafeArea.bind(unsafeAreaController)
);

router.get(
  "/",
  authenticate,
  authorize("admin"),
  unsafeAreaController.getUnsafeAreas.bind(unsafeAreaController)
);

router.get(
  "/:id",
  authenticate,
  authorize("admin"),
  unsafeAreaController.getUnsafeAreaById.bind(unsafeAreaController)
);

router.put(
  "/:id",
  authenticate,
  authorize("admin"),
  unsafeAreaController.updateUnsafeArea.bind(unsafeAreaController)
);

router.delete(
  "/:id",
  authenticate,
  authorize("admin"),
  alertRateLimiter,
  unsafeAreaController.deleteUnsafeArea.bind(unsafeAreaController)
);

export default router;
