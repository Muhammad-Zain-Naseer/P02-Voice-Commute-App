import express from "express";
import adminController from "../controllers/admin.controller.js";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import connectionPoolService from "../services/connectionPool.service.js";

const router = express.Router();

// Debug endpoint - check connection pool (NO AUTH for quick testing)
router.get("/debug/pool", (req, res) => {
  const stats = connectionPoolService.getStats();
  const allRides = connectionPoolService.getRides();

  res.json({
    success: true,
    stats,
    rides: allRides.map((r) => ({
      id: r.id,
      status: r.status,
      userName: r.userName,
      source: r.source.address,
      destination: r.destination.address,
      createdAt: r.createdAt
    }))
  });
});

// All admin routes require authentication and admin role
router.use(authenticate);
router.use(authorize("admin"));

// ==================== DASHBOARD STATISTICS ====================
router.get("/stats/overview", adminController.getOverviewStats);
router.get("/stats/users", adminController.getUserStats);
router.get("/stats/drivers", adminController.getDriverStats);
router.get("/stats/rides", adminController.getRideStats);
router.get("/stats/payments", adminController.getPaymentStats);
router.get("/stats/verification", adminController.getVerificationStats);

// ==================== USER MANAGEMENT ====================
router.get("/users/search", adminController.searchUsers);
router.get("/users", adminController.getUsers);
router.get("/users/:userId/activity", adminController.getUserActivity);
router.get("/users/:userId", adminController.getUserDetails);
router.patch("/users/:userId/verify", adminController.verifyUser);
router.patch("/users/:userId/activate", adminController.activateUser);
router.patch("/users/:userId/deactivate", adminController.deactivateUser);
router.patch("/users/:userId/suspend", adminController.suspendUser);
router.patch("/users/:userId/unsuspend", adminController.unsuspendUser);
router.patch("/users/:userId/role", adminController.updateUserRole);
router.delete("/users/:userId", adminController.deleteUser);

// ==================== DRIVER MANAGEMENT ====================
router.get("/drivers", adminController.getDrivers);
router.get("/drivers/:driverId", adminController.getDriverDetails);

// ==================== DRIVER VERIFICATION (UC-013) ====================
router.patch("/drivers/:driverId/approve", adminController.approveDriver);
router.patch("/drivers/:driverId/reject", adminController.rejectDriver);
router.patch("/drivers/:driverId/resubmission", adminController.requestResubmission);
router.patch("/drivers/:driverId/suspend", adminController.suspendDriver);
router.patch("/drivers/:driverId/reactivate", adminController.reactivateDriver);
router.patch("/drivers/:driverId/status", adminController.updateDriverStatus);

// ==================== RIDE MANAGEMENT ====================
router.get("/trips/active", adminController.getActiveTrips);
router.get("/rides", adminController.getRides);
router.get("/rides/:rideId", adminController.getRideDetails);

// ==================== PAYMENT MANAGEMENT ====================
router.get("/payments/pending", adminController.getPendingPayments);
router.patch("/payments/:paymentId/verify", adminController.verifyPayment);
router.patch("/payments/:paymentId/reject", adminController.rejectPayment);

// ==================== DRIVER PAYMENT ACCOUNT MANAGEMENT ====================
router.get("/drivers/:driverId/payment-accounts", adminController.getDriverPaymentAccounts);
router.patch("/drivers/:driverId/payment-accounts/verify", adminController.verifyPaymentAccount);
router.patch("/drivers/:driverId/payment-accounts/reject", adminController.rejectPaymentAccount);

export default router;
