import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart'; // ✅ Import this

class SafetyAlertDialog extends StatelessWidget {
  final String message;
  final String severity;
  final String sentAt;

  const SafetyAlertDialog({
    super.key,
    required this.message,
    required this.severity,
    required this.sentAt,
  });

  // Helper to determine color based on severity
  Color _getSeverityColor() {
    switch (severity.toLowerCase()) {
      case 'critical':
      case 'high':
        return const Color(0xFFD32F2F); // Dark Red
      case 'medium':
        return const Color(0xFFF57C00); // Orange
      case 'low':
        return const Color(0xFF1976D2); // Blue
      default:
        return const Color(0xFFD32F2F);
    }
  }

  IconData _getSeverityIcon() {
    switch (severity.toLowerCase()) {
      case 'critical':
      case 'high':
        return Icons.warning_rounded;
      case 'medium':
        return Icons.info_outline;
      case 'low':
        return Icons.notifications_active;
      default:
        return Icons.warning_amber_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = _getSeverityColor();

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 10,
      backgroundColor: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with Icon
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
              color: themeColor.withOpacity(0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Icon(_getSeverityIcon(), size: 50, color: themeColor),
          ),

          Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                // Title (Urdu)
                Text(
                  'حفاظتی انتباہ', // "Safety Alert"
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: themeColor,
                  ),
                  textDirection: TextDirection.rtl,
                ),
                const SizedBox(height: 16),

                // Message Body
                Text(
                  message, // The dynamic message from Admin
                  textAlign: TextAlign.center,
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 18,
                    color: Colors.black87,
                    height: 1.6, // Better line height for Urdu
                  ),
                  textDirection: TextDirection.rtl, // Ensure RTL
                ),
                const SizedBox(height: 24),

                // Time
                Text(
                  'وقت اشاعت: ${_formatDate(sentAt)}', // "Publish Time: ..."
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                  textDirection: TextDirection.rtl,
                ),
              ],
            ),
          ),

          // Dismiss Button
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'ٹھیک ہے', // "Okay" / "Acknowledge"
                  style: GoogleFonts.notoNastaliqUrdu(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr).toLocal();
      // Simple format: HH:MM - DD/MM/YYYY
      return "${date.hour}:${date.minute.toString().padLeft(2, '0')} - ${date.day}/${date.month}/${date.year}";
    } catch (e) {
      return dateStr;
    }
  }
}
