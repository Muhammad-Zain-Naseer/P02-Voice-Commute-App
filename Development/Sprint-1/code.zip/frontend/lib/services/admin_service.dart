import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_config.dart';

class AdminService {
  final String baseUrl = AppConfig.apiBaseUrl;
  String? _token;

  void setToken(String token) {
    _token = token;
  }

  Map<String, String> _getHeaders() {
    return {
      'Content-Type': 'application/json',
      if (_token != null) 'Authorization': 'Bearer $_token',
    };
  }

  // Get overview statistics
  Future<Map<String, dynamic>?> getOverviewStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/overview'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching overview stats: $e');
      return null;
    }
  }

  // Get user statistics
  Future<Map<String, dynamic>?> getUserStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/users'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching user stats: $e');
      return null;
    }
  }

  // Get driver statistics
  Future<Map<String, dynamic>?> getDriverStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/drivers'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching driver stats: $e');
      return null;
    }
  }

  // Get ride statistics
  Future<Map<String, dynamic>?> getRideStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/rides'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching ride stats: $e');
      return null;
    }
  }

  // Get payment statistics
  Future<Map<String, dynamic>?> getPaymentStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/stats/payments'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching payment stats: $e');
      return null;
    }
  }

  // Get users
  Future<Map<String, dynamic>?> getUsers({String? role, bool? isVerified, int page = 1}) async {
    try {
      String url = '$baseUrl/api/admin/users?page=$page';
      if (role != null) url += '&role=$role';
      if (isVerified != null) url += '&isVerified=$isVerified';

      final response = await http.get(
        Uri.parse(url),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching users: $e');
      return null;
    }
  }

  // Get drivers
  Future<Map<String, dynamic>?> getDrivers({String? status, int page = 1}) async {
    try {
      String url = '$baseUrl/api/admin/drivers?page=$page';
      if (status != null) url += '&status=$status';

      final response = await http.get(
        Uri.parse(url),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching drivers: $e');
      return null;
    }
  }

  // Update driver status
  Future<bool> updateDriverStatus(String driverId, String status, {String? rejectionReason}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/drivers/$driverId/status'),
        headers: _getHeaders(),
        body: jsonEncode({
          'status': status,
          if (rejectionReason != null) 'rejectionReason': rejectionReason,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error updating driver status: $e');
      return false;
    }
  }

  // Get pending payments
  Future<Map<String, dynamic>?> getPendingPayments({int page = 1}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/admin/payments/pending?page=$page'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'];
      }
      return null;
    } catch (e) {
      print('Error fetching pending payments: $e');
      return null;
    }
  }

  // Verify payment
  Future<bool> verifyPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/verify'),
        headers: _getHeaders(),
        body: jsonEncode({
          if (notes != null) 'notes': notes,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error verifying payment: $e');
      return false;
    }
  }

  // Reject payment
  Future<bool> rejectPayment(String paymentId, {String? notes}) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/api/admin/payments/$paymentId/reject'),
        headers: _getHeaders(),
        body: jsonEncode({
          if (notes != null) 'notes': notes,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Error rejecting payment: $e');
      return false;
    }
  }

  // Send safety alert
  Future<bool> sendSafetyAlert({
    required String message,
    required String severity,
    String targetAudience = 'all',
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/admin/alerts/alerts'),
        headers: _getHeaders(),
        body: jsonEncode({
          'message': message,
          'severity': severity,
          'targetAudience': targetAudience,
        }),
      );

      return response.statusCode == 201;
    } catch (e) {
      print('Error sending safety alert: $e');
      return false;
    }
  }
}
