import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import '../../widgets/custom_button.dart';
import '../../services/auth_service.dart';
import '../../services/admin_service.dart';
import '../home_screen.dart';
import '../driver/driver_page.dart';
import '../../services/storage_service.dart';
import '../admin/admin_home_screen.dart';

class LoginPinScreen extends StatefulWidget {
  final String email;

  const LoginPinScreen({super.key, required this.email});

  @override
  State<LoginPinScreen> createState() => _LoginPinScreenState();
}

class _LoginPinScreenState extends State<LoginPinScreen> {
  final TextEditingController _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        final authService = AuthService();
        final result = await authService.login(
          email: widget.email,
          pin: _pinController.text,
        );

        setState(() {
          _isLoading = false;
        });

        if (result['success']) {
          // Login successful
          if (mounted) {
            print('--- LOGIN SUCCESS, CHECKING DATA ---');
            print(result['data']);
            // SAVE USER DATA TO STORAGE
            await StorageService.saveUserData(result['data']);

            // Get user data for navigation
            final user = result['data']['user'];
            final userName = user['name'] ?? 'User';
            final userEmail = user['email'] ?? widget.email;
            final userId = user['id'] ?? '';
            final userRole = user['role'] ?? 'commuter';

            // Navigate based on user role
            if (userRole == 'driver') {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => const AvailableRidesPage(),
                ),
              );
            } else if (userRole == 'admin') {
              // Get token for admin
              final token = result['data']['token'] ?? '';

              // Set token in admin service
              final adminService = AdminService();
              adminService.setToken(token);

              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => AdminHomeScreen(
                    userName: userName,
                    userEmail: userEmail,
                    token: token,
                  ),
                ),
              );
            } else {
              // Default to commuter home screen
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => HomeScreen(
                    userName: userName,
                    userEmail: userEmail,
                    userId: userId,
                  ),
                ),
              );
            }
          }
        } else {
          // Login failed
          if (mounted) {
            final message = result['message'] ?? 'لاگ ان ناکام';

            if (message.toLowerCase().contains('verify') ||
                message.toLowerCase().contains('تصدیق')) {
              _showVerificationDialog();
            } else if (message.toLowerCase().contains('invalid') ||
                message.toLowerCase().contains('غلط')) {
              _showInvalidCredentialsDialog();
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(message, textDirection: TextDirection.rtl),
                  backgroundColor: Colors.red,
                ),
              );
            }
          }
        }
      } catch (e) {
        setState(() {
          _isLoading = false;
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'کوئی خرابی پیش آگئی: $e',
                textDirection: TextDirection.rtl,
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  void _showVerificationDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFFFAECF1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.email_outlined,
                  color: Color(0xFFCF4374),
                  size: 50,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'براہ کرم پہلے اپنی ای میل کی تصدیق کریں',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  'ٹھیک ہے',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showInvalidCredentialsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFFFAECF1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.error_outline,
                  color: Color(0xFFCF4374),
                  size: 50,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'غلط ای میل یا PIN',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _pinController.clear();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  'دوبارہ کوشش کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 32.0,
              vertical: 20.0,
            ),
            child: Column(
              children: [
                // Top section - Back button and logo
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 70,
                      height: 70,
                    ),
                    const SizedBox(width: 48),
                  ],
                ),

                const SizedBox(height: 30),

                // Sound Wave
                const SoundWave(),

                const SizedBox(height: 40),

                // Title
                const Text(
                  'اپنا PIN درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 40),

                // PIN Input Field
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _pinController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    obscureText: true,
                    maxLength: 4,
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                      letterSpacing: 20,
                    ),
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                      hintText: '••••',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withOpacity(0.3),
                        fontSize: 32,
                        letterSpacing: 20,
                      ),
                      counterText: '',
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.7),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFCF4374),
                          width: 2,
                        ),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 1.5,
                        ),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.red,
                          width: 2,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 16,
                      ),
                      errorStyle: const TextStyle(height: 0),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return '';
                      }
                      if (value.length != 4) {
                        return '';
                      }
                      return null;
                    },
                  ),
                ),

                const SizedBox(height: 60),

                // Bottom Section - Login Button
                _isLoading
                    ? const CircularProgressIndicator(color: Color(0xFFCF4374))
                    : CustomButton(
                        text: 'لاگ ان کریں',
                        onPressed: _login,
                        height: 56,
                        isPrimary: false,
                        backgroundColor: const Color(0xFFCF4374),
                        textColor: Colors.white,
                        fontSize: 20,
                        isGradient: true,
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
