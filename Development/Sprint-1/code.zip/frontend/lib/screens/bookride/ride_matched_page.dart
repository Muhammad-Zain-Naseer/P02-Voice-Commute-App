import 'package:flutter/material.dart';
import 'dart:async';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../utils/logger.dart';
import '../commuter/active_ride_page.dart';

class RideMatchedPage extends StatefulWidget {
  final RideRequest ride;

  const RideMatchedPage({
    super.key,
    required this.ride,
  });

  @override
  State<RideMatchedPage> createState() => _RideMatchedPageState();
}

class _RideMatchedPageState extends State<RideMatchedPage> {
  int _remainingSeconds = 5;
  Timer? _timer;
  bool _isCancelled = false;
  bool _isNavigating = false;
  String _sourceUrdu = '...لوڈ ہو رہا ہے';
  String _destinationUrdu = '...لوڈ ہو رہا ہے';

  @override
  void initState() {
    super.initState();
    _startCountdown();
    _fetchAddressTranslations();
  }

  Future<void> _fetchAddressTranslations() async {
    try {
      final source = widget.ride.source.address;
      final destination = widget.ride.destination.address;

      final translatedAddresses = await MapService.translateAddresses(
        source: source,
        destination: destination,
      );

      if (mounted) {
        setState(() {
          _sourceUrdu = translatedAddresses['source'] ?? source;
          _destinationUrdu = translatedAddresses['destination'] ?? destination;
        });
      }
    } catch (e) {
      Logger.error('❌ Error translating addresses: $e');
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  /// Start countdown timer
  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        timer.cancel();
        if (!_isCancelled && mounted) {
          _navigateToActiveRide();
        }
      }
    });
  }

  /// Navigate to active ride page after countdown
  void _navigateToActiveRide() {
    if (_isNavigating) return;

    setState(() {
      _isNavigating = true;
    });

    Logger.log('⏰ Countdown finished - navigating to active ride page');

    if (!mounted) return;

    // Get driver ID and user ID from the ride
    final driverId = widget.ride.matchedWith?.driverId ?? '';
    final userId = widget.ride.userId ?? '';

    // Navigate to the active ride page
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => CommuterActiveRidePage(
          ride: widget.ride,
          userId: userId,
          driverId: driverId,
        ),
      ),
    );
  }

  void _showCancelDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFF682AA),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Sound wave icon (matching ride_waiting_page.dart)
                const Icon(Icons.graphic_eq, color: Color(0xFFCF4374), size: 40),
                const SizedBox(height: 16),
                const Text(
                  'کیا آپ واقعی سواری منسوخ کرنا چاہتے ہیں؟',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Cancel (Cross) Button
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.black54,
                          size: 32,
                        ),
                      ),
                    ),
                    // Confirm (Tick) Button
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).pop();
                        _confirmCancelRide(context);
                      },
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xFFF48FB1),
                              Color(0xFFCF4374),
                            ],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _confirmCancelRide(BuildContext context) async {
    setState(() {
      _isCancelled = true;
    });
    _timer?.cancel();

    SocketService.cancelRide(widget.ride.id!);
      Logger.log('Ride cancelled from Matched Page: ${widget.ride.id}');

    Navigator.of(context).popUntil((route) => route.isFirst);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'سواری کی درخواست منسوخ ہو گئی',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Colors.orange,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final driver = widget.ride.matchedWith;

    // Use actual driver data if available, otherwise show defaults
    final String driverName = driver?.driverName ?? 'ڈرائیور صارف';
    final String vehicleModel = driver?.vehicleModel ?? 'نامعلوم ماڈل'; 
    final String vehicleNumber = driver?.vehicleNumber ?? 'N/A';

    return Scaffold(
      body: Container( 
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Back Arrow
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Top Section - Logo and Sound Wave
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 8.0),
                child: Column(
                  children: [
                    // Car Icon - using flutter's built-in icon instead
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF682AA),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(
                        Icons.directions_car,
                        size: 50,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Sound wave indicator
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.volume_up, color: Color(0xFFCF4374), size: 28),
                        const SizedBox(width: 8),
                        ...List.generate(20, (index) {
                          return Container(
                            width: 3,
                            height: (index % 3 == 0) ? 20 : (index % 2 == 0) ? 30 : 15,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFCF4374),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          );
                        }),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'آپ کا ڈرائیور مقرر ہو گیا ہے،\nوہ 5 منٹ کی دوری پر ہے',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Driver Details Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFF682AA),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _buildDetailRow('نام:', driverName),
                      const SizedBox(height: 16),
                      Container(
                        height: 1,
                        color: const Color(0xFFF682AA).withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      _buildDetailRow('گاڑی:', vehicleModel),
                      const SizedBox(height: 16),
                      Container(
                        height: 1,
                        color: const Color(0xFFF682AA).withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      _buildDetailRow('نمبر:', vehicleNumber),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Action Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  textDirection: TextDirection.rtl,
                  children: [
                    _buildActionButton(
                      context,
                      label: 'کال کریں',
                      icon: Icons.call,
                      onTap: () {
                        Logger.log('Call button pressed for driver: $driverName');
                      },
                    ),
                    const SizedBox(width: 20),
                    _buildActionButton(
                      context,
                      label: 'منسوخ کریں',
                      icon: Icons.close,
                      onTap: () => _showCancelDialog(context),
                      isCancel: true,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Bottom Navigation Bar with timer on bottom-left
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFFDF0F4),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Countdown timer on bottom-left
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: const Color(0xFFCF4374),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            '$_remainingSeconds ثانیوں',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                        ),
                        // Navigation items in center
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _buildNavItem(Icons.home_outlined, 'ہوم', true),
                            const SizedBox(width: 20),
                            _buildNavItem(Icons.notifications_outlined, 'اطلاعات', false),
                            const SizedBox(width: 20),
                            _buildNavItem(Icons.person_outline, 'پروفائل', false),
                          ],
                        ),
                        const SizedBox(width: 40),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      textDirection: TextDirection.rtl,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFFCF4374),
          ),
          textDirection: TextDirection.rtl,
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.left,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isCancel = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 140,
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isCancel
                ? [
                    const Color(0xFFF48FB1),
                    const Color(0xFFCF4374),
                  ]
                : [
                    const Color(0xFFF48FB1).withValues(alpha: 0.8),
                    const Color(0xFFCF4374).withValues(alpha: 0.8),
                  ],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCF4374).withValues(alpha: 0.3),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          textDirection: TextDirection.rtl,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 8),
            Icon(icon, color: Colors.white, size: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? const Color(0xFFCF4374) : Colors.grey,
          size: 28,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isActive ? const Color(0xFFCF4374) : Colors.grey,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}
