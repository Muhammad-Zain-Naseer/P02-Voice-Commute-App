import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../widgets/sound_wave.dart';
import '../../services/admin_service.dart';
import 'send_alert_page.dart';

class AdminDashboardScreen extends StatefulWidget {
  final String token;

  const AdminDashboardScreen({super.key, required this.token});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late AdminService _adminService;

  Map<String, dynamic>? _overviewStats;
  Map<String, dynamic>? _userStats;
  Map<String, dynamic>? _driverStats;
  Map<String, dynamic>? _rideStats;
  Map<String, dynamic>? _paymentStats;

  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _adminService = AdminService();
    _adminService.setToken(widget.token);
    _loadAllStats();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadAllStats() async {
    setState(() => _isLoading = true);

    final results = await Future.wait([
      _adminService.getOverviewStats(),
      _adminService.getUserStats(),
      _adminService.getDriverStats(),
      _adminService.getRideStats(),
      _adminService.getPaymentStats(),
    ]);

    setState(() {
      _overviewStats = results[0];
      _userStats = results[1];
      _driverStats = results[2];
      _rideStats = results[3];
      _paymentStats = results[4];
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Admin Dashboard',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.refresh,
                            color: Color(0xFFCF4374),
                            size: 24,
                          ),
                          onPressed: _loadAllStats,
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.campaign,
                            color: Color(0xFFCF4374),
                            size: 24,
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => SendAlertPage(token: widget.token),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Tabs
              Container(
                color: Colors.white.withValues(alpha: 0.5),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  labelColor: const Color(0xFFCF4374),
                  unselectedLabelColor: const Color(0xFFCF4374).withValues(alpha: 0.5),
                  indicatorColor: const Color(0xFFCF4374),
                  tabs: const [
                    Tab(text: 'Overview'),
                    Tab(text: 'Users'),
                    Tab(text: 'Drivers'),
                    Tab(text: 'Rides'),
                    Tab(text: 'Payments'),
                  ],
                ),
              ),

              // Tab Content
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFCF4374)),
                        ),
                      )
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _buildOverviewTab(),
                          _buildUsersTab(),
                          _buildDriversTab(),
                          _buildRidesTab(),
                          _buildPaymentsTab(),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOverviewTab() {
    if (_overviewStats == null) {
      return const Center(child: Text('No data available'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildStatCard(
            'Total Users',
            _overviewStats!['totalUsers'].toString(),
            Icons.people,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Total Drivers',
            _overviewStats!['totalDrivers'].toString(),
            Icons.local_taxi,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Total Rides',
            _overviewStats!['totalRides'].toString(),
            Icons.directions_car,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Completed Rides',
            _overviewStats!['completedRides'].toString(),
            Icons.check_circle,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Admin Revenue (20% Commission)',
            'Rs ${_overviewStats!['adminRevenue'] ?? 0}',
            Icons.attach_money,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Driver Earnings (80%)',
            'Rs ${_overviewStats!['driverEarnings'] ?? 0}',
            Icons.account_balance_wallet,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Approved Drivers',
            _overviewStats!['approvedDrivers'].toString(),
            Icons.verified,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Active Rides (Real-Time)',
            _overviewStats!['activeRides'].toString(),
            Icons.play_circle,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          if (_overviewStats!['connectedUsers'] != null)
            _buildStatCard(
              'Users Online Now',
              _overviewStats!['connectedUsers'].toString(),
              Icons.person_pin,
              const Color(0xFF00BCD4),
            ),
        ],
      ),
    );
  }

  Widget _buildUsersTab() {
    if (_userStats == null) {
      return const Center(child: Text('No data available'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Users',
            _userStats!['totalUsers'].toString(),
            Icons.people,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Verified Users',
            _userStats!['verifiedUsers'].toString(),
            Icons.verified_user,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Unverified Users',
            _userStats!['unverifiedUsers'].toString(),
            Icons.person_off,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Commuters',
            _userStats!['commuters'].toString(),
            Icons.person,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Users with Trusted Contacts',
            _userStats!['usersWithTrustedContacts'].toString(),
            Icons.contact_phone,
            const Color(0xFF00BCD4),
          ),
          const SizedBox(height: 24),
          const Text(
            'Recent Users',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 12),
          ...(_userStats!['recentUsers'] as List).map((user) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    user['role'] == 'driver' ? Icons.local_taxi : Icons.person,
                    color: const Color(0xFFCF4374),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user['name'] ?? 'Unknown',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                        Text(
                          user['email'] ?? '',
                          style: TextStyle(
                            fontSize: 12,
                            color: const Color(0xFFCF4374).withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    user['isVerified'] == true ? Icons.check_circle : Icons.cancel,
                    color: user['isVerified'] == true ? Colors.green : Colors.red,
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildDriversTab() {
    if (_driverStats == null) {
      return const Center(child: Text('No data available'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Drivers',
            _driverStats!['totalDrivers'].toString(),
            Icons.local_taxi,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Pending Approval',
            _driverStats!['pendingDrivers'].toString(),
            Icons.hourglass_empty,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Approved',
            _driverStats!['approvedDrivers'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Rejected',
            _driverStats!['rejectedDrivers'].toString(),
            Icons.cancel,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Suspended',
            _driverStats!['suspendedDrivers'].toString(),
            Icons.block,
            const Color(0xFF000000),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Available Now',
            _driverStats!['availableDrivers'].toString(),
            Icons.check,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 24),
          const Text(
            'Top Drivers',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 12),
          ...(_driverStats!['topDrivers'] as List).map((driver) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.star,
                    color: Color(0xFFFFD700),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          driver['name'] ?? 'Unknown',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                        Text(
                          '${driver['totalRides']} rides • ${driver['averageRating']?.toStringAsFixed(1) ?? '0.0'} ⭐',
                          style: TextStyle(
                            fontSize: 12,
                            color: const Color(0xFFCF4374).withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    driver['isAvailable'] == true ? Icons.check_circle : Icons.cancel,
                    color: driver['isAvailable'] == true ? Colors.green : Colors.grey,
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildRidesTab() {
    if (_rideStats == null) {
      return const Center(child: Text('No data available'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildStatCard(
            'Total Rides',
            _rideStats!['totalRides'].toString(),
            Icons.directions_car,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Active Rides (Real-Time)',
            _rideStats!['matchedRides'].toString(),
            Icons.link,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Completed Rides',
            _rideStats!['completedRides'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Cancelled Rides',
            _rideStats!['cancelledRides'].toString(),
            Icons.cancel,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'SOS Incidents',
            _rideStats!['sosIncidents'].toString(),
            Icons.warning,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Average Rating',
            _rideStats!['averageRating']?.toStringAsFixed(1) ?? '0.0',
            Icons.star,
            const Color(0xFFFFD700),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentsTab() {
    if (_paymentStats == null) {
      return const Center(child: Text('No data available'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Payments',
            _paymentStats!['totalPayments'].toString(),
            Icons.payments,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Pending Verification',
            _paymentStats!['pendingPayments'].toString(),
            Icons.pending,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Verified',
            _paymentStats!['verifiedPayments'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Admin Revenue (20% Commission)',
            'Rs ${_paymentStats!['adminRevenue'] ?? 0}',
            Icons.attach_money,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Driver Earnings (80%)',
            'Rs ${_paymentStats!['driverEarnings'] ?? 0}',
            Icons.account_balance_wallet,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 24),
          const Text(
            'Payment Methods',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 12),
          ...(_paymentStats!['paymentMethods'] as List).map((method) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.payment,
                    color: Color(0xFFCF4374),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      method['_id']?.toString().toUpperCase() ?? 'UNKNOWN',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ),
                  Text(
                    '${method['count']} (Rs ${method['total']})',
                    style: const TextStyle(
                      color: Color(0xFFCF4374),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.2),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    color: const Color(0xFFCF4374).withValues(alpha: 0.7),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
