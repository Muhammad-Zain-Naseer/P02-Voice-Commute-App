/**
 * Verify ALL pending payments and calculate commission
 */

import mongoose from "mongoose";
import dotenv from "dotenv";
import Payment from "./src/models/Payment.js";

dotenv.config();

const verifyAllPendingPayments = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/hersafar");
    console.log("✅ Connected to MongoDB\n");

    // Find all pending payments
    const pendingPayments = await Payment.find({ status: "pending" }).sort({ createdAt: 1 });

    if (pendingPayments.length === 0) {
      console.log("❌ No pending payments found");
      process.exit(0);
    }

    console.log(`📋 Found ${pendingPayments.length} pending payments\n`);
    console.log(`🔄 Verifying all payments...\n`);

    let totalAmount = 0;
    let totalAdminCommission = 0;
    let totalDriverEarnings = 0;

    const commissionRate = 0.20;

    // Process each payment
    for (let i = 0; i < pendingPayments.length; i++) {
      const payment = pendingPayments[i];

      // Calculate commission
      const adminCommission = Math.round(payment.amount * commissionRate);
      const driverEarnings = payment.amount - adminCommission;

      // Update payment
      payment.status = "verified";
      payment.verifiedAt = new Date();
      payment.adminCommission = adminCommission;
      payment.driverEarnings = driverEarnings;
      payment.commissionRate = commissionRate;
      payment.notes = "Bulk verified via script";

      await payment.save();

      totalAmount += payment.amount;
      totalAdminCommission += adminCommission;
      totalDriverEarnings += driverEarnings;

      console.log(`✅ ${i + 1}/${pendingPayments.length} | Rs ${payment.amount} → Admin: Rs ${adminCommission}, Driver: Rs ${driverEarnings}`);
    }

    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`🎉 ALL PAYMENTS VERIFIED!`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
    console.log(`📊 Summary:`);
    console.log(`   Total Payments Verified: ${pendingPayments.length}`);
    console.log(`   Total Ride Amount: Rs ${totalAmount}`);
    console.log(`   Admin Revenue (20%): Rs ${totalAdminCommission}`);
    console.log(`   Driver Earnings (80%): Rs ${totalDriverEarnings}`);
    console.log(`\n💰 Dashboard will now show:`);
    console.log(`   Admin Revenue: Rs ${totalAdminCommission + 28}  (includes previous Rs 28)`);
    console.log(`   Driver Earnings: Rs ${totalDriverEarnings + 112}  (includes previous Rs 112)`);
    console.log(`\n🔄 Refresh your admin dashboard to see the updated revenue!`);

    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error.message);
    process.exit(1);
  }
};

verifyAllPendingPayments();
