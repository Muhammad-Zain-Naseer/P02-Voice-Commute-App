import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "./src/models/User.js";

dotenv.config();

const seedAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB");

    // Check if admin already exists
    const existingAdmin = await User.findOne({ email: "admin@hersafar.com" });

    if (existingAdmin) {
      // Update existing admin's PIN to be numeric
      existingAdmin.pin = "1234";
      await existingAdmin.save();
      console.log("Admin user already exists - PIN updated to numeric");
      console.log("Email: admin@hersafar.com");
      console.log("PIN: 1234");
      process.exit(0);
    }

    // Create admin user with email "admin@hersafar.com" and PIN "1234"
    const adminUser = new User({
      userId: `admin-${Date.now()}`,
      name: "Admin",
      email: "admin@hersafar.com",
      pin: "1234",
      role: "admin",
      isVerified: true,
    });

    await adminUser.save();
    console.log("Admin user created successfully!");
    console.log("Email: admin@hersafar.com");
    console.log("PIN: 1234");

    process.exit(0);
  } catch (error) {
    console.error("Error seeding admin:", error);
    process.exit(1);
  }
};

seedAdmin();
