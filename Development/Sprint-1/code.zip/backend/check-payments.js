/**
 * Check all payments and their status
 */

import mongoose from "mongoose";
import dotenv from "dotenv";
import Payment from "./src/models/Payment.js";

dotenv.config();

const checkPayments = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/hersafar");
    console.log("✅ Connected to MongoDB\n");

    // Get all payments
    const allPayments = await Payment.find().sort({ createdAt: -1 });

    console.log(`📊 Total Payments: ${allPayments.length}\n`);

    // Group by status
    const pending = allPayments.filter(p => p.status === 'pending');
    const verified = allPayments.filter(p => p.status === 'verified');
    const rejected = allPayments.filter(p => p.status === 'rejected');

    console.log(`Status Breakdown:`);
    console.log(`  ✅ Verified: ${verified.length}`);
    console.log(`  ⏳ Pending: ${pending.length}`);
    console.log(`  ❌ Rejected: ${rejected.length}\n`);

    if (pending.length > 0) {
      console.log(`⏳ PENDING PAYMENTS:\n`);
      pending.forEach((p, i) => {
        console.log(`${i + 1}. Amount: Rs ${p.amount} | Method: ${p.paymentMethod} | Submitted: ${p.submittedAt}`);
        console.log(`   RideID: ${p.rideId}`);
        console.log(`   PaymentID: ${p._id}\n`);
      });
    }

    if (verified.length > 0) {
      console.log(`✅ VERIFIED PAYMENTS:\n`);
      let totalAdminRevenue = 0;
      let totalDriverEarnings = 0;

      verified.forEach((p, i) => {
        console.log(`${i + 1}. Amount: Rs ${p.amount} | Admin: Rs ${p.adminCommission} | Driver: Rs ${p.driverEarnings}`);
        totalAdminRevenue += p.adminCommission || 0;
        totalDriverEarnings += p.driverEarnings || 0;
      });

      console.log(`\n💰 TOTAL REVENUE:`);
      console.log(`   Admin Revenue (20%): Rs ${totalAdminRevenue}`);
      console.log(`   Driver Earnings (80%): Rs ${totalDriverEarnings}`);
      console.log(`   Total: Rs ${totalAdminRevenue + totalDriverEarnings}`);
    }

    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error.message);
    process.exit(1);
  }
};

checkPayments();
