/**
 * Quick script to verify a pending payment
 * This simulates what happens when admin clicks "Verify" in the UI
 */

import mongoose from "mongoose";
import dotenv from "dotenv";
import Payment from "./src/models/Payment.js";

dotenv.config();

const verifyLatestPayment = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/hersafar");
    console.log("✅ Connected to MongoDB");

    // Find the latest pending payment
    const payment = await Payment.findOne({ status: "pending" })
      .sort({ createdAt: -1 });

    if (!payment) {
      console.log("❌ No pending payments found");
      process.exit(0);
    }

    console.log(`\n📋 Found pending payment:`);
    console.log(`   Payment ID: ${payment._id}`);
    console.log(`   Ride ID: ${payment.rideId}`);
    console.log(`   Amount: Rs ${payment.amount}`);
    console.log(`   Method: ${payment.paymentMethod}`);
    console.log(`   Status: ${payment.status}`);

    // Calculate commission (20% to admin, 80% to driver)
    const commissionRate = 0.20;
    const adminCommission = Math.round(payment.amount * commissionRate);
    const driverEarnings = payment.amount - adminCommission;

    console.log(`\n💰 Commission Breakdown:`);
    console.log(`   Admin Commission (20%): Rs ${adminCommission}`);
    console.log(`   Driver Earnings (80%): Rs ${driverEarnings}`);

    // Update payment
    payment.status = "verified";
    payment.verifiedAt = new Date();
    payment.adminCommission = adminCommission;
    payment.driverEarnings = driverEarnings;
    payment.commissionRate = commissionRate;
    payment.notes = "Auto-verified via script";

    await payment.save();

    console.log(`\n✅ Payment verified successfully!`);
    console.log(`   Status: ${payment.status}`);
    console.log(`   Admin earned: Rs ${payment.adminCommission}`);
    console.log(`   Driver earned: Rs ${payment.driverEarnings}`);
    console.log(`\n🎉 Revenue will now show in admin dashboard!`);

    process.exit(0);
  } catch (error) {
    console.error("❌ Error:", error.message);
    process.exit(1);
  }
};

verifyLatestPayment();
