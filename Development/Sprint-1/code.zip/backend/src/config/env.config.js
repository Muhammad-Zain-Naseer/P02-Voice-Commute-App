import dotenv from "dotenv";
dotenv.config();
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file
dotenv.config({ path: path.join(__dirname, "../../.env") });

// Export configuration object
const config = {
  // Server Configuration
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || "development",

  // Logging
  logLevel: process.env.LOG_LEVEL || "info",

  // Add more configuration as needed

  mongoUri: process.env.MONGODB_URI,
  jwtSecret: process.env.JWT_SECRET,
  jwtExpire: "7d",

  emailFrom: process.env.EMAIL_FROM,
  sendgridApiKey: process.env.SENDGRID_API_KEY,
  appName: process.env.APP_NAME || "MyApp"
};

export default config;
