import express from "express";
import adminController from "../controllers/admin.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorize } from "../middleware/role.middleware.js";
import connectionPoolService from "../services/connectionPool.service.js";

const router = express.Router();

// Debug endpoint - check connection pool (NO AUTH for quick testing)
router.get("/debug/pool", (req, res) => {
  const stats = connectionPoolService.getStats();
  const allRides = connectionPoolService.getRides();

  res.json({
    success: true,
    stats,
    rides: allRides.map(r => ({
      id: r.id,
      status: r.status,
      userName: r.userName,
      source: r.source.address,
      destination: r.destination.address,
      createdAt: r.createdAt
    }))
  });
});

// All admin routes require authentication and admin role
router.use(authenticate);
router.use(authorize("admin"));

// Dashboard statistics
router.get("/stats/overview", (req, res) => adminController.getOverviewStats(req, res));
router.get("/stats/users", (req, res) => adminController.getUserStats(req, res));
router.get("/stats/drivers", (req, res) => adminController.getDriverStats(req, res));
router.get("/stats/rides", (req, res) => adminController.getRideStats(req, res));
router.get("/stats/payments", (req, res) => adminController.getPaymentStats(req, res));

// User management
router.get("/users", (req, res) => adminController.getUsers(req, res));
router.get("/users/:userId", (req, res) => adminController.getUserDetails(req, res));
router.patch("/users/:userId/verify", (req, res) => adminController.verifyUser(req, res));

// Driver management
router.get("/drivers", (req, res) => adminController.getDrivers(req, res));
router.get("/drivers/:driverId", (req, res) => adminController.getDriverDetails(req, res));
router.patch("/drivers/:driverId/status", (req, res) => adminController.updateDriverStatus(req, res));

// Ride management
router.get("/rides", (req, res) => adminController.getRides(req, res));
router.get("/rides/:rideId", (req, res) => adminController.getRideDetails(req, res));

// Payment management
router.get("/payments/pending", (req, res) => adminController.getPendingPayments(req, res));
router.patch("/payments/:paymentId/verify", (req, res) => adminController.verifyPayment(req, res));
router.patch("/payments/:paymentId/reject", (req, res) => adminController.rejectPayment(req, res));

export default router;
