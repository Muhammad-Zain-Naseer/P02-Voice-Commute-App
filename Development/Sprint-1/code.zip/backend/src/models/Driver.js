import mongoose from "mongoose";

const driverSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      ref: "User",
      required: false,
      unique: true,
      index: true
    },

    name: {
      type: String,
      required: true,
      trim: true
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true
    },
    phone: {
      type: String,
      sparse: true,
      trim: true
    },
    cnic: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true
    },
    drivingLicense: {
      type: String,
      required: false,
      unique: true,
      sparse: true,
      trim: true,
      index: true
    },
    isVerified: {
      type: Boolean,
      default: false
    },
    verificationOTP: String,
    verificationOTPExpiry: Date,

    // Vehicle Information
    vehicle: {
      registrationNumber: {
        type: String,
        required: false,
        unique: true,
        uppercase: true,
        trim: true,
        sparse: true,
        index: true
      },
      color: {
        type: String,
        trim: true
      },
      model: {
        type: String,
        trim: true
      },
      registrationPhoto: {
        type: String,
        default: null
      },
      year: { type: String }
    },

    // Driver Status
    status: {
      type: String,
      enum: ["pending", "approved", "rejected", "suspended"],
      default: "pending",
      index: true
    },

    approvalDate: Date,
    rejectionReason: String,

    // Ratings
    averageRating: {
      type: Number,
      default: 0
    },
    totalRides: {
      type: Number,
      default: 0
    },

    // Activity
    isAvailable: {
      type: Boolean,
      default: false
    },
    lastLogin: Date,

    // Payment
    paymentAccounts: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

// Virtual populate
driverSchema.virtual("user", {
  ref: "User",
  localField: "userId",
  foreignField: "userId",
  justOne: true
});

driverSchema.set("toJSON", { virtuals: true });
driverSchema.set("toObject", { virtuals: true });

export default mongoose.model("Driver", driverSchema);
