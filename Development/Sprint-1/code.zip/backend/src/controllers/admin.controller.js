import User from "../models/User.js";
import Driver from "../models/Driver.js";
import Ride from "../models/Ride.js";
import Payment from "../models/Payment.js";
import logger from "../utils/logger.js";
import connectionPoolService from "../services/connectionPool.service.js";

class AdminController {
  // Get overview statistics
  async getOverviewStats(req, res) {
    try {
      // Get real-time active rides from connection pool
      const poolStats = connectionPoolService.getStats();

      const [
        totalUsers,
        totalDrivers,
        totalRides,
        completedRides,
        revenueStats,
        pendingPayments,
        approvedDrivers,
        pendingDrivers
      ] = await Promise.all([
        User.countDocuments({ role: { $in: ["commuter", "driver"] } }),
        Driver.countDocuments(),
        Ride.countDocuments(),
        Ride.countDocuments({ status: "completed" }),
        Payment.aggregate([
          { $match: { status: "verified" } },
          {
            $group: {
              _id: null,
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" }
            }
          }
        ]),
        Payment.countDocuments({ status: "pending" }),
        Driver.countDocuments({ status: "approved" }),
        Driver.countDocuments({ status: "pending" })
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalUsers,
          totalDrivers,
          totalRides,
          completedRides,
          adminRevenue: revenueStats[0]?.adminRevenue || 0,
          driverEarnings: revenueStats[0]?.driverEarnings || 0,
          pendingPayments,
          approvedDrivers,
          pendingDrivers,
          activeRides: poolStats.totalRides, // Real-time active rides from memory
          pendingRidesNow: poolStats.pendingRides, // Rides waiting for match
          matchedRidesNow: poolStats.matchedRides, // Rides in progress
          connectedUsers: poolStats.connectedUsers, // Users online now
          timestamp: new Date()
        }
      });
    } catch (error) {
      logger.error("Error in getOverviewStats:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch overview statistics"
      });
    }
  }

  // Get user statistics
  async getUserStats(req, res) {
    try {
      const [
        totalUsers,
        verifiedUsers,
        unverifiedUsers,
        commuters,
        driversWithAccount,
        usersWithTrustedContacts,
        recentUsers
      ] = await Promise.all([
        User.countDocuments(),
        User.countDocuments({ isVerified: true }),
        User.countDocuments({ isVerified: false }),
        User.countDocuments({ role: "commuter" }),
        User.countDocuments({ role: "driver" }),
        User.countDocuments({ "trustedContacts.0": { $exists: true } }),
        User.find()
          .sort({ createdAt: -1 })
          .limit(7)
          .select("name email role isVerified createdAt lastLogin")
      ]);

      // Get user growth by day (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const userGrowth = await User.aggregate([
        { $match: { createdAt: { $gte: sevenDaysAgo } } },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
            count: { $sum: 1 }
          }
        },
        { $sort: { _id: 1 } }
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalUsers,
          verifiedUsers,
          unverifiedUsers,
          commuters,
          driversWithAccount,
          usersWithTrustedContacts,
          recentUsers,
          userGrowth
        }
      });
    } catch (error) {
      logger.error("Error in getUserStats:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch user statistics"
      });
    }
  }

  // Get driver statistics
  async getDriverStats(req, res) {
    try {
      const [
        totalDrivers,
        pendingDrivers,
        approvedDrivers,
        rejectedDrivers,
        suspendedDrivers,
        availableDrivers,
        topDrivers
      ] = await Promise.all([
        Driver.countDocuments(),
        Driver.countDocuments({ status: "pending" }),
        Driver.countDocuments({ status: "approved" }),
        Driver.countDocuments({ status: "rejected" }),
        Driver.countDocuments({ status: "suspended" }),
        Driver.countDocuments({ isAvailable: true, status: "approved" }),
        Driver.find({ status: "approved" })
          .sort({ averageRating: -1, totalRides: -1 })
          .limit(10)
          .select("name email averageRating totalRides isAvailable vehicle.model")
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalDrivers,
          pendingDrivers,
          approvedDrivers,
          rejectedDrivers,
          suspendedDrivers,
          availableDrivers,
          topDrivers
        }
      });
    } catch (error) {
      logger.error("Error in getDriverStats:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch driver statistics"
      });
    }
  }

  // Get ride statistics
  async getRideStats(req, res) {
    try {
      // Get real-time active rides from connection pool
      const poolStats = connectionPoolService.getStats();

      const [
        totalRides,
        completedRides,
        cancelledRides,
        sosIncidents,
        avgRating
      ] = await Promise.all([
        Ride.countDocuments(),
        Ride.countDocuments({ status: "completed" }),
        Ride.countDocuments({ status: "cancelled" }),
        Ride.countDocuments({ "sosAlert.triggeredAt": { $exists: true } }),
        Ride.aggregate([
          { $match: { rating: { $ne: null } } },
          { $group: { _id: null, avg: { $avg: "$rating" } } }
        ])
      ]);

      // Get ride trends (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const rideTrends = await Ride.aggregate([
        { $match: { createdAt: { $gte: sevenDaysAgo } } },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
            total: { $sum: 1 },
            completed: {
              $sum: { $cond: [{ $eq: ["$status", "completed"] }, 1, 0] }
            },
            cancelled: {
              $sum: { $cond: [{ $eq: ["$status", "cancelled"] }, 1, 0] }
            }
          }
        },
        { $sort: { _id: 1 } }
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalRides,
          pendingRides: poolStats.pendingRides, // Real-time from connection pool
          matchedRides: poolStats.matchedRides, // Real-time from connection pool
          completedRides,
          cancelledRides,
          sosIncidents,
          averageRating: avgRating[0]?.avg || 0,
          rideTrends,
          activeRidesNow: poolStats.totalRides, // Real-time active rides
          connectedUsers: poolStats.connectedUsers // Users online now
        }
      });
    } catch (error) {
      logger.error("Error in getRideStats:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch ride statistics"
      });
    }
  }

  // Get payment statistics
  async getPaymentStats(req, res) {
    try {
      const [
        totalPayments,
        pendingPayments,
        verifiedPayments,
        rejectedPayments,
        revenueStats,
        paymentMethods,
        revenueByDay
      ] = await Promise.all([
        Payment.countDocuments(),
        Payment.countDocuments({ status: "pending" }),
        Payment.countDocuments({ status: "verified" }),
        Payment.countDocuments({ status: "rejected" }),
        Payment.aggregate([
          { $match: { status: "verified" } },
          {
            $group: {
              _id: null,
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" }
            }
          }
        ]),
        Payment.aggregate([
          {
            $group: {
              _id: "$paymentMethod",
              count: { $sum: 1 },
              total: { $sum: "$amount" }
            }
          }
        ]),
        Payment.aggregate([
          {
            $match: {
              status: "verified",
              createdAt: {
                $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
              }
            }
          },
          {
            $group: {
              _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
              adminRevenue: { $sum: "$adminCommission" },
              driverEarnings: { $sum: "$driverEarnings" },
              count: { $sum: 1 }
            }
          },
          { $sort: { _id: 1 } }
        ])
      ]);

      res.status(200).json({
        success: true,
        data: {
          totalPayments,
          pendingPayments,
          verifiedPayments,
          rejectedPayments,
          adminRevenue: revenueStats[0]?.adminRevenue || 0,
          driverEarnings: revenueStats[0]?.driverEarnings || 0,
          paymentMethods,
          revenueByDay
        }
      });
    } catch (error) {
      logger.error("Error in getPaymentStats:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch payment statistics"
      });
    }
  }

  // Get users with filters
  async getUsers(req, res) {
    try {
      const { role, isVerified, limit = 50, page = 1 } = req.query;
      const query = {};

      if (role) query.role = role;
      if (isVerified !== undefined) query.isVerified = isVerified === "true";

      const users = await User.find(query)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit))
        .select("-pin -verificationToken -verificationTokenExpiry");

      const total = await User.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          users,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getUsers:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch users"
      });
    }
  }

  // Get user details
  async getUserDetails(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOne({ userId }).select(
        "-pin -verificationToken -verificationTokenExpiry"
      );

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      res.status(200).json({
        success: true,
        data: user
      });
    } catch (error) {
      logger.error("Error in getUserDetails:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch user details"
      });
    }
  }

  // Verify user
  async verifyUser(req, res) {
    try {
      const { userId } = req.params;

      const user = await User.findOneAndUpdate(
        { userId },
        { isVerified: true, verificationToken: undefined, verificationTokenExpiry: undefined },
        { new: true }
      ).select("-pin");

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      res.status(200).json({
        success: true,
        message: "User verified successfully",
        data: user
      });
    } catch (error) {
      logger.error("Error in verifyUser:", error);
      res.status(500).json({
        success: false,
        message: "Failed to verify user"
      });
    }
  }

  // Get drivers with filters
  async getDrivers(req, res) {
    try {
      const { status, limit = 50, page = 1 } = req.query;
      const query = {};

      if (status) query.status = status;

      const drivers = await Driver.find(query)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Driver.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          drivers,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getDrivers:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch drivers"
      });
    }
  }

  // Get driver details
  async getDriverDetails(req, res) {
    try {
      const { driverId } = req.params;

      const driver = await Driver.findOne({ userId: driverId });

      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver not found"
        });
      }

      res.status(200).json({
        success: true,
        data: driver
      });
    } catch (error) {
      logger.error("Error in getDriverDetails:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch driver details"
      });
    }
  }

  // Update driver status
  async updateDriverStatus(req, res) {
    try {
      const { driverId } = req.params;
      const { status, rejectionReason } = req.body;

      if (!["pending", "approved", "rejected", "suspended"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid status"
        });
      }

      const updateData = { status };

      if (status === "approved") {
        updateData.isVerified = true;
        updateData.approvalDate = new Date();
      }

      if (status === "rejected" && rejectionReason) {
        updateData.rejectionReason = rejectionReason;
      }

      const driver = await Driver.findOneAndUpdate(
        { userId: driverId },
        updateData,
        { new: true }
      );

      if (!driver) {
        return res.status(404).json({
          success: false,
          message: "Driver not found"
        });
      }

      res.status(200).json({
        success: true,
        message: "Driver status updated successfully",
        data: driver
      });
    } catch (error) {
      logger.error("Error in updateDriverStatus:", error);
      res.status(500).json({
        success: false,
        message: "Failed to update driver status"
      });
    }
  }

  // Get rides with filters
  async getRides(req, res) {
    try {
      const { status, userId, limit = 50, page = 1 } = req.query;
      const query = {};

      if (status) query.status = status;
      if (userId) query.userId = userId;

      const rides = await Ride.find(query)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Ride.countDocuments(query);

      res.status(200).json({
        success: true,
        data: {
          rides,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getRides:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch rides"
      });
    }
  }

  // Get ride details
  async getRideDetails(req, res) {
    try {
      const { rideId } = req.params;

      const ride = await Ride.findOne({ rideId });

      if (!ride) {
        return res.status(404).json({
          success: false,
          message: "Ride not found"
        });
      }

      res.status(200).json({
        success: true,
        data: ride
      });
    } catch (error) {
      logger.error("Error in getRideDetails:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch ride details"
      });
    }
  }

  // Get pending payments
  async getPendingPayments(req, res) {
    try {
      const { limit = 50, page = 1 } = req.query;

      const payments = await Payment.find({ status: "pending" })
        .sort({ submittedAt: 1 })
        .limit(parseInt(limit))
        .skip((parseInt(page) - 1) * parseInt(limit));

      const total = await Payment.countDocuments({ status: "pending" });

      res.status(200).json({
        success: true,
        data: {
          payments,
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      });
    } catch (error) {
      logger.error("Error in getPendingPayments:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch pending payments"
      });
    }
  }

  // Verify payment
  async verifyPayment(req, res) {
    try {
      const { paymentId } = req.params;
      const { notes } = req.body;

      // Find the payment first to get the amount
      const payment = await Payment.findById(paymentId);

      if (!payment) {
        return res.status(404).json({
          success: false,
          message: "Payment not found"
        });
      }

      // Calculate commission (20% to admin, 80% to driver)
      const commissionRate = 0.20;
      const adminCommission = Math.round(payment.amount * commissionRate);
      const driverEarnings = payment.amount - adminCommission;

      // Update payment with commission breakdown
      payment.status = "verified";
      payment.verifiedAt = new Date();
      payment.verifiedBy = req.user._id;
      payment.notes = notes;
      payment.adminCommission = adminCommission;
      payment.driverEarnings = driverEarnings;
      payment.commissionRate = commissionRate;

      await payment.save();

      res.status(200).json({
        success: true,
        message: "Payment verified successfully",
        data: payment
      });
    } catch (error) {
      logger.error("Error in verifyPayment:", error);
      res.status(500).json({
        success: false,
        message: "Failed to verify payment"
      });
    }
  }

  // Reject payment
  async rejectPayment(req, res) {
    try {
      const { paymentId } = req.params;
      const { notes } = req.body;

      const payment = await Payment.findByIdAndUpdate(
        paymentId,
        {
          status: "rejected",
          verifiedAt: new Date(),
          verifiedBy: req.user._id,
          notes
        },
        { new: true }
      );

      if (!payment) {
        return res.status(404).json({
          success: false,
          message: "Payment not found"
        });
      }

      res.status(200).json({
        success: true,
        message: "Payment rejected",
        data: payment
      });
    } catch (error) {
      logger.error("Error in rejectPayment:", error);
      res.status(500).json({
        success: false,
        message: "Failed to reject payment"
      });
    }
  }
}

export default new AdminController();
