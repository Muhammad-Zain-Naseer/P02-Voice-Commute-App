import User from "../models/User.js";
import emailService from "../services/emailService.js";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

class AuthController {
  // Generate JWT
  generateToken(userId) {
    return jwt.sign({ userId }, config.jwtSecret, {
      expiresIn: config.jwtExpire
    });
  }

  // Request OTP for signup
  async signup(req, res) {
    try {
      let { name, email, pin, role, trustedContactEmail, trustedContactName } =
        req.body;

      if (!name) {
        return res.status(400).json({
          success: false,
          message: "Name is required"
        });
      }

      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({
          success: false,
          message: "Invalid email format"
        });
      }

      email = email.toLowerCase().trim();

      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: "User already exists. Please login."
        });
      }

      if (!/^\d{4}$/.test(pin)) {
        return res.status(400).json({
          success: false,
          message: "PIN must be exactly 4 digits"
        });
      }

      // Validate trusted contact email if provided
      if (trustedContactEmail) {
        const trustedEmail = trustedContactEmail.toLowerCase().trim();

        if (!emailRegex.test(trustedEmail)) {
          return res.status(400).json({
            success: false,
            message: "Invalid trusted contact email format"
          });
        }

        if (trustedEmail === email) {
          return res.status(400).json({
            success: false,
            message: "Trusted contact email cannot be the same as your email"
          });
        }
      }

      // Generate verification token
      const verificationToken = crypto.randomBytes(32).toString("hex");
      const verificationTokenExpiry = new Date(
        Date.now() + 24 * 60 * 60 * 1000
      ); // 24 hours

      const userData = new User({
        name: name.trim(),
        email,
        pin,
        role: role || "commuter",
        isVerified: false,
        verificationToken,
        verificationTokenExpiry
      });

      // Add trusted contact if provided
      if (trustedContactEmail) {
        userData.trustedContacts = [
          {
            email: trustedContactEmail.toLowerCase().trim(),
            name: trustedContactName?.trim() || undefined
          }
        ];
      }

      const user = new User(userData);
      await user.save();

      // Send verification email
      const verificationUrl = `${config.frontendUrl}/verify-email?token=${verificationToken}`;
      await emailService.sendVerificationEmail(email, verificationUrl);

      res.status(201).json({
        success: true,
        message:
          "Account created successfully. Please check your email to verify your account.",
        data: {
          email: user.email
        }
      });
    } catch (error) {
      logger.error("Error in signup:", error);
      res.status(500).json({
        success: false,
        message: "Failed to create account"
      });
    }
  }

  // Verify email
  async verifyEmail(req, res) {
    try {
      const { token } = req.query;

      if (!token) {
        return res.status(400).json({
          success: false,
          message: "Verification token is required"
        });
      }

      const user = await User.findOne({
        verificationToken: token,
        verificationTokenExpiry: { $gt: Date.now() }
      });

      if (!user) {
        return res.status(400).json({
          success: false,
          message: "Invalid or expired verification token"
        });
      }

      user.isVerified = true;
      user.verificationToken = undefined;
      user.verificationTokenExpiry = undefined;
      await user.save();

      const authToken = this.generateToken(user._id);

      res.status(200).json({
        success: true,
        message: "Email verified successfully",
        data: {
          user: {
            id: user._id,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified
          },
          token: authToken
        }
      });
    } catch (error) {
      logger.error("Error in verifyEmail:", error);
      res.status(500).json({
        success: false,
        message: "Email verification failed"
      });
    }
  }

  // Resend verification email
  async resendVerificationEmail(req, res) {
    try {
      let { email } = req.body;

      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }

      email = email.toLowerCase().trim();

      const user = await User.findOne({ email });

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      if (user.isVerified) {
        return res.status(400).json({
          success: false,
          message: "Email is already verified"
        });
      }

      // Generate new verification token
      const verificationToken = crypto.randomBytes(32).toString("hex");
      const verificationTokenExpiry = new Date(
        Date.now() + 24 * 60 * 60 * 1000
      );

      user.verificationToken = verificationToken;
      user.verificationTokenExpiry = verificationTokenExpiry;
      await user.save();

      // Send verification email
      const verificationUrl = `${config.frontendUrl}/verify-email?token=${verificationToken}`;
      await emailService.sendVerificationEmail(email, verificationUrl);

      res.status(200).json({
        success: true,
        message: "Verification email sent successfully"
      });
    } catch (error) {
      logger.error("Error in resendVerificationEmail:", error);
      res.status(500).json({
        success: false,
        message: "Failed to resend verification email"
      });
    }
  }

  // Login
  async login(req, res) {
    try {
      let { email, pin } = req.body;

      if (!email || !pin) {
        return res.status(400).json({
          success: false,
          message: "Email and PIN are required"
        });
      }

      email = email.toLowerCase().trim();

      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: "Invalid email or PIN"
        });
      }

      if (!user.isVerified) {
        return res.status(403).json({
          success: false,
          message: "Please verify your email before logging in"
        });
      }

      const isPinValid = await user.comparePin(pin);
      if (!isPinValid) {
        return res.status(401).json({
          success: false,
          message: "Invalid email or PIN"
        });
      }

      user.lastLogin = new Date();
      await user.save();

      const token = this.generateToken(user._id);

      res.status(200).json({
        success: true,
        message: "Login successful",
        data: {
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            role: user.role
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in login:", error);
      res.status(500).json({
        success: false,
        message: "Login failed"
      });
    }
  }
}

export default new AuthController();
