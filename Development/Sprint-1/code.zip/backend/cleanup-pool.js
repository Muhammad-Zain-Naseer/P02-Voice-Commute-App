/**
 * Clean up stale rides from connection pool
 */

import axios from 'axios';

const cleanupPool = async () => {
  try {
    console.log("🧹 Checking connection pool...\n");

    // Get current pool state
    const response = await axios.get('http://localhost:3000/api/admin/debug/pool');
    const { stats, rides } = response.data;

    console.log("📊 Current Pool State:");
    console.log(`   Total Rides: ${stats.totalRides}`);
    console.log(`   Connected Users: ${stats.connectedUsers}`);
    console.log(`   Matched Rides: ${stats.matchedRides}\n`);

    if (rides.length === 0) {
      console.log("✅ Pool is clean! No rides to remove.\n");
      return;
    }

    console.log("🔍 Rides in pool:");
    rides.forEach((ride, i) => {
      const createdAt = new Date(ride.createdAt);
      const ageMinutes = Math.round((Date.now() - createdAt) / 60000);
      console.log(`   ${i + 1}. ${ride.id} | Status: ${ride.status} | Age: ${ageMinutes} mins | User: ${ride.userName}`);
    });

    if (stats.connectedUsers === 0 && stats.totalRides > 0) {
      console.log("\n⚠️  Found stale rides (no users connected)");
      console.log("💡 Restart the backend server to clear the connection pool automatically.");
      console.log("   OR wait - they will auto-cleanup after 60 minutes.");
    } else {
      console.log("\n✅ Pool looks normal (users are connected)");
    }

  } catch (error) {
    console.error("❌ Error:", error.message);
  }
};

cleanupPool();
