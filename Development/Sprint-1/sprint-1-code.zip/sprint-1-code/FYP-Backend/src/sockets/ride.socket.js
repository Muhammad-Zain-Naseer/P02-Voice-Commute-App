/**
 * Socket Event Handlers for Ride Matching System
 * Handles real-time ride requests, matching, and updates
 */

import connectionPoolService from "../services/connectionPool.service.js";
import emailService from "../services/emailService.js";
import User from "../models/User.js";
import logger from "../utils/logger.js";

/**
 * Setup ride-related socket event handlers
 * @param {Server} io - Socket.IO server instance
 * @param {Socket} socket - Individual socket connection
 */
export const handleRideEvents = (io, socket) => {
  logger.info(`Setting up ride event handlers for socket: ${socket.id}`);

  /**
   * Handle user connection initialization
   * Client sends user data when connecting
   */
  socket.on("user:register", (userData) => {
    try {
      logger.info(`User registration: ${JSON.stringify(userData)}`);

      const userType = userData.userType || "commuter";

      // Add user to connection pool
      connectionPoolService.addUser(socket.id, {
        userId: userData.userId || socket.id,
        userName: userData.userName || "Anonymous User",
        userEmail: userData.userEmail || null,
        userType: userType
      });

      // Join appropriate room based on user type
      if (userType === "driver") {
        socket.join("drivers");
        logger.info(`Driver joined 'drivers' room: ${socket.id}`);

        // Send all pending rides to the driver when they join
        const pendingRides = connectionPoolService.getPendingRides();
        socket.emit("ride:list", {
          success: true,
          rides: pendingRides.map((ride) => ride.toJSON()),
          count: pendingRides.length
        });
        logger.info(
          `Sent ${pendingRides.length} pending rides to newly joined driver`
        );
      } else if (userType === "commuter") {
        socket.join("commuters");
        logger.info(`Commuter joined 'commuters' room: ${socket.id}`);
      }

      // Send acknowledgment with pool stats
      const stats = connectionPoolService.getStats();
      socket.emit("user:registered", {
        success: true,
        socketId: socket.id,
        userType: userType,
        room: userType === "driver" ? "drivers" : "commuters",
        stats
      });

      logger.info(`User registered successfully: ${socket.id} as ${userType}`);
    } catch (error) {
      logger.error(`Error in user:register: ${error.message}`);
      socket.emit("error", {
        event: "user:register",
        message: "Failed to register user"
      });
    }
  });

  /**
   * Handle new ride creation
   * Commuter creates a ride request with source and destination
   */
  socket.on("ride:create", (rideData) => {
    try {
      logger.info(`Ride creation request: ${JSON.stringify(rideData)}`);

      // Validate ride data
      if (!rideData.source || !rideData.destination) {
        socket.emit("ride:error", {
          message: "Source and destination are required"
        });
        return;
      }

      // Get user from connection pool
      const user = connectionPoolService.getUser(socket.id);

      // Add ride to connection pool
      const ride = connectionPoolService.addRide({
        userId: user?.userId || socket.id,
        userName: user?.userName || rideData.userName || "Anonymous User",
        userEmail: user?.userEmail || rideData.userEmail || null,
        userType: "commuter",
        source: rideData.source,
        destination: rideData.destination,
        sourceCoordinates: rideData.sourceCoordinates || null,
        destinationCoordinates: rideData.destinationCoordinates || null,
        socketId: socket.id
      });

      // Notify the commuter that ride was created
      socket.emit("ride:created", {
        success: true,
        ride: ride.toJSON()
      });

      // Emit new ride to ALL drivers in the 'drivers' room
      io.to("drivers").emit("ride:new", {
        ride: ride.toJSON()
      });

      logger.info(`Ride created and sent to drivers room: ${ride.id}`);
    } catch (error) {
      logger.error(`Error in ride:create: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to create ride request"
      });
    }
  });

  /**
   * Handle ride list request
   * Drivers request list of all available rides
   */
  socket.on("ride:list", () => {
    try {
      logger.info(`Ride list requested by: ${socket.id}`);

      // Get pending rides by default
      const rides = connectionPoolService.getPendingRides();

      socket.emit("ride:list", {
        success: true,
        rides: rides.map((ride) => ride.toJSON()),
        count: rides.length
      });

      logger.info(`Sent ${rides.length} pending rides to ${socket.id}`);
    } catch (error) {
      logger.error(`Error in ride:list: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to fetch ride list"
      });
    }
  });

  /**
   * Handle ride matching
   * Driver accepts a ride request
   */
  socket.on("ride:match", (matchData) => {
    try {
      logger.info(`Ride match request: ${JSON.stringify(matchData)}`);

      const { rideId, driverId, driverName } = matchData;

      if (!rideId) {
        socket.emit("ride:error", {
          message: "Ride ID is required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      if (ride.status !== "pending") {
        socket.emit("ride:error", {
          message: "Ride is no longer available"
        });
        return;
      }

      // Get driver's email from connection pool for database lookups
      const driverConnection = connectionPoolService.getUser(socket.id);
      const driverEmail = driverConnection?.userEmail || null;

      // Match the ride
      const matchedRide = connectionPoolService.matchRide(rideId, {
        driverId: driverId || socket.id,
        driverName: driverName || "Driver",
        driverEmail: driverEmail, // Store email for later database lookups
        socketId: socket.id
      });

      if (!matchedRide) {
        socket.emit("ride:error", {
          message: "Failed to match ride"
        });
        return;
      }

      // Notify the driver
      socket.emit("ride:matched", {
        success: true,
        ride: matchedRide.toJSON(),
        role: "driver"
      });

      // Notify the commuter
      io.to(matchedRide.socketId).emit("ride:matched", {
        success: true,
        ride: matchedRide.toJSON(),
        role: "commuter"
      });

      // Broadcast to all drivers in the room that this ride is no longer available
      io.to("drivers").emit("ride:unavailable", {
        rideId: matchedRide.id
      });

      logger.info(
        `Ride matched successfully: ${rideId} with driver: ${socket.id}`
      );

      // Don't remove matched rides automatically - they stay until completed
      // This allows REST API endpoints (like SOS) to access the ride
    } catch (error) {
      logger.error(`Error in ride:match: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to match ride"
      });
    }
  });

  /**
   * Handle driver reached notification
   * Driver notifies that they have reached the pickup location
   */
  socket.on("driver:reached", (data) => {
    try {
      logger.info(`Driver reached notification: ${JSON.stringify(data)}`);

      const { rideId } = data;

      if (!rideId) {
        socket.emit("ride:error", {
          message: "Ride ID is required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if the ride is matched
      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Only matched rides can receive reached notification"
        });
        return;
      }

      // Check if the driver owns this ride
      if (ride.matchedWith?.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "Only the assigned driver can send reached notification"
        });
        return;
      }

      // Notify the commuter that driver has reached
      io.to(ride.socketId).emit("driver:reached", {
        success: true,
        rideId: ride.id
      });

      logger.info(
        `Driver reached notification sent to commuter for ride: ${rideId}`
      );
    } catch (error) {
      logger.error(`Error in driver:reached: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to send driver reached notification"
      });
    }
  });

  /**
   * Handle ride cancellation
   * Commuter cancels their ride request
   */
  socket.on("ride:cancel", (data) => {
    try {
      logger.info(`Ride cancellation request: ${JSON.stringify(data)}`);

      const { rideId } = data;

      if (!rideId) {
        socket.emit("ride:error", {
          message: "Ride ID is required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if the user owns this ride
      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "You can only cancel your own rides"
        });
        return;
      }

      // Check if ride was already matched with a driver
      const wasMatched = ride.status === "matched" && ride.matchedWith;

      // Cancel the ride
      connectionPoolService.cancelRide(rideId);

      // Notify the commuter
      socket.emit("ride:cancelled", {
        success: true,
        rideId
      });

      // If ride was matched, notify the specific driver
      if (wasMatched) {
        logger.info(
          `Notifying driver ${ride.matchedWith.socketId} that matched ride ${rideId} was cancelled`
        );
        io.to(ride.matchedWith.socketId).emit("ride:cancelled:matched", {
          rideId,
          message: "The commuter has cancelled the ride"
        });
      } else {
        // If ride was not matched yet, broadcast to all drivers
        io.to("drivers").emit("ride:cancelled", {
          rideId
        });
      }

      logger.info(
        `Ride cancelled: ${rideId} (was matched: ${wasMatched})`
      );
    } catch (error) {
      logger.error(`Error in ride:cancel: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to cancel ride"
      });
    }
  });

  /**
   * Handle ride completion
   * Driver marks the ride as completed
   * Calculates fare and prompts commuter for payment
   */
  socket.on("ride:complete", async (data) => {
    try {
      logger.info(`Ride completion request: ${JSON.stringify(data)}`);

      const { rideId, distanceKm } = data;

      if (!rideId) {
        socket.emit("ride:error", {
          message: "Ride ID is required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if the ride is matched
      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Only matched rides can be completed"
        });
        return;
      }

      // Check if the driver owns this ride
      if (ride.matchedWith?.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "Only the assigned driver can complete this ride"
        });
        return;
      }

      // Calculate fare based on distance
      // Fare rate: PKR 18 per kilometer
      const FARE_RATE_PER_KM = 18;
      const calculatedDistance = distanceKm || 0;
      const fare = Math.round(calculatedDistance * FARE_RATE_PER_KM);

      logger.info(
        `💰 Calculated fare: ${calculatedDistance} km × ${FARE_RATE_PER_KM} = PKR ${fare}`
      );

      // Complete the ride
      const completedRide = connectionPoolService.completeRide(rideId);

      if (!completedRide) {
        socket.emit("ride:error", {
          message: "Failed to complete ride"
        });
        return;
      }

      // Fetch driver payment account details from database
      let driverPaymentDetails = {
        easyPaisa: { accountTitle: "", accountNumber: "" },
        jazzCash: { accountTitle: "", accountNumber: "" }
      };

      try {
        logger.info(`🔍 Attempting to find driver with ID: ${ride.matchedWith.driverId}`);
        logger.info(`🔍 Driver socket ID: ${ride.matchedWith.socketId}`);
        logger.info(`🔍 Driver name from ride: ${ride.matchedWith.driverName}`);

        // Get driver info from connection pool first
        const connectionUser = connectionPoolService.getUser(ride.matchedWith.socketId);
        logger.info(`🔍 Driver from connection pool: ${JSON.stringify(connectionUser)}`);

        // Try to find driver by ObjectId first
        let driver = null;
        try {
          // Check if the ID looks like a valid ObjectId (24 hex characters)
          if (/^[0-9a-fA-F]{24}$/.test(ride.matchedWith.driverId)) {
            logger.info(`🔍 Trying ObjectId lookup...`);
            driver = await User.findById(ride.matchedWith.driverId);
          } else {
            logger.info(`🔍 Driver ID "${ride.matchedWith.driverId}" is not a valid ObjectId (UUID format)`);
          }
        } catch (idError) {
          logger.error(`🔍 Error during ObjectId lookup: ${idError.message}`);
        }

        // If not found by ID, try to find by email (stored in matchedWith.driverEmail)
        if (!driver && ride.matchedWith.driverEmail) {
          logger.info(`🔍 Searching driver by email: ${ride.matchedWith.driverEmail}`);
          driver = await User.findOne({ email: ride.matchedWith.driverEmail });
        }

        // If still not found, get the driver from connection pool email
        if (!driver && connectionUser && connectionUser.userEmail) {
          logger.info(`🔍 Searching driver by connection pool email: ${connectionUser.userEmail}`);
          driver = await User.findOne({ email: connectionUser.userEmail });
        }

        // Debug: List all drivers in database to verify
        if (!driver) {
          const allDrivers = await User.find({ role: 'driver' }).select('email name role').limit(5);
          logger.info(`🔍 DATABASE CHECK: Found ${allDrivers.length} drivers in database:`);
          allDrivers.forEach(d => {
            logger.info(`   - ${d.name} (${d.email}) - Role: ${d.role}`);
          });
        }

        logger.info(`🔍 Driver found in DB: ${driver ? driver.name : 'null'}`);
        if (driver) {
          logger.info(`💳 Driver email: ${driver.email}`);
          logger.info(`💳 Driver role: ${driver.role}`);
          logger.info(`💳 Driver _id: ${driver._id}`);
          logger.info(`💳 Driver payment accounts: ${JSON.stringify(driver.paymentAccounts)}`);
        }

        if (driver) {
          if (driver.paymentAccounts) {
            driverPaymentDetails = {
              easyPaisa: driver.paymentAccounts.easyPaisa || {
                accountTitle: "",
                accountNumber: ""
              },
              jazzCash: driver.paymentAccounts.jazzCash || {
                accountTitle: "",
                accountNumber: ""
              }
            };
            logger.info(
              `✅ Fetched payment details for driver: ${driver.name}`
            );
          } else {
            logger.warn(`⚠️ Driver ${driver.name} has no paymentAccounts field`);
          }
        } else {
          logger.warn(`⚠️ Driver not found with ID: ${ride.matchedWith.driverId}`);
        }
      } catch (error) {
        logger.error(
          `⚠️ Failed to fetch driver payment details: ${error.message}`
        );
      }

      // Add fare information to the ride data
      const rideWithFare = {
        ...completedRide.toJSON(),
        fare: {
          distanceKm: calculatedDistance,
          ratePerKm: FARE_RATE_PER_KM,
          totalAmount: fare
        }
      };

      // Notify the driver
      socket.emit("ride:completed", {
        success: true,
        ride: rideWithFare,
        fare: {
          distanceKm: calculatedDistance,
          ratePerKm: FARE_RATE_PER_KM,
          totalAmount: fare
        }
      });

      // Notify the commuter with payment prompt including driver payment details
      logger.info(`📤 Sending payment request with driver details: ${JSON.stringify(driverPaymentDetails)}`);

      io.to(completedRide.socketId).emit("ride:payment:request", {
        success: true,
        ride: rideWithFare,
        fare: {
          distanceKm: calculatedDistance,
          ratePerKm: FARE_RATE_PER_KM,
          totalAmount: fare
        },
        driverPaymentDetails,
        message: `Your ride is complete. Total fare: PKR ${fare}`
      });

      logger.info(`Ride completed successfully: ${rideId}`);
      logger.info(
        `💳 Payment request sent to commuter: PKR ${fare} (${calculatedDistance} km @ PKR ${FARE_RATE_PER_KM}/km)`
      );
    } catch (error) {
      logger.error(`Error in ride:complete: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to complete ride"
      });
    }
  });

  /**
   * Handle SOS alert
   * Commuter triggers emergency SOS
   */
  socket.on("ride:sos", async (data) => {
    try {
      logger.warn(`🚨 SOS ALERT REQUEST: ${JSON.stringify(data)}`);

      const { rideId, location, message } = data;

      if (!rideId) {
        socket.emit("ride:error", {
          message: "Ride ID is required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if the user owns this ride (commuter)
      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "You can only trigger SOS for your own rides"
        });
        return;
      }

      // Trigger SOS
      const sosData = {
        triggeredBy: ride.userId,
        location: location || null,
        message: message || "Emergency SOS triggered"
      };

      const updatedRide = connectionPoolService.triggerSOS(rideId, sosData);

      if (!updatedRide) {
        socket.emit("ride:error", {
          message: "Failed to trigger SOS"
        });
        return;
      }

      // Notify the commuter
      socket.emit("ride:sos:triggered", {
        success: true,
        ride: updatedRide.toJSON(),
        sosAlert: updatedRide.sosAlert
      });

      // Notify the driver if ride is matched
      if (updatedRide.matchedWith) {
        io.to(updatedRide.matchedWith.socketId).emit("ride:sos:alert", {
          ride: updatedRide.toJSON(),
          sosAlert: updatedRide.sosAlert
        });
      }

      // Send email to trusted contacts
      try {
        logger.warn(
          `[SOS EMAIL] Attempting to find user in database with ID: ${ride.userId}`
        );

        // Find the user in the database to get their trusted contacts
        const user = await User.findOne({ _id: ride.userId }).select(
          "name email trustedContacts"
        );

        logger.warn(
          `[SOS EMAIL] Database query completed. User found: ${!!user}`
        );

        if (!user) {
          logger.error(
            ` [SOS EMAIL] User not found in database with ID: ${ride.userId}`
          );
        } else {
          logger.warn(
            `👤 [SOS EMAIL] User found - Name: ${user.name}, Email: ${user.email}`
          );
          logger.warn(
            `📋 [SOS EMAIL] Trusted contacts count: ${user.trustedContacts?.length || 0}`
          );
          logger.warn(
            `📋 [SOS EMAIL] Trusted contacts: ${JSON.stringify(user.trustedContacts, null, 2)}`
          );
        }

        if (user && user.trustedContacts && user.trustedContacts.length > 0) {
          logger.warn(
            `📧 [SOS EMAIL] Starting to send SOS emails to ${user.trustedContacts.length} trusted contact(s)`
          );

          // Prepare email data
          const sosEmailData = {
            commuterName: user.name || ride.userName,
            commuterEmail: user.email,
            driverName: updatedRide.matchedWith?.driverName || null,
            pickupLocation: updatedRide.source.address,
            dropoffLocation: updatedRide.destination.address,
            triggeredAt: updatedRide.sosAlert.triggeredAt,
            sosMessage: updatedRide.sosAlert.message
          };

          logger.warn(
            `📦 [SOS EMAIL] Email data prepared: ${JSON.stringify(sosEmailData, null, 2)}`
          );

          // Send email to each trusted contact
          const emailPromises = user.trustedContacts.map(
            async (contact, index) => {
              try {
                logger.warn(
                  `📨 [SOS EMAIL] Sending email ${index + 1}/${user.trustedContacts.length} to ${contact.name} (${contact.email})`
                );

                await emailService.sendSOSAlert(contact.email, sosEmailData);

                logger.warn(
                  `[SOS EMAIL] Successfully sent email to ${contact.name} (${contact.email})`
                );
              } catch (emailError) {
                logger.error(
                  ` [SOS EMAIL] Failed to send email to ${contact.email}`
                );
                logger.error(` [SOS EMAIL] Error: ${emailError.message}`);
                logger.error(` [SOS EMAIL] Stack: ${emailError.stack}`);
              }
            }
          );

          // Wait for all emails to be sent (don't block the response)
          logger.warn(
            `⏳ [SOS EMAIL] Waiting for all ${emailPromises.length} emails to complete...`
          );

          Promise.all(emailPromises)
            .then(() => {
              logger.warn(`[SOS EMAIL] All SOS emails processed successfully!`);
            })
            .catch((err) => {
              logger.error(` [SOS EMAIL] Error in Promise.all: ${err.message}`);
              logger.error(` [SOS EMAIL] Stack: ${err.stack}`);
            });
        } else {
          logger.warn(
            `[SOS EMAIL] User ${ride.userId} has no trusted contacts configured`
          );
        }
      } catch (dbError) {
        logger.error(` [SOS EMAIL] Database error while fetching user`);
        logger.error(` [SOS EMAIL] Error message: ${dbError.message}`);
        logger.error(` [SOS EMAIL] Error stack: ${dbError.stack}`);
      }

      logger.warn(
        `🚨 SOS TRIGGERED for ride ${rideId} by user ${ride.userName}`
      );
    } catch (error) {
      logger.error(`Error in ride:sos: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to trigger SOS"
      });
    }
  });

  /**
   * Handle chat messages
   * Send chat messages between driver and commuter
   */
  socket.on("chat:message", (data) => {
    try {
      logger.info(`Chat message received: ${JSON.stringify(data)}`);

      const { rideId, message, senderId, senderName } = data;

      if (!rideId || !message) {
        socket.emit("ride:error", {
          message: "Ride ID and message are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if ride is matched
      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Chat is only available for matched rides"
        });
        return;
      }

      // Determine recipient socket ID
      let recipientSocketId;
      if (socket.id === ride.socketId) {
        // Sender is commuter, send to driver
        recipientSocketId = ride.matchedWith?.socketId;
      } else if (socket.id === ride.matchedWith?.socketId) {
        // Sender is driver, send to commuter
        recipientSocketId = ride.socketId;
      } else {
        socket.emit("ride:error", {
          message: "You are not part of this ride"
        });
        return;
      }

      // Send message to recipient
      if (recipientSocketId) {
        io.to(recipientSocketId).emit("chat:message", {
          rideId,
          message,
          senderId,
          senderName,
          timestamp: new Date().toISOString()
        });

        logger.info(
          `Chat message sent from ${socket.id} to ${recipientSocketId} for ride ${rideId}`
        );
      }
    } catch (error) {
      logger.error(`Error in chat:message: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to send chat message"
      });
    }
  });

  /**
   * Handle voice chat messages
   * Send voice messages between driver and commuter
   */
  socket.on("chat:voice", (data) => {
    try {
      logger.info(`Voice message received for ride: ${data.rideId}`);

      const { rideId, audioData, duration, senderId, senderName } = data;

      if (!rideId || !audioData) {
        socket.emit("ride:error", {
          message: "Ride ID and audio data are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if ride is matched
      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Chat is only available for matched rides"
        });
        return;
      }

      // Determine recipient socket ID
      let recipientSocketId;
      if (socket.id === ride.socketId) {
        // Sender is commuter, send to driver
        recipientSocketId = ride.matchedWith?.socketId;
      } else if (socket.id === ride.matchedWith?.socketId) {
        // Sender is driver, send to commuter
        recipientSocketId = ride.socketId;
      } else {
        socket.emit("ride:error", {
          message: "You are not part of this ride"
        });
        return;
      }

      // Send voice message to recipient
      if (recipientSocketId) {
        io.to(recipientSocketId).emit("chat:voice", {
          rideId,
          audioData,
          duration,
          senderId,
          senderName,
          timestamp: new Date().toISOString()
        });

        logger.info(
          `Voice message sent from ${socket.id} to ${recipientSocketId} for ride ${rideId}`
        );
      }
    } catch (error) {
      logger.error(`Error in chat:voice: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to send voice message"
      });
    }
  });

  /**
   * Handle connection pool stats request
   */
  socket.on("pool:stats", () => {
    try {
      const stats = connectionPoolService.getStats();
      socket.emit("pool:stats", stats);
      logger.info(`Pool stats sent to ${socket.id}`);
    } catch (error) {
      logger.error(`Error in pool:stats: ${error.message}`);
    }
  });

  /**
   * Handle disconnection
   */
  socket.on("disconnect", () => {
    logger.info(`Client disconnecting: ${socket.id}`);

    // Remove user and their rides from pool
    const removedUser = connectionPoolService.getUser(socket.id);
    connectionPoolService.removeUser(socket.id);

    // If a commuter disconnects, update all drivers with the current pending rides
    if (removedUser && removedUser.userType === "commuter") {
      const pendingRides = connectionPoolService.getPendingRides();
      io.to("drivers").emit("ride:list:updated", {
        rides: pendingRides.map((ride) => ride.toJSON()),
        count: pendingRides.length
      });
    }
  });
};
