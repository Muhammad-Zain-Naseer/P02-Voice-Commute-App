// import express from "express";
// import { createServer } from "http";
// import { Server } from "socket.io";
// import cors from "cors";
// import config from "../config/env.config.js";
// import socketConfig from "../config/socket.config.js";
// import logger from "../utils/logger.js";
// import audioRoutes from "../routes/audio.routes.js";
// import rideRoutes from "../routes/ride.routes.js";
// import authRoutes from "../routes/authRoutes.js";
// import paymentRoutes from "../routes/payment.routes.js";
// import mapsRoutes from "../routes/maps.routes.js";
// import commuterRoutes from "../routes/commuter.routes.js";
// import connectDB from "../config/db.js";
// import dotenv from "dotenv";
// import mongoose from "mongoose";
// import emailService from "../services/emailService.js";
// import {
//   errorHandler,
//   notFoundHandler
// } from "../middleware/errorHandler.middleware.js";
// import { handleRideEvents } from "../sockets/ride.socket.js";

// dotenv.config();
// connectDB();

// const app = express();

// // Create HTTP server
// const httpServer = createServer(app);

// // Initialize Socket.IO with configuration
// const io = new Server(httpServer, socketConfig);

// // Enable CORS for all origins (for development)
// app.use(cors());

// // Increase payload limit for payment screenshots (base64 images can be large)
// app.use(express.json({ limit: '10mb' }));
// app.use(express.urlencoded({ limit: '10mb', extended: true }));

// // Health check endpoint
// app.get("/", (req, res) => {
//   logger.info("Health check endpoint accessed");
//   res.json({
//     message: "Server is running!",
//     features: ["Audio Processing", "Real-time Ride Matching"],
//     socketEnabled: true
//   });
// });

// // API Routes
// app.use("/api/auth", authRoutes);
// app.use("/api/audio", audioRoutes);
// app.use("/api/rides", rideRoutes);
// app.use("/api/payments", paymentRoutes);
// app.use("/api/maps", mapsRoutes);
// app.use("/api/commuter", commuterRoutes);

// // Socket.IO connection handling
// io.on("connection", (socket) => {
//   logger.info(`Socket connected: ${socket.id}`);

//   // Setup ride event handlers
//   handleRideEvents(io, socket);

//   socket.on("disconnect", (reason) => {
//     logger.info(`Socket disconnected: ${socket.id} | Reason: ${reason}`);
//   });
// });

// // 404 handler - must be after all routes
// app.use(notFoundHandler);

// // Error handler - must be last
// app.use(errorHandler);

// // Start server with Socket.IO support
// httpServer.listen(config.port, () => {
//   logger.info(
//     `Server running on port ${config.port} in ${config.nodeEnv} mode`
//   );
//   logger.info(`Socket.IO enabled and ready for connections`);
//   logger.info(`WebSocket URL: ws://localhost:${config.port}`);

//   //  DATABASE CONNECTION
//   const connectDB = async () => {
//     try {
//       await mongoose.connect(config.mongoUri);
//       logger.info("MongoDB connected successfully");
//     } catch (error) {
//       logger.error("MongoDB connection error:", error);
//       process.exit(1);
//     }
//   };

//   //TART SERVER WITH DB
//   connectDB().then(async () => {
//     app.listen(config.port, () => {
//       logger.info(
//         `Server running on port ${config.port} in ${config.nodeEnv} mode`
//       );
//     });

//     await emailService.verifyConnection();
//   });
// });

import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import config from "../config/env.config.js";
import socketConfig from "../config/socket.config.js";
import logger from "../utils/logger.js";
import audioRoutes from "../routes/audio.routes.js";
import rideRoutes from "../routes/ride.routes.js";
import authRoutes from "../routes/authRoutes.js";
import driverAuthRoutes from "../routes/driverAuth.routes.js"; // NEW
import paymentRoutes from "../routes/payment.routes.js";
import mapsRoutes from "../routes/maps.routes.js";
import commuterRoutes from "../routes/commuter.routes.js";
import connectDB from "../config/db.js";
import dotenv from "dotenv";
import mongoose from "mongoose";
import emailService from "../services/emailService.js";
import {
  errorHandler,
  notFoundHandler
} from "../middleware/errorHandler.middleware.js";
import { handleRideEvents } from "../sockets/ride.socket.js";

dotenv.config();
connectDB();

const app = express();

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, "..", "uploads", "vehicle-registrations");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  logger.info("Created uploads directory for vehicle registrations");
}

// Create HTTP server
const httpServer = createServer(app);

// Initialize Socket.IO with configuration
const io = new Server(httpServer, socketConfig);

// Enable CORS for all origins (for development)
app.use(cors());

// Increase payload limit for payment screenshots (base64 images can be large)
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// Serve static files for uploaded vehicle registration images
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

// Health check endpoint
app.get("/", (req, res) => {
  logger.info("Health check endpoint accessed");
  res.json({
    message: "Server is running!",
    features: [
      "Audio Processing",
      "Real-time Ride Matching",
      "Driver Registration"
    ],
    socketEnabled: true
  });
});

// API Routes
app.use("/api/auth", authRoutes); // Commuter auth
app.use("/api/driver/auth", driverAuthRoutes); // NEW - Driver auth
app.use("/api/audio", audioRoutes);
app.use("/api/rides", rideRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/maps", mapsRoutes);
app.use("/api/commuter", commuterRoutes);

// Socket.IO connection handling
io.on("connection", (socket) => {
  logger.info(`Socket connected: ${socket.id}`);

  // Setup ride event handlers
  handleRideEvents(io, socket);

  socket.on("disconnect", (reason) => {
    logger.info(`Socket disconnected: ${socket.id} | Reason: ${reason}`);
  });
});

// 404 handler - must be after all routes
app.use(notFoundHandler);

// Error handler - must be last
app.use(errorHandler);

// DATABASE CONNECTION
const connectDatabase = async () => {
  try {
    await mongoose.connect(config.mongoUri);
    logger.info("MongoDB connected successfully");
  } catch (error) {
    logger.error("MongoDB connection error:", error);
    process.exit(1);
  }
};

// START SERVER WITH DB
connectDatabase().then(async () => {
  httpServer.listen(config.port, () => {
    logger.info(
      `Server running on port ${config.port} in ${config.nodeEnv} mode`
    );
    logger.info(`Socket.IO enabled and ready for connections`);
    logger.info(`WebSocket URL: ws://localhost:${config.port}`);
    logger.info(`Vehicle uploads directory: ${uploadsDir}`);
  });

  await emailService.verifyConnection();
});
