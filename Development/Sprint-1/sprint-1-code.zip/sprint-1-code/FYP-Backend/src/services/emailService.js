import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: config.emailHost,
      port: config.emailPort,
      secure: config.emailPort === 465, // true for 465, false for other ports
      auth: {
        user: config.emailUser,
        pass: config.emailPassword
      }
    });
  }

  // Send verification email
  async sendVerificationEmail(email, verificationUrl) {
    try {
      const mailOptions = {
        from: `"${config.appName}" <${config.emailFrom}>`,
        to: email,
        subject: "Verify Your Email Address",
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
              }
              .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
              }
              .header {
                background-color: #4CAF50;
                color: white;
                padding: 20px;
                text-align: center;
                border-radius: 5px 5px 0 0;
              }
              .content {
                background-color: #f9f9f9;
                padding: 30px;
                border-radius: 0 0 5px 5px;
              }
              .button {
                display: inline-block;
                padding: 12px 30px;
                margin: 20px 0;
                background-color: #4CAF50;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
              }
              .footer {
                margin-top: 20px;
                padding-top: 20px;
                border-top: 1px solid #ddd;
                font-size: 12px;
                color: #666;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>Email Verification</h1>
              </div>
              <div class="content">
                <h2>Welcome to ${config.appName}!</h2>
                <p>Thank you for signing up. Please verify your email address to complete your registration.</p>
                <p>Click the button below to verify your email:</p>
                <center>
                  <a href="${verificationUrl}" class="button">Verify Email</a>
                </center>
                <p>Or copy and paste this link into your browser:</p>
                <p style="word-break: break-all; color: #4CAF50;">${verificationUrl}</p>
                <div class="footer">
                  <p>This link will expire in 24 hours.</p>
                  <p>If you didn't create an account with ${config.appName}, please ignore this email.</p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
        text: `
          Welcome to ${config.appName}!
          
          Thank you for signing up. Please verify your email address to complete your registration.
          
          Click the link below to verify your email:
          ${verificationUrl}
          
          This link will expire in 24 hours.
          
          If you didn't create an account with ${config.appName}, please ignore this email.
        `
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info(`Verification email sent to ${email}: ${info.messageId}`);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      logger.error("Error sending verification email:", error);
      throw new Error("Failed to send verification email");
    }
  }

  // Send password reset email (for future use)
  async sendPasswordResetEmail(email, resetUrl) {
    try {
      const mailOptions = {
        from: `"${config.appName}" <${config.emailFrom}>`,
        to: email,
        subject: "Reset Your PIN",
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
              }
              .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
              }
              .header {
                background-color: #f44336;
                color: white;
                padding: 20px;
                text-align: center;
                border-radius: 5px 5px 0 0;
              }
              .content {
                background-color: #f9f9f9;
                padding: 30px;
                border-radius: 0 0 5px 5px;
              }
              .button {
                display: inline-block;
                padding: 12px 30px;
                margin: 20px 0;
                background-color: #f44336;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
              }
              .footer {
                margin-top: 20px;
                padding-top: 20px;
                border-top: 1px solid #ddd;
                font-size: 12px;
                color: #666;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>PIN Reset Request</h1>
              </div>
              <div class="content">
                <h2>Reset Your PIN</h2>
                <p>You requested to reset your PIN. Click the button below to proceed:</p>
                <center>
                  <a href="${resetUrl}" class="button">Reset PIN</a>
                </center>
                <p>Or copy and paste this link into your browser:</p>
                <p style="word-break: break-all; color: #f44336;">${resetUrl}</p>
                <div class="footer">
                  <p>This link will expire in 1 hour.</p>
                  <p>If you didn't request a PIN reset, please ignore this email.</p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
        text: `
          PIN Reset Request
          
          You requested to reset your PIN. Click the link below to proceed:
          ${resetUrl}
          
          This link will expire in 1 hour.
          
          If you didn't request a PIN reset, please ignore this email.
        `
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info(`Password reset email sent to ${email}: ${info.messageId}`);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      logger.error("Error sending password reset email:", error);
      throw new Error("Failed to send password reset email");
    }
  }

  // Add this method inside your EmailService class

  async sendRideDetailsEmail(
    recipientEmail,
    userName,
    rideDetails,
    recipientName
  ) {
    const subject = `${userName} shared their ride details with you - HerSafar`;

    const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; background-color: #FDEAF0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; }
        h2 { color: #CF4374; }
        .details { background-color: #FAECF1; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .detail-row { margin: 10px 0; }
        .label { font-weight: bold; color: #CF4374; }
        .button { background-color: #CF4374; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px; }
        .footer { color: #666; font-size: 12px; margin-top: 30px; text-align: center; }
      </style>
    </head>
    <body>
      <div class="container">
        <h2>🚗 Ride Details from ${userName}</h2>
        
        <p>Hi ${recipientName || "there"},</p>
        
        <p>${userName} has shared their ride details with you for safety:</p>
        
        <div class="details">
          <div class="detail-row">
            <span class="label">Pickup Location:</span> ${rideDetails.pickup || "N/A"}
          </div>
          <div class="detail-row">
            <span class="label">Drop-off Location:</span> ${rideDetails.dropoff || "N/A"}
          </div>
          <div class="detail-row">
            <span class="label">Driver Name:</span> ${rideDetails.driverName || "N/A"}
          </div>
          <div class="detail-row">
            <span class="label">Status:</span> ${rideDetails.estimatedArrival || "In Progress"}
          </div>
        </div>
        
        ${
          rideDetails.trackingLink
            ? `
          <div style="text-align: center;">
            <a href="${rideDetails.trackingLink}" class="button">
              Track Live Location
            </a>
          </div>
        `
            : ""
        }
        
        <p class="footer">
          This is an automated message from HerSafar for safety purposes.
        </p>
      </div>
    </body>
    </html>
  `;

    await this.transporter.sendMail({
      from: this.from,
      to: recipientEmail,
      subject: subject,
      html: html
    });
  }

  // Send SOS alert email to trusted contacts
  async sendSOSAlert(trustedContactEmail, sosData) {
    try {
      logger.warn(
        `📧 [EMAIL SERVICE] Starting to send SOS email to: ${trustedContactEmail}`
      );
      logger.warn(
        `📧 [EMAIL SERVICE] SOS Data received: ${JSON.stringify(sosData, null, 2)}`
      );

      const {
        commuterName,
        commuterEmail,
        driverName,
        pickupLocation,
        dropoffLocation,
        triggeredAt,
        sosMessage
      } = sosData;

      logger.warn(
        `📧 [EMAIL SERVICE] Extracted data - Commuter: ${commuterName}, Email: ${commuterEmail}`
      );

      const mailOptions = {
        from: `"${config.appName} - Emergency Alert" <${config.emailFrom}>`,
        to: trustedContactEmail,
        subject: `🚨 EMERGENCY SOS ALERT - ${commuterName}`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
              }
              .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
              }
              .header {
                background-color: #d32f2f;
                color: white;
                padding: 30px 20px;
                text-align: center;
                border-radius: 5px 5px 0 0;
              }
              .alert-icon {
                font-size: 48px;
                margin-bottom: 10px;
              }
              .content {
                background-color: #fff3e0;
                padding: 30px;
                border: 3px solid #d32f2f;
                border-radius: 0 0 5px 5px;
              }
              .info-box {
                background-color: white;
                padding: 15px;
                margin: 15px 0;
                border-left: 4px solid #d32f2f;
                border-radius: 3px;
              }
              .label {
                font-weight: bold;
                color: #d32f2f;
                margin-bottom: 5px;
              }
              .value {
                color: #333;
                margin-bottom: 10px;
              }
              .emergency-note {
                background-color: #ffebee;
                padding: 20px;
                margin: 20px 0;
                border-radius: 5px;
                border: 2px solid #d32f2f;
              }
              .footer {
                margin-top: 20px;
                padding-top: 20px;
                border-top: 2px solid #d32f2f;
                font-size: 12px;
                color: #666;
                text-align: center;
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="alert-icon">🚨</div>
                <h1 style="margin: 0;">EMERGENCY SOS ALERT</h1>
                <p style="margin: 10px 0 0 0; font-size: 16px;">Immediate Attention Required</p>
              </div>
              <div class="content">
                <div class="emergency-note">
                  <h2 style="color: #d32f2f; margin-top: 0;">Your Trusted Contact Has Triggered an SOS Alert</h2>
                  <p><strong>${commuterName}</strong> has activated an emergency SOS alert during their ride. Please take immediate action.</p>
                </div>

                <div class="info-box">
                  <div class="label">📅 Alert Triggered At:</div>
                  <div class="value">${new Date(triggeredAt).toLocaleString()}</div>
                </div>

                <div class="info-box">
                  <div class="label">👤 Commuter Details:</div>
                  <div class="value">
                    <strong>Name:</strong> ${commuterName}<br>
                    <strong>Email:</strong> ${commuterEmail}
                  </div>
                </div>

                ${
                  driverName
                    ? `
                <div class="info-box">
                  <div class="label">🚗 Driver Information:</div>
                  <div class="value"><strong>${driverName}</strong></div>
                </div>
                `
                    : ""
                }

                <div class="info-box">
                  <div class="label">📍 Ride Details:</div>
                  <div class="value">
                    <strong>Pickup:</strong> ${pickupLocation}<br>
                    <strong>Drop-off:</strong> ${dropoffLocation}
                  </div>
                </div>

                ${
                  sosMessage
                    ? `
                <div class="info-box">
                  <div class="label">💬 SOS Message:</div>
                  <div class="value">${sosMessage}</div>
                </div>
                `
                    : ""
                }

                <div class="emergency-note">
                  <h3 style="color: #d32f2f; margin-top: 0;">🆘 Recommended Actions:</h3>
                  <ol style="margin: 10px 0; padding-left: 20px;">
                    <li>Try to contact ${commuterName} immediately</li>
                    <li>If unable to reach them, consider contacting local authorities</li>
                    <li>Keep this information ready when contacting emergency services</li>
                    <li>Monitor the situation and follow up</li>
                  </ol>
                </div>

                <div class="footer">
                  <p><strong>This is an automated emergency alert from ${config.appName}</strong></p>
                  <p>You received this because you are listed as a trusted contact for ${commuterName}</p>
                  <p style="color: #d32f2f; font-weight: bold;">DO NOT IGNORE THIS MESSAGE</p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
        text: `
          🚨 EMERGENCY SOS ALERT 🚨

          Your trusted contact ${commuterName} has triggered an SOS alert during their ride.

          ALERT DETAILS:
          ===============

          Triggered At: ${new Date(triggeredAt).toLocaleString()}

          Commuter: ${commuterName}
          Email: ${commuterEmail}

          ${driverName ? `Driver: ${driverName}\n` : ""}

          Ride Details:
          Pickup: ${pickupLocation}
          Drop-off: ${dropoffLocation}

          ${sosMessage ? `SOS Message: ${sosMessage}\n` : ""}

          RECOMMENDED ACTIONS:
          ====================
          1. Try to contact ${commuterName} immediately
          2. If unable to reach them, consider contacting local authorities
          3. Keep this information ready when contacting emergency services
          4. Monitor the situation and follow up

          DO NOT IGNORE THIS MESSAGE

          This is an automated emergency alert from ${config.appName}.
          You received this because you are listed as a trusted contact.
        `,
        priority: "high"
      };

      logger.warn(
        `📧 [EMAIL SERVICE] Mail options prepared. From: ${mailOptions.from}, To: ${mailOptions.to}`
      );
      logger.warn(`📧 [EMAIL SERVICE] Sending email via transporter...`);

      const info = await this.transporter.sendMail(mailOptions);

      logger.warn(`[EMAIL SERVICE] SOS email successfully sent!`);
      logger.warn(`[EMAIL SERVICE] Message ID: ${info.messageId}`);
      logger.warn(`[EMAIL SERVICE] Recipient: ${trustedContactEmail}`);
      logger.warn(`[EMAIL SERVICE] Response: ${JSON.stringify(info.response)}`);

      return { success: true, messageId: info.messageId };
    } catch (error) {
      logger.error(
        ` [EMAIL SERVICE] FAILED to send SOS email to ${trustedContactEmail}`
      );
      logger.error(` [EMAIL SERVICE] Error name: ${error.name}`);
      logger.error(` [EMAIL SERVICE] Error message: ${error.message}`);
      logger.error(` [EMAIL SERVICE] Error stack: ${error.stack}`);
      logger.error(
        ` [EMAIL SERVICE] Full error object: ${JSON.stringify(error, null, 2)}`
      );

      throw new Error(`Failed to send SOS alert email: ${error.message}`);
    }
  }

  // Verify email configuration
  async verifyConnection() {
    try {
      logger.info("[EMAIL CONFIG] Verifying email configuration...");
      logger.info(`[EMAIL CONFIG] Host: ${config.emailHost}`);
      logger.info(`[EMAIL CONFIG] Port: ${config.emailPort}`);
      logger.info(`[EMAIL CONFIG] User: ${config.emailUser}`);
      logger.info(`[EMAIL CONFIG] From: ${config.emailFrom}`);
      logger.info(`[EMAIL CONFIG] Secure: ${config.emailPort === 465}`);

      await this.transporter.verify();

      logger.info("[EMAIL CONFIG] Email service is ready to send emails!");
      return true;
    } catch (error) {
      logger.error(" [EMAIL CONFIG] Email service connection FAILED!");
      logger.error(` [EMAIL CONFIG] Error: ${error.message}`);
      logger.error(` [EMAIL CONFIG] Stack: ${error.stack}`);
      return false;
    }
  }

  async sendOTP(email, otp) {
    const mailOptions = {
      from: config.emailFrom,
      to: email,
      subject: "Your Driver Registration OTP",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              color: #333;
            }
            .container {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .header {
              background-color: #4CAF50;
              color: white;
              padding: 20px;
              text-align: center;
              border-radius: 5px 5px 0 0;
            }
            .content {
              background-color: #f9f9f9;
              padding: 30px;
              border-radius: 0 0 5px 5px;
            }
            .otp-box {
              background-color: white;
              border: 2px dashed #4CAF50;
              padding: 20px;
              text-align: center;
              font-size: 32px;
              font-weight: bold;
              letter-spacing: 5px;
              color: #4CAF50;
              margin: 20px 0;
              border-radius: 5px;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              font-size: 12px;
              color: #666;
            }
            .warning {
              background-color: #fff3cd;
              border-left: 4px solid #ffc107;
              padding: 10px;
              margin: 15px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Driver Registration</h1>
            </div>
            <div class="content">
              <h2>Welcome to Our Platform!</h2>
              <p>You're one step closer to becoming a driver. Use the OTP below to verify your email address:</p>
              
              <div class="otp-box">
                ${otp}
              </div>
              
              <div class="warning">
                <strong>⚠️ Important:</strong> This OTP is valid for 10 minutes only.
              </div>
              
              <p>If you didn't request this OTP, please ignore this email.</p>
              
              <p>Thank you for joining us!</p>
            </div>
            <div class="footer">
              <p>This is an automated email. Please do not reply.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `Your OTP for driver registration is: ${otp}. This OTP is valid for 10 minutes.`
    };

    try {
      await this.transporter.sendMail(mailOptions);
      logger.info(`OTP email sent successfully to ${email}`);
      return true;
    } catch (error) {
      logger.error("Error sending OTP email:", error);
      throw error;
    }
  }
}

export default new EmailService();
