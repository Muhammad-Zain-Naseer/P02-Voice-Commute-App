import express from "express";
import rideController from "../controllers/ride.controller.js";
import shareRideDetailsController from "../controllers/shareRideDetailscontroller.js";

const router = express.Router();

router.get("/stats", rideController.getStats);

router.get("/history", rideController.getRideHistory);

router.get("/pending", rideController.getPendingRides);

router.post("/", rideController.createRide);

router.get("/", rideController.getRides);

router.get("/:id", rideController.getRide);

router.post("/:id/match", rideController.matchRide);

router.delete("/:id", rideController.cancelRide);

router.post("/:id/rate", rideController.rateRide);

router.post("/:id/sos", rideController.triggerSOS);

router.post(
  "/share-ride-details-selected",
  shareRideDetailsController.shareRideDetailsWithSelectedContacts
);

router.get(
  "/driver/:driverId/earnings",
  rideController.getEarningsHistory
);

export default router;
