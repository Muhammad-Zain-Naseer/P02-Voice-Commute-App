import Driver from "../models/Driver.js";
import User from "../models/User.js";
import emailService from "../services/emailService.js";
import jwt from "jsonwebtoken";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";
import { v4 as uuidv4 } from "uuid";

class DriverAuthController {
  generateToken(driverId) {
    return jwt.sign({ driverId, role: "driver" }, config.jwtSecret, {
      expiresIn: config.jwtExpire
    });
  }

  // 6-digit OTP
  generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  // Step 1: Request OTP (Email)
  async requestOTP(req, res) {
    try {
      let { email } = req.body;

      if (!email) return res.status(400).json({ success: false, message: "Email is required" });

      email = email.toLowerCase().trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) return res.status(400).json({ success: false, message: "Invalid email format" });

      const existingDriver = await Driver.findOne({ email });
      if (existingDriver && existingDriver.isVerified) {
        return res.status(400).json({ success: false, message: "Driver account already exists. Please login." });
      }

      const otp = this.generateOTP();
      const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

      if (existingDriver) {
        existingDriver.verificationOTP = otp;
        existingDriver.verificationOTPExpiry = otpExpiry;
        await existingDriver.save();
      } else {
        const newDriver = new Driver({
          email,
          verificationOTP: otp,
          verificationOTPExpiry: otpExpiry,
          name: "Pending",
          cnic: `TEMP_${Date.now()}`,
          vehicle: {
            registrationNumber: `TEMP_${Date.now()}`,
            color: "Pending",
            model: "Pending"
          }
        });
        await newDriver.save();
      }

      await emailService.sendOTP(email, otp);

      res.status(200).json({ success: true, message: "OTP sent successfully", data: { email } });
    } catch (error) {
      logger.error("Error in requestOTP:", error);
      res.status(500).json({ success: false, message: "Failed to send OTP" });
    }
  }

  // Step 2: Verify OTP
  async verifyOTP(req, res) {
    try {
      let { email, otp } = req.body;
      if (!email || !otp) return res.status(400).json({ success: false, message: "Email and OTP are required" });

      email = email.toLowerCase().trim();

      const driver = await Driver.findOne({
        email,
        verificationOTP: otp,
        verificationOTPExpiry: { $gt: Date.now() }
      });

      if (!driver) return res.status(400).json({ success: false, message: "Invalid or expired OTP" });

      driver.verificationOTP = undefined;
      driver.verificationOTPExpiry = undefined;
      await driver.save();

      const tempToken = this.generateToken(driver._id);

      res.status(200).json({ 
        success: true, 
        message: "OTP verified successfully", 
        data: { 
          driverId: driver._id, 
          email: driver.email, 
          token: tempToken 
        } 
      });
    } catch (error) {
      logger.error("Error in verifyOTP:", error);
      res.status(500).json({ success: false, message: "OTP verification failed" });
    }
  }

  // Step 3: Submit Name
  async submitName(req, res) {
    try {
      const { name } = req.body;
      const driverId = req.driver._id;

      if (!name || name.trim().length < 2) return res.status(400).json({ success: false, message: "Valid name is required" });

      const driver = await Driver.findById(driverId);
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      driver.name = name.trim();
      await driver.save();

      logger.info(`Name submitted for driver: ${driver.email}`);

      res.status(200).json({ 
        success: true, 
        message: "Name saved successfully", 
        data: { 
          driverId: driver._id, 
          name: driver.name 
        } 
      });
    } catch (error) {
      logger.error("Error in submitName:", error);
      res.status(500).json({ success: false, message: "Failed to save name" });
    }
  }

  // Step 4: Submit CNIC
  async submitCNIC(req, res) {
    try {
      const { cnic } = req.body;
      const driverId = req.driver._id;

      if (!cnic) return res.status(400).json({ success: false, message: "CNIC is required" });

      const cleanCNIC = cnic.replace(/[-\s]/g, "");
      if (!/^\d{13}$/.test(cleanCNIC)) return res.status(400).json({ success: false, message: "CNIC must be 13 digits" });

      const existingDriver = await Driver.findOne({ cnic: cleanCNIC, _id: { $ne: driverId } });
      if (existingDriver) return res.status(400).json({ success: false, message: "This CNIC is already registered" });

      const driver = await Driver.findById(driverId);
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      driver.cnic = cleanCNIC;
      await driver.save();

      logger.info(`CNIC submitted for driver: ${driver.email}`);

      res.status(200).json({ 
        success: true, 
        message: "CNIC saved successfully", 
        data: { 
          driverId: driver._id, 
          cnic: driver.cnic 
        } 
      });
    } catch (error) {
      logger.error("Error in submitCNIC:", error);
      res.status(500).json({ success: false, message: "Failed to save CNIC" });
    }
  }

  // Step 5: Submit Driving License
  async submitDrivingLicense(req, res) {
    try {
      const { drivingLicense } = req.body;
      const driverId = req.driver._id;

      if (!drivingLicense) return res.status(400).json({ success: false, message: "Driving license number is required" });

      const cleanLicense = drivingLicense.trim().toUpperCase();
      
      const licensePattern = /^[A-Z]{3}-?\d{7}$/;
      if (!licensePattern.test(cleanLicense.replace(/-/g, ''))) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid license format. Expected format: LHR-1234567" 
        });
      }

      const existingDriver = await Driver.findOne({ drivingLicense: cleanLicense, _id: { $ne: driverId } });
      if (existingDriver) return res.status(400).json({ success: false, message: "This driving license is already registered" });

      const driver = await Driver.findById(driverId);
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      driver.drivingLicense = cleanLicense;
      await driver.save();

      logger.info(`Driving license submitted for driver: ${driver.email}`);

      res.status(200).json({ 
        success: true, 
        message: "Driving license saved successfully", 
        data: { 
          driverId: driver._id, 
          drivingLicense: driver.drivingLicense 
        } 
      });
    } catch (error) {
      logger.error("Error in submitDrivingLicense:", error);
      res.status(500).json({ success: false, message: "Failed to save driving license" });
    }
  }

  // Step 6: Submit Vehicle Registration
  async submitVehicleRegistration(req, res) {
    try {
      const driverId = req.driver._id;
      const { registrationNumber, color, model, year } = req.body;

      if (!req.file) return res.status(400).json({ success: false, message: "Vehicle registration photo is required" });
      if (!registrationNumber) return res.status(400).json({ success: false, message: "Vehicle registration number is required" });
      if (!color) return res.status(400).json({ success: false, message: "Vehicle color is required" });
      if (!model) return res.status(400).json({ success: false, message: "Vehicle model is required" });
      if (!year) return res.status(400).json({ success: false, message: "Vehicle year is required" });

      const driver = await Driver.findById(driverId);
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      if (!driver.name || driver.name === "Pending") return res.status(400).json({ success: false, message: "Please complete the name step first" });
      if (!driver.cnic || driver.cnic.startsWith("TEMP_")) return res.status(400).json({ success: false, message: "Please complete the CNIC step first" });
      if (!driver.drivingLicense) return res.status(400).json({ success: false, message: "Please complete the driving license step first" });

      const cleanRegNumber = registrationNumber.toUpperCase().replace(/[\s-]/g, "");
      const existingVehicle = await Driver.findOne({ "vehicle.registrationNumber": cleanRegNumber, _id: { $ne: driverId } });
      if (existingVehicle) return res.status(400).json({ success: false, message: "This vehicle is already registered" });

      driver.vehicle = {
        registrationNumber: cleanRegNumber,
        color: color.trim(),
        model: model.trim(),
        year: year.trim(),
        registrationPhoto: req.file.path || req.file.filename
      };
      await driver.save();

      logger.info(`Vehicle registration submitted for driver: ${driver.email}`);

      res.status(200).json({
        success: true,
        message: "Vehicle registration saved successfully. Please set up your PIN.",
        data: {
          driverId: driver._id,
          vehicle: driver.vehicle
        }
      });
    } catch (error) {
      logger.error("Error in submitVehicleRegistration:", error);
      res.status(500).json({ success: false, message: "Failed to save vehicle registration" });
    }
  }

  // Step 7: Submit PIN and Complete Registration
  async submitPIN(req, res) {
    try {
      const driverId = req.driver._id;
      const { pin } = req.body;

      if (!pin) return res.status(400).json({ success: false, message: "PIN is required" });
      
      const cleanPin = pin.toString().trim();
      if (!/^\d{4}$/.test(cleanPin)) return res.status(400).json({ success: false, message: "PIN must be exactly 4 digits" });

      const driver = await Driver.findById(driverId);
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      if (!driver.name || driver.name === "Pending") return res.status(400).json({ success: false, message: "Please complete the name step first" });
      if (!driver.cnic || driver.cnic.startsWith("TEMP_")) return res.status(400).json({ success: false, message: "Please complete the CNIC step first" });
      if (!driver.drivingLicense) return res.status(400).json({ success: false, message: "Please complete the driving license step first" });
      if (!driver.vehicle || !driver.vehicle.registrationPhoto) return res.status(400).json({ success: false, message: "Please complete the vehicle registration step first" });

      const userId = uuidv4();

      let user = await User.findOne({ email: driver.email });

      if (!user) {
        user = new User({
          userId,
          name: driver.name,
          email: driver.email,
          pin: cleanPin, 
          role: "driver",
          isVerified: true
        });
        await user.save();
        logger.info(`Created User for driver: ${driver.email}`);
      } else {
        user.name = driver.name;
        user.pin = cleanPin; 
        user.role = "driver";
        user.isVerified = true;
        user.userId = userId;
        await user.save();
        logger.info(`Updated existing User to driver role: ${driver.email}`);
      }

      driver.userId = userId;
      driver.isVerified = true;
      driver.status = "approved";
      await driver.save();

      logger.info(`Driver registration completed: ${driver.email}`);

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Registration completed successfully",
        data: {
          driver: {
            id: driver._id,
            userId: driver.userId,
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle,
            status: driver.status
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in submitPIN:", error);
      res.status(500).json({ success: false, message: "Failed to complete registration" });
    }
  }

  // Login
  async login(req, res) {
    try {
      let { email } = req.body;
      if (!email) return res.status(400).json({ success: false, message: "Email is required" });
      email = email.toLowerCase().trim();

      const driver = await Driver.findOne({ email });
      if (!driver) return res.status(401).json({ success: false, message: "Invalid credentials" });

      if (!driver.isVerified) return res.status(403).json({ success: false, message: "Please complete your registration" });
      if (driver.status === "rejected") return res.status(403).json({ success: false, message: "Your account has been rejected." });
      if (driver.status === "suspended") return res.status(403).json({ success: false, message: "Your account has been suspended." });

      driver.lastLogin = new Date();
      await driver.save();

      const token = this.generateToken(driver._id);

      res.status(200).json({
        success: true,
        message: "Login successful",
        data: {
          driver: {
            id: driver._id,
            userId: driver.userId,
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle,
            status: driver.status,
            averageRating: driver.averageRating
          },
          token
        }
      });
    } catch (error) {
      logger.error("Error in driver login:", error);
      res.status(500).json({ success: false, message: "Login failed" });
    }
  }

  // Registration Status
  async getRegistrationStatus(req, res) {
    try {
      const driverId = req.driver._id;
      const driver = await Driver.findById(driverId).select("-verificationOTP -verificationOTPExpiry");
      if (!driver) return res.status(404).json({ success: false, message: "Driver not found" });

      res.status(200).json({
        success: true,
        data: {
          driver: {
            id: driver._id,
            userId: driver.userId,
            name: driver.name,
            email: driver.email,
            cnic: driver.cnic,
            drivingLicense: driver.drivingLicense,
            vehicle: driver.vehicle,
            status: driver.status,
            isVerified: driver.isVerified
          }
        }
      });
    } catch (error) {
      logger.error("Error in getRegistrationStatus:", error);
      res.status(500).json({ success: false, message: "Failed to get registration status" });
    }
  }
}

export default new DriverAuthController();