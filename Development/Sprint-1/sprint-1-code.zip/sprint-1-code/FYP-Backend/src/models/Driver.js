// // import mongoose from "mongoose";
// // import bcrypt from "bcrypt";

// // const driverSchema = new mongoose.Schema(
// //   {
// //     name: {
// //       type: String,
// //       required: true,
// //       trim: true
// //     },
// //     email: {
// //       type: String,
// //       required: true,
// //       unique: true,
// //       lowercase: true,
// //       trim: true
// //     },
// //     phone: {
// //       type: String,
// //       sparse: true,
// //       trim: true
// //     },
// //     cnic: {
// //       type: String,
// //       required: true,
// //       unique: true,
// //       trim: true
// //     },
// //     drivingLicense: {
// //       type: String,
// //       required: false, // Not required initially, will be added in step 5
// //       unique: true,
// //       sparse: true, // Allows multiple null values
// //       trim: true
// //     },
// //     isVerified: {
// //       type: Boolean,
// //       default: false
// //     },
// //     verificationOTP: String,
// //     verificationOTPExpiry: Date,
    
// //     // Vehicle Information
// //     vehicle: {
// //       registrationNumber: {
// //         type: String,
// //         required: true,
// //         unique: true,
// //         uppercase: true,
// //         trim: true
// //       },
// //       color: {
// //         type: String,
// //         required: true,
// //         trim: true
// //       },
// //       model: {
// //         type: String,
// //         required: true,
// //         trim: true
// //       },
// //       registrationPhoto: {
// //         type: String, // URL or path to stored image
// //         required: true
// //       }
// //     },
    
// //     // Driver Status
// //     status: {
// //       type: String,
// //       enum: ["pending", "approved", "rejected", "suspended"],
// //       default: "pending"
// //     },
    
// //     approvalDate: Date,
// //     rejectionReason: String,
    
// //     // Ratings
// //     averageRating: {
// //       type: Number,
// //       default: 0
// //     },
// //     totalRides: {
// //       type: Number,
// //       default: 0
// //     },
    
// //     // Activity
// //     isAvailable: {
// //       type: Boolean,
// //       default: false
// //     },
// //     lastLogin: Date,
    
// //     // Payment
// //     paymentAccounts: {
// //       type: Map,
// //       of: mongoose.Schema.Types.Mixed,
// //       default: {}
// //     }
// //   },
// //   {
// //     timestamps: true
// //   }
// // );

// // // Index for faster queries
// // driverSchema.index({ email: 1 });
// // driverSchema.index({ cnic: 1 });
// // driverSchema.index({ drivingLicense: 1 });
// // driverSchema.index({ "vehicle.registrationNumber": 1 });
// // driverSchema.index({ status: 1 });

// // // Reference to User model (if driver also needs to be a user)
// // driverSchema.virtual('user', {
// //   ref: 'User',
// //   localField: 'email',
// //   foreignField: 'email',
// //   justOne: true
// // });

// // export default mongoose.model("Driver", driverSchema);

// import mongoose from "mongoose";

// const driverSchema = new mongoose.Schema(
//   {
//     // Foreign key to User (userId from User collection)
//     userId: {
//       type: String,
//       ref: "User",
//       required: false,
//       unique: true,
//       index: true
//     },
//     name: {
//       type: String,
//       required: true,
//       trim: true
//     },
//     email: {
//       type: String,
//       required: true,
//       unique: true,
//       lowercase: true,
//       trim: true,
//       index: true
//     },
//     phone: {
//       type: String,
//       sparse: true,
//       trim: true
//     },
//     cnic: {
//       type: String,
//       required: true,
//       unique: true,
//       trim: true,
//       index: true
//     },
//     drivingLicense: {
//       type: String,
//       required: false,
//       unique: true,
//       sparse: true,
//       trim: true,
//       index: true
//     },
//     isVerified: {
//       type: Boolean,
//       default: false
//     },
//     verificationOTP: String,
//     verificationOTPExpiry: Date,

//     // Vehicle Information
//     vehicle: {
//       registrationNumber: {
//         type: String,
//         required: false,
//         unique: true,
//         uppercase: true,
//         trim: true,
//         sparse: true,
//         index: true
//       },
//       color: {
//         type: String,
//         trim: true
//       },
//       model: {
//         type: String,
//         trim: true
//       },
//       registrationPhoto: {
//         type: String,
//         default: null
//       }
//     },

//     // Driver Status
//     status: {
//       type: String,
//       enum: ["pending", "approved", "rejected", "suspended"],
//       default: "pending",
//       index: true
//     },

//     approvalDate: Date,
//     rejectionReason: String,

//     // Ratings
//     averageRating: {
//       type: Number,
//       default: 0
//     },
//     totalRides: {
//       type: Number,
//       default: 0
//     },

//     // Activity
//     isAvailable: {
//       type: Boolean,
//       default: false
//     },
//     lastLogin: Date,

//     // Payment
//     paymentAccounts: {
//       type: Map,
//       of: mongoose.Schema.Types.Mixed,
//       default: {}
//     }
//   },
//   {
//     timestamps: true
//   }
// );

// // Index for faster queries
// driverSchema.index({ userId: 1 });
// driverSchema.index({ email: 1 });
// driverSchema.index({ cnic: 1 });
// driverSchema.index({ drivingLicense: 1 });
// driverSchema.index({ "vehicle.registrationNumber": 1 });
// driverSchema.index({ status: 1 });

// // // Virtual populate to get User data
// // driverSchema.virtual("user", {
// //   ref: "User",
// //   localField: "userId",
// //   foreignField: "_id",
// //   justOne: true
// // });

// driverSchema.virtual("user", {
//   ref: "User",
//   localField: "userId",
//   foreignField: "userId", // <- use this instead of "_id"
//   justOne: true
// });


// // Enable virtuals in toJSON
// driverSchema.set("toJSON", { virtuals: true });
// driverSchema.set("toObject", { virtuals: true });

// export default mongoose.model("Driver", driverSchema);

import mongoose from "mongoose";

const driverSchema = new mongoose.Schema(
  {
    // This will appear immediately after _id in the output
    userId: {
      type: String,
      ref: "User",
      required: false,
      unique: true,
      index: true
    },

    name: {
      type: String,
      required: true,
      trim: true
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true
    },
    phone: {
      type: String,
      sparse: true,
      trim: true
    },
    cnic: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true
    },
    drivingLicense: {
      type: String,
      required: false,
      unique: true,
      sparse: true,
      trim: true,
      index: true
    },
    isVerified: {
      type: Boolean,
      default: false
    },
    verificationOTP: String,
    verificationOTPExpiry: Date,

    // Vehicle Information
    vehicle: {
      registrationNumber: {
        type: String,
        required: false,
        unique: true,
        uppercase: true,
        trim: true,
        sparse: true,
        index: true
      },
      color: {
        type: String,
        trim: true
      },
      model: {
        type: String,
        trim: true
      },
      registrationPhoto: {
        type: String,
        default: null
      },
      year: { type: String }
    },

    // Driver Status
    status: {
      type: String,
      enum: ["pending", "approved", "rejected", "suspended"],
      default: "pending",
      index: true
    },

    approvalDate: Date,
    rejectionReason: String,

    // Ratings
    averageRating: {
      type: Number,
      default: 0
    },
    totalRides: {
      type: Number,
      default: 0
    },

    // Activity
    isAvailable: {
      type: Boolean,
      default: false
    },
    lastLogin: Date,

    // Payment
    paymentAccounts: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

// Indexes
driverSchema.index({ userId: 1 });
driverSchema.index({ email: 1 });
driverSchema.index({ cnic: 1 });
driverSchema.index({ drivingLicense: 1 });
driverSchema.index({ "vehicle.registrationNumber": 1 });
driverSchema.index({ status: 1 });

// Virtual populate
driverSchema.virtual("user", {
  ref: "User",
  localField: "userId",
  foreignField: "userId",
  justOne: true
});

driverSchema.set("toJSON", { virtuals: true });
driverSchema.set("toObject", { virtuals: true });

export default mongoose.model("Driver", driverSchema);
