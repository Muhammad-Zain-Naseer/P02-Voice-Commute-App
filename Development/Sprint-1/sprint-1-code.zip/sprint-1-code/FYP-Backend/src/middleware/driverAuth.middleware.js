import jwt from "jsonwebtoken";
import Driver from "../models/Driver.js";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";

export const authenticateDriver = async (req, res, next) => {
  try {
        console.log("AUTH HEADER:", req.headers.authorization);   // ADD THIS
        const token = req.headers.authorization?.split(" ")[1];
        console.log("TOKEN EXTRACTED:", token);    

    // const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Authentication required"
      });
    }

    const decoded = jwt.verify(token, config.jwtSecret);

    if (decoded.role !== "driver" && !decoded.driverId) {
      return res.status(403).json({
        success: false,
        message: "Access denied. Driver authentication required."
      });
    }

    const driver = await Driver.findById(decoded.driverId).select(
      "-verificationOTP -verificationOTPExpiry"
    );

    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver not found"
      });
    }

    req.driver = driver;
    next();
  } catch (error) {
    logger.error("Driver authentication error:", error);
    
    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        success: false,
        message: "Invalid token"
      });
    }
    
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        message: "Token expired"
      });
    }

    return res.status(500).json({
      success: false,
      message: "Authentication failed"
    });
  }
};