import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';

void main() {
  runApp(const HerSafarApp());
}

class HerSafarApp extends StatelessWidget {
  const HerSafarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HerSafar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
        fontFamily: 'Urdu',
      ),
      home: const WelcomeScreen(),
    
    );
  }
}