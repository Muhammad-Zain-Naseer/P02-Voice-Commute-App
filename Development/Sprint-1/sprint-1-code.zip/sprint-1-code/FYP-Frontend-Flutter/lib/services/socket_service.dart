import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../constants/app_config.dart';
import '../models/ride_request.dart';
import '../utils/logger.dart';

/// Socket Service for Real-time Communication
/// Manages Socket.IO connection and ride-related events
class SocketService {
  static IO.Socket? _socket;
  static bool _isConnected = false;
  static String? _userId;
  static String? _userName;
  static String? _userEmail;

  /// Get connection status
  static bool get isConnected => _isConnected;

  /// Get socket instance
  static IO.Socket? get socket => _socket;

  static String? _userType;

  /// Connect to Socket.IO server
  static Future<void> connect({
    required String userId,
    String? userName,
    String? userEmail,
    required String userType, // 'driver' or 'commuter'
  }) async {
    if (_isConnected && _socket != null) {
      return;
    }

    _userId = userId;
    _userName = userName ?? 'Anonymous User';
    _userEmail = userEmail;
    _userType = userType;

    try {

      _socket = IO.io(
        AppConfig.socketUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .enableAutoConnect()
            .enableReconnection()
            .setReconnectionDelay(
              AppConfig.socketReconnectionDelay.inMilliseconds,
            )
            .setReconnectionAttempts(AppConfig.socketReconnectionAttempts)
            .setTimeout(AppConfig.socketTimeout.inMilliseconds)
            .build(),
      );

      // Connection event handlers
      _socket!.onConnect((_) {
        _isConnected = true;
        Logger.log('✅ Socket connected: ${_socket!.id}');

        // Register user with server - MUST include userType
        _socket!.emit('user:register', {
          'userId': _userId,
          'userName': _userName,
          'userEmail': _userEmail,
          'userType': _userType, // REQUIRED: 'driver' or 'commuter'
        });
      });

      _socket!.onDisconnect((_) {
        _isConnected = false;
        Logger.log('❌ Socket disconnected');
      });

      _socket!.onConnectError((error) {
        _isConnected = false;
        Logger.error('🔴 Socket connection error: $error');
      });

      _socket!.onError((error) {
        Logger.error('🔴 Socket error: $error');
      });

      _socket!.on('user:registered', (data) {
        Logger.log('✅ User registered on server: $data');
      });

      _socket!.on('error', (data) {
        Logger.error('🔴 Server error: $data');
      });

      _socket!.connect();
    } catch (e) {
      Logger.error('💥 Failed to connect socket: $e');
      _isConnected = false;
    }
  }

  /// Disconnect from Socket.IO server
  static void disconnect() {
    if (_socket != null) {
      Logger.log('🔌 Disconnecting socket...');
      _socket!.disconnect();
      _socket!.dispose();
      _socket = null;
      _isConnected = false;
    }
  }

  /// Emit a ride request to the server
  static void emitRideRequest({
    required String source,
    required String destination,
    Map<String, double>? sourceCoordinates,
    Map<String, double>? destinationCoordinates,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot emit ride request: Socket not connected');
      return;
    }

    final rideData = {
      'userId': _userId,
      'userName': _userName,
      'userEmail': _userEmail,
      'source': source,
      'destination': destination,
      'sourceCoordinates': sourceCoordinates,
      'destinationCoordinates': destinationCoordinates,
    };

    Logger.log('📤 Emitting ride request: $rideData');
    _socket!.emit('ride:create', rideData);
  }

  /// Listen for ride created confirmation
  static void onRideCreated(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:created: Socket not initialized');
      return;
    }

    _socket!.on('ride:created', (data) {
      Logger.log('✅ Ride created: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = data is List ? data[0] : data;
        callback(responseData as Map<String, dynamic>);
      } catch (e) {
        Logger.error('💥 Error parsing ride created: $e');
      }
    });
  }

  /// Listen for ride matched event
  static void onRideMatched(Function(RideRequest, String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:matched: Socket not initialized');
      return;
    }

    _socket!.on('ride:matched', (data) {
      Logger.log('🎉 Ride matched: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final role = responseData['role'] as String;
        final ride = RideRequest.fromJson(rideData);
        callback(ride, role);
      } catch (e) {
        Logger.error('💥 Error parsing matched ride: $e');
      }
    });
  }

  /// Listen for new rides (for drivers)
  static void onNewRide(Function(RideRequest) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:new: Socket not initialized');
      return;
    }

    _socket!.on('ride:new', (data) {
      Logger.log('🆕 New ride available: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);
        callback(ride);
      } catch (e) {
        Logger.error('💥 Error parsing new ride: $e');
      }
    });
  }

  /// Listen for ride list updates
  static void onRideListUpdated(Function(List<RideRequest>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:list:updated: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:list:updated', (data) {
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        Logger.log('🔄 Ride list updated: ${responseData['count']} rides');
        final ridesData = responseData['rides'] as List;
        final rides = ridesData
            .map((r) => RideRequest.fromJson(r as Map<String, dynamic>))
            .toList();
        callback(rides);
      } catch (e) {
        Logger.error('💥 Error parsing ride list: $e');
      }
    });
  }

  /// Listen for ride errors
  static void onRideError(Function(String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:error: Socket not initialized');
      return;
    }

    _socket!.on('ride:error', (data) {
      Logger.error('🔴 Ride error: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final message = responseData['message'] as String? ?? 'Unknown error occurred';
        callback(message);
      } catch (e) {
        callback('Unknown error occurred');
      }
    });
  }

  /// Request list of pending rides (for drivers)
  static void requestRideList() {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot request ride list: Socket not connected');
      return;
    }

    Logger.log('📤 Requesting ride list...');
    _socket!.emit('ride:list', {});
  }

  /// Listen for ride list response
  static void onRideList(Function(List<RideRequest>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:list: Socket not initialized');
      return;
    }

    _socket!.on('ride:list', (data) {
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        Logger.log('📥 Received ride list: ${responseData['count']} rides');
        final ridesData = responseData['rides'] as List;
        final rides = ridesData
            .map((r) => RideRequest.fromJson(r as Map<String, dynamic>))
            .toList();
        callback(rides);
      } catch (e) {
        Logger.error('💥 Error parsing ride list: $e');
      }
    });
  }

  /// Cancel a ride request
  static void cancelRide(String rideId) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot cancel ride: Socket not connected');
      return;
    }

    Logger.log('📤 Cancelling ride: $rideId');
    _socket!.emit('ride:cancel', {'rideId': rideId});
  }

  /// Listen for ride cancelled event
  static void onRideCancelled(Function(String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:cancelled: Socket not initialized');
      return;
    }

    _socket!.on('ride:cancelled', (data) {
      Logger.log('🚫 Ride cancelled: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        callback(rideId);
      } catch (e) {
        Logger.error('💥 Error parsing cancelled ride: $e');
      }
    });
  }

  /// Listen for ride unavailable event (when another driver accepts the ride)
  /// NOTE: This event is ONLY sent to drivers when another driver accepts a ride
  /// Commuters should NOT receive this event for their own matched rides
  static void onRideUnavailable(Function(String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:unavailable: Socket not initialized');
      return;
    }

    _socket!.on('ride:unavailable', (data) {
      Logger.log('⚠️ Ride unavailable: $data');
      try {
        // Socket.IO may wrap data in array, extract first element
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;

        // Only process if the user is a driver (not a commuter)
        // Commuters should keep their socket connection active after matching
        if (_userType == 'driver') {
          Logger.log('⚠️ [DRIVER] Ride $rideId is no longer available');
          callback(rideId);
        } else {
          Logger.log('ℹ️ [COMMUTER] Ignoring ride:unavailable for own matched ride');
        }
      } catch (e) {
        Logger.error('💥 Error parsing unavailable ride: $e');
      }
    });
  }

  /// Match with a ride (for drivers)
  static void matchRide({
    required String rideId,
    required String driverId,
    String? driverName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot match ride: Socket not connected');
      return;
    }

    final matchData = {
      'rideId': rideId,
      'driverId': driverId,
      'driverName': driverName ?? 'Driver',
    };

    Logger.log('📤 Matching ride: $matchData');
    _socket!.emit('ride:match', matchData);
  }

  /// Complete a ride (for drivers)
  static void completeRide(String rideId, {double? distanceKm}) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot complete ride: Socket not connected');
      Logger.error('   Socket exists: ${_socket != null}');
      Logger.error('   Is connected: $_isConnected');
      return;
    }

    final payload = {
      'rideId': rideId,
      'distanceKm': distanceKm ?? 0,
    };

    Logger.log('📤 Emitting ride:complete event');
    Logger.log('   Ride ID: $rideId');
    Logger.log('   Distance: ${distanceKm ?? 0} km');
    Logger.log('   Socket ID: ${_socket!.id}');
    Logger.log('   User Type: $_userType');
    Logger.log('   Payload: $payload');

    _socket!.emit('ride:complete', payload);

    Logger.log('✅ ride:complete event emitted successfully');
    Logger.log('💳 Backend should calculate fare and emit ride:payment:request to commuter');
  }

  /// Listen for ride completed event
  static void onRideCompleted(Function(RideRequest) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:completed: Socket not initialized');
      return;
    }

    _socket!.on('ride:completed', (data) {
      Logger.log('✅ Ride completed: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);
        callback(ride);
      } catch (e) {
        Logger.error('💥 Error parsing completed ride: $e');
      }
    });
  }

  /// Trigger SOS alert (for commuters)
  static void triggerSOS({
    required String rideId,
    Map<String, double>? location,
    String? message,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot trigger SOS: Socket not connected');
      return;
    }

    final sosData = {
      'rideId': rideId,
      'location': location,
      'message': message ?? 'Emergency SOS triggered',
    };

    Logger.log('🚨 Triggering SOS: $sosData');
    _socket!.emit('ride:sos', sosData);
  }

  /// Listen for SOS triggered confirmation (for commuters)
  static void onSOSTriggered(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:sos:triggered: Socket not initialized');
      return;
    }

    _socket!.on('ride:sos:triggered', (data) {
      Logger.log('🚨 SOS triggered confirmation: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing SOS triggered: $e');
      }
    });
  }

  /// Listen for SOS alert (for drivers)
  static void onSOSAlert(Function(RideRequest, Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:sos:alert: Socket not initialized');
      return;
    }

    _socket!.on('ride:sos:alert', (data) {
      Logger.log('🚨 SOS ALERT received: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final sosAlert = responseData['sosAlert'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);
        callback(ride, sosAlert);
      } catch (e) {
        Logger.error('💥 Error parsing SOS alert: $e');
      }
    });
  }

  /// Listen for payment request (for commuters)
  static void onPaymentRequest(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:payment:request: Socket not initialized');
      return;
    }

    // Remove any existing listener first to avoid duplicates
    _socket!.off('ride:payment:request');

    _socket!.on('ride:payment:request', (data) {
      Logger.log('💳 Payment request received: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        Logger.log('💳 Processing payment request: $responseData');
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing payment request: $e');
      }
    });

    Logger.log('✅ Payment request listener registered for commuter');
  }

  /// Ensure socket connection is maintained (useful after ride matching)
  static void ensureConnection() {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Socket is not connected');
      return;
    }
    Logger.log('✅ Socket connection confirmed: ${_socket!.id}');
  }

  /// Check if payment listener is registered
  static bool hasPaymentListener() {
    if (_socket == null) return false;
    // Socket.IO doesn't provide a direct way to check listeners, so we log for debugging
    Logger.log('ℹ️ Checking socket connection for payment listener...');
    return _isConnected;
  }

  /// Remove all event listeners
  static void removeAllListeners() {
    if (_socket != null) {
      _socket!.off('ride:created');
      _socket!.off('ride:matched');
      _socket!.off('ride:new');
      _socket!.off('ride:list');
      _socket!.off('ride:list:updated');
      _socket!.off('ride:error');
      _socket!.off('ride:cancelled');
      _socket!.off('ride:unavailable');
      _socket!.off('ride:completed');
      _socket!.off('ride:sos:triggered');
      _socket!.off('ride:sos:alert');
      _socket!.off('ride:payment:request');
      Logger.log('🗑️ Removed all socket listeners');
    }
  }

  /// Remove only payment listener (useful when navigating away from active ride page)
  static void removePaymentListener() {
    if (_socket != null) {
      _socket!.off('ride:payment:request');
      Logger.log('🗑️ Removed payment listener');
    }
  }

  /// Emit driver reached event (for drivers)
  static void emitDriverReached(String rideId) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot emit driver reached: Socket not connected');
      return;
    }

    Logger.log('📤 Emitting driver:reached event for ride: $rideId');
    _socket!.emit('driver:reached', {'rideId': rideId});
  }

  /// Listen for driver reached event (for commuters)
  static void onDriverReached(Function(String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for driver:reached: Socket not initialized');
      return;
    }

    _socket!.on('driver:reached', (data) {
      Logger.log('🚗 Driver reached notification: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        callback(rideId);
      } catch (e) {
        Logger.error('💥 Error parsing driver reached: $e');
      }
    });
  }

  /// Listen for matched ride cancellation (for drivers)
  static void onMatchedRideCancelled(Function(String, String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:cancelled:matched: Socket not initialized');
      return;
    }

    _socket!.on('ride:cancelled:matched', (data) {
      Logger.log('🚫 Matched ride cancelled: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        final message = responseData['message'] as String? ?? 'Ride cancelled';
        callback(rideId, message);
      } catch (e) {
        Logger.error('💥 Error parsing matched ride cancellation: $e');
      }
    });
  }

  /// Send a chat message
  static void sendChatMessage({
    required String rideId,
    required String message,
    required String senderId,
    required String senderName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot send chat message: Socket not connected');
      return;
    }

    final chatData = {
      'rideId': rideId,
      'message': message,
      'senderId': senderId,
      'senderName': senderName,
    };

    Logger.log('📤 Sending chat message: $chatData');
    _socket!.emit('chat:message', chatData);
  }

  /// Listen for incoming chat messages
  static void onChatMessage(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for chat:message: Socket not initialized');
      return;
    }

    _socket!.on('chat:message', (data) {
      Logger.log('💬 Chat message received: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing chat message: $e');
      }
    });
  }

  /// Send a voice message
  static void sendVoiceMessage({
    required String rideId,
    required String audioData,
    required int duration,
    required String senderId,
    required String senderName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot send voice message: Socket not connected');
      return;
    }

    final voiceData = {
      'rideId': rideId,
      'audioData': audioData,
      'duration': duration,
      'senderId': senderId,
      'senderName': senderName,
    };

    Logger.log('📤 Sending voice message: ${voiceData['rideId']} - ${voiceData['duration']}s');
    _socket!.emit('chat:voice', voiceData);
  }

  /// Listen for incoming voice messages
  static void onVoiceMessage(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for chat:voice: Socket not initialized');
      return;
    }

    _socket!.on('chat:voice', (data) {
      Logger.log('🎤 Voice message received: $data');
      try {
        final responseData = (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing voice message: $e');
      }
    });
  }
}
