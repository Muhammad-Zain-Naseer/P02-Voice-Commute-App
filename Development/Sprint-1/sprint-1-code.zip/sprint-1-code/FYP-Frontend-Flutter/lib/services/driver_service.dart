import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/ride_request.dart';
import 'storage_service.dart';
import '../utils/logger.dart';

class DriverService {
  static const String _baseUrl = "http://localhost:3000";

  /// Fetch the completed ride history and stats for the logged-in driver.
  Future<Map<String, dynamic>> getEarningsHistory() async {
    final driverId = await StorageService.getUserId();

    if (driverId == null || driverId.isEmpty) {
      Logger.error('Driver ID not found, cannot fetch earnings.');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }

    final url = Uri.parse('$_baseUrl/api/rides/driver/$driverId/earnings');

    try {
      final response = await http.get(
        url,
        headers: {'Content-Type': 'application/json; charset=UTF-8'},
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final List<dynamic> rideData = body['data']['rides'];

        final total =
            (body['data']['totalEarningsThisMonth'] as num?)?.toDouble() ?? 0.0;

        final rides = rideData
            .map((json) => RideRequest.fromJson(json))
            .toList();

        Logger.log(
          'Fetched ${rides.length} completed rides. Total this month: $total',
        );

        return {'rides': rides, 'totalThisMonth': total};
      } else {
        Logger.error('Failed to load earnings: ${response.body}');
        return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
      }
    } catch (e) {
      Logger.error('Error calling getEarningsHistory API: $e');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }
  }
}
