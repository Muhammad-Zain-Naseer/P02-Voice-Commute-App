import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:async';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../utils/logger.dart';
import '../commuter/active_ride_page.dart';
import '../chat/chat_page.dart';

/// Pre-ride waiting page that shows driver information
/// Waits for driver to reach before navigating to active ride page
class PreSOSPage extends StatefulWidget {
  final RideRequest ride;
  final String userId;

  const PreSOSPage({super.key, required this.ride, required this.userId});

  @override
  State<PreSOSPage> createState() => _PreSOSPageState();
}

class _PreSOSPageState extends State<PreSOSPage> {
  Timer? _timer;
  bool _isCancelled = false;
  bool _isTriggering = false;
  bool _driverReached = false;
  int _unreadCount = 0;

  @override
  void initState() {
    super.initState();
    _setupDriverReachedListener();
    _setupUnreadCountListener();
    _initializeChatSystem();
  }

  /// Initialize chat system for this ride
  void _initializeChatSystem() {
    // Register this commuter as a participant even before opening chat
    // This ensures messages can be received from the start
    ChatPage.registerParticipant(widget.ride.id, widget.userId);
    Logger.log('✅ Commuter registered as chat participant for ride ${widget.ride.id}');
  }

  @override
  void dispose() {
    _timer?.cancel();
    // Remove the driver:reached listener when leaving this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('driver:reached');
      Logger.log('🗑️ Removed driver:reached listener from PreSOSPage');
    }
    super.dispose();
  }

  /// Listen for driver reached event
  void _setupDriverReachedListener() {
    Logger.log('👂 Setting up driver:reached listener in PreSOSPage');

    SocketService.onDriverReached((rideId) {
      Logger.log('🚗 Driver has reached! Ride ID: $rideId');

      if (!mounted || _isCancelled) {
        Logger.log('⚠️ Widget not mounted or cancelled, skipping navigation');
        return;
      }

      if (rideId == widget.ride.id) {
        setState(() {
          _driverReached = true;
        });

        // Navigate to active ride page after driver reaches
        Logger.log('🚗 Navigating to active ride page');
        _navigateToActiveRide();
      }
    });

    Logger.log('✅ Driver:reached listener setup complete');
  }

  /// Setup listener for unread message count updates
  void _setupUnreadCountListener() {
    // Poll unread count every second
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;

      final newCount = ChatPage.getUnreadCount(widget.ride.id, widget.userId);
      if (newCount != _unreadCount) {
        setState(() {
          _unreadCount = newCount;
        });
        Logger.log('📬 Updated unread count for commuter: $_unreadCount');
      }

      return mounted; // Continue polling while mounted
    });
  }

  /// Navigate to active ride page after countdown
  void _navigateToActiveRide() {
    if (_isTriggering) return;

    setState(() {
      _isTriggering = true;
    });

    Logger.log('⏰ Countdown finished - navigating to active ride page');

    if (!mounted) return;

    // Get driver ID from the matched driver
    final driverId = widget.ride.matchedWith?.driverId ?? '';

    // Navigate to the active ride page
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => CommuterActiveRidePage(
          ride: widget.ride,
          userId: widget.userId,
          driverId: driverId,
        ),
      ),
    );
  }

  /// Cancel and go back
  void _cancel() {
    setState(() {
      _isCancelled = true;
    });
    _timer?.cancel();

    // Emit ride cancellation event to notify the driver
    Logger.log('🚫 Commuter cancelling matched ride: ${widget.ride.id}');
    SocketService.cancelRide(widget.ride.id);

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final driver = widget.ride.matchedWith;
    final String driverName = driver?.driverName ?? 'ڈرائیور صارف';

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Back arrow
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: _cancel,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(
                                0xFFCF4374,
                              ).withValues(alpha: 0.2),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ),

                  const Spacer(),

                  // HerSafar Logo
                  SizedBox(
                    height: 80,
                    width: 80,
                    child: SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      fit: BoxFit.contain,
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Sound wave animation
                  Container(
                    height: 40,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(10, (index) {
                        return AnimatedContainer(
                          duration: Duration(milliseconds: 300 + (index * 50)),
                          width: 4,
                          height: 20 + (index % 3) * 10,
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFCF4374),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      }),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Urdu text
                  const Text(
                    'آپ کا ڈرائیور مقرر ہو گیا ہے۔',
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _driverReached
                        ? 'ڈرائیور پہنچ گیا ہے'
                        : 'ڈرائیور آ رہا ہے، براہ کرم انتظار کریں',
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      color: _driverReached ? Colors.green : Colors.black54,
                      fontWeight: _driverReached
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Driver information card
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFF682AA),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.2),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildInfoRow('نام:', driverName),
                        const SizedBox(height: 16),
                        const Divider(color: Color(0xFFF682AA), thickness: 1),
                        const SizedBox(height: 16),
                        _buildInfoRow('گاڑی:', 'Suzuki Mehran'),
                        const SizedBox(height: 16),
                        const Divider(color: Color(0xFFF682AA), thickness: 1),
                        const SizedBox(height: 16),
                        _buildInfoRow('نمبر:', 'LEA-123'),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Action buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Cancel button
                      Expanded(
                        child: GestureDetector(
                          onTap: _cancel,
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xFFE57373), Color(0xFFD32F2F)],
                              ),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.red.withValues(alpha: 0.3),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.close,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(width: 12),

                      // Chat button with notification badge
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            // Clear unread count when opening chat
                            ChatPage.clearUnreadCount(widget.ride.id, widget.userId);
                            setState(() {
                              _unreadCount = 0;
                            });

                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => ChatPage(
                                  rideId: widget.ride.id,
                                  currentUserId: widget.userId,
                                  otherUserName: driver?.driverName ?? 'Driver',
                                  userType: 'commuter',
                                ),
                              ),
                            );
                          },
                          child: Container(
                            height: 60,
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 60,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [Color(0xFF81C784), Color(0xFF66BB6A)],
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.green.withValues(alpha: 0.3),
                                        blurRadius: 10,
                                        spreadRadius: 2,
                                      ),
                                    ],
                                  ),
                                  child: const Center(
                                    child: Icon(
                                      Icons.chat_bubble_outline,
                                      color: Colors.white,
                                      size: 28,
                                    ),
                                  ),
                                ),
                                if (_unreadCount > 0)
                                  Positioned(
                                    right: 4,
                                    top: 4,
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: const BoxDecoration(
                                        color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      constraints: const BoxConstraints(
                                        minWidth: 18,
                                        minHeight: 18,
                                      ),
                                      child: Text(
                                        _unreadCount > 9 ? '9+' : '$_unreadCount',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(width: 12),

                      // Call driver button
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            // TODO: Implement call functionality
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Calling driver...'),
                                duration: Duration(seconds: 1),
                              ),
                            );
                          },
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xFFF48FB1), Color(0xFFCF4374)],
                              ),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFFCF4374,
                                  ).withValues(alpha: 0.3),
                                  blurRadius: 10,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.phone,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Status display
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: _driverReached
                            ? Colors.green
                            : const Color(0xFFCF4374),
                        width: 2,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (!_driverReached)
                          const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                        if (!_driverReached) const SizedBox(width: 8),
                        Text(
                          _driverReached
                              ? 'ڈرائیور پہنچ گیا ہے! سواری شروع کریں'
                              : 'ڈرائیور کے پہنچنے کا انتظار ہے...',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: _driverReached
                                ? Colors.green
                                : const Color(0xFFCF4374),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      textDirection: TextDirection.rtl,
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
          textDirection: TextDirection.rtl,
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFFCF4374),
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}
