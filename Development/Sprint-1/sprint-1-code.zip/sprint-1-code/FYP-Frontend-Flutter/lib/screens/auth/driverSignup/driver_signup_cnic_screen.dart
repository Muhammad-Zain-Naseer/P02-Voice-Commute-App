import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;

import '../../../constants/app_config.dart';
import '../../../widgets/sound_wave.dart';
import 'driver_signup_license_screen.dart';

class DriverSignupCnicScreen extends StatefulWidget {
  final String email;
  final String token;

  const DriverSignupCnicScreen({
    super.key,
    required this.email,
    required this.token,
  });

  @override
  State<DriverSignupCnicScreen> createState() => _DriverSignupCnicScreenState();
}

class _DriverSignupCnicScreenState extends State<DriverSignupCnicScreen> {
  final TextEditingController _cnicController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _cnicController.dispose();
    super.dispose();
  }

  /// format CNIC with dashes (xxxxx-xxxxxxx-x)
  String _formatCnic(String value) {
    String digits = value.replaceAll(RegExp(r'[^0-9]'), '');

    if (digits.length > 13) digits = digits.substring(0, 13);

    if (digits.length > 12) {
      return '${digits.substring(0, 5)}-${digits.substring(5, 12)}-${digits.substring(12)}';
    } else if (digits.length > 5) {
      return '${digits.substring(0, 5)}-${digits.substring(5)}';
    }

    return digits;
  }

  Future<void> _continue() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final url = Uri.parse('${AppConfig.apiBaseUrl}/api/driver/auth/submit-cnic');

      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${widget.token}",
        },
        body: jsonEncode({
          "cnic": _cnicController.text.replaceAll('-', ''),
        }),
      );

      final data = jsonDecode(response.body);

      if (mounted) {
        if (response.statusCode == 200 && data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("شناختی کارڈ نمبر محفوظ ہو گیا"),
              backgroundColor: Colors.green,
            ),
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DriverSignupLicenseScreen(
                email: widget.email,
                token: widget.token,
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'CNIC محفوظ نہیں ہوا'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("نیٹ ورک میں خرابی: $e"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 70,
                      height: 70,
                    ),
                    const SizedBox(width: 48),
                  ],
                ),

                const SizedBox(height: 30),
                const SoundWave(),
                const SizedBox(height: 40),

                const Text(
                  'اپنا شناختی کارڈ نمبر درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 30),

                // CNIC Input
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _cnicController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Color(0xFFCF4374),
                      letterSpacing: 2,
                    ),
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(13),
                    ],
                    onChanged: (value) {
                      final formatted = _formatCnic(value);
                      if (formatted != value) {
                        _cnicController.value = TextEditingValue(
                          text: formatted,
                          selection: TextSelection.collapsed(offset: formatted.length),
                        );
                      }
                    },
                    decoration: InputDecoration(
                      hintText: '00000-0000000-0',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withOpacity(0.4),
                        fontSize: 18,
                        letterSpacing: 2,
                      ),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFFF682AA),
                          width: 1.5,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) return '';
                      final clean = value.replaceAll(RegExp(r'[^0-9]'), '');
                      if (clean.length != 13) return '';
                      return null;
                    },
                  ),
                ),

                const Spacer(),

                // Button
                GestureDetector(
                  onTap: _isLoading ? null : _continue,
                  child: Container(
                    width: 200,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFFCF4374),
                          Color(0xFF69223B),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFCF4374).withOpacity(0.3),
                          blurRadius: 10,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Center(
                      child: _isLoading
                          ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                          : const Text(
                              'اگلا',
                              textDirection: TextDirection.rtl,
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
