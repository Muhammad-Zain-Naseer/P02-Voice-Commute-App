import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'bookride/book_ride_page.dart';
import '../widgets/rate_ride_dialog.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  final String userEmail;
  final String userId;

  const HomeScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userId,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void _showRatingDialog(String rideId) {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return RateRideDialog(rideId: rideId);
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 32.0,
              vertical: 20.0,
            ),
            child: Column(
              children: [
                SvgPicture.asset(
                  'assets/icons/car_icon.svg',
                  width: 80,
                  height: 80,
                ),

                const SizedBox(height: 30),

                Text(
                  'خوش آمدید!',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 40),

                // Sound Wave Visualization
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.volume_up,
                        color: Color(0xFFCF4374),
                        size: 40,
                      ),
                      const SizedBox(width: 16),
                      // Sound wave bars
                      ...List.generate(15, (index) {
                        return Container(
                          width: 4,
                          height: 30 + (index % 3) * 20,
                          margin: const EdgeInsets.symmetric(horizontal: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFCF4374),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      }),
                      const SizedBox(width: 16),
                      const Icon(
                        Icons.volume_up,
                        color: Color(0xFFCF4374),
                        size: 40,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // Instruction Text
                const Text(
                  'سواری بُک کرنے کے لیے نیچے',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Color(0xFFCF4374),
                    height: 1.5,
                  ),
                ),
                const Text(
                  'دیا گیا بٹن دبائیں۔',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    color: Color(0xFFCF4374),
                    height: 1.5,
                  ),
                ),

                const Spacer(),

                // const SizedBox(height: 30),

                // Book Ride Button
                GestureDetector(
                  // 3. MAKE THIS FUNCTION ASYNC
                  onTap: () async {
                    // 4. AWAIT THE RESULT FROM THE NAVIGATION
                    // This will wait until the ride flow is
                    // finished and pops back here.
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookRidePage(
                          userId: widget.userId,
                          userName: widget.userName,
                          userEmail: widget.userEmail,
                        ),
                      ),
                    );

                    // 5. CHECK IF WE GOT A RIDE ID BACK
                    if (result != null && result is String) {
                      final rideIdToRate = result;
                      // 6. SHOW THE RATING DIALOG
                      _showRatingDialog(rideIdToRate);
                    }
                  },
                  child: Container(
                    width: double.infinity,
                    height: 70,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                      ),
                      borderRadius: BorderRadius.circular(35),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(
                            0xFFCF4374,
                          ).withOpacity(0.4), // Use withOpacity
                          blurRadius: 15,
                          spreadRadius: 2,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.directions_car,
                          color: Colors.white,
                          size: 32,
                        ),
                        SizedBox(width: 16),
                        Text(
                          'رائیڈ بُک کریں',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
