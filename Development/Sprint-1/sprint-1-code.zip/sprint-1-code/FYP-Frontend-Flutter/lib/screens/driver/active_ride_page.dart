import 'package:flutter/material.dart';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../utils/logger.dart';
import '../chat/chat_page.dart';

/// Driver Active Ride Page - Shows ongoing ride with complete button
class DriverActiveRidePage extends StatefulWidget {
  final RideRequest ride;
  final String driverId;

  const DriverActiveRidePage({
    super.key,
    required this.ride,
    required this.driverId,
  });

  @override
  State<DriverActiveRidePage> createState() => _DriverActiveRidePageState();
}

class _DriverActiveRidePageState extends State<DriverActiveRidePage> {
  bool _isCompletingRide = false;
  bool _hasReached = false;
  int _unreadCount = 0;

  @override
  void initState() {
    super.initState();
    _ensureSocketConnection();
    _setupCancellationListener();
    _setupUnreadCountListener();
    _initializeChatSystem();
  }

  /// Initialize chat system for this ride
  void _initializeChatSystem() {
    // Register this driver as a participant even before opening chat
    // This ensures messages can be received from the start
    ChatPage.registerParticipant(widget.ride.id, widget.driverId);
    Logger.log('✅ Driver registered as chat participant for ride ${widget.ride.id}');
  }

  /// Ensure socket connection is maintained for active ride
  void _ensureSocketConnection() {
    SocketService.ensureConnection();
    Logger.log('🔌 Socket connection verified for driver active ride page');
  }

  /// Setup listener for matched ride cancellation
  void _setupCancellationListener() {
    Logger.log('👂 Setting up matched ride cancellation listener');

    SocketService.onMatchedRideCancelled((rideId, message) {
      Logger.log('🚫 Ride cancelled by commuter: $rideId');

      if (!mounted) {
        Logger.log('⚠️ Widget not mounted, skipping navigation');
        return;
      }

      if (rideId == widget.ride.id) {
        // Show cancellation dialog
        _showCancellationDialog(message);
      }
    });

    Logger.log('✅ Cancellation listener setup complete');
  }

  /// Setup listener for unread message count updates
  void _setupUnreadCountListener() {
    // Poll unread count every second
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;

      final newCount = ChatPage.getUnreadCount(widget.ride.id, widget.driverId);
      if (newCount != _unreadCount) {
        setState(() {
          _unreadCount = newCount;
        });
        Logger.log('📬 Updated unread count for driver: $_unreadCount');
      }

      return mounted; // Continue polling while mounted
    });
  }

  /// Show dialog when commuter cancels the ride
  void _showCancellationDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'Ride Cancelled',
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            message,
            style: const TextStyle(fontSize: 16),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Navigate back to available rides page (previous page in stack)
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFCF4374),
              ),
              child: const Text(
                'OK',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    // Remove the cancellation listener when leaving this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('ride:cancelled:matched');
      Logger.log('🗑️ Removed ride:cancelled:matched listener');
    }
    // IMPORTANT: Keep socket connected even after completing ride
    // Only disconnect when the driver completely exits the app or logs out
    Logger.log('🗑️ Disposing DriverActiveRidePage - keeping socket connected');
    super.dispose();
  }

  /// Notify commuter that driver has reached
  Future<void> _notifyReached() async {
    setState(() {
      _hasReached = true;
    });

    try {
      Logger.log('🚗 Notifying commuter that driver has reached...');
      SocketService.emitDriverReached(widget.ride.id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Passenger notified that you have arrived!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      Logger.error('❌ Failed to notify reached: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send notification: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// Complete the ride - automatically calculate fare from distance
  Future<void> _completeRide() async {
    // Show confirmation dialog first
    final confirmed = await _showCompleteRideConfirmation();
    if (!confirmed) return;

    setState(() {
      _isCompletingRide = true;
    });

    try {
      // Get coordinates from ride
      final sourceCoords = widget.ride.source.coordinates;
      final destCoords = widget.ride.destination.coordinates;

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Coordinates not available');
      }

      Logger.log('📍 Calculating distance from coordinates...');

      // Call backend to calculate distance
      final routeData = await MapService.calculateRoute(
        sourceLat: sourceCoords.lat,
        sourceLng: sourceCoords.lon,
        destLat: destCoords.lat,
        destLng: destCoords.lon,
      );

      // Extract distance (e.g., "5.2 km" -> 5.2)
      final distanceStr = routeData['distance'] ?? '0 km';
      final distanceKm = double.tryParse(distanceStr.split(' ')[0]) ?? 0;

      Logger.log('✅ Distance calculated: $distanceKm km');

      if (distanceKm <= 0) {
        throw Exception('Invalid distance calculated');
      }

      // Verify socket is still connected before sending
      if (!SocketService.isConnected) {
        throw Exception('Socket connection lost! Cannot complete ride.');
      }

      Logger.log('📡 Sending ride completion to backend...');
      Logger.log('   Ride ID: ${widget.ride.id}');
      Logger.log('   Distance: $distanceKm km');
      Logger.log('   Socket Connected: ${SocketService.isConnected}');
      Logger.log('   Socket ID: ${SocketService.socket?.id}');

      // Send to backend with distance - this triggers payment calculation
      SocketService.completeRide(widget.ride.id, distanceKm: distanceKm);

      Logger.log('✅ Ride completion event sent to backend');
      Logger.log('💳 Backend should now calculate fare and send payment request to commuter');

      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ride completed! Distance: ${distanceKm.toStringAsFixed(1)} km\nPayment request sent to passenger.'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );

        Logger.log('⏳ Waiting 3 seconds before navigating back...');

        // Navigate back to available rides page after 3 seconds
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) {
            Logger.log('🏠 Navigating back to available rides page');
            Navigator.of(context).pop();
          }
        });
      }
    } catch (e) {
      Logger.error('❌ Failed to complete ride: $e');
      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to complete ride: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  /// Show complete ride confirmation dialog
  Future<bool> _showCompleteRideConfirmation() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text(
                'Complete Ride',
                style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontWeight: FontWeight.bold,
                ),
              ),
              content: const Text(
                'Are you sure you want to complete this ride?\n\nFare will be calculated automatically based on distance.',
                style: TextStyle(fontSize: 16),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCF4374),
                  ),
                  child: const Text(
                    'Complete',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text(
          'Active Ride',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFFCF4374),
        elevation: 0,
        automaticallyImplyLeading: false, // Remove back button
        actions: [
          // Chat button with notification badge
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
                onPressed: () {
                  // Clear unread count when opening chat
                  ChatPage.clearUnreadCount(widget.ride.id, widget.driverId);
                  setState(() {
                    _unreadCount = 0;
                  });

                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => ChatPage(
                        rideId: widget.ride.id,
                        currentUserId: widget.driverId,
                        otherUserName: widget.ride.userName,
                        userType: 'driver',
                      ),
                    ),
                  );
                },
                tooltip: 'Chat with passenger',
              ),
              if (_unreadCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 18,
                      minHeight: 18,
                    ),
                    child: Text(
                      _unreadCount > 9 ? '9+' : '$_unreadCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              // Status Badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.local_taxi,
                      color: Colors.white,
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Ride in Progress',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              // Ride Details Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFFF682AA),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withValues(alpha: 0.1),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Passenger Name
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFCE4EC),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.person,
                            color: Color(0xFFCF4374),
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Passenger',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                              Text(
                                widget.ride.userName,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFCF4374),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    const Divider(color: Color(0xFFF682AA)),

                    const SizedBox(height: 24),

                    // Source Location
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.location_on,
                          color: Colors.green,
                          size: 24,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Pickup Location',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                widget.ride.source.address,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.black87,
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // Destination Location
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.flag,
                          color: Colors.red,
                          size: 24,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Drop-off Location',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                widget.ride.destination.address,
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.black87,
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const Spacer(),

              // Reached Button (shown when driver hasn't notified yet)
              if (!_hasReached) ...[
                SizedBox(
                  width: double.infinity,
                  height: 70,
                  child: ElevatedButton(
                    onPressed: _notifyReached,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35),
                      ),
                      elevation: 8,
                      shadowColor: Colors.orange.withValues(alpha: 0.4),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.location_on,
                          color: Colors.white,
                          size: 32,
                        ),
                        SizedBox(width: 12),
                        Text(
                          'I Have Reached',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],

              // Complete Ride Button (enabled after reaching)
              SizedBox(
                width: double.infinity,
                height: 70,
                child: ElevatedButton(
                  onPressed: (_isCompletingRide || !_hasReached) ? null : _completeRide,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCF4374),
                    disabledBackgroundColor: Colors.grey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(35),
                    ),
                    elevation: 8,
                    shadowColor: const Color(0xFFCF4374).withValues(alpha: 0.4),
                  ),
                  child: _isCompletingRide
                      ? const CircularProgressIndicator(
                          color: Colors.white,
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.check_circle_outline,
                              color: Colors.white,
                              size: 32,
                            ),
                            SizedBox(width: 12),
                            Text(
                              'Complete Ride',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
