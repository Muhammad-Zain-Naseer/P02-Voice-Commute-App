import 'package:flutter/material.dart';
import '../../models/ride_request.dart';
import '../../models/driver_payment_details.dart';
import '../../services/sos_service.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../utils/logger.dart';
import '../payment/payment_page.dart';

class RideStartedPage extends StatefulWidget {
  final RideRequest ride;
  final String role; // 'driver' or 'commuter'

  const RideStartedPage({
    super.key,
    required this.ride,
    this.role = 'commuter', // Default to commuter
  });

  @override
  State<RideStartedPage> createState() => _RideStartedPageState();
}

class _RideStartedPageState extends State<RideStartedPage> {
  bool _isSendingSOS = false;
  bool _isCompletingRide = false;

  @override
  void initState() {
    super.initState();
    // Setup listeners and verify connection based on role
    if (widget.role == 'commuter') {
      _setupPaymentListener();
    }
    _ensureSocketConnection();
  }

  @override
  void dispose() {
    // IMPORTANT: Keep socket connected throughout ride lifecycle
    // Don't disconnect here - socket should stay alive for payment processing
    Logger.log('🗑️ Disposing RideStartedPage (${widget.role}) - keeping socket connected');
    super.dispose();
  }

  /// Ensure socket connection is maintained
  void _ensureSocketConnection() {
    SocketService.ensureConnection();
    Logger.log('🔌 Socket connection verified for ride started page');
  }

  /// Setup payment listener for commuters
  void _setupPaymentListener() {
    Logger.log('💳 Setting up payment listener for commuter in RideStartedPage');
    SocketService.onPaymentRequest(_handlePaymentRequest);
    Logger.log('✅ Payment listener registered in RideStartedPage');
  }

  /// Handle payment request from driver
  void _handlePaymentRequest(Map<String, dynamic> data) {
    Logger.log('💳 Payment request received in RideStartedPage: $data');

    if (!mounted) {
      Logger.log('⚠️ Widget not mounted, skipping payment dialog');
      return;
    }

    try {
      final fare = data['fare'] as Map<String, dynamic>;
      final distanceKm = (fare['distanceKm'] as num).toDouble();
      final totalAmount = (fare['totalAmount'] as num).toInt();

      // Extract driver payment details
      final driverPaymentDetailsJson = data['driverPaymentDetails'] as Map<String, dynamic>?;
      final driverPaymentDetails = DriverPaymentDetails.fromJson(driverPaymentDetailsJson);

      Logger.log('✅ Parsed payment in RideStartedPage: PKR $totalAmount for $distanceKm km');
      Logger.log('💳 Driver payment details: $driverPaymentDetails');

      _showPaymentDialog(distanceKm, totalAmount, driverPaymentDetails);
    } catch (e) {
      Logger.error('💥 Error processing payment in RideStartedPage: $e');
    }
  }

  /// Complete ride (for drivers) - Calculate distance automatically
  Future<void> _completeRide() async {
    final confirmed = await _showCompleteRideConfirmation();
    if (!confirmed) return;

    setState(() {
      _isCompletingRide = true;
    });

    try {
      // Get coordinates from ride
      final sourceCoords = widget.ride.source.coordinates;
      final destCoords = widget.ride.destination.coordinates;

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Coordinates not available');
      }

      Logger.log('📍 Calculating distance from coordinates...');

      // Call backend to calculate distance
      final routeData = await MapService.calculateRoute(
        sourceLat: sourceCoords.lat,
        sourceLng: sourceCoords.lon,
        destLat: destCoords.lat,
        destLng: destCoords.lon,
      );

      // Extract distance (e.g., "5.2 km" -> 5.2)
      final distanceStr = routeData['distance'] ?? '0 km';
      final distanceKm = double.tryParse(distanceStr.split(' ')[0]) ?? 0;

      Logger.log('✅ Distance calculated: $distanceKm km');

      if (distanceKm <= 0) {
        throw Exception('Invalid distance calculated');
      }

      // Send to backend
      SocketService.completeRide(widget.ride.id, distanceKm: distanceKm);

      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        _showSuccessDialog('سواری مکمل ہو گئی');
        // Navigate back after 2 seconds
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) {
            Navigator.of(context).popUntil((route) => route.isFirst);
          }
        });
      }
    } catch (e) {
      Logger.error('❌ Failed to complete ride: $e');
      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        _showErrorDialog('سواری مکمل کرنے میں ناکامی\n${e.toString()}');
      }
    }
  }

  /// Show complete ride confirmation dialog
  Future<bool> _showCompleteRideConfirmation() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFFCF4374),
                    width: 2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle,
                        color: Color(0xFFCF4374), size: 50),
                    const SizedBox(height: 16),
                    const Text(
                      'کیا آپ سواری مکمل کرنا چاہتے ہیں؟',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'کرایہ خودکار طریقے سے حساب ہو جائے گا',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Cancel Button
                        GestureDetector(
                          onTap: () => Navigator.of(context).pop(false),
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.close,
                              color: Colors.black54,
                              size: 32,
                            ),
                          ),
                        ),
                        // Confirm Button
                        GestureDetector(
                          onTap: () => Navigator.of(context).pop(true),
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: const BoxDecoration(
                              color: Color(0xFFCF4374),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 32,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ) ??
        false;
  }

  /// Show payment dialog to commuter
  void _showPaymentDialog(double distanceKm, int totalAmount, DriverPaymentDetails driverPaymentDetails) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFCF4374),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.payment, color: Color(0xFFCF4374), size: 50),
                const SizedBox(height: 16),
                const Text(
                  'سواری مکمل ہو گئی',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'فاصلہ: ${distanceKm.toStringAsFixed(1)} کلومیٹر',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'کرایہ: PKR $totalAmount',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop();
                    // Navigate to Payment Page
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => PaymentPage(
                          ride: widget.ride,
                          userId: widget.ride.userId,
                          driverId: widget.ride.matchedWith!.driverId,
                          amount: totalAmount.toDouble(),
                          driverPaymentDetails: driverPaymentDetails,
                        ),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFCF4374),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'ادائیگی کریں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSuccessDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.green,
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 50),
                const SizedBox(height: 16),
                Text(
                  message,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.red,
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error, color: Colors.red, size: 50),
                const SizedBox(height: 16),
                Text(
                  message,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'ٹھیک ہے',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Trigger SOS alert directly
  Future<void> _triggerSOS() async {
    // Show confirmation dialog first
    final confirmed = await _showSOSConfirmationDialog();
    if (!confirmed) return;

    try {
      Logger.log('🚨 Triggering SOS for ride: ${widget.ride.id}');

      final result = await SOSService.triggerSOSWithRetry(
        rideId: widget.ride.id ?? '',
        message: 'Emergency SOS triggered by commuter',
      );

      if (mounted) {
        if (result) {
          _showSOSSuccessDialog();
        } else {
          _showSOSErrorDialog();
        }
      }
    } catch (e) {
      Logger.error('❌ Failed to trigger SOS: $e');
      if (mounted) {
        _showSOSErrorDialog();
      }
    }
  }

  /// Show SOS confirmation dialog
  Future<bool> _showSOSConfirmationDialog() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.red,
                    width: 2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.warning, color: Colors.red, size: 50),
                    const SizedBox(height: 16),
                    const Text(
                      'کیا آپ ایمرجنسی الرٹ بھیجنا چاہتے ہیں؟',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'آپ کے معتبر رابطوں کو ای میل بھیجی جائے گی',
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.of(context).pop(false),
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.close,
                              color: Colors.black54,
                              size: 32,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.of(context).pop(true),
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 32,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ) ??
        false;
  }

  void _showSOSSuccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.green,
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 50),
                const SizedBox(height: 16),
                const Text(
                  'ایمرجنسی الرٹ بھیج دی گئی!',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'آپ کے معتبر رابطوں کو اطلاع دے دی گئی ہے',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'ٹھیک ہے',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSOSErrorDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.red,
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error, color: Colors.red, size: 50),
                const SizedBox(height: 16),
                const Text(
                  'ایمرجنسی الرٹ بھیجنے میں ناکامی',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'براہ کرم دوبارہ کوشش کریں',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'ٹھیک ہے',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final driver = widget.ride.matchedWith;
    final String driverName = driver?.driverName ?? 'ڈرائیور صارف';

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFDEAF0),
              Color(0xFFF8BBD0),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Back Arrow
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFCF4374)
                                  .withValues(alpha: 0.2),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward,
                          color: Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              // Ride Started Title
              const Text(
                'سواری شروع ہو گئی',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFCF4374),
                ),
              ),

              const SizedBox(height: 20),

              // Driver Name
              Text(
                'ڈرائیور: $driverName',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 40),

              // Journey Info Card
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFF682AA),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color:
                            const Color(0xFFCF4374).withValues(alpha: 0.2),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      _buildJourneyRow('شروعات:', widget.ride.source.address),
                      const SizedBox(height: 16),
                      Container(
                        height: 1,
                        color: const Color(0xFFF682AA).withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      _buildJourneyRow(
                          'منزل:', widget.ride.destination.address),
                    ],
                  ),
                ),
              ),

              const Spacer(),

              // Show SOS button for commuters, Complete Ride for drivers
              widget.role == 'driver'
                  ? _buildCompleteRideButton()
                  : _buildSOSButton(),

              const Spacer(),

              // Bottom Navigation Bar
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFFDF0F4),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 10,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildNavItem(Icons.home_outlined, 'ہوم', true),
                        _buildNavItem(
                            Icons.notifications_outlined, 'اطلاعات', false),
                        _buildNavItem(Icons.person_outline, 'پروفائل', false),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompleteRideButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32.0),
      child: Column(
        children: [
          const Text(
            'سواری مکمل کریں',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _isCompletingRide ? null : _completeRide,
            child: Container(
              width: double.infinity,
              height: 60,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFF48FB1),
                    Color(0xFFCF4374),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(
                child: _isCompletingRide
                    ? const CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 3,
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(
                            Icons.check_circle,
                            color: Colors.white,
                            size: 24,
                          ),
                          SizedBox(width: 8),
                          Text(
                            'سواری مکمل کریں',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'کرایہ خودکار طریقے سے حساب ہو جائے گا',
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSOSButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32.0),
      child: Column(
        children: [
          const Text(
            'ایمرجنسی کی صورت میں',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _isSendingSOS ? null : _triggerSOS,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFFF6B6B),
                    Color(0xFFFF0000),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.red.withValues(alpha: 0.5),
                    blurRadius: 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Center(
                child: _isSendingSOS
                    ? const CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 3,
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.warning_amber_rounded,
                            size: 80,
                            color: Colors.white,
                          ),
                          SizedBox(height: 8),
                          Text(
                            'SOS',
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'دبائیں اور اپنے معتبر رابطوں کو الرٹ بھیجیں',
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJourneyRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      textDirection: TextDirection.rtl,
      children: [
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(width: 16),
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFFCF4374),
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? const Color(0xFFCF4374) : Colors.grey,
          size: 28,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: isActive ? const Color(0xFFCF4374) : Colors.grey,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}
