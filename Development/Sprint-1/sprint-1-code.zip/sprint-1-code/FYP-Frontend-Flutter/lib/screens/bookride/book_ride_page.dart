import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:math' as math;
import 'package:record/record.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path_provider/path_provider.dart';

import '../../services/audio_api_service.dart';
import '../../services/location_service.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../utils/logger.dart';

// Local page imports
import 'ride_waiting_page.dart';
import 'ride_started_page.dart';

class BookRidePage extends StatefulWidget {
  final String userId;
  final String userName;
  final String userEmail;

  const BookRidePage({
    super.key,
    required this.userId,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<BookRidePage> createState() => _BookRidePageState();
}

class _BookRidePageState extends State<BookRidePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  final AudioRecorder _audioRecorder = AudioRecorder();

  bool _isListening = false;
  bool _isProcessing = false;
  bool _isPublishing = false;

  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  String? _currentRideId;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    _loadCurrentLocation();
    _initializeSocket();
  }

  /// Initialize socket connection and event listeners
  Future<void> _initializeSocket() async {
    try {
      // Connect to socket server as COMMUTER using logged-in user data
      await SocketService.connect(
        userId: widget.userId,
        userName: widget.userName,
        userEmail: widget.userEmail,
        userType: 'commuter',
      );

      // Listen for ride created confirmation
      SocketService.onRideCreated((data) {
        Logger.log('✅ Ride created confirmation: $data');
        if (mounted) {
          setState(() {
            _isPublishing = false;
            _currentRideId = data['ride']['id'] as String?;
          });

          // 🚀 NAVIGATION: Go to RideWaitingPage
          if (_currentRideId != null) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => RideWaitingPage(
                  rideId: _currentRideId!,
                  source: _sourceController.text, // Pass English address
                  destination:
                      _destinationController.text, // Pass English address
                ),
              ),
            );
          }
        }
      });

      // Listen for ride matched event
      SocketService.onRideMatched((ride, role) {
        Logger.log('🎉 Ride matched! Role: $role');
        if (mounted) {
          Navigator.of(context).pop(); // Close the RideWaitingPage
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => RideStartedPage(
                ride: ride,
                role: role, // Pass the role (driver or commuter)
              ),
            ),
          );
        }
      });

      // Listen for ride errors
      SocketService.onRideError((message) {
        Logger.error('🔴 Ride error: $message');
        if (mounted) {
          setState(() {
            _isPublishing = false;
          });

          if (Navigator.canPop(context)) {
            Navigator.of(context).pop();
          }

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $message'),
              backgroundColor: Colors.red,
            ),
          );
        }
      });

      Logger.log('✅ Socket initialized successfully');
    } catch (e) {
      Logger.error('Failed to initialize socket: $e');
    }
  }

  /// Load current location and set it as source
  Future<void> _loadCurrentLocation() async {
    Logger.log('🌍 Loading current location on page load...');
    try {
      final location = await LocationService.getCurrentLocationAddress();
      if (location != null && mounted) {
        setState(() {
          _sourceController.text = location;
        });
        Logger.log('✅ Source set to current location: $location');
      }
    } catch (e) {
      Logger.error('❌ Error loading current location: $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _audioRecorder.dispose();
    _sourceController.dispose();
    _destinationController.dispose();
    SocketService.removeAllListeners();
    SocketService.disconnect();
    super.dispose();
  }

  /// Publish ride request to the connection pool
  Future<void> _publishRide() async {
    final source = _sourceController.text.trim();
    final destination = _destinationController.text.trim();

    // Validation checks...
    if (source.isEmpty || destination.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'براہ کرم شروعاتی جگہ اور منزل دونوں درج کریں',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    if (source == destination) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'شروعاتی جگہ اور منزل ایک جیسی نہیں ہو سکتی',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (!SocketService.isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'سرور سے منسلک نہیں۔ دوبارہ کوشش کریں۔',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.red,
        ),
      );
      await _initializeSocket();
      return;
    }

    setState(() {
      _isPublishing = true;
    });

    try {
      Logger.log('Publishing ride request...');
      Logger.log('Geocoding addresses before sending...');

      // Geocode source and destination to get coordinates
      final sourceCoords = await MapService.geocodeAddress(source);
      final destCoords = await MapService.geocodeAddress(destination);

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Failed to geocode addresses');
      }

      Logger.log(
        '✅ Source coords: ${sourceCoords['latitude']}, ${sourceCoords['longitude']}',
      );
      Logger.log(
        '✅ Dest coords: ${destCoords['latitude']}, ${destCoords['longitude']}',
      );

      // Emit ride request with coordinates
      SocketService.emitRideRequest(
        source: source,
        destination: destination,
        sourceCoordinates: sourceCoords,
        destinationCoordinates: destCoords,
      );
    } catch (e) {
      Logger.error('💥 Failed to publish ride: $e');

      setState(() {
        _isPublishing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _toggleListening() async {
    Logger.log('🎤 Toggle listening called. Current state: $_isListening');

    if (_isProcessing) {
      Logger.log('⚠️ Already processing, ignoring click');
      return;
    }

    if (_isListening) {
      Logger.log('🛑 Stopping recording...');
      await _stopRecording();
    } else {
      Logger.log('▶️ Starting recording...');
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    setState(() {
      _isProcessing = true;
    });

    Logger.log('📱 Requesting microphone permission...');
    final status = await Permission.microphone.request();

    if (!status.isGranted) {
      Logger.error('❌ Permission denied!');
      setState(() {
        _isProcessing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Microphone permission is required'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    try {
      Logger.log('🎙️ Starting audio recorder...');

      if (kIsWeb) {
        await _audioRecorder.start(
          const RecordConfig(
            encoder: AudioEncoder.wav,
            numChannels: 1,
            sampleRate: 16000,
          ),
          path: 'audio_recording',
        );
      } else {
        final tempDir = await getTemporaryDirectory();
        final filePath =
            '${tempDir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

        await _audioRecorder.start(
          const RecordConfig(
            encoder: AudioEncoder.aacLc,
            numChannels: 1,
            sampleRate: 16000,
          ),
          path: filePath,
        );
      }

      Logger.log('✅ Recording started successfully!');
      setState(() {
        _isListening = true;
        _isProcessing = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Recording started...'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      Logger.error('💥 ERROR starting recording: $e');
      setState(() {
        _isProcessing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error starting recording: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _stopRecording() async {
    try {
      Logger.log('⏹️ Stopping audio recorder...');
      final path = await _audioRecorder.stop();

      setState(() {
        _isListening = false;
      });

      Logger.log('📍 Recording stopped. Path: $path');

      if (path != null && path.isNotEmpty) {
        Logger.log('🚀 Processing audio...');
        await _commonAudioProcessing(() => AudioApiService.processAudio(path));
      } else {
        Logger.error('⚠️ No recording path returned!');
      }
    } catch (e) {
      Logger.error('💥 ERROR stopping recording: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error stopping recording: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _commonAudioProcessing(
    Future<Map<String, dynamic>?> Function() apiCall,
  ) async {
    setState(() {
      _isProcessing = true;
    });

    try {
      Logger.log('📍 Attempting to get current location...');
      String? currentLocation =
          await LocationService.getCurrentLocationAddress();

      Logger.log('📡 Calling API service...');
      final result = await apiCall();
      Logger.log('📥 API Response: $result');

      if (result != null && mounted) {
        String source = '';
        if (currentLocation != null && currentLocation.isNotEmpty) {
          source = currentLocation;
        } else if (result['source'] != null &&
            result['source'].toString().isNotEmpty) {
          source = result['source'];
        }

        final destination = result['destination'] ?? '';
        Logger.log('✅ Success! Source: $source, Destination: $destination');

        setState(() {
          _sourceController.text = source;
          _destinationController.text = destination;
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Locations extracted!\nFrom: ${source.isEmpty ? "Not set" : source}\nTo: ${destination.isEmpty ? "Not found" : destination}',
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
      } else if (mounted) {
        Logger.error('❌ API returned null result');

        setState(() {
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to process audio. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e, stackTrace) {
      Logger.error('💥 ERROR processing audio: $e');
      Logger.error('Stack trace: $stackTrace');

      if (mounted) {
        setState(() {
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC), // Light pink background
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Column(
              children: [
                const SizedBox(height: 40),
                // Car icon with HerSafar text (Placeholder for the actual widget)
                Column(
                  children: [
                    // SVG ICON (Car)
                    SizedBox(
                      height: 70,
                      width: 70,
                      child: SvgPicture.asset(
                        'assets/icons/car_icon.svg',
                        fit: BoxFit.contain,
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 30),
                // Audio waveform
                SizedBox(
                  height: 100,
                  child: AnimatedBuilder(
                    animation: _animationController,
                    builder: (context, child) {
                      return CustomPaint(
                        painter: WaveformPainter(
                          animation: _animationController.value,
                          isListening: _isListening,
                        ),
                        size: const Size(double.infinity, 100),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 30),
                // Microphone button container
                Container(
                  width: double.infinity,
                  height: 300,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: Colors.pink[200]!, width: 2),
                  ),
                  child: Center(
                    child: _isProcessing
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const CircularProgressIndicator(
                                color: Colors.pink,
                              ),
                              const SizedBox(height: 20),
                              Text(
                                'پروسیسنگ جاری ہے',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey[700],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          )
                        : GestureDetector(
                            onTap: () {
                              Logger.log('👆 BUTTON CLICKED!');
                              _toggleListening();
                            },
                            child: Container(
                              width: 140,
                              height: 140,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.pink[300]!,
                                  width: 3,
                                ),
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: _isListening
                                      ? [Colors.pink[300]!, Colors.pink[400]!]
                                      : [Colors.pink[200]!, Colors.pink[300]!],
                                ),
                                boxShadow: _isListening
                                    ? [
                                        BoxShadow(
                                          color: Colors.pink[200]!.withValues(
                                            alpha: 0.5,
                                          ),
                                          blurRadius: 20,
                                          spreadRadius: 5,
                                        ),
                                      ]
                                    : [],
                              ),
                              child: Icon(
                                _isListening ? Icons.stop : Icons.mic,
                                size: 70,
                                color: Colors.white,
                              ),
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 30),
                // "OR" divider in Urdu
                Row(
                  children: [
                    Expanded(
                      child: Divider(color: Colors.grey[400], thickness: 1),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Text(
                        'یا',
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Divider(color: Colors.grey[400], thickness: 1),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                // Text heading in Urdu
                Text(
                  'لکھ کر بتائیں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 28,
                    color: Colors.grey[800],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                // Source input field
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.pink[200]!, width: 2),
                  ),
                  child: TextField(
                    controller: _sourceController,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                    decoration: InputDecoration(
                      hintText: 'شروعاتی جگہ (Source)',
                      hintTextDirection: TextDirection.rtl,
                      hintStyle: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 16,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 16,
                      ),
                      suffixIcon: Icon(
                        Icons.location_on_outlined,
                        color: Colors.pink[300],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Destination input field
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.pink[200]!, width: 2),
                  ),
                  child: TextField(
                    controller: _destinationController,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                    decoration: InputDecoration(
                      hintText: 'منزل (Destination)',
                      hintTextDirection: TextDirection.rtl,
                      hintStyle: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 16,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 16,
                      ),
                      suffixIcon: Icon(
                        Icons.flag_outlined,
                        color: Colors.pink[300],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 40),
                // Publish Ride Button
                SizedBox(
                  width: double.infinity,
                  height: 60,
                  child: ElevatedButton(
                    onPressed: (_isPublishing || _isProcessing)
                        ? null
                        : _publishRide,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFCF4374),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 4,
                    ),
                    child: (_isPublishing || _isProcessing)
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text(
                            'سواری شائع کریں',
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class WaveformPainter extends CustomPainter {
  final double animation;
  final bool isListening;

  WaveformPainter({required this.animation, required this.isListening});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..strokeCap = StrokeCap.round;

    const barCount = 50;
    final barWidth = size.width / (barCount * 2);
    final centerY = size.height / 2;

    for (int i = 0; i < barCount; i++) {
      final x = i * barWidth * 2 + barWidth;

      final waveOffset = math.sin(
        (i / barCount * math.pi * 2) + (animation * math.pi * 2),
      );

      double barHeight;
      if (isListening) {
        barHeight = (20 + (waveOffset.abs() * 60)).clamp(10.0, 80.0);
      } else {
        barHeight = 10 + (waveOffset.abs() * 5);
      }

      final gradientColors = [
        Colors.pink[200]!,
        Colors.pink[300]!,
        Colors.pink[400]!,
      ];

      final colorIndex = (i / barCount * 2).clamp(0.0, 1.0);
      paint.color = Color.lerp(
        gradientColors[0],
        gradientColors[2],
        colorIndex,
      )!.withValues(alpha: 0.6 + (waveOffset.abs() * 0.4));

      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(x, centerY),
            width: barWidth,
            height: barHeight,
          ),
          Radius.circular(barWidth / 2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(WaveformPainter oldDelegate) {
    return oldDelegate.animation != animation ||
        oldDelegate.isListening != isListening;
  }
}
