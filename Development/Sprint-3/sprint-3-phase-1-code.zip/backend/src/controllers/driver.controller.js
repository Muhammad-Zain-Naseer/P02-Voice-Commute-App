import Payment from "../models/Payment.js";
import logger from "../utils/logger.js";
import Driver from "../models/Driver.js";
import User from "../models/User.js";

/**
 * Get driver's statistics for today
 * GET /api/driver/stats/today
 */
export const getTodayStats = async (req, res) => {
  try {
    const driverId = req.user.id; // From auth middleware

    // Calculate the start of the current day
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const stats = await Payment.aggregate([
      {
        $match: {
          driverId,
          status: "verified",
          createdAt: { $gte: startOfDay }
        }
      },
      {
        $group: {
          _id: null,
          totalEarnings: { $sum: "$driverEarnings" },
          totalTrips: { $sum: 1 }
        }
      }
    ]);

    // If no rides found, return 0
    const result = stats[0] || { totalEarnings: 0, totalTrips: 0 };

    res.status(200).json({
      success: true,
      data: {
        earnings: result.totalEarnings,
        trips: result.totalTrips
      }
    });
  } catch (error) {
    logger.error("Error fetching driver stats:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch driver statistics"
    });
  }
};

/**
 * Get complete driver profile information
 * GET /api/driver/profile
 */
export const getDriverProfile = async (req, res) => {
  try {
    const userId = req.user.userId; // from auth middleware (JWT token)

    logger.info(`Fetching profile for userId: ${userId}`);

    // fetch driver data
    const driver = await Driver.findOne({ userId }).lean();
    
    if (!driver) {
      return res.status(404).json({
        success: false,
        message: "Driver profile not found"
      });
    }

    // fetch user data for ratings
    const user = await User.findOne({ userId }).lean();

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User account not found"
      });
    }

    // combine driver and user data
    const profileData = {
      userId: driver.userId,
      name: driver.name,
      email: driver.email,
      phone: driver.phone || null,
      cnic: driver.cnic,
      drivingLicense: driver.drivingLicense,
      isVerified: driver.isVerified,
      status: driver.status,
      vehicle: driver.vehicle || null,
      averageRating: user.averageRating || 0,
      totalRides: driver.totalRides || 0,
      ratings: user.ratings || [],
      paymentAccounts: driver.paymentAccounts || {
        easyPaisa: {
          accountNumber: "",
          accountTitle: "",
          isVerified: false
        },
        jazzCash: {
          accountNumber: "",
          accountTitle: "",
          isVerified: false
        }
      },
      createdAt: driver.createdAt,
      approvalDate: driver.approvalDate || null,
      rejectionReason: driver.rejectionReason || null,
      resubmissionNotes: driver.resubmissionNotes || null,
      suspensionReason: driver.suspensionReason || null,
      lastLogin: driver.lastLogin || null
    };

    logger.info(`Profile fetched successfully for driver: ${driver.name}`);

    res.status(200).json({
      success: true,
      data: profileData
    });

  } catch (error) {
    logger.error("Error fetching driver profile:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch driver profile",
      error: error.message
    });
  }
};