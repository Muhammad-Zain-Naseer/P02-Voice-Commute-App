/// Application Configuration
/// Centralized constants for API endpoints, socket URLs, and app settings
library;

import 'package:flutter_dotenv/flutter_dotenv.dart';

class AppConfig {
  // ========================================
  // ENVIRONMENT CONFIGURATION
  // ========================================
  // Environment value is read from .env file
  // 0 = Local Browser (http://localhost:3000)
  // 1 = Local Phone/USB (http://YOUR_COMPUTER_IP:3000)
  // 2 = Production (https://fyp-backend-3oxm.onrender.com)
  static int get environment => int.parse(dotenv.env['ENVIRONMENT'] ?? '0');

  // API Configuration
  static const String _localBrowserUrl = 'http://localhost:3000';
  static String get _localPhoneUrl =>
      dotenv.env['LOCAL_PHONE_URL'] ?? 'http://localhost:3000';
  static const String _productionApiUrl =
      'https://fyp-backend-3oxm.onrender.com';

  static String get apiBaseUrl {
    switch (environment) {
      case 0:
        return _localBrowserUrl;
      case 1:
        return _localPhoneUrl;
      case 2:
        return _productionApiUrl;
      default:
        return _localBrowserUrl;
    }
  }

  static String get socketUrl => apiBaseUrl;

  // Socket options
  static const Duration socketReconnectionDelay = Duration(seconds: 2);
  static const int socketReconnectionAttempts = 5;
  static const Duration socketTimeout = Duration(seconds: 10);

  // App Settings
  static const String appName = 'HerSafar';
  static const String appVersion = '1.0.0';

  // Location Settings
  static const Duration locationCacheDuration = Duration(minutes: 2);

  // Audio Recording Settings
  static const int audioSampleRate = 16000;
  static const Duration audioMaxDuration = Duration(minutes: 1);
}
