import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/ride_request.dart';
import 'storage_service.dart';
import '../utils/logger.dart';
import '../constants/app_config.dart';

class DriverService {
  static String get _baseUrl => AppConfig.apiBaseUrl;

  /// fetch the completed ride history and stats for the logged-in driver
  Future<Map<String, dynamic>> getEarningsHistory() async {
    final driverId = await StorageService.getUserId();
    final token = await StorageService.getToken();

    if (driverId == null || driverId.isEmpty) {
      Logger.error('Driver ID not found, cannot fetch earnings.');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }

    final url = Uri.parse('$_baseUrl/api/rides/driver/$driverId/earnings');

    try {
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        final List<dynamic> rideData =
            (data['rides'] as List?) ?? <dynamic>[];

        final total = (data['totalEarningsThisMonth'] as num?)?.toDouble() ??
            (data['totalThisMonth'] as num?)?.toDouble() ??
            (data['total'] as num?)?.toDouble() ??
            0.0;

        final rides = rideData
            .map((json) => RideRequest.fromJson(json))
            .toList();

        Logger.log(
          'Fetched ${rides.length} completed rides. Total this month: $total',
        );

        return {'rides': rides, 'totalThisMonth': total};
      } else {
        Logger.error('Failed to load earnings: ${response.body}');
        return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
      }
    } catch (e) {
      Logger.error('Error calling getEarningsHistory API: $e');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }
  }

  /// fetch today's earnings and ride count
  static Future<Map<String, dynamic>> getTodayStats() async {
    final url = Uri.parse('$_baseUrl/api/driver/stats/today');
    final token = await StorageService.getToken();

    if (token == null) {
      Logger.error(' Cannot fetch stats: No auth token found');
      return {'earnings': 0, 'trips': 0};
    }

    try {
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        Logger.log(' Fetched driver stats: $data');
        return {
          'earnings': data['earnings'] ?? data['totalEarnings'] ?? 0,
          'trips': data['trips'] ?? data['totalTrips'] ?? data['rides']?.length ?? 0,
        };
      } else {
        Logger.error(' Failed to fetch stats: ${response.body}');
        return {'earnings': 0, 'trips': 0};
      }
    } catch (e) {
      Logger.error(' Error fetching stats: $e');
      return {'earnings': 0, 'trips': 0};
    }
  }

  /// fetch complete driver profile information
  static Future<Map<String, dynamic>> getDriverProfile() async {
    final driverId = await StorageService.getUserId();
    final token = await StorageService.getToken();

    if (driverId == null || driverId.isEmpty) {
      Logger.error('Driver ID not found, cannot fetch profile.');
      throw Exception('Driver ID not available');
    }

    if (token == null || token.isEmpty) {
      Logger.error('Auth token not found, cannot fetch profile.');
      throw Exception('Authentication token not available');
    }

    final url = Uri.parse('$_baseUrl/api/driver/profile');

    try {
      Logger.log('Fetching driver profile for: $driverId');
      
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        
        Logger.log('✅ Driver profile fetched successfully');
        
        return {
          'userId': data['userId'],
          'name': data['name'],
          'email': data['email'],
          'phone': data['phone'],
          'cnic': data['cnic'],
          'drivingLicense': data['drivingLicense'],
          'isVerified': data['isVerified'] ?? false,
          'status': data['status'] ?? 'pending',
          'vehicle': data['vehicle'],
          'averageRating': (data['averageRating'] as num?)?.toDouble() ?? 0.0,
          'totalRides': data['totalRides'] ?? 0,
          'ratings': data['ratings'] ?? [],
          'paymentAccounts': data['paymentAccounts'] ?? {
            'easyPaisa': {'accountNumber': '', 'accountTitle': '', 'isVerified': false},
            'jazzCash': {'accountNumber': '', 'accountTitle': '', 'isVerified': false},
          },
          'createdAt': data['createdAt'],
          'approvalDate': data['approvalDate'],
          'rejectionReason': data['rejectionReason'],
          'resubmissionNotes': data['resubmissionNotes'],
          'suspensionReason': data['suspensionReason'],
        };
      } else {
        Logger.error('❌ Failed to fetch driver profile: ${response.statusCode} - ${response.body}');
        throw Exception('Failed to load driver profile: ${response.body}');
      }
    } catch (e) {
      Logger.error('Error fetching driver profile: $e');
      rethrow;
    }
  }

}