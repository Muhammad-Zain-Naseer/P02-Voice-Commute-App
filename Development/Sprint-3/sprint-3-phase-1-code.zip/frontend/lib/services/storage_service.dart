import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _userIdKey = 'userId';
  static const String _userNameKey = 'userName';
  static const String _userEmailKey = 'userEmail';
  static const String _userRoleKey = 'userRole';
  static const String _tokenKey = 'token';
  static const String _lastViewedAlertKey = 'lastViewedAlertTime';

  /// Saves user data to local storage after a successful login
  static Future<void> saveUserData(Map<String, dynamic> userData) async {
    final prefs = await SharedPreferences.getInstance();

    final user = userData['user'];

    // Save each piece of data
    await prefs.setString(_userIdKey, user['id'] ?? '');
    await prefs.setString(_userNameKey, user['name'] ?? '');
    await prefs.setString(_userEmailKey, user['email'] ?? '');
    await prefs.setString(_userRoleKey, user['role'] ?? '');

    if (userData.containsKey('token')) {
      await prefs.setString(_tokenKey, userData['token']);
    }
  }

  /// Gets the stored user ID
  static Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userIdKey);
  }

  /// Gets the stored user name
  static Future<String?> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userNameKey);
  }

  /// Gets the stored user email
  static Future<String?> getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userEmailKey);
  }

  /// Gets the stored user role
  static Future<String?> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userRoleKey);
  }

  // Save the current time when user opens the alerts page
  static Future<void> markAlertsAsViewed() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastViewedAlertKey, DateTime.now().toIso8601String());
  }

  // Get the last time the user checked alerts
  static Future<DateTime?> getLastViewedAlertTime() async {
    final prefs = await SharedPreferences.getInstance();
    final timeStr = prefs.getString(_lastViewedAlertKey);
    if (timeStr == null) return null;
    return DateTime.tryParse(timeStr);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  /// Clears all stored data on logout
  static Future<void> clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
