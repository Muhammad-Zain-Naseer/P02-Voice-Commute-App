import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'screens/welcome_screen.dart';
import 'screens/home_screen.dart';
import 'screens/admin/admin_home_screen.dart';
import 'screens/driver/driver_dashboard.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  runApp(const HerSafarApp());
}

class HerSafarApp extends StatelessWidget {
  const HerSafarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HerSafar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
        fontFamily: 'Urdu',
      ),
      home: const _AuthCheck(),
    );
  }
}

class _AuthCheck extends StatefulWidget {
  const _AuthCheck();

  @override
  State<_AuthCheck> createState() => _AuthCheckState();
}

class _AuthCheckState extends State<_AuthCheck> {
  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    final token = await StorageService.getToken();

    if (!mounted) return;

    if (token == null || token.isEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      );
      return;
    }

    final role = await StorageService.getUserRole() ?? 'commuter';
    final userName = await StorageService.getUserName() ?? 'User';
    final userEmail = await StorageService.getUserEmail() ?? '';
    final userId = await StorageService.getUserId() ?? '';

    if (!mounted) return;

    Widget destination;
    if (role == 'driver') {
      destination = const DriverDashboard();
    } else if (role == 'admin') {
      destination = AdminHomeScreen(
        userName: userName,
        userEmail: userEmail,
        token: token,
      );
    } else {
      destination = HomeScreen(
        userName: userName,
        userEmail: userEmail,
        userId: userId,
      );
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => destination),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      ),
    );
  }
}