import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../constants/app_config.dart';
import '../models/ride_request.dart';
import '../utils/logger.dart';
import 'encryption_service.dart';

class SocketService {
  static IO.Socket? _socket;
  static bool _isConnected = false;
  static String? _userId;
  static String? _userName;
  static String? _userEmail;
  static String? _userType;

  // store callbacks and email for re-registration after reconnection
  static Function(Map<String, dynamic>)? _tripNotificationCallback;
  static Function(Map<String, dynamic>)? _trustedContactRegisteredCallback;
  static String? _registeredEmail;

  static bool get isConnected => _isConnected;

  static IO.Socket? get socket => _socket;

  static void registerAsTrustedContact(String email) {
    if (_socket == null || !_socket!.connected) {
      Logger.error('❌ Cannot register trusted contact - socket not connected');
      Logger.error('   Socket exists: ${_socket != null}');
      Logger.error('   Socket connected: ${_socket?.connected}');
      return;
    }

    _registeredEmail = email;
    Logger.log('Registering as trusted contact: $email');
    Logger.log('   Socket ID: ${_socket!.id}');
    _socket!.emit('trustedContact:register', {'email': email});
    Logger.log('✅ Registration event emitted');
  }

  /// Listen for trip notifications with enhanced logging
  static void onTripNotification(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Socket not initialized for trip notifications');
      return;
    }

    // Store callback for reconnection
    _tripNotificationCallback = callback;

    Logger.log('Setting up trip:notification listener');
    Logger.log('   Socket ID: ${_socket!.id}');
    Logger.log('   Socket connected: ${_socket!.connected}');

    // Remove existing listener if any to avoid duplicates
    _socket!.off('trip:notification');

    _socket!.on('trip:notification', (data) {
      Logger.log('RAW SOCKET EVENT RECEIVED: trip:notification');
      Logger.log('Data type: ${data.runtimeType}');
      Logger.log('Raw data: $data');

      try {
        final responseData = data is List ? data[0] : data;
        final notificationData = responseData as Map<String, dynamic>;
        Logger.log('Parsed notification type: ${notificationData['type']}');
        callback(notificationData);
      } catch (e, stackTrace) {
        Logger.error('❌ Error processing trip notification: $e');
        Logger.error('Stack: $stackTrace');
        Logger.error('Raw data: $data');
      }
    });
    Logger.log('✅ Trip notification listener registered successfully');
  }

  /// Listen for trusted contact registration confirmation
  static void onTrustedContactRegistered(
    Function(Map<String, dynamic>) callback,
  ) {
    if (_socket == null) {
      Logger.error('❌ Socket not initialized');
      return;
    }

    // Store callback for reconnection
    _trustedContactRegisteredCallback = callback;

    // Remove existing listener
    _socket!.off('trustedContact:registered');

    _socket!.on('trustedContact:registered', (data) {
      Logger.log('✅ Trusted contact registration confirmed');
      Logger.log('   Data: $data');

      try {
        final responseData = data is List ? data[0] : data;
        final registrationData = responseData as Map<String, dynamic>;
        callback(registrationData);
      } catch (e) {
        Logger.error('❌ Error processing registration data: $e');
      }
    });
  }

  /// Connect to Socket.IO server
  static Future<void> connect({
    required String userId,
    String? userName,
    String? userEmail,
    required String userType, // 'driver' or 'commuter'
  }) async {
    if (_isConnected && _socket != null) {
      Logger.log('⚠️ Socket already connected: ${_socket!.id}');
      return;
    }

    _userId = userId;
    _userName = userName ?? 'Anonymous User';
    _userEmail = userEmail;
    _userType = userType;

    try {
      Logger.log('Creating socket connection...');
      Logger.log('   URL: ${AppConfig.socketUrl}');
      Logger.log('   User: $_userName');
      Logger.log('   Email: $_userEmail');
      Logger.log('   Type: $_userType');

      _socket = IO.io(
        AppConfig.socketUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .enableAutoConnect()
            .enableReconnection()
            .setReconnectionDelay(
              AppConfig.socketReconnectionDelay.inMilliseconds,
            )
            .setReconnectionAttempts(AppConfig.socketReconnectionAttempts)
            .setTimeout(AppConfig.socketTimeout.inMilliseconds)
            .build(),
      );

      // Connection event handlers
      _socket!.onConnect((_) {
        _isConnected = true;
        Logger.log('✅ Socket connected: ${_socket!.id}');

        // Register user with server - MUST include userType
        _socket!.emit('user:register', {
          'userId': _userId,
          'userName': _userName,
          'userEmail': _userEmail,
          'userType': _userType, // REQUIRED: 'driver' or 'commuter'
        });

        // Re-register as trusted contact if previously registered
        if (_registeredEmail != null) {
          Logger.log('🔄 Re-registering trusted contact after reconnection');
          Future.delayed(const Duration(milliseconds: 500), () {
            registerAsTrustedContact(_registeredEmail!);

            // Re-setup notification listeners
            if (_tripNotificationCallback != null) {
              onTripNotification(_tripNotificationCallback!);
            }
            if (_trustedContactRegisteredCallback != null) {
              onTrustedContactRegistered(_trustedContactRegisteredCallback!);
            }
          });
        }
      });

      _socket!.onDisconnect((_) {
        _isConnected = false;
        Logger.log('❌ Socket disconnected');
      });

      _socket!.onConnectError((error) {
        _isConnected = false;
        Logger.error('🔴 Socket connection error: $error');
      });

      _socket!.onError((error) {
        Logger.error('🔴 Socket error: $error');
      });

      _socket!.on('user:registered', (data) {
        Logger.log('✅ User registered on server: $data');
      });

      _socket!.on('error', (data) {
        Logger.error('🔴 Server error: $data');
      });

      _socket!.connect();
      Logger.log('Socket connection initiated');
    } catch (e) {
      Logger.error('💥 Failed to connect socket: $e');
      _isConnected = false;
    }
  }

  /// Disconnect from Socket.IO server
  static void disconnect() {
    if (_socket != null) {
      Logger.log('🔌 Disconnecting socket...');
      _socket!.disconnect();
      _socket!.dispose();
      _socket = null;
      _isConnected = false;
      _registeredEmail = null;
      _tripNotificationCallback = null;
      _trustedContactRegisteredCallback = null;
    }
  }

  /// Emit a ride request to the server
  static void emitRideRequest({
    required String source,
    required String destination,
    Map<String, double>? sourceCoordinates,
    Map<String, double>? destinationCoordinates,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot emit ride request: Socket not connected');
      return;
    }

    final rideData = {
      'userId': _userId,
      'userName': _userName,
      'userEmail': _userEmail,
      'source': source,
      'destination': destination,
      'sourceCoordinates': sourceCoordinates,
      'destinationCoordinates': destinationCoordinates,
    };

    Logger.log('📤 Emitting ride request: $rideData');
    _socket!.emit('ride:create', rideData);
  }

  /// Listen for ride created confirmation
  static void onRideCreated(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:created: Socket not initialized');
      return;
    }

    _socket!.on('ride:created', (data) {
      Logger.log('✅ Ride created: $data');
      try {
        final responseData = data is List ? data[0] : data;
        callback(responseData as Map<String, dynamic>);
      } catch (e) {
        Logger.error('💥 Error parsing ride created: $e');
      }
    });
  }

  /// Listen for ride matched event
  static void onRideMatched(Function(RideRequest, String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:matched: Socket not initialized');
      return;
    }

    _socket!.on('ride:matched', (data) {
      Logger.log('🎉 Ride matched: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final role = responseData['role'] as String;
        final ride = RideRequest.fromJson(rideData);

        if (responseData.containsKey('sessionKey')) {
          final sessionKey = responseData['sessionKey'] as String;
          EncryptionService.setSessionKey(sessionKey);
          Logger.log('🔐 Session key received and stored for ride: ${ride.id}');
        }

        callback(ride, role);
      } catch (e) {
        Logger.error('💥 Error parsing matched ride: $e');
      }
    });
  }

  /// Listen for new rides (for drivers)
  static void onNewRide(Function(RideRequest) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:new: Socket not initialized');
      return;
    }

    _socket!.on('ride:new', (data) {
      Logger.log('🆕 New ride available: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);
        callback(ride);
      } catch (e) {
        Logger.error('💥 Error parsing new ride: $e');
      }
    });
  }

  /// Listen for ride list updates
  static void onRideListUpdated(Function(List<RideRequest>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:list:updated: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:list:updated', (data) {
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        Logger.log('🔄 Ride list updated: ${responseData['count']} rides');
        final ridesData = responseData['rides'] as List;
        final rides = ridesData
            .map((r) => RideRequest.fromJson(r as Map<String, dynamic>))
            .toList();
        callback(rides);
      } catch (e) {
        Logger.error('💥 Error parsing ride list: $e');
      }
    });
  }

  /// Listen for ride errors
  static void onRideError(Function(String) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:error: Socket not initialized');
      return;
    }

    _socket!.on('ride:error', (data) {
      Logger.error('🔴 Ride error: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final message =
            responseData['message'] as String? ?? 'Unknown error occurred';
        callback(message);
      } catch (e) {
        callback('Unknown error occurred');
      }
    });
  }

  /// Request list of pending rides (for drivers)
  static void requestRideList() {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot request ride list: Socket not connected');
      return;
    }

    Logger.log('📤 Requesting ride list...');
    _socket!.emit('ride:list', {});
  }

  /// Listen for ride list response
  static void onRideList(Function(List<RideRequest>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for ride:list: Socket not initialized');
      return;
    }

    _socket!.on('ride:list', (data) {
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        Logger.log('📥 Received ride list: ${responseData['count']} rides');
        final ridesData = responseData['rides'] as List;
        final rides = ridesData
            .map((r) => RideRequest.fromJson(r as Map<String, dynamic>))
            .toList();
        callback(rides);
      } catch (e) {
        Logger.error('💥 Error parsing ride list: $e');
      }
    });
  }

  /// Cancel a ride request with optional reason
  static void cancelRide(
    String rideId, {
    String? reasonCode,
    String? reasonText,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot cancel ride: Socket not connected');
      return;
    }

    Logger.log('📤 Cancelling ride: $rideId, reason: $reasonCode');
    final payload = <String, dynamic>{'rideId': rideId};
    if (reasonCode != null) payload['reasonCode'] = reasonCode;
    if (reasonText != null && reasonText.isNotEmpty) {
      payload['reasonText'] = reasonText;
    }
    _socket!.emit('ride:cancel', payload);
  }

  /// Listen for ride cancelled event
  static void onRideCancelled(Function(String) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:cancelled: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:cancelled', (data) {
      Logger.log('🚫 Ride cancelled: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;

        EncryptionService.clearSessionKey();

        callback(rideId);
      } catch (e) {
        Logger.error('💥 Error parsing cancelled ride: $e');
      }
    });
  }

  /// Listen for ride unavailable event
  static void onRideUnavailable(Function(String) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:unavailable: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:unavailable', (data) {
      Logger.log('⚠️ Ride unavailable: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;

        if (_userType == 'driver') {
          Logger.log('⚠️ [DRIVER] Ride $rideId is no longer available');
          callback(rideId);
        } else {
          Logger.log(
            'ℹ️ [COMMUTER] Ignoring ride:unavailable for own matched ride',
          );
        }
      } catch (e) {
        Logger.error('💥 Error parsing unavailable ride: $e');
      }
    });
  }

  /// Match with a ride (for drivers)
  static void matchRide({
    required String rideId,
    required String driverId,
    String? driverName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot match ride: Socket not connected');
      return;
    }

    final matchData = {
      'rideId': rideId,
      'driverId': driverId,
      'driverName': driverName ?? 'Driver',
    };

    Logger.log('📤 Matching ride: $matchData');
    _socket!.emit('ride:match', matchData);
  }

  /// Complete a ride (for drivers)
  static void completeRide(String rideId, {double? distanceKm}) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot complete ride: Socket not connected');
      return;
    }

    final payload = {'rideId': rideId, 'distanceKm': distanceKm ?? 0};

    Logger.log('📤 Emitting ride:complete event');
    _socket!.emit('ride:complete', payload);
  }

  /// Listen for ride completed event
  static void onRideCompleted(Function(RideRequest) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:completed: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:completed', (data) {
      Logger.log('✅ Ride completed: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);

        EncryptionService.clearSessionKey();

        callback(ride);
      } catch (e) {
        Logger.error('💥 Error parsing completed ride: $e');
      }
    });
  }

  /// Trigger SOS alert (for commuters)
  static void triggerSOS({
    required String rideId,
    Map<String, double>? location,
    String? message,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot trigger SOS: Socket not connected');
      return;
    }

    final sosData = {
      'rideId': rideId,
      'location': location,
      'message': message ?? 'Emergency SOS triggered',
    };

    Logger.log('🚨 Triggering SOS: $sosData');
    _socket!.emit('ride:sos', sosData);
  }

  /// Listen for SOS triggered confirmation (for commuters)
  static void onSOSTriggered(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:sos:triggered: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:sos:triggered', (data) {
      Logger.log('🚨 SOS triggered confirmation: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing SOS triggered: $e');
      }
    });
  }

  /// Listen for SOS alert (for drivers)
  static void onSOSAlert(Function(RideRequest, Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:sos:alert: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:sos:alert', (data) {
      Logger.log('🚨 SOS ALERT received: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideData = responseData['ride'] as Map<String, dynamic>;
        final sosAlert = responseData['sosAlert'] as Map<String, dynamic>;
        final ride = RideRequest.fromJson(rideData);
        callback(ride, sosAlert);
      } catch (e) {
        Logger.error('💥 Error parsing SOS alert: $e');
      }
    });
  }

  /// Listen for payment request (for commuters)
  static void onPaymentRequest(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:payment:request: Socket not initialized',
      );
      return;
    }

    _socket!.off('ride:payment:request');

    _socket!.on('ride:payment:request', (data) {
      Logger.log('💳 Payment request received: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing payment request: $e');
      }
    });
  }

  /// Ensure socket connection is maintained (useful after ride matching)
  static void ensureConnection() {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Socket is not connected');
      return;
    }
    Logger.log('✅ Socket connection confirmed: ${_socket!.id}');
  }

  /// Check if payment listener is registered
  static bool hasPaymentListener() {
    if (_socket == null) return false;
    // Socket.IO doesn't provide a direct way to check listeners, so we log for debugging
    Logger.log('ℹ️ Checking socket connection for payment listener...');
    return _isConnected;
  }

  /// Remove only payment listener (useful when navigating away from active ride page)
  static void removePaymentListener() {
    if (_socket != null) {
      _socket!.off('ride:payment:request');
      Logger.log('🗑️ Removed payment listener');
    }
  }

  /// Remove all event listeners
  static void removeAllListeners() {
    if (_socket != null) {
      _socket!.off('ride:created');
      _socket!.off('ride:matched');
      _socket!.off('ride:new');
      _socket!.off('ride:list');
      _socket!.off('ride:list:updated');
      _socket!.off('ride:error');
      _socket!.off('ride:cancelled');
      _socket!.off('ride:unavailable');
      _socket!.off('ride:completed');
      _socket!.off('ride:sos:triggered');
      _socket!.off('ride:sos:alert');
      _socket!.off('ride:payment:request');
      _socket!.off('trustedContact:register');
      _socket!.off('trip:notification');
      _socket!.off('trustedContact:registered');
      Logger.log('🗑️ Removed all socket listeners');
    }
  }

  /// Emit driver reached event (for drivers)
  static void emitDriverReached(String rideId) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot emit driver reached: Socket not connected');
      return;
    }

    Logger.log('📤 Emitting driver:reached event for ride: $rideId');
    _socket!.emit('driver:reached', {'rideId': rideId});
  }

  /// Listen for driver reached event (for commuters)
  static void onDriverReached(Function(String) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for driver:reached: Socket not initialized',
      );
      return;
    }

    _socket!.on('driver:reached', (data) {
      Logger.log('🚗 Driver reached notification: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        callback(rideId);
      } catch (e) {
        Logger.error('💥 Error parsing driver reached: $e');
      }
    });
  }

  /// Emit driver location update (for drivers)
  static void emitDriverLocation({
    required String rideId,
    required double latitude,
    required double longitude,
    double? heading,
    double? speed,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot emit driver location: Socket not connected');
      return;
    }

    _socket!.emit('driver:location:update', {
      'rideId': rideId,
      'latitude': latitude,
      'longitude': longitude,
      'heading': heading,
      'speed': speed,
    });
  }

  /// Listen for driver location updates (for commuters)
  static void onDriverLocationUpdate(
    Function(String, double, double, double?, double?, String) callback,
  ) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for driver:location:updated: Socket not initialized',
      );
      return;
    }

    _socket!.on('driver:location:updated', (data) {
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        final latitude = (responseData['latitude'] as num).toDouble();
        final longitude = (responseData['longitude'] as num).toDouble();
        final heading = responseData['heading'] != null
            ? (responseData['heading'] as num).toDouble()
            : null;
        final speed = responseData['speed'] != null
            ? (responseData['speed'] as num).toDouble()
            : null;
        final timestamp = responseData['timestamp'] as String;
        callback(rideId, latitude, longitude, heading, speed, timestamp);
      } catch (e) {
        Logger.error('Error parsing driver location: $e');
      }
    });
  }

  /// Remove driver location update listener
  static void removeDriverLocationListener() {
    if (_socket != null) {
      _socket!.off('driver:location:updated');
      Logger.log('Removed driver location listener');
    }
  }

  /// Emit passenger location update (for passengers)
  static void emitPassengerLocation({
    required String rideId,
    required double latitude,
    required double longitude,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('Cannot emit passenger location: Socket not connected');
      return;
    }

    _socket!.emit('passenger:location:update', {
      'rideId': rideId,
      'latitude': latitude,
      'longitude': longitude,
    });
  }

  /// Listen for passenger location updates (for drivers)
  static void onPassengerLocationUpdate(
    Function(String, double, double, String) callback,
  ) {
    if (_socket == null) {
      Logger.error(
        'Cannot listen for passenger:location:updated: Socket not initialized',
      );
      return;
    }

    _socket!.on('passenger:location:updated', (data) {
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        final latitude = (responseData['latitude'] as num).toDouble();
        final longitude = (responseData['longitude'] as num).toDouble();
        final timestamp = responseData['timestamp'] as String;
        callback(rideId, latitude, longitude, timestamp);
      } catch (e) {
        Logger.error('Error parsing passenger location: $e');
      }
    });
  }

  /// Remove passenger location update listener
  static void removePassengerLocationListener() {
    if (_socket != null) {
      _socket!.off('passenger:location:updated');
      Logger.log('Removed passenger location listener');
    }
  }

  /// Listen for admin ride location updates
  static void onAdminRideLocationUpdate(
    Function(String, String, double, double, double?, double?, String) callback,
  ) {
    if (_socket == null) {
      Logger.error(
        'Cannot listen for admin:ride:location: Socket not initialized',
      );
      return;
    }

    _socket!.on('admin:ride:location', (data) {
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        final role = responseData['role'] as String;
        final latitude = (responseData['latitude'] as num).toDouble();
        final longitude = (responseData['longitude'] as num).toDouble();
        final heading = responseData['heading'] != null
            ? (responseData['heading'] as num).toDouble()
            : null;
        final speed = responseData['speed'] != null
            ? (responseData['speed'] as num).toDouble()
            : null;
        final timestamp = responseData['timestamp'] as String;
        callback(rideId, role, latitude, longitude, heading, speed, timestamp);
      } catch (e) {
        Logger.error('Error parsing admin ride location: $e');
      }
    });
  }

  /// Remove admin ride location listener
  static void removeAdminRideLocationListener() {
    if (_socket != null) {
      _socket!.off('admin:ride:location');
      Logger.log('Removed admin ride location listener');
    }
  }

  /// Listen for matched ride cancellation (for drivers)
  static void onMatchedRideCancelled(Function(String, String) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for ride:cancelled:matched: Socket not initialized',
      );
      return;
    }

    _socket!.on('ride:cancelled:matched', (data) {
      Logger.log('Matched ride cancelled: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        final rideId = responseData['rideId'] as String;
        final message = responseData['message'] as String? ?? 'Ride cancelled';
        callback(rideId, message);
      } catch (e) {
        Logger.error('Error parsing matched ride cancellation: $e');
      }
    });
  }

  /// Send a chat message
  static void sendChatMessage({
    required String rideId,
    required String message,
    required String senderId,
    required String senderName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot send chat message: Socket not connected');
      return;
    }

    final chatData = {
      'rideId': rideId,
      'message': message,
      'senderId': senderId,
      'senderName': senderName,
    };

    Logger.log('📤 Sending chat message: $chatData');
    _socket!.emit('chat:message', chatData);
  }

  /// Listen for incoming chat messages
  static void onChatMessage(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for chat:message: Socket not initialized');
      return;
    }

    _socket!.on('chat:message', (data) {
      Logger.log('💬 Chat message received: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('Error parsing chat message: $e');
      }
    });
  }

  /// Send a voice message
  static void sendVoiceMessage({
    required String rideId,
    required String audioData,
    required int duration,
    required String senderId,
    required String senderName,
  }) {
    if (_socket == null || !_isConnected) {
      Logger.error('❌ Cannot send voice message: Socket not connected');
      return;
    }

    final voiceData = {
      'rideId': rideId,
      'audioData': audioData,
      'duration': duration,
      'senderId': senderId,
      'senderName': senderName,
    };

    Logger.log(
      '📤 Sending voice message: ${voiceData['rideId']} - ${voiceData['duration']}s',
    );
    _socket!.emit('chat:voice', voiceData);
  }

  /// Listen for incoming voice messages
  static void onVoiceMessage(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error('❌ Cannot listen for chat:voice: Socket not initialized');
      return;
    }

    _socket!.on('chat:voice', (data) {
      Logger.log('Voice message received: $data');
      try {
        final responseData =
            (data is List ? data[0] : data) as Map<String, dynamic>;
        callback(responseData);
      } catch (e) {
        Logger.error('💥 Error parsing voice message: $e');
      }
    });
  }

  /// Listen for global safety alerts from Admin
  static void onSafetyAlert(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for admin:safety_alert: Socket not initialized',
      );
      return;
    }

    _socket!.on('admin:safety_alert', (data) {
      Logger.log('🚨 RECEIVED SAFETY ALERT: $data');
      try {
        final responseData = data is List ? data[0] : data;

        if (responseData != null && responseData is Map<String, dynamic>) {
          callback(responseData);
        } else {
          callback(Map<String, dynamic>.from(responseData));
        }
      } catch (e) {
        Logger.error('💥 Error parsing safety alert: $e');
      }
    });
  }

  /// Listen for policy updates from Admin
  static void onPolicyUpdate(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for admin:policy_update: Socket not initialized',
      );
      return;
    }

    _socket!.on('admin:policy_update', (data) {
      Logger.log('📋 RECEIVED POLICY UPDATE: $data');
      try {
        final responseData = data is List ? data[0] : data;

        if (responseData != null && responseData is Map<String, dynamic>) {
          callback(responseData);
        } else {
          callback(Map<String, dynamic>.from(responseData));
        }
      } catch (e) {
        Logger.error('💥 Error parsing policy update: $e');
      }
    });
  }

  /// Listen for fare price updates from Admin
  static void onFareUpdate(Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      Logger.error(
        '❌ Cannot listen for admin:fare_update: Socket not initialized',
      );
      return;
    }

    _socket!.on('admin:fare_update', (data) {
      Logger.log('💰 RECEIVED FARE UPDATE: $data');
      try {
        final responseData = data is List ? data[0] : data;

        if (responseData != null && responseData is Map<String, dynamic>) {
          callback(responseData);
        } else {
          callback(Map<String, dynamic>.from(responseData));
        }
      } catch (e) {
        Logger.error('💥 Error parsing fare update: $e');
      }
    });
  }
}
