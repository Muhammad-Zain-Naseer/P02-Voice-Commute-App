package com.example.hersafar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
