import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../services/storage_service.dart';
import '../services/socket_service.dart';
import '../screens/landing_page.dart';
import 'logger.dart';

final navigatorKey = GlobalKey<NavigatorState>();

class ApiClient {
  static Future<void> checkResponse(http.Response response) async {
    if (response.statusCode == 401) await _handleUnauthorized();
  }

  static Future<void> _handleUnauthorized() async {
    Logger.log('🔐 Token expired — logging out');
    await StorageService.clearUserData();
    SocketService.disconnect();
    navigatorKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LandingPage()),
      (_) => false,
    );
  }

  static Future<http.Response> get(Uri url,
      {Map<String, String>? headers}) async {
    final response = await http.get(url, headers: headers);
    if (response.statusCode == 401) await _handleUnauthorized();
    return response;
  }

  static Future<http.Response> post(Uri url,
      {Map<String, String>? headers, Object? body, Encoding? encoding}) async {
    final response = await http.post(url,
        headers: headers, body: body, encoding: encoding);
    if (response.statusCode == 401) await _handleUnauthorized();
    return response;
  }

  static Future<http.Response> put(Uri url,
      {Map<String, String>? headers, Object? body, Encoding? encoding}) async {
    final response = await http.put(url,
        headers: headers, body: body, encoding: encoding);
    if (response.statusCode == 401) await _handleUnauthorized();
    return response;
  }

  static Future<http.Response> patch(Uri url,
      {Map<String, String>? headers, Object? body, Encoding? encoding}) async {
    final response = await http.patch(url,
        headers: headers, body: body, encoding: encoding);
    if (response.statusCode == 401) await _handleUnauthorized();
    return response;
  }

  static Future<http.Response> delete(Uri url,
      {Map<String, String>? headers, Object? body, Encoding? encoding}) async {
    final response = await http.delete(url,
        headers: headers, body: body, encoding: encoding);
    if (response.statusCode == 401) await _handleUnauthorized();
    return response;
  }
}
