// Stub for native platforms — does nothing
void startWebSpeech({required Function(String) onResult, required Function() onError}) {}
void stopWebSpeech() {}
String? getWebTranscript() => '';