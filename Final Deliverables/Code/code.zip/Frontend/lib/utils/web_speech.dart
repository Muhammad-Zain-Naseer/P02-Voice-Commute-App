// ignore_for_file: avoid_web_libraries_in_flutter, deprecated_member_use
import 'dart:js' as js;

void startWebSpeech({required Function(String) onResult, required Function() onError}) {
  js.context.callMethod('eval', ['''
    window._hersafarDone = false;
    window._hersafarTranscript = '';
    var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      window._hersafarDone = true;
    } else {
      window._hersafarRecognition = new SpeechRecognition();
      window._hersafarRecognition.lang = 'ur-PK';
      window._hersafarRecognition.interimResults = false;
      window._hersafarRecognition.maxAlternatives = 1;
      window._hersafarRecognition.onresult = function(event) {
        window._hersafarTranscript = event.results[0][0].transcript;
        window._hersafarDone = true;
      };
      window._hersafarRecognition.onerror = function(e) {
        window._hersafarTranscript = '';
        window._hersafarDone = true;
      };
      window._hersafarRecognition.onend = function() {
        if (!window._hersafarDone) {
          window._hersafarTranscript = '';
          window._hersafarDone = true;
        }
      };
      window._hersafarRecognition.start();
    }
  ''']);
}

void stopWebSpeech() {
  try {
    js.context.callMethod('eval', ['''
      if (window._hersafarRecognition) {
        window._hersafarRecognition.stop();
      }
    ''']);
  } catch (_) {}
}

String? getWebTranscript() {
  try {
    final done = js.context['_hersafarDone'] as bool? ?? false;
    if (!done) return null; // not ready yet
    return js.context['_hersafarTranscript'] as String? ?? '';
  } catch (_) {
    return '';
  }
}