import 'package:flutter/foundation.dart';

/// Custom logger that prints to console
/// Note: debugPrint already shows in both Flutter console and browser DevTools
class Logger {
  // Set to false to disable all debug logs (keeps error logs)
  static const bool _enableDebugLogs = false;

  // Set to false to disable error logs as well
  static const bool _enableErrorLogs = true;

  static void log(String message) {
    if (_enableDebugLogs) {
      debugPrint(message);
    }
  }

  static void error(String message) {
    if (_enableErrorLogs) {
      debugPrint('ERROR: $message');
    }
  }
}
