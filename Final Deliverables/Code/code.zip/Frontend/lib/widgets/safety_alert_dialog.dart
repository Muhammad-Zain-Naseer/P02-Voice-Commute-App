import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';

class SafetyAlertDialog extends StatefulWidget {
  final String message;
  final String severity;
  final String sentAt;

  const SafetyAlertDialog({
    super.key,
    required this.message,
    required this.severity,
    required this.sentAt,
  });

  @override
  State<SafetyAlertDialog> createState() => _SafetyAlertDialogState();
}

class _SafetyAlertDialogState extends State<SafetyAlertDialog> {
  @override
  void initState() {
    super.initState();
    _speakAlert();
  }

  Future<void> _speakAlert() async {
    if (widget.message.trim().isEmpty) return;
    await AudioPlayerService.stop(); 
    final audioBytes = await VoiceService.textToSpeech(widget.message);
    if (audioBytes != null && mounted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
  }

  Color _getSeverityColor() {
    switch (widget.severity.toLowerCase()) {
      case 'critical':
      case 'high':
        return const Color(0xFFD32F2F);
      case 'medium':
        return const Color(0xFFF57C00);
      case 'low':
        return const Color(0xFF1976D2);
      default:
        return const Color(0xFFD32F2F);
    }
  }

  IconData _getSeverityIcon() {
    switch (widget.severity.toLowerCase()) {
      case 'critical':
      case 'high':
        return Icons.warning_rounded;
      case 'medium':
        return Icons.info_outline;
      case 'low':
        return Icons.notifications_active;
      default:
        return Icons.warning_amber_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = _getSeverityColor();

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 10,
      backgroundColor: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with Icon
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
              color: themeColor.withValues(alpha: 0.1),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Icon(_getSeverityIcon(), size: 50, color: themeColor),
          ),

          Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                // Title (Urdu)
                Text(
                  'حفاظتی انتباہ',
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: themeColor,
                  ),
                  textDirection: TextDirection.rtl,
                ),
                const SizedBox(height: 16),

                // Message Body
                Text(
                  widget.message,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 18,
                    color: Colors.black87,
                    height: 1.6,
                  ),
                  textDirection: TextDirection.rtl,
                ),
                const SizedBox(height: 24),

                // Time
                Text(
                  'وقت اشاعت: ${_formatDate(widget.sentAt)}',
                  style: GoogleFonts.notoNastaliqUrdu(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                  textDirection: TextDirection.rtl,
                ),
              ],
            ),
          ),

          // Dismiss Button
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () {
                  AudioPlayerService.stop(); 
                  Navigator.of(context).pop();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'ٹھیک ہے',
                  style: GoogleFonts.notoNastaliqUrdu(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr).toLocal();
      return "${date.hour}:${date.minute.toString().padLeft(2, '0')} - ${date.day}/${date.month}/${date.year}";
    } catch (e) {
      return dateStr;
    }
  }
}