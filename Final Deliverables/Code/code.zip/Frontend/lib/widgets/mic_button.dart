import 'package:flutter/material.dart';

/// Shared mic button widget used across all voice-input screens.
/// Displays a 3-layer pulsing circle with gradient, matching the
/// book-ride page design.
class MicButton extends StatelessWidget {
  final bool isListening;
  final bool isInterpreting;
  final Animation<double> pulseAnimation;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final VoidCallback? onLongPressUp;

  const MicButton({
    super.key,
    required this.isListening,
    required this.isInterpreting,
    required this.pulseAnimation,
    this.onTap,
    this.onLongPress,
    this.onLongPressUp,
  });

  List<Color> _gradientColors() {
    if (isListening) return [const Color(0xFFE91E8C), const Color(0xFF9C0055)];
    if (isInterpreting) return [const Color(0xFFCF4374), const Color(0xFF8B1A4A)];
    return [const Color(0xFFF06292), const Color(0xFFCF4374)];
  }

  Widget _buildInnerIcon() {
    if (isInterpreting) {
      return const Center(
        child: SizedBox(
          width: 32,
          height: 32,
          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
        ),
      );
    }
    final icon = isListening ? Icons.stop_rounded : Icons.mic_none_rounded;
    return Center(
      child: Icon(
        icon,
        color: Colors.white,
        size: 38,
        shadows: [
          Shadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      onLongPressUp: onLongPressUp,
      child: AnimatedBuilder(
        animation: pulseAnimation,
        builder: (context, child) {
          return Stack(
            alignment: Alignment.center,
            children: [
              if (isListening)
                Transform.scale(
                  scale: pulseAnimation.value,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.25),
                        width: 2,
                      ),
                    ),
                  ),
                ),
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (isListening || isInterpreting)
                      ? const Color(0xFFCF4374).withValues(alpha: 0.12)
                      : Colors.white.withValues(alpha: 0.35),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCF4374)
                          .withValues(alpha: isListening ? 0.4 : 0.15),
                      blurRadius: isListening ? 28 : 12,
                      spreadRadius: isListening ? 6 : 2,
                    ),
                  ],
                ),
              ),
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: _gradientColors(),
                    stops: const [0.0, 1.0],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCF4374).withValues(alpha: 0.5),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: _buildInnerIcon(),
              ),
            ],
          );
        },
      ),
    );
  }
}
