import 'package:flutter/material.dart';
import 'dart:math' as math;

class SoundWave extends StatefulWidget {
  final bool isAnimating;
  const SoundWave({super.key, this.isAnimating = false});

  @override
  State<SoundWave> createState() => _SoundWaveState();
}

class _SoundWaveState extends State<SoundWave>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    if (widget.isAnimating) _controller.repeat();
  }

  @override
  void didUpdateWidget(SoundWave oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isAnimating && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.isAnimating && _controller.isAnimating) {
      _controller.stop();
      _controller.reset();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          size: const Size(200, 60),
          painter: SoundWavePainter(
            animationValue: _controller.value,
            isAnimating: widget.isAnimating,
          ),
        );
      },
    );
  }
}

class SoundWavePainter extends CustomPainter {
  final double animationValue;
  final bool isAnimating;

  SoundWavePainter({required this.animationValue, required this.isAnimating});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFCF4374)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final centerY = size.height / 2;
    const barWidth = 4.0;
    const barSpacing = 8.0;
    const numBars = 15;

    for (int i = 0; i < numBars; i++) {
      final x = i * (barWidth + barSpacing) +
          (size.width - (numBars * (barWidth + barSpacing))) / 2;

      double barHeight;
      if (isAnimating) {
        final heightFactor = math.sin(
            (i / numBars * math.pi * 2) + (animationValue * math.pi * 2));
        barHeight = (size.height / 2) * (0.3 + (heightFactor.abs() * 0.7));
      } else {
        barHeight = 4.0;
      }

      canvas.drawLine(
        Offset(x + barWidth / 2, centerY - barHeight / 2),
        Offset(x + barWidth / 2, centerY + barHeight / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(SoundWavePainter oldDelegate) {
    return oldDelegate.animationValue != animationValue ||
        oldDelegate.isAnimating != isAnimating;
  }
}