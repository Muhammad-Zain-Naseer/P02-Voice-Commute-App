import 'package:flutter/foundation.dart';
import 'dart:convert';
import '../utils/api_client.dart';
import '../constants/app_config.dart';
import 'audio_player_service.dart';
import 'tts_cache_service.dart';

class VoiceService {
  static const String _contentType = 'Content-Type';
  static const String _applicationJson = 'application/json';
  static String get _baseUrl => '${AppConfig.apiBaseUrl}/api/voice';

  // ── Text to Speech — returns MP3 bytes (cached) ───────────────────────────
  static Future<Uint8List?> textToSpeech(String text,
      {String language = 'ur-PK'}) async {
    // Don't make network calls when app is backgrounded/locked.
    if (!AudioPlayerService.isAppActive) return null;

    final cached = await TtsCacheService.get(text);
    if (cached != null) {
      debugPrint('=== TTS cache hit: "${text.substring(0, text.length.clamp(0, 20))}"');
      return cached;
    }

    try {
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/tts'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'text': text, 'language': language}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final bytes = base64Decode(data['audioContent']);
          await TtsCacheService.put(text, bytes);
          return bytes;
        }
      }
      debugPrint('=== TTS failed: ${response.body}');
      return null;
    } catch (e) {
      debugPrint('=== TTS error: $e');
      return null;
    }
  }

  // ── Interpret speech intent — audio direct to Gemini ─────────────────────
  // Returns: 0 = new user, 1 = already registered, 2 = driver, -1 = no match
  static Future<int> interpretAudio(String audioBase64,
      {String mimeType = 'audio/mp4'}) async {
    try {
      debugPrint('=== Calling Gemini interpret (audio direct)');
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/interpret'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'audioBase64': audioBase64, 'mimeType': mimeType}),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final matched = data['matched'] as int? ?? -1;
          debugPrint('=== Gemini matched: $matched');
          return matched;
        }
      }
      debugPrint('=== Interpret API failed: ${response.body}');
    } catch (e) {
      debugPrint('=== Interpret error: $e');
    }
    return -1;
  }

  // ── Extract email from audio — audio direct to Gemini ────────────────────
  static Future<String?> extractEmailFromAudio(String audioBase64,
      {String mimeType = 'audio/mp4'}) async {
    try {
      debugPrint('=== Calling Gemini extract-email (audio direct)');
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/extract-email'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'audioBase64': audioBase64, 'mimeType': mimeType}),
      ).timeout(const Duration(seconds: 25));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return data['email'] as String?;
      }
      debugPrint('=== Extract email failed: ${response.body}');
    } catch (e) {
      debugPrint('=== Extract email error: $e');
    }
    return null;
  }

  // ── Extract name from audio — audio direct to Gemini ─────────────────────
  static Future<String?> extractNameFromAudio(String audioBase64,
      {String mimeType = 'audio/mp4'}) async {
    try {
      debugPrint('=== Calling Gemini extract-name (audio direct)');
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/extract-name'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'audioBase64': audioBase64, 'mimeType': mimeType}),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return data['name'] as String?;
      }
      debugPrint('=== Extract name failed: ${response.body}');
    } catch (e) {
      debugPrint('=== Extract name error: $e');
    }
    return null;
  }

  // ── Extract PIN from audio — audio direct to Gemini ──────────────────────
  static Future<String?> extractPinFromAudio(String audioBase64,
      {String mimeType = 'audio/mp4'}) async {
    try {
      debugPrint('=== Calling Gemini extract-pin (audio direct)');
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/extract-pin'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'audioBase64': audioBase64, 'mimeType': mimeType}),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return data['pin'] as String?;
      }
      debugPrint('=== Extract PIN failed: ${response.body}');
    } catch (e) {
      debugPrint('=== Extract PIN error: $e');
    }
    return null;
  }

  // ── Interpret active-ride voice command — SOS / Share / Cancel ───────────
  static Future<int> interpretRideAction(String audioBase64,
      {String mimeType = 'audio/wav'}) async {
    try {
      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/interpret-ride-action'),
        headers: {_contentType: _applicationJson},
        body: jsonEncode({'audioBase64': audioBase64, 'mimeType': mimeType}),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return data['matched'] as int? ?? -1;
      }
      debugPrint('=== Interpret ride action failed: ${response.body}');
    } catch (e) {
      debugPrint('=== Interpret ride action error: $e');
    }
    return -1;
  }
}
