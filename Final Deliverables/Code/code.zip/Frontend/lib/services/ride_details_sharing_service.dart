import 'dart:convert';
import '../utils/api_client.dart';
import '../constants/app_config.dart';


class RideSharingService {
  
  /// Get user's trusted contacts
  Future<Map<String, dynamic>> getTrustedContacts({
    required String userId,
  }) async {
    try {
      final response = await ApiClient.get(
        Uri.parse('${AppConfig.apiBaseUrl}/api/commuter/trusted-contacts/$userId'),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'contacts': responseData['trustedContacts'] ?? [],
        };
      } else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Failed to get contacts',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

  /// Share ride with selected contacts
  Future<Map<String, dynamic>> shareRideWithSelectedContacts({
    required String userId,
    required String rideId,
    required Map<String, dynamic> rideDetails,
    required List<String> contactEmails,
  }) async {
    try {
      final response = await ApiClient.post(
        Uri.parse('${AppConfig.apiBaseUrl}/api/rides/share-ride-details-selected'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'userId': userId,
          'rideId': rideId,
          'rideDetails': rideDetails,
          'contactEmails': contactEmails,
        }),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': responseData['message'],
        };
      } else {
        return {
          'success': false,
          'message': responseData['message'] ?? 'Failed to share ride',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Network error: $e',
      };
    }
  }

}