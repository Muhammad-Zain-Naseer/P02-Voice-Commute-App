/// Real-time Location Tracking Service
/// Sends periodic location updates for driver tracking
library;

import 'dart:async';
import 'package:geolocator/geolocator.dart';
import '../utils/logger.dart';
import 'socket_service.dart';

class LocationTrackingService {
  static Timer? _trackingTimer;
  static bool _isTracking = false;
  static String? _currentRideId;

  /// Start tracking driver location and send updates every 5 seconds
  static Future<void> startTracking({
    required String rideId,
    Duration interval = const Duration(seconds: 5),
  }) async {
    if (_isTracking) {
      Logger.log('⚠️ Location tracking already active');
      return;
    }

    Logger.log('📍 Starting location tracking for ride: $rideId');
    _isTracking = true;
    _currentRideId = rideId;

    // Send initial location immediately
    await _sendLocationUpdate();

    // Then send periodic updates
    _trackingTimer = Timer.periodic(interval, (timer) async {
      await _sendLocationUpdate();
    });
  }

  /// Stop tracking driver location
  static void stopTracking() {
    if (!_isTracking) {
      return;
    }

    Logger.log('🛑 Stopping location tracking');
    _trackingTimer?.cancel();
    _trackingTimer = null;
    _isTracking = false;
    _currentRideId = null;
  }

  /// Send current location update via socket
  static Future<void> _sendLocationUpdate() async {
    if (_currentRideId == null) {
      Logger.error('❌ Cannot send location: No active ride');
      return;
    }

    try {
      // Check if location services are enabled
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        Logger.error('❌ Location services are disabled');
        return;
      }

      // Check location permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          Logger.error('❌ Location permissions denied');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        Logger.error('❌ Location permissions permanently denied');
        return;
      }

      // Get current position with high accuracy
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 10, // Update only if moved 10 meters
        ),
      );

      // Send location update via socket
      SocketService.emitDriverLocation(
        rideId: _currentRideId!,
        latitude: position.latitude,
        longitude: position.longitude,
        heading: position.heading,
        speed: position.speed,
      );

      Logger.log(
        '📍 Location sent: (${position.latitude}, ${position.longitude})',
      );
    } catch (e) {
      Logger.error('💥 Error getting location: $e');
    }
  }

  /// Check if tracking is currently active
  static bool get isTracking => _isTracking;

  /// Get current ride ID being tracked
  static String? get currentRideId => _currentRideId;
}
