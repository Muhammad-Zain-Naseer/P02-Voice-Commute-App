import 'package:flutter/foundation.dart';
import 'dart:convert';
import '../utils/api_client.dart';
import '../constants/app_config.dart';

class RideService {
  static String get _baseUrl => AppConfig.apiBaseUrl;

  Future<bool> rateRide(String rideId, double rating) async {
    final url = Uri.parse('$_baseUrl/api/rides/$rideId/rate');

    try {
      final response = await ApiClient.post(
        url,
        headers: {'Content-Type': 'application/json; charset=UTF-8'},
        body: jsonEncode({'rating': rating}),
      );

      if (response.statusCode == 200) {
        debugPrint("Rating submitted successfully!");
        return true;
      } else {
        debugPrint("Failed to submit rating: ${response.body}");
        return false;
      }
    } catch (e) {
      debugPrint("Error calling rateRide API: $e");
      return false;
    }
  }
}
