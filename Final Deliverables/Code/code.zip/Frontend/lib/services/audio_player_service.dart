// ignore_for_file: experimental_member_use
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:just_audio/just_audio.dart';

class AudioPlayerService {
  static AudioPlayer _player = AudioPlayer();

  // Set to false when the app goes to background/locked so no audio plays.
  static bool _appActive = true;

  static void onAppPaused() {
    _appActive = false;
    stop();
  }

  static void onAppResumed() {
    _appActive = true;
  }

  static bool get isAppActive => _appActive;

  static Future<void> playBytes(Uint8List bytes) async {
    if (!_appActive) return;
    StreamSubscription? sub;
    try {
      // Stop any current playback. If the player is in a bad state (e.g. after
      // a hot restart that interrupted mid-playback), recreate it so the next
      // call gets a clean native-side instance.
      try {
        await _player.stop();
      } catch (_) {
        await _recreatePlayer();
      }

      final source = BytesAudioSource(bytes);
      // initialPosition: Duration.zero ensures we always start from the
      // beginning, even if the native player remembers a previous position.
      await _player.setAudioSource(source, initialPosition: Duration.zero);

      // Set up the completion listener BEFORE play() so we never miss a state
      // transition. The hasStartedPlaying gate prevents the initial idle state
      // (from stop() above) from resolving the completer prematurely.
      final completer = Completer<void>();
      bool hasStartedPlaying = false;
      sub = _player.playerStateStream.listen((state) {
        if (state.playing) hasStartedPlaying = true;
        if (hasStartedPlaying &&
            (state.processingState == ProcessingState.completed ||
             state.processingState == ProcessingState.idle)) {
          if (!completer.isCompleted) completer.complete();
        }
      });

      await _player.play();
      await completer.future.timeout(const Duration(seconds: 30));
    } catch (e) {
      debugPrint('=== Audio player error/timeout: $e');
      try {
        await _player.stop();
      } catch (_) {
        await _recreatePlayer();
      }
    } finally {
      await sub?.cancel();
    }
  }

  static Future<void> _recreatePlayer() async {
    try { _player.dispose(); } catch (_) {}
    _player = AudioPlayer();
  }

  static Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {
      await _recreatePlayer();
    }
  }

  static bool get isPlaying => _player.playing;
  static Stream<bool> get playingStream => _player.playingStream;

  static void dispose() {
    _player.dispose();
  }
}

class BytesAudioSource extends StreamAudioSource {
  final Uint8List _bytes;
  BytesAudioSource(this._bytes);

  @override
  Future<StreamAudioResponse> request([int? start, int? end]) async {
    start ??= 0;
    end ??= _bytes.length;
    return StreamAudioResponse(
      sourceLength: _bytes.length,
      contentLength: end - start,
      offset: start,
      stream: Stream.value(_bytes.sublist(start, end)),
      contentType: 'audio/mpeg',
    );
  }
}
