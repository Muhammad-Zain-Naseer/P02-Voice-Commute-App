import 'dart:convert';
import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as encrypt;
import '../utils/logger.dart';

/// Encryption Service for secure message transmission
/// Uses AES-256-GCM for symmetric encryption (matches backend)
class EncryptionService {
  static String? _sessionKey;

  /// Set the session key for the current ride
  static void setSessionKey(String key) {
    _sessionKey = key;
    Logger.log('🔐 Session key set for encryption');
  }

  /// Clear the session key (when ride ends)
  static void clearSessionKey() {
    _sessionKey = null;
    Logger.log('🔐 Session key cleared');
  }

  /// Check if session key is available
  static bool get hasSessionKey => _sessionKey != null;

  /// Encrypt a text message
  static Map<String, String>? encryptMessage(String plaintext) {
    if (_sessionKey == null) {
      Logger.log('⚠️ No session key available for encryption');
      return null;
    }

    try {
      final keyBytes = _hexToBytes(_sessionKey!);
      final key = encrypt.Key(keyBytes);
      final iv = encrypt.IV.fromSecureRandom(16);

      final encrypter = encrypt.Encrypter(
        encrypt.AES(key, mode: encrypt.AESMode.gcm),
      );

      final encrypted = encrypter.encrypt(plaintext, iv: iv);

      return {
        'encrypted': encrypted.base64,
        'iv': iv.base64,
        'authTag': '', // GCM tag is included in the encrypted data for this library
      };
    } catch (e) {
      Logger.error('❌ Encryption error: $e');
      return null;
    }
  }

  /// Decrypt a text message
  static String? decryptMessage(String encryptedBase64, String ivBase64, String? authTag) {
    if (_sessionKey == null) {
      Logger.log('⚠️ No session key available for decryption');
      return null;
    }

    try {
      final keyBytes = _hexToBytes(_sessionKey!);
      final key = encrypt.Key(keyBytes);
      final iv = encrypt.IV.fromBase64(ivBase64);

      final encrypter = encrypt.Encrypter(
        encrypt.AES(key, mode: encrypt.AESMode.gcm),
      );

      // For GCM mode with authTag, we need to handle it properly
      // The backend sends authTag separately, so we need to reconstruct
      if (authTag != null && authTag.isNotEmpty) {
        // Append authTag to encrypted data for GCM decryption
        final encryptedBytes = base64Decode(encryptedBase64);
        final authTagBytes = base64Decode(authTag);
        final combined = Uint8List(encryptedBytes.length + authTagBytes.length);
        combined.setRange(0, encryptedBytes.length, encryptedBytes);
        combined.setRange(encryptedBytes.length, combined.length, authTagBytes);

        final encrypted = encrypt.Encrypted(combined);
        final decrypted = encrypter.decrypt(encrypted, iv: iv);
        return decrypted;
      } else {
        // AuthTag already included in encrypted data
        final encrypted = encrypt.Encrypted.fromBase64(encryptedBase64);
        final decrypted = encrypter.decrypt(encrypted, iv: iv);
        return decrypted;
      }
    } catch (e) {
      Logger.error('❌ Decryption error: $e');
      return null;
    }
  }

  /// Encrypt binary data (for voice messages)
  static Map<String, String>? encryptBinary(String base64Data) {
    if (_sessionKey == null) {
      Logger.log('⚠️ No session key available for encryption');
      return null;
    }

    try {
      final keyBytes = _hexToBytes(_sessionKey!);
      final key = encrypt.Key(keyBytes);
      final iv = encrypt.IV.fromSecureRandom(16);

      final encrypter = encrypt.Encrypter(
        encrypt.AES(key, mode: encrypt.AESMode.gcm),
      );

      final dataBytes = base64Decode(base64Data);
      final encrypted = encrypter.encryptBytes(dataBytes, iv: iv);

      return {
        'encrypted': encrypted.base64,
        'iv': iv.base64,
        'authTag': '',
      };
    } catch (e) {
      Logger.error('❌ Binary encryption error: $e');
      return null;
    }
  }

  /// Decrypt binary data (for voice messages)
  static String? decryptBinary(String encryptedBase64, String ivBase64, String? authTag) {
    if (_sessionKey == null) {
      Logger.log('⚠️ No session key available for decryption');
      return null;
    }

    try {
      final keyBytes = _hexToBytes(_sessionKey!);
      final key = encrypt.Key(keyBytes);
      final iv = encrypt.IV.fromBase64(ivBase64);

      final encrypter = encrypt.Encrypter(
        encrypt.AES(key, mode: encrypt.AESMode.gcm),
      );

      Uint8List decryptedBytes;

      if (authTag != null && authTag.isNotEmpty) {
        // Append authTag to encrypted data for GCM decryption
        final encryptedBytes = base64Decode(encryptedBase64);
        final authTagBytes = base64Decode(authTag);
        final combined = Uint8List(encryptedBytes.length + authTagBytes.length);
        combined.setRange(0, encryptedBytes.length, encryptedBytes);
        combined.setRange(encryptedBytes.length, combined.length, authTagBytes);

        final encrypted = encrypt.Encrypted(combined);
        decryptedBytes = Uint8List.fromList(encrypter.decryptBytes(encrypted, iv: iv));
      } else {
        final encrypted = encrypt.Encrypted.fromBase64(encryptedBase64);
        decryptedBytes = Uint8List.fromList(encrypter.decryptBytes(encrypted, iv: iv));
      }

      return base64Encode(decryptedBytes);
    } catch (e) {
      Logger.error('❌ Binary decryption error: $e');
      return null;
    }
  }

  /// Convert hex string to bytes
  static Uint8List _hexToBytes(String hex) {
    final length = hex.length;
    final bytes = Uint8List(length ~/ 2);
    for (var i = 0; i < length; i += 2) {
      bytes[i ~/ 2] = int.parse(hex.substring(i, i + 2), radix: 16);
    }
    return bytes;
  }
}
