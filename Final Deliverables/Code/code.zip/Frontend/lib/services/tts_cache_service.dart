import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Persistent TTS audio cache.
/// - Mobile/Desktop: saves MP3 files to app documents directory
/// - Web: saves base64 strings to localStorage via shared_preferences
/// - Max cache size: 5MB (evicts oldest entries when exceeded)
class TtsCacheService {
  static const int _maxCacheSizeBytes = 5 * 1024 * 1024; // 5MB
  static const String _indexKey = 'tts_cache_index';
  static const String _cacheDir = 'tts_cache';

  static Map<String, Map<String, dynamic>> _index = {};
  static bool _initialized = false;

  // djb2 hash — no external package needed
  static String _hash(String text) {
    int hash = 5381;
    for (final c in utf8.encode(text)) {
      hash = ((hash << 5) + hash) + c;
      hash &= 0x7FFFFFFF;
    }
    return hash.toRadixString(16);
  }

  static Future<void> _init() async {
    if (_initialized) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_indexKey);
    if (raw != null) {
      _index = Map<String, Map<String, dynamic>>.from(
        (jsonDecode(raw) as Map).map(
          (k, v) => MapEntry(k, Map<String, dynamic>.from(v)),
        ),
      );
    }
    _initialized = true;
  }

  static Future<void> _saveIndex() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_indexKey, jsonEncode(_index));
  }

  static Future<Uint8List?> get(String text) async {
    await _init();
    final hash = _hash(text);
    final entry = _index[hash];
    if (entry == null) return null;

    if (kIsWeb) {
      final b64 = entry['data'] as String?;
      if (b64 == null) return null;
      return base64Decode(b64);
    } else {
      final path = entry['path'] as String?;
      if (path == null) return null;
      final file = File(path);
      if (!await file.exists()) {
        _index.remove(hash);
        await _saveIndex();
        return null;
      }
      return await file.readAsBytes();
    }
  }

  static Future<void> put(String text, Uint8List bytes) async {
    await _init();
    final hash = _hash(text);

    if (kIsWeb) {
      _index[hash] = {
        'data': base64Encode(bytes),
        'size': bytes.length,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
    } else {
      final dir = await getApplicationDocumentsDirectory();
      final cacheFolder = Directory('${dir.path}/$_cacheDir');
      if (!await cacheFolder.exists()) await cacheFolder.create();
      final file = File('${cacheFolder.path}/$hash.mp3');
      await file.writeAsBytes(bytes);
      _index[hash] = {
        'path': file.path,
        'size': bytes.length,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
    }

    await _saveIndex();
    await _evictIfNeeded();
  }

  static Future<void> _evictIfNeeded() async {
    int totalSize =
        _index.values.fold(0, (sum, e) => sum + (e['size'] as int));
    if (totalSize <= _maxCacheSizeBytes) return;

    final sorted = _index.entries.toList()
      ..sort((a, b) => (a.value['timestamp'] as int)
          .compareTo(b.value['timestamp'] as int));

    for (final entry in sorted) {
      if (totalSize <= _maxCacheSizeBytes) break;
      totalSize -= entry.value['size'] as int;
      if (!kIsWeb) {
        final path = entry.value['path'] as String?;
        if (path != null) {
          final file = File(path);
          if (await file.exists()) await file.delete();
        }
      }
      _index.remove(entry.key);
    }

    await _saveIndex();
  }
}
