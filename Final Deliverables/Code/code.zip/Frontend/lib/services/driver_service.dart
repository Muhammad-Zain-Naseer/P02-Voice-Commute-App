import 'dart:convert';
import '../utils/api_client.dart';
import '../models/ride_request.dart';
import 'storage_service.dart';
import '../utils/logger.dart';
import '../constants/app_config.dart';

class DriverService {
  static String get _baseUrl => AppConfig.apiBaseUrl;


  static Future<Map<String, String>> _authHeaders() async {
    final token = await StorageService.getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  // ─── EARNINGS ─────────────────────────────────────────────

  /// Fetch completed ride history and earnings stats for the logged-in driver
  Future<Map<String, dynamic>> getEarningsHistory() async {
    final driverId = await StorageService.getUserId();
    final token    = await StorageService.getToken();

    if (driverId == null || driverId.isEmpty) {
      Logger.error('Driver ID not found, cannot fetch earnings.');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }

    final url = Uri.parse('$_baseUrl/api/rides/driver/$driverId/earnings');

    try {
      final response = await ApiClient.get(
        url,
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        final List<dynamic> rideData = (data['rides'] as List?) ?? [];

        final total =
            (data['totalEarningsThisMonth'] as num?)?.toDouble() ??
            (data['totalThisMonth'] as num?)?.toDouble()         ??
            (data['total'] as num?)?.toDouble()                  ??
            0.0;

        final rides = rideData.map((json) => RideRequest.fromJson(json)).toList();
        Logger.log('Fetched ${rides.length} completed rides. Total this month: $total');
        return {'rides': rides, 'totalThisMonth': total};
      } else {
        Logger.error('Failed to load earnings: ${response.body}');
        return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
      }
    } catch (e) {
      Logger.error('Error calling getEarningsHistory API: $e');
      return {'rides': <RideRequest>[], 'totalThisMonth': 0.0};
    }
  }

  // ─── STATS ────────────────────────────────────────────────

  /// Fetch today's earnings and ride count
  static Future<Map<String, dynamic>> getTodayStats() async {
    try {
      final response = await ApiClient.get(
        Uri.parse('$_baseUrl/api/driver/stats/today'),
        headers: await _authHeaders(),
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        Logger.log('Fetched driver stats: $data');
        return {
          'earnings': data['earnings'] ?? data['totalEarnings'] ?? 0,
          'trips':    data['trips']    ?? data['totalTrips']    ?? data['rides']?.length ?? 0,
        };
      } else {
        Logger.error('Failed to fetch stats: ${response.body}');
        return {'earnings': 0, 'trips': 0};
      }
    } catch (e) {
      Logger.error('Error fetching stats: $e');
      return {'earnings': 0, 'trips': 0};
    }
  }

  // ─── PROFILE ──────────────────────────────────────────────

  /// Fetch complete driver profile
  static Future<Map<String, dynamic>> getDriverProfile() async {
    final driverId = await StorageService.getUserId();
    if (driverId == null || driverId.isEmpty) {
      throw Exception('Driver ID not available');
    }

    try {
      Logger.log('Fetching driver profile for: $driverId');

      final response = await ApiClient.get(
        Uri.parse('$_baseUrl/api/driver/profile'),
        headers: await _authHeaders(),
      );

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'] ?? body;
        Logger.log('Driver profile fetched successfully');

        return {
          'userId':            data['userId'],
          'name':              data['name'],
          'email':             data['email'],
          'phone':             data['phone'],
          'cnic':              data['cnic'],
          'drivingLicense':    data['drivingLicense'],
          'isVerified':        data['isVerified']  ?? false,
          'status':            data['status']      ?? 'pending',
          'vehicle':           data['vehicle'],
          'averageRating':     (data['averageRating'] as num?)?.toDouble() ?? 0.0,
          'totalRides':        data['totalRides']  ?? 0,
          'ratings':           data['ratings']     ?? [],
          'paymentAccounts':   data['paymentAccounts'] ?? {
            'easyPaisa': {'accountNumber': '', 'accountTitle': '', 'isVerified': false},
            'jazzCash':  {'accountNumber': '', 'accountTitle': '', 'isVerified': false},
          },
          'createdAt':         data['createdAt'],
          'approvalDate':      data['approvalDate'],
          'rejectionReason':   data['rejectionReason'],
          'resubmissionNotes': data['resubmissionNotes'],
          'suspensionReason':  data['suspensionReason'],
        };
      } else {
        throw Exception('Failed to load driver profile: ${response.body}');
      }
    } catch (e) {
      Logger.error('Error fetching driver profile: $e');
      rethrow;
    }
  }

  // ─── PAYMENT ACCOUNTS ─────────────────────────────────────

  /// Save EasyPaisa and JazzCash account details
  static Future<void> updatePaymentAccounts({
    required Map<String, String> easyPaisa,
    required Map<String, String> jazzCash,
  }) async {
    try {
      final response = await ApiClient.put(
        Uri.parse('$_baseUrl/api/driver/payment-accounts'),
        headers: await _authHeaders(),
        body: jsonEncode({
          'easyPaisa': easyPaisa,
          'jazzCash':  jazzCash,
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        final body = jsonDecode(response.body);
        throw Exception(body['message'] ?? 'Failed to update payment accounts');
      }

      Logger.log('Payment accounts updated successfully');
    } catch (e) {
      Logger.error('Error updating payment accounts: $e');
      rethrow;
    }
  }

  /// Send verification email for a payment account
  static Future<void> requestPaymentVerification({
    required String provider,
  }) async {
    try {
      Logger.log('Requesting payment verification email for: $provider');

      final response = await ApiClient.post(
        Uri.parse('$_baseUrl/api/driver/payment-accounts/verify/request'),
        headers: await _authHeaders(),
        body: jsonEncode({'provider': provider}),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        Logger.log('Verification email sent for $provider');
      } else {
        final body = jsonDecode(response.body);
        throw Exception(body['message'] ?? 'Failed to send verification email');
      }
    } catch (e) {
      Logger.error('Error requesting payment verification: $e');
      rethrow;
    }
  }

  /// Fetch current payment account details only (lightweight call)
  static Future<Map<String, dynamic>> getPaymentAccounts() async {
    try {
      final response = await ApiClient.get(
        Uri.parse('$_baseUrl/api/driver/payment-accounts'),
        headers: await _authHeaders(),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        return body['data'] ?? {};
      } else {
        final body = jsonDecode(response.body);
        throw Exception(body['message'] ?? 'Failed to fetch payment accounts');
      }
    } catch (e) {
      Logger.error('Error fetching payment accounts: $e');
      rethrow;
    }
  }
}