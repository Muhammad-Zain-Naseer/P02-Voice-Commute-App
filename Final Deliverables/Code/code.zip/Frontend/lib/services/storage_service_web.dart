// ignore_for_file: avoid_web_libraries_in_flutter, deprecated_member_use
import 'dart:html' as html;

/// Web implementation — uses sessionStorage (tab-specific, not shared across tabs)
class StorageService {
  static const String _userIdKey = 'userId';
  static const String _userNameKey = 'userName';
  static const String _userEmailKey = 'userEmail';
  static const String _userRoleKey = 'userRole';
  static const String _tokenKey = 'token';
  static const String _lastViewedAlertKey = 'lastViewedAlertTime';

  static Future<void> saveUserData(Map<String, dynamic> userData) async {
    final user = userData['user'];
    html.window.sessionStorage[_userIdKey] = user['id'] ?? '';
    html.window.sessionStorage[_userNameKey] = user['name'] ?? '';
    html.window.sessionStorage[_userEmailKey] = user['email'] ?? '';
    html.window.sessionStorage[_userRoleKey] = user['role'] ?? '';
    if (userData.containsKey('token')) {
      html.window.sessionStorage[_tokenKey] = userData['token'];
    }
  }

  static Future<String?> getUserId() async =>
      html.window.sessionStorage[_userIdKey];

  static Future<String?> getUserName() async =>
      html.window.sessionStorage[_userNameKey];

  static Future<String?> getUserEmail() async =>
      html.window.sessionStorage[_userEmailKey];

  static Future<String?> getUserRole() async =>
      html.window.sessionStorage[_userRoleKey];

  static Future<void> markAlertsAsViewed() async {
    html.window.sessionStorage[_lastViewedAlertKey] =
        DateTime.now().toIso8601String();
  }

  static Future<DateTime?> getLastViewedAlertTime() async {
    final timeStr = html.window.sessionStorage[_lastViewedAlertKey];
    if (timeStr == null) return null;
    return DateTime.tryParse(timeStr);
  }

  static Future<String?> getToken() async =>
      html.window.sessionStorage[_tokenKey];

  static Future<void> clearUserData() async {
    html.window.sessionStorage.clear();
  }
}
