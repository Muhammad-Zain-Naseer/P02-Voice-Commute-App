import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/ride_request.dart';
import '../../models/driver_payment_details.dart';
import '../../services/payment_service.dart';
import '../../services/storage_service.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import '../../utils/logger.dart';
import '../home_screen.dart';

/// Payment Page - Shows payment details and allows submission
class PaymentPage extends StatefulWidget {
  final RideRequest ride;
  final String userId;
  final String driverId;
  final double amount;
  final DriverPaymentDetails driverPaymentDetails;
  final double? baseFare;
  final bool discountApplied;
  final double discountPercentage;
  final double discountAmount;

  const PaymentPage({
    super.key,
    required this.ride,
    required this.userId,
    required this.driverId,
    required this.amount,
    required this.driverPaymentDetails,
    this.baseFare,
    this.discountApplied = false,
    this.discountPercentage = 0,
    this.discountAmount = 0,
  });

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  final TextEditingController _transactionIdController =
      TextEditingController();
  final _formKey = GlobalKey<FormState>();

  String _selectedPaymentMethod = 'cash'; // Default to cash
  bool _isSubmitting = false;

  // Voice state
  bool _isMuted = false;
  bool _isPaymentPlaying = false;
  bool _speechCancelled = false;
  Timer? _replayTimer;

  // Coupon state
  final TextEditingController _couponController = TextEditingController();
  bool _isValidatingCoupon = false;
  String? _appliedCouponCode;
  double _couponDiscountPercentage = 0;
  double _couponDiscountAmount = 0;
  String _couponMessage = '';

  final List<Map<String, String>> _paymentMethods = [
    {'value': 'cash', 'label': 'Cash'},
    {'value': 'easypaisa', 'label': 'EasyPaisa'},
    {'value': 'jazzcash', 'label': 'JazzCash'},
  ];

  // ── Voice Logic ──────────────────────────────────────────

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 8), () async {
      if (!_isMuted && !_speechCancelled && !_isPaymentPlaying && mounted) {
        await _speakPaymentDetails();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPaymentDetails();
    }
  }

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakPaymentDetails() async {
    if (_isMuted || _isPaymentPlaying) return;
    _isPaymentPlaying = true;
    _cancelReplayTimer();
    final amount = (widget.amount - _couponDiscountAmount).toStringAsFixed(0);
    await _speakAndWait('ادائیگی کا صفحہ۔');
    if (!_speechCancelled && !_isMuted && mounted) {
      await _speakAndWait('کل رقم $amount روپے ہے۔');
    }
    if (!_speechCancelled && !_isMuted && mounted) {
      await _speakAndWait('ادائیگی کا طریقہ منتخب کریں: نقد، ایزی پیسہ، یا جیز کیش۔');
    }
    if (!_speechCancelled && !_isMuted && mounted) {
      await _speakAndWait('رقم ادا کرنے کے بعد تصدیق کا بٹن دبائیں۔');
    }
    _isPaymentPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPaymentDetails();
    });
    // Log payment details when page loads
    Logger.log('💳 ========== PAYMENT PAGE INITIALIZED ==========');
    Logger.log('💳 Driver Payment Details Received:');
    Logger.log(
      '💳 EasyPaisa Title: ${widget.driverPaymentDetails.easyPaisaAccountTitle}',
    );
    Logger.log(
      '💳 EasyPaisa Number: ${widget.driverPaymentDetails.easyPaisaAccountNumber}',
    );
    Logger.log(
      '💳 JazzCash Title: ${widget.driverPaymentDetails.jazzCashAccountTitle}',
    );
    Logger.log(
      '💳 JazzCash Number: ${widget.driverPaymentDetails.jazzCashAccountNumber}',
    );
    Logger.log(
      '💳 Has EasyPaisa: ${widget.driverPaymentDetails.hasEasyPaisaAccount}',
    );
    Logger.log(
      '💳 Has JazzCash: ${widget.driverPaymentDetails.hasJazzCashAccount}',
    );
    Logger.log(
      '💳 Has Any Account: ${widget.driverPaymentDetails.hasAnyAccount}',
    );
    Logger.log('💳 ==============================================');
  }

  /// Generate a unique transaction ID for cash payments
  String _generateCashTransactionId() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = (timestamp % 10000).toString().padLeft(4, '0');
    final userIdShort = widget.userId.length > 6
        ? widget.userId.substring(widget.userId.length - 6)
        : widget.userId.padLeft(6, '0');
    return 'CASH-$timestamp-$userIdShort-$random';
  }

  /// Validate required IDs before payment; shows error and returns false if invalid
  bool _validatePaymentIds() {
    if (widget.userId.isEmpty) {
      Logger.error('❌ User ID is empty!');
      _showErrorDialog('User ID is missing. Please restart the app and try again.');
      return false;
    }
    if (widget.driverId.isEmpty) {
      Logger.error('❌ Driver ID is empty!');
      _showErrorDialog('Driver ID is missing. Please restart the app and try again.');
      return false;
    }
    if (widget.ride.id.isEmpty) {
      Logger.error('❌ Ride ID is empty!');
      _showErrorDialog('Ride ID is missing. Please restart the app and try again.');
      return false;
    }
    return true;
  }

  String _getTransactionId() {
    return _selectedPaymentMethod == 'cash'
        ? _generateCashTransactionId()
        : _transactionIdController.text.trim();
  }

  void _showLoadingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Color(0xFFCF4374)),
                SizedBox(height: 16),
                Text(
                  'Submitting Payment...',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _processPaymentResult(Map<String, dynamic> result) async {
    if (mounted) Navigator.of(context).pop();
    setState(() { _isSubmitting = false; });
    if (result['success'] == true) {
      Logger.log('✅ Payment submitted successfully');
      if (mounted) _showSuccessDialog();
    } else {
      final errorMessage = result['message'] ?? 'Failed to submit payment';
      Logger.error('❌ Payment failed: $errorMessage');
      if (mounted) _handlePaymentError(errorMessage);
    }
  }

  /// Submit payment to backend
  Future<void> _submitPayment() async {
    Logger.log('🔍 ========== PAYMENT SUBMISSION DEBUG ==========');
    Logger.log('🔍 Ride ID: ${widget.ride.id}');
    Logger.log('🔍 User ID: ${widget.userId}');
    Logger.log('🔍 Driver ID: ${widget.driverId}');
    Logger.log('🔍 Amount: ${widget.amount}');
    Logger.log('🔍 Payment Method: $_selectedPaymentMethod');

    if (!_validatePaymentIds()) return;

    if (_selectedPaymentMethod == 'cash') {
      Logger.log('💳 Processing cash payment...');
    } else {
      if (!_formKey.currentState!.validate()) return;
    }

    setState(() { _isSubmitting = true; });

    Logger.log('💳 Submitting $_selectedPaymentMethod payment...');

    _showLoadingDialog();

    try {
      final transactionId = _getTransactionId();
      Logger.log('💳 Transaction ID: $transactionId');

      final result = await PaymentService.submitPayment(
        rideId: widget.ride.id,
        userId: widget.userId,
        driverId: widget.driverId,
        amount: widget.amount - _couponDiscountAmount,
        transactionId: transactionId,
        paymentMethod: _selectedPaymentMethod,
        couponCode: _appliedCouponCode,
      );

      await _processPaymentResult(result);
    } catch (e) {
      Logger.error('❌ Payment error: $e');
      if (mounted) Navigator.of(context).pop();
      setState(() { _isSubmitting = false; });
      if (mounted) _showErrorDialog('Network error. Please check your connection.');
    }
  }

  /// Handle payment error by showing an appropriate error dialog
  void _handlePaymentError(String errorMessage) {
    if (errorMessage.contains('already submitted for this ride') ||
        errorMessage.contains('Payment already exists')) {
      _showErrorDialog(
        'Payment has already been submitted for this ride. '
        'If you believe this is an error, please contact support.',
      );
    } else if (errorMessage.contains('Transaction ID already exists')) {
      _showErrorDialog(
        'This transaction ID has already been used. '
        'Please enter a unique transaction ID from your payment receipt.',
      );
    } else {
      _showErrorDialog(errorMessage);
    }
  }

  /// Show success dialog
  void _showSuccessDialog() {
    final isCash = _selectedPaymentMethod == 'cash';
    _speechCancelled = true;
    _cancelReplayTimer();
    Future(() async {
      if (!mounted || _isMuted) return;
      _speechCancelled = false;
      await _speakAndWait('ادائیگی کامیابی سے جمع ہو گئی۔');
      if (!_speechCancelled && !_isMuted && mounted && !isCash) {
        await _speakAndWait('آپ کی ادائیگی ایڈمن کی جانب سے تصدیق کی جائے گی۔');
      }
    });
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 32),
            SizedBox(width: 12),
            Text('ادائیگی جمع ہو گئی', textDirection: TextDirection.rtl),
          ],
        ),
        content: Text(
          isCash
              ? 'نقد ادائیگی کامیابی سے تصدیق ہو گئی!'
              : 'آپ کی ادائیگی کامیابی سے جمع ہو گئی۔ ایڈمن تصدیق کرے گا۔',
          textDirection: TextDirection.rtl,
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(context);
              nav.pop(); // close dialog

              final userName = await StorageService.getUserName() ?? '';
              final userEmail = await StorageService.getUserEmail() ?? '';
              final userId = await StorageService.getUserId() ?? widget.userId;

              nav.pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => HomeScreen(
                    userName: userName,
                    userEmail: userEmail,
                    userId: userId,
                  ),
                ),
                (route) => false,
              );
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Show error dialog
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red, size: 32),
            SizedBox(width: 12),
            Text('Payment Failed'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// Copy account number to clipboard
  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label copied to clipboard'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  void dispose() {
    _speechCancelled = true;
    _cancelReplayTimer();
    AudioPlayerService.stop();
    _transactionIdController.dispose();
    _couponController.dispose();
    super.dispose();
  }

  /// Validate and apply a coupon code
  Future<void> _applyCoupon() async {
    final code = _couponController.text.trim();
    if (code.isEmpty) return;

    setState(() {
      _isValidatingCoupon = true;
      _couponMessage = '';
    });

    final result = await PaymentService.validateCoupon(code);

    if (!mounted) return;

    if (result['success'] == true) {
      final discountPct = (result['discountPercentage'] as double);
      // Apply coupon on top of the already-discounted amount shown to user
      final couponDiscount = (widget.amount * discountPct / 100).roundToDouble();
      setState(() {
        _appliedCouponCode = result['code'] as String;
        _couponDiscountPercentage = discountPct;
        _couponDiscountAmount = couponDiscount;
        _couponMessage = 'Coupon applied: ${discountPct.toStringAsFixed(0)}% off!';
        _isValidatingCoupon = false;
      });
    } else {
      setState(() {
        _appliedCouponCode = null;
        _couponDiscountPercentage = 0;
        _couponDiscountAmount = 0;
        _couponMessage = result['message'] as String? ?? 'Invalid coupon code';
        _isValidatingCoupon = false;
      });
    }
  }

  /// Remove applied coupon
  void _removeCoupon() {
    setState(() {
      _appliedCouponCode = null;
      _couponDiscountPercentage = 0;
      _couponDiscountAmount = 0;
      _couponMessage = '';
      _couponController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Payment',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFCF4374),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            onPressed: _toggleMute,
            icon: Icon(
              _isMuted ? Icons.volume_off : Icons.volume_up,
              color: Colors.white,
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFFFCE4EC),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Payment Details Card
              _buildPaymentDetailsCard(),
              const SizedBox(height: 16),

              // Coupon Code Section
              _buildCouponSection(),
              const SizedBox(height: 16),

              // Payment Method Dropdown
              _buildPaymentMethodDropdown(),
              const SizedBox(height: 20),

              // Conditional UI based on payment method
              if (_selectedPaymentMethod == 'cash')
                _buildCashPaymentNotice()
              else ...[
                // Driver Payment Details Card (for online payments)
                _buildDriverPaymentDetailsCard(),
                const SizedBox(height: 20),

                // Transaction ID Input
                _buildTransactionIdField(),
              ],

              const SizedBox(height: 12),

              // Submit Button
              _buildSubmitButton(),
            ],
          ),
        ),
      ),
    );
  }

  /// Build payment details card
  Widget _buildPaymentDetailsCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF682AA), width: 2),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withValues(alpha: 0.15),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'تفصیلات',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 16),
          if (widget.discountApplied && widget.baseFare != null) ...[
              _buildDetailRow(
                'Original Fare',
                'Rs. ${widget.baseFare!.toStringAsFixed(2)}',
                strikethrough: true,
              ),
              const SizedBox(height: 6),
              _buildDiscountRow(
                '${widget.discountPercentage.toStringAsFixed(0)}% OFF',
                'First-ride Discount',
                '-Rs. ${widget.discountAmount.toStringAsFixed(2)}',
              ),
              const SizedBox(height: 6),
            ],
            if (_appliedCouponCode != null) ...[
              _buildDiscountRow(
                '${_couponDiscountPercentage.toStringAsFixed(0)}% OFF',
                'Coupon ($_appliedCouponCode)',
                '-Rs. ${_couponDiscountAmount.toStringAsFixed(2)}',
              ),
              const SizedBox(height: 6),
            ],
            if (widget.discountApplied || _appliedCouponCode != null)
              const Divider(height: 16),
            _buildDetailRow(
              _appliedCouponCode != null
                  ? 'Total (after coupon)'
                  : 'Amount',
              'Rs. ${(widget.amount - _couponDiscountAmount).toStringAsFixed(2)}',
              isAmount: true,
            ),
          ],
        ),
      );
  }

  /// Build coupon code input section
  Widget _buildCouponSection() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF682AA), width: 2),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Have a Coupon?',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
            const SizedBox(height: 10),
            if (_appliedCouponCode == null) ...[
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _couponController,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(
                        hintText: 'Enter coupon code',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _isValidatingCoupon ? null : _applyCoupon,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFCF4374),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: _isValidatingCoupon
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Text(
                              'Apply',
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                  ),
                ],
              ),
              if (_couponMessage.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    _couponMessage,
                    style: TextStyle(
                      color: _couponMessage.contains('applied')
                          ? Colors.green
                          : Colors.red,
                      fontSize: 13,
                    ),
                  ),
                ),
            ] else ...[
              // Applied coupon chip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_offer, color: Colors.green, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '$_appliedCouponCode — ${_couponDiscountPercentage.toStringAsFixed(0)}% OFF applied',
                        style: const TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _removeCoupon,
                      child: const Icon(Icons.close, color: Colors.green, size: 20),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      );
  }

  /// Build payment method dropdown
  Widget _buildPaymentMethodDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Payment Method',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          initialValue: _selectedPaymentMethod,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
          ),
          items: _paymentMethods.map((method) {
            return DropdownMenuItem(
              value: method['value'],
              child: Text(method['label']!),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedPaymentMethod = value!;
              // Reset form fields when changing payment method
              _transactionIdController.clear();
            });
          },
        ),
      ],
    );
  }

  /// Build driver payment details card (for EasyPaisa/JazzCash)
  Widget _buildDriverPaymentDetailsCard() {
    final accountTitle = _selectedPaymentMethod == 'easypaisa'
        ? widget.driverPaymentDetails.easyPaisaAccountTitle
        : widget.driverPaymentDetails.jazzCashAccountTitle;
    final accountNumber = _selectedPaymentMethod == 'easypaisa'
        ? widget.driverPaymentDetails.easyPaisaAccountNumber
        : widget.driverPaymentDetails.jazzCashAccountNumber;

    final methodLabel = _selectedPaymentMethod == 'easypaisa'
        ? 'EasyPaisa'
        : 'JazzCash';

    // Debug logging
    Logger.log('💳 Building payment details card for: $_selectedPaymentMethod');
    Logger.log(
      '💳 Account Title: "$accountTitle" (isEmpty: ${accountTitle.isEmpty})',
    );
    Logger.log(
      '💳 Account Number: "$accountNumber" (isEmpty: ${accountNumber.isEmpty})',
    );
    Logger.log(
      '💳 Will show details: ${accountTitle.isNotEmpty && accountNumber.isNotEmpty}',
    );

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFFCE4EC),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF682AA), width: 2),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.account_balance_wallet,
                color: Color(0xFFCF4374),
                size: 28,
              ),
              const SizedBox(width: 12),
              Text(
                'Pay Using $methodLabel',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8B1A4A),
                ),
              ),
            ],
          ),
            const SizedBox(height: 16),
            if (accountTitle.isEmpty || accountNumber.isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.warning, color: Colors.orange[900]),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Driver has not added $methodLabel account details yet',
                        style: TextStyle(color: Colors.orange[900]),
                      ),
                    ),
                  ],
                ),
              )
            else ...[
              _buildAccountDetailRow('Account Title', accountTitle),
              const SizedBox(height: 12),
              _buildAccountDetailRow(
                'Account Number',
                accountNumber,
                isCopyable: true,
              ),
            ],
          ],
        ),
      );
  }

  /// Build account detail row with copy button
  Widget _buildAccountDetailRow(
    String label,
    String value, {
    bool isCopyable = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFF682AA)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
          if (isCopyable)
            IconButton(
              icon: const Icon(Icons.copy, color: Colors.green),
              onPressed: () => _copyToClipboard(value, label),
              tooltip: 'Copy',
            ),
        ],
      ),
    );
  }

  /// Build cash payment notice
  Widget _buildCashPaymentNotice() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFFCE4EC),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF682AA), width: 2),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const Icon(Icons.payments_rounded, size: 64, color: Color(0xFFCF4374)),
          const SizedBox(height: 16),
          const Text(
            'نقد ادائیگی',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'براہ کرم Rs. ${(widget.amount - _couponDiscountAmount).toStringAsFixed(2)} ڈرائیور کو نقد ادا کریں۔',
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: const TextStyle(fontSize: 16, color: Color(0xFF8B1A4A)),
          ),
          const SizedBox(height: 12),
          Text(
            'نقد رقم دینے کے بعد ہی ادائیگی کی تصدیق کریں۔',
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[700],
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  /// Build transaction ID field
  Widget _buildTransactionIdField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Transaction ID',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _transactionIdController,
          decoration: InputDecoration(
            hintText: 'Enter transaction ID',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
          ),
          validator: (value) {
            if (_selectedPaymentMethod != 'cash' &&
                (value == null || value.trim().isEmpty)) {
              return 'Transaction ID is required';
            }
            return null;
          },
        ),
      ],
    );
  }

  /// Build submit button
  Widget _buildSubmitButton() {
    final buttonText = _selectedPaymentMethod == 'cash'
        ? 'Confirm Cash Payment'
        : 'Submit Payment';

    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _isSubmitting ? null : _submitPayment,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFCF4374),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: _isSubmitting
            ? const CircularProgressIndicator(color: Colors.white)
            : Text(
                buttonText,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
      ),
    );
  }

  /// Build a discount row with badge label and green styling
  Widget _buildDiscountRow(String badge, String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                badge,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(fontSize: 14, color: Colors.green),
            ),
          ],
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.green,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  /// Build detail row widget
  Widget _buildDetailRow(String label, String value, {bool isAmount = false, bool strikethrough = false}) {
    final Color valueColor;
    if (strikethrough) {
      valueColor = Colors.grey;
    } else if (isAmount) {
      valueColor = const Color(0xFFCF4374);
    } else {
      valueColor = Colors.black87;
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 14, color: Colors.grey)),
          Flexible(
            child: Text(
              value,
              style: TextStyle(
                fontSize: isAmount ? 20 : 14,
                fontWeight: isAmount ? FontWeight.bold : FontWeight.normal,
                color: valueColor,
                decoration: strikethrough ? TextDecoration.lineThrough : null,
              ),
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
