import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'bookride/book_ride_page.dart';
import '../widgets/rate_ride_dialog.dart';
import '../widgets/sound_wave.dart';
import '../services/notification_service.dart';
import '../services/socket_service.dart';
import '../services/voice_service.dart';
import '../services/audio_player_service.dart';
import '../utils/logger.dart';
import 'notifications_page.dart';
import 'ride_history_page.dart';
import 'safety_alerts_history_page.dart';
import '../widgets/safety_alert_dialog.dart';
import '../services/safety_service.dart';
import '../services/storage_service.dart';
import 'support_ticket_page.dart';
import 'dart:async';
import '../services/auth_service.dart';
import 'landing_page.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  final String userEmail;
  final String userId;

  const HomeScreen({
    super.key,
    required this.userName,
    required this.userEmail,
    required this.userId,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final _notificationService = NotificationService();
  bool _hasNewAlerts = false;

  // Voice state
  bool _isSpeaking = false;
  bool _isMuted = false;
  bool _isHomePromptPlaying = false;
  bool _speechCancelled = false;
  Timer? _replayTimer;

  @override
  void initState() {
    super.initState();

    _notificationService.initialize(widget.userEmail);
    _connectSocketAndRegister();
    _setupPolicyListener();
    _setupFareUpdateListener();
    _setupSafetyAlertListener();
    _checkForNewAlerts();

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakHomePrompt();
    });
  }

  // ── Voice ───

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 6), () {
      if (!_isSpeaking && !_isMuted && !_isHomePromptPlaying && mounted) {
        _speakHomePrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakAndWait(String text) async {
    if (_isMuted || _speechCancelled) return;
    if (mounted) setState(() => _isSpeaking = true);
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakHomePrompt() async {
    if (_isMuted || _speechCancelled || _isHomePromptPlaying) return;
    _isHomePromptPlaying = true;
    _cancelReplayTimer();

    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) {
      _isHomePromptPlaying = false;
      return;
    }

    await _speakAndWait('خوش آمدید! سواری بک کرنے کے لیے نیچے دیا گیا بٹن دبائیں');

    _isHomePromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakHomePrompt();
    }
  }

  // ── Socket / alerts ────

  Future<void> _checkForNewAlerts() async {
    final alerts = await SafetyService.getRecentAlerts();
    if (alerts.isNotEmpty) {
      final latestAlertTime =
          DateTime.parse(alerts.first['sentAt']).toLocal();
      final lastViewed = await StorageService.getLastViewedAlertTime();
      if (lastViewed == null || latestAlertTime.isAfter(lastViewed)) {
        if (mounted) setState(() => _hasNewAlerts = true);
      }
    }
  }

  void _setupSafetyAlertListener() {
    SocketService.onSafetyAlert((data) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => SafetyAlertDialog(
            message: data['message'] ?? 'Safety Alert',
            severity: data['severity'] ?? 'medium',
            sentAt: data['sentAt'] ?? DateTime.now().toString(),
          ),
        );
      }
    });
  }

  void _setupPolicyListener() {
    SocketService.onPolicyUpdate((data) {
      if (mounted) {
        final targetAudience = data['targetAudience'] ?? 'all';
        if (targetAudience == 'all' || targetAudience == 'commuters') {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Row(
                children: [
                  const Icon(Icons.policy, color: Color(0xFFCF4374), size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      data['title'] ?? 'Policy Update',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (data['category'] != null) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          data['category'].toString().toUpperCase(),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    Text(data['message'] ?? '',
                        style: const TextStyle(fontSize: 15, height: 1.5)),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  style: TextButton.styleFrom(
                    backgroundColor: const Color(0xFFCF4374),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                  ),
                  child: const Text('Got it',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600)),
                ),
              ],
            ),
          );
        }
      }
    });
  }

  void _setupFareUpdateListener() {
    SocketService.onFareUpdate((data) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20)),
            title: const Row(
              children: [
                Icon(Icons.attach_money, color: Color(0xFFCF4374), size: 28),
                SizedBox(width: 12),
                Expanded(
                  child: Text('Fare Rate Updated',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374))),
                ),
              ],
            ),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(data['message'] ?? 'Fare price has been updated',
                    style: const TextStyle(fontSize: 15, height: 1.5)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('New Rate: ',
                          style: TextStyle(
                              fontSize: 14, color: Colors.grey[700])),
                      Text(
                        '${data['ratePerKm']} ${data['currency'] ?? 'PKR'} / km',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                ),
                child: const Text('Got it',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        );
      }
    });
  }

  Future<void> _connectSocketAndRegister() async {
    try {
      await SocketService.connect(
        userId: widget.userId,
        userName: widget.userName,
        userEmail: widget.userEmail,
        userType: 'commuter',
      );
      await Future.delayed(const Duration(seconds: 2));
      if (SocketService.isConnected && SocketService.socket != null) {
        _notificationService.registerWhenConnected();
        await Future.delayed(const Duration(milliseconds: 500));
      } else {
        await Future.delayed(const Duration(seconds: 3));
        _connectSocketAndRegister();
      }
    } catch (e, stackTrace) {
      Logger.error('Error connecting socket: $e');
      Logger.error('Stack trace: $stackTrace');
    }
  }

  void _showRatingDialog(String rideId) {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        showDialog(
          context: context,
          builder: (BuildContext context) => RateRideDialog(rideId: rideId),
        );
      }
    });
  }

  void _onItemTapped(int index) => setState(() => _selectedIndex = index);

  Widget _getSelectedPage() {
    switch (_selectedIndex) {
      case 0:
        return _buildHomeContent();
      case 1:
        return const NotificationsPage();
      case 2:
        return _buildProfileContent();
      default:
        return _buildHomeContent();
    }
  }

  // ── Home Content ───

  Widget _buildHomeContent() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              // ── Top row: mute | logo | safety ────
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Mute button
                  GestureDetector(
                    onTap: _toggleMute,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.5),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _isMuted
                            ? Icons.volume_off_rounded
                            : Icons.volume_up_rounded,
                        color: const Color(0xFFCF4374),
                        size: 28,
                      ),
                    ),
                  ),

                  // Logo centred between the two icons
                  SvgPicture.asset(
                    'assets/icons/logo_hersafar.svg',
                    width: 90,
                    height: 50,
                  ),

                  // Safety alert button
                  Stack(
                    children: [
                      GestureDetector(
                        onTap: () async {
                          await StorageService.markAlertsAsViewed();
                          setState(() => _hasNewAlerts = false);
                          if (mounted) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const SafetyAlertsHistoryPage()),
                            );
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.5),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.security,
                              color: Color(0xFFCF4374), size: 28),
                        ),
                      ),
                      if (_hasNewAlerts)
                        Positioned(
                          right: 6,
                          top: 6,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                              border:
                                  Border.all(color: Colors.white, width: 1.5),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // ── Sound wave ───
              SoundWave(isAnimating: _isSpeaking),

              const SizedBox(height: 14),

              // ── Welcome greeting ───
              const Text(
                'خوش آمدید!',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFCF4374),
                  letterSpacing: 0.5,
                ),
              ),

              const SizedBox(height: 28),

              // ── Instruction text ───
              const Text(
                'سواری بُک کرنے کے لیے نیچے',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFFCF4374),
                  height: 1.5,
                ),
              ),
              const Text(
                'دیا گیا بٹن دبائیں۔',
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFFCF4374),
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 20),

              const Spacer(),

              // ── Book Ride button ───
              _AnimatedBookButton(
                isHighlighted: _isSpeaking,
                onTap: () async {
                  _cancelReplayTimer();
                  _speechCancelled = true;
                  await AudioPlayerService.stop();

                  if (!mounted) return;

                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BookRidePage(
                        userId: widget.userId,
                        userName: widget.userName,
                        userEmail: widget.userEmail,
                      ),
                    ),
                  );

                  _speechCancelled = false;
                  if (!_isMuted) _speakHomePrompt();

                  if (result != null && result is String) {
                    _showRatingDialog(result);
                  }
                },
              ),
              const SizedBox(height: 225),
            ],
          ),
        ),
      ),
    );
  }

  // ── Profile Content ───

  Widget _buildProfileContent() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundColor: Color(0xFFCF4374),
                  child: Icon(Icons.person, size: 50, color: Colors.white),
                ),
                const SizedBox(height: 20),
                Text(
                  widget.userName,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.userEmail,
                  style: const TextStyle(
                      fontSize: 16, color: Color(0xFFCF4374)),
                ),
                const SizedBox(height: 30),
                _buildProfileOption(
                  icon: Icons.history,
                  title: 'رائڈ ہسٹری',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            RideHistoryPage(userId: widget.userId)),
                  ),
                ),
                const SizedBox(height: 12),
                _buildProfileOption(
                  icon: Icons.help_outline,
                  title: 'مسئلہ رپورٹ کریں',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => SupportTicketPage(
                            userId: widget.userId, role: 'commuter')),
                  ),
                ),
                const SizedBox(height: 12),

                // Logout Option
                _buildProfileOption(
                  icon: Icons.logout,
                  title: 'لاگ آؤٹ',
                  onTap: () async {
                    bool? confirmLogout = await showDialog<bool>(
                      context: context,
                      builder: (context) => AlertDialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        title: const Text(
                          'لاگ آؤٹ',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: Color(0xFFCF4374),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        content: const Text(
                          'کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 16),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context, false),
                            child: const Text(
                              'نہیں',
                              style: TextStyle(color: Colors.grey, fontSize: 16),
                            ),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            child: const Text(
                              'ہاں',
                              style: TextStyle(
                                color: Color(0xFFCF4374),
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );

                    if (confirmLogout == true) {
                      await AuthService().logout();

                      NotificationService().clearAll();

                      if (mounted) {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LandingPage(),
                          ),
                          (route) => false,
                        );
                      }
                    }
                  },
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: SocketService.isConnected
                          ? Colors.green
                          : Colors.red,
                      width: 2,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        SocketService.isConnected
                            ? Icons.check_circle
                            : Icons.error,
                        color: SocketService.isConnected
                            ? Colors.green
                            : Colors.red,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        SocketService.isConnected
                            ? 'Connected to notifications'
                            : 'Not connected',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: SocketService.isConnected
                              ? Colors.green
                              : Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileOption({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withValues(alpha: 0.1),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Row(
              children: [
                Icon(icon, color: const Color(0xFFCF4374), size: 28),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    title,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF69223B),
                    ),
                  ),
                ),
                const Icon(Icons.arrow_back_ios,
                    size: 16, color: Color(0xFFCF4374)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _getSelectedPage(),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFFCE5EC),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
        ),
        child: ValueListenableBuilder(
          valueListenable: _notificationService.notificationStream,
          builder: (context, notifications, _) {
            final unreadCount = _notificationService.unreadCount;
            return BottomNavigationBar(
              currentIndex: _selectedIndex,
              onTap: _onItemTapped,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.transparent,
              elevation: 0,
              selectedItemColor: const Color(0xFFCF4374),
              unselectedItemColor:
                  const Color(0xFFCF4374).withValues(alpha: 0.6),
              selectedLabelStyle: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w600),
              unselectedLabelStyle: const TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w500),
              items: [
                const BottomNavigationBarItem(
                  icon: Icon(Icons.home, size: 24),
                  activeIcon: Icon(Icons.home, size: 28),
                  label: 'ہوم',
                ),
                BottomNavigationBarItem(
                  icon: _notifIcon(unreadCount, false),
                  activeIcon: _notifIcon(unreadCount, true),
                  label: 'اطلاعات',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(Icons.person_outline, size: 24),
                  activeIcon: Icon(Icons.person, size: 28),
                  label: 'پروفائل',
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _notifIcon(int unreadCount, bool active) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(active ? Icons.notifications : Icons.notifications_outlined,
            size: active ? 28 : 24),
        if (unreadCount > 0)
          Positioned(
            right: -6,
            top: -6,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                  color: Colors.red, shape: BoxShape.circle),
              constraints:
                  const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Text(
                unreadCount > 9 ? '9+' : unreadCount.toString(),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
          ),
      ],
    );
  }

  @override
  void dispose() {
    _cancelReplayTimer();
    super.dispose();
  }
}

// ── Animated Book Ride Button ──

class _AnimatedBookButton extends StatelessWidget {
  final bool isHighlighted;
  final VoidCallback onTap;

  const _AnimatedBookButton({
    required this.isHighlighted,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: isHighlighted ? 1.05 : 1.0,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOut,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: isHighlighted
              ? [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.60),
                    blurRadius: 28,
                    spreadRadius: 8,
                  ),
                ]
              : [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.35),
                    blurRadius: 12,
                    spreadRadius: 2,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            width: 250,
            height: 60,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFCF4374), Color(0xFF69223B)],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.directions_car, color: Colors.white, size: 26),
                SizedBox(width: 12),
                Text(
                  'رائیڈ بُک کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}