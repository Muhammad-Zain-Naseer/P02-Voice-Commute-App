import 'package:flutter/material.dart';
import '../../services/admin_service.dart';
import '../../services/socket_service.dart';
import '../../widgets/live_tracking_map.dart';

class AdminTripMonitorScreen extends StatefulWidget {
  final String token;
  final String adminName;
  final String adminEmail;

  const AdminTripMonitorScreen({
    super.key,
    required this.token,
    required this.adminName,
    required this.adminEmail,
  });

  @override
  State<AdminTripMonitorScreen> createState() => _AdminTripMonitorScreenState();
}

class _AdminTripMonitorScreenState extends State<AdminTripMonitorScreen> {
  final AdminService _adminService = AdminService();
  List<Map<String, dynamic>> _trips = [];
  bool _isLoading = true;
  String? _selectedTripId;

  @override
  void initState() {
    super.initState();
    _adminService.setToken(widget.token);
    _loadTrips();
    _setupSocket();
  }

  @override
  void dispose() {
    SocketService.removeAdminRideLocationListener();
    super.dispose();
  }

  Future<void> _setupSocket() async {
    await SocketService.connect(
      userId: widget.adminEmail,
      userName: widget.adminName,
      userEmail: widget.adminEmail,
      userType: 'admin',
    );

    SocketService.onAdminRideLocationUpdate((
      rideId,
      role,
      lat,
      lng,
      heading,
      speed,
      timestamp,
    ) {
      final index = _trips.indexWhere((trip) => trip['id'] == rideId);
      if (index == -1) {
        return;
      }

      final updatedTrip = Map<String, dynamic>.from(_trips[index]);
      if (role == 'driver') {
        updatedTrip['lastDriverLocation'] = {
          'latitude': lat,
          'longitude': lng,
          'heading': heading,
          'speed': speed,
          'timestamp': timestamp,
        };
      } else {
        updatedTrip['lastPassengerLocation'] = {
          'latitude': lat,
          'longitude': lng,
          'timestamp': timestamp,
        };
      }

      setState(() {
        _trips[index] = updatedTrip;
      });
    });
  }

  Future<void> _loadTrips() async {
    setState(() {
      _isLoading = true;
    });

    final data = await _adminService.getActiveTrips();
    if (!mounted) return;

    final trips = (data?['trips'] as List?)?.cast<Map<String, dynamic>>() ?? [];

    setState(() {
      _trips = trips;
      _isLoading = false;
      _selectedTripId = trips.isNotEmpty ? trips.first['id'] as String : null;
    });
  }

  Map<String, dynamic>? _getSelectedTrip() {
    if (_selectedTripId == null) return null;
    return _trips.firstWhere(
      (trip) => trip['id'] == _selectedTripId,
      orElse: () => <String, dynamic>{},
    );
  }

  double? _readLat(Map<String, dynamic>? coords) {
    if (coords == null) return null;
    if (coords['latitude'] != null) {
      return (coords['latitude'] as num).toDouble();
    }
    if (coords['lat'] != null) {
      return (coords['lat'] as num).toDouble();
    }
    final raw = coords['coordinates'];
    if (raw is List && raw.length >= 2) {
      return (raw[1] as num).toDouble();
    }
    return null;
  }

  double? _readLng(Map<String, dynamic>? coords) {
    if (coords == null) return null;
    if (coords['longitude'] != null) {
      return (coords['longitude'] as num).toDouble();
    }
    if (coords['lng'] != null) {
      return (coords['lng'] as num).toDouble();
    }
    final raw = coords['coordinates'];
    if (raw is List && raw.length >= 2) {
      return (raw[0] as num).toDouble();
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final selectedTrip = _getSelectedTrip();
    final Map<String, dynamic>? driverLoc =
        selectedTrip?['lastDriverLocation'] as Map<String, dynamic>?;
    final Map<String, dynamic>? passengerLoc =
        selectedTrip?['lastPassengerLocation'] as Map<String, dynamic>?;
    final Map<String, dynamic>? sourceCoords =
        selectedTrip?['source']?['coordinates'] as Map<String, dynamic>?;

    final double? driverLat = _readLat(driverLoc);
    final double? driverLng = _readLng(driverLoc);
    final double? passengerLat =
        _readLat(passengerLoc) ?? _readLat(sourceCoords);
    final double? passengerLng =
        _readLng(passengerLoc) ?? _readLng(sourceCoords);

    final bool hasMapLocations =
        driverLat != null &&
        driverLng != null &&
        passengerLat != null &&
        passengerLng != null;

    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text('Trip Monitor'),
        backgroundColor: const Color(0xFFCF4374),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loadTrips,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _buildBody(hasMapLocations, driverLat, driverLng, passengerLat, passengerLng),
    );
  }

  Widget _buildBody(bool hasMapLocations, double? driverLat, double? driverLng, double? passengerLat, double? passengerLng) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      );
    }
    final Widget mapWidget = hasMapLocations
        ? LiveTrackingMap(
            driverLat: driverLat!,
            driverLng: driverLng!,
            passengerLat: passengerLat!,
            passengerLng: passengerLng!,
            polylineEncoded: null,
            showRoute: true,
          )
        : const Center(
            child: Text(
              'Waiting for live locations...',
              style: TextStyle(color: Colors.grey),
            ),
          );
    final Widget tripsList = _trips.isEmpty
        ? const Center(
            child: Text(
              'No active trips right now.',
              style: TextStyle(color: Colors.grey),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _trips.length,
            itemBuilder: (context, index) {
              final trip = _trips[index];
              final isSelected = trip['id'] == _selectedTripId;
              final status = trip['status']?.toString() ?? 'unknown';
              final passengerName = trip['userName']?.toString() ?? 'Passenger';
              final driverName =
                  trip['matchedWith']?['driverName']?.toString() ?? 'Unassigned';
              final rideId = trip['id']?.toString() ?? '';
              return Card(
                elevation: isSelected ? 4 : 1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: isSelected ? const Color(0xFFCF4374) : Colors.transparent,
                    width: 1.5,
                  ),
                ),
                child: ListTile(
                  onTap: () {
                    setState(() {
                      _selectedTripId = rideId;
                    });
                  },
                  title: Text(
                    '$passengerName • $driverName',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    'Ride ID: $rideId',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: status == 'matched'
                          ? Colors.green.withValues(alpha: 0.15)
                          : Colors.orange.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      status.toUpperCase(),
                      style: TextStyle(
                        color: status == 'matched' ? Colors.green : Colors.orange,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
    return Column(
      children: [
        SizedBox(height: 280, child: mapWidget),
        Expanded(child: tripsList),
      ],
    );
  }
}
