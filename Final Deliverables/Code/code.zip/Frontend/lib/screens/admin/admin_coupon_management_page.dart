import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/coupon_service.dart';

class AdminCouponManagementPage extends StatefulWidget {
  final String token;

  const AdminCouponManagementPage({super.key, required this.token});

  @override
  State<AdminCouponManagementPage> createState() =>
      _AdminCouponManagementPageState();
}

class _AdminCouponManagementPageState
    extends State<AdminCouponManagementPage> {
  static const _pink = Color(0xFFCF4374);

  late final CouponService _couponService;
  List<Map<String, dynamic>> _coupons = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _couponService = CouponService(token: widget.token);
    _loadCoupons();
  }

  Future<void> _loadCoupons() async {
    setState(() => _isLoading = true);
    final coupons = await _couponService.getCoupons();
    if (mounted) {
      setState(() {
      _coupons = coupons;
      _isLoading = false;
    });
    }
  }

  // ── Create coupon bottom sheet ──────────────────────────────────────────────
  Future<void> _saveCoupon({
    required BuildContext ctx,
    required String code,
    required String discountText,
    required String descText,
    required String maxUsesText,
    required DateTime? selectedExpiry,
    required void Function(void Function()) setSheet,
  }) async {
    final pct = double.tryParse(discountText);
    if (code.isEmpty) {
      _snack(ctx, 'Coupon code is required', isError: true);
      return;
    }
    if (pct == null || pct < 1 || pct > 100) {
      _snack(ctx, 'Enter a valid discount (1–100)', isError: true);
      return;
    }
    setSheet(() {});
    final maxUses = maxUsesText.isEmpty ? null : int.tryParse(maxUsesText);
    final result = await _couponService.createCoupon(
      code: code,
      discountPercentage: pct,
      description: descText,
      maxUses: maxUses,
      expiryDate: selectedExpiry,
    );
    if (!ctx.mounted) return;
    Navigator.pop(ctx);
    if (!mounted) return;
    if (result['success'] == true) {
      _snack(context, 'Coupon created successfully!');
      _loadCoupons();
    } else {
      _snack(context, result['message'] ?? 'Failed to create coupon', isError: true);
    }
  }

  Widget _buildExpiryPicker({
    required BuildContext ctx,
    required DateTime? selectedExpiry,
    required void Function(void Function()) setSheet,
  }) {
    return GestureDetector(
      onTap: () async {
        final picked = await showDatePicker(
          context: ctx,
          initialDate: DateTime.now().add(const Duration(days: 30)),
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
          builder: (context, child) => Theme(
            data: ThemeData.light().copyWith(
              colorScheme: const ColorScheme.light(primary: _pink),
            ),
            child: child!,
          ),
        );
        if (picked != null) {
          setSheet(() => selectedExpiry = picked);
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade400),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today_outlined, color: _pink, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                selectedExpiry == null
                    ? 'Expiry Date (optional — blank = no expiry)'
                    : 'Expires: ${_formatDate(selectedExpiry)}',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: selectedExpiry == null ? Colors.grey.shade600 : Colors.black87,
                ),
              ),
            ),
            if (selectedExpiry != null)
              GestureDetector(
                onTap: () => setSheet(() => selectedExpiry = null),
                child: const Icon(Icons.close, color: Colors.grey, size: 18),
              ),
          ],
        ),
      ),
    );
  }

  void _showCreateCouponSheet() {
    final codeCtrl = TextEditingController();
    final discountCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final maxUsesCtrl = TextEditingController();
    DateTime? selectedExpiry;
    bool saving = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            return Padding(
              padding: EdgeInsets.fromLTRB(24, 24, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.local_offer, color: _pink),
                        const SizedBox(width: 8),
                        Text('Create Coupon', style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 20),
                    _buildSheetField(controller: codeCtrl, label: 'Coupon Code *', hint: 'e.g. WELCOME20', icon: Icons.confirmation_number_outlined, caps: TextCapitalization.characters),
                    const SizedBox(height: 14),
                    _buildSheetField(controller: discountCtrl, label: 'Discount Percentage *', hint: 'e.g. 20', icon: Icons.percent, keyboard: TextInputType.number, formatter: FilteringTextInputFormatter.digitsOnly),
                    const SizedBox(height: 14),
                    _buildSheetField(controller: descCtrl, label: 'Description (optional)', hint: 'e.g. New user welcome offer', icon: Icons.description_outlined),
                    const SizedBox(height: 14),
                    _buildSheetField(controller: maxUsesCtrl, label: 'Max Uses (optional — blank = unlimited)', hint: 'e.g. 100', icon: Icons.people_outline, keyboard: TextInputType.number, formatter: FilteringTextInputFormatter.digitsOnly),
                    const SizedBox(height: 14),
                    _buildExpiryPicker(ctx: ctx, selectedExpiry: selectedExpiry, setSheet: setSheet),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: saving
                            ? null
                            : () async {
                                setSheet(() => saving = true);
                                await _saveCoupon(
                                  ctx: ctx,
                                  code: codeCtrl.text.trim(),
                                  discountText: discountCtrl.text.trim(),
                                  descText: descCtrl.text.trim(),
                                  maxUsesText: maxUsesCtrl.text.trim(),
                                  selectedExpiry: selectedExpiry,
                                  setSheet: setSheet,
                                );
                                setSheet(() => saving = false);
                              },
                        style: ElevatedButton.styleFrom(backgroundColor: _pink, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                        child: saving
                            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : Text('Create Coupon', style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ── Toggle active ───────────────────────────────────────────────────────────
  Future<void> _toggleCoupon(Map<String, dynamic> coupon) async {
    final id = coupon['_id'] as String;
    final ok = await _couponService.toggleCoupon(id);
    if (!mounted) return;
    if (ok) {
      _snack(
        context,
        coupon['isActive'] == true
            ? 'Coupon deactivated'
            : 'Coupon activated',
      );
      _loadCoupons();
    } else {
      _snack(context, 'Failed to update coupon', isError: true);
    }
  }

  // ── Delete ──────────────────────────────────────────────────────────────────
  Future<void> _deleteCoupon(Map<String, dynamic> coupon) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Delete Coupon',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        content: Text(
          'Delete coupon "${coupon['code']}"? This cannot be undone.',
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: GoogleFonts.poppins()),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style:
                ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text('Delete',
                style: GoogleFonts.poppins(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final id = coupon['_id'] as String;
    final ok = await _couponService.deleteCoupon(id);
    if (!mounted) return;
    if (ok) {
      _snack(context, 'Coupon deleted');
      _loadCoupons();
    } else {
      _snack(context, 'Failed to delete coupon', isError: true);
    }
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────
  void _snack(BuildContext ctx, String msg, {bool isError = false}) {
    ScaffoldMessenger.of(ctx).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.poppins()),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  String _formatDate(DateTime dt) =>
      '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';

  Widget _buildSheetField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboard = TextInputType.text,
    TextInputFormatter? formatter,
    TextCapitalization caps = TextCapitalization.none,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboard,
      textCapitalization: caps,
      inputFormatters: formatter != null ? [formatter] : null,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: _pink),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: _pink, width: 2),
        ),
        labelStyle: GoogleFonts.poppins(fontSize: 13),
      ),
      style: GoogleFonts.poppins(fontSize: 14),
    );
  }

  // ── Coupon card ─────────────────────────────────────────────────────────────
  Widget _buildCouponCard(Map<String, dynamic> coupon) {
    final isActive = coupon['isActive'] == true;
    final code = coupon['code'] as String? ?? '';
    final pct = (coupon['discountPercentage'] as num?)?.toInt() ?? 0;
    final usedCount = (coupon['usedCount'] as num?)?.toInt() ?? 0;
    final maxUses = coupon['maxUses'];
    final description = coupon['description'] as String? ?? '';
    final expiryRaw = coupon['expiryDate'];
    final expiry = expiryRaw != null
        ? _formatDate(DateTime.parse(expiryRaw as String).toLocal())
        : null;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row: code badge + status chip + toggle + delete
            Row(
              children: [
                // Code badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isActive ? _pink : Colors.grey.shade400,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    code,
                    style: GoogleFonts.poppins(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Discount badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '$pct% OFF',
                    style: GoogleFonts.poppins(
                      color: Colors.green.shade800,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
                const Spacer(),
                // Toggle switch
                Switch(
                  value: isActive,
                  activeThumbColor: _pink,
                  onChanged: (_) => _toggleCoupon(coupon),
                ),
                // Delete button
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  tooltip: 'Delete',
                  onPressed: () => _deleteCoupon(coupon),
                ),
              ],
            ),

            if (description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                description,
                style: GoogleFonts.poppins(fontSize: 13, color: Colors.grey.shade700),
              ),
            ],

            const SizedBox(height: 10),
            // Usage + expiry row
            Wrap(
              spacing: 12,
              runSpacing: 6,
              children: [
                _infoChip(
                  Icons.people_outline,
                  maxUses == null
                      ? '$usedCount uses (unlimited)'
                      : '$usedCount / $maxUses uses',
                ),
                if (expiry != null)
                  _infoChip(Icons.calendar_today_outlined, 'Expires $expiry'),
                _infoChip(
                  isActive ? Icons.check_circle_outline : Icons.cancel_outlined,
                  isActive ? 'Active' : 'Inactive',
                  color: isActive ? Colors.green : Colors.red,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoChip(IconData icon, String label, {Color? color}) {
    final c = color ?? Colors.grey.shade700;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: c),
        const SizedBox(width: 4),
        Text(
          label,
          style: GoogleFonts.poppins(fontSize: 12, color: c),
        ),
      ],
    );
  }

  // ── Build ───────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Coupon Management',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: _pink,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            tooltip: 'Refresh',
            onPressed: _loadCoupons,
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_pink, Color(0xFFB83A63)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(top: 20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: _buildCouponListBody(),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreateCouponSheet,
        backgroundColor: _pink,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'Add Coupon',
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildCouponListBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: _pink));
    }
    if (_coupons.isEmpty) {
      return _buildEmptyState();
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 100),
      itemCount: _coupons.length,
      itemBuilder: (_, i) => _buildCouponCard(_coupons[i]),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.local_offer_outlined, size: 72, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text(
            'No Coupons Yet',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap + Add Coupon to create your first coupon',
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey.shade400,
            ),
          ),
        ],
      ),
    );
  }
}
