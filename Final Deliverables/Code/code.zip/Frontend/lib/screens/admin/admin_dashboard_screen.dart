import 'package:flutter/material.dart';
import '../../services/admin_service.dart';
import 'send_alert_page.dart';
import 'driver_verification_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  final String token;

  const AdminDashboardScreen({super.key, required this.token});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen>
    with SingleTickerProviderStateMixin {
  static const String _noDataAvailable = 'No data available';
  late TabController _tabController;
  late AdminService _adminService;

  Map<String, dynamic>? _overviewStats;
  Map<String, dynamic>? _userStats;
  Map<String, dynamic>? _driverStats;
  Map<String, dynamic>? _rideStats;
  Map<String, dynamic>? _paymentStats;

  bool _isLoading = true;

  // Pending drivers count for the pink dot + bar text
  int _pendingDriversCount = 0;

  // Theme colors
  static const Color _primaryPink = Color(0xFFCF4374);
  static const Color _borderPink = Color(0xFFF682AA);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _adminService = AdminService();
    _adminService.setToken(widget.token);
    _loadAllStats();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadAllStats() async {
    setState(() => _isLoading = true);

    final results = await Future.wait([
      _adminService.getOverviewStats(),
      _adminService.getUserStats(),
      _adminService.getDriverStats(),
      _adminService.getRideStats(),
      _adminService.getPaymentStats(),
    ]);

    final driverStats = results[2];

    setState(() {
      _overviewStats = results[0];
      _userStats = results[1];
      _driverStats = driverStats;
      _rideStats = results[3];
      _paymentStats = results[4];

      _pendingDriversCount = (driverStats?['pendingDrivers'] ?? 0) is int
          ? (driverStats?['pendingDrivers'] ?? 0) as int
          : int.tryParse('${driverStats?['pendingDrivers'] ?? 0}') ?? 0;

      _isLoading = false;
    });
  }


Widget _tabLabelWithDotOverlay(String text, {required bool showDot}) {
  return SizedBox(
    height: 36, // fixed height so it matches other tabs and doesn't push down
    child: Stack(
      alignment: Alignment.center,
      clipBehavior: Clip.none,
      children: [
        Text(text),
        if (showDot)
          const Positioned(
            top: -2, // floats above text without changing layout
            child: SizedBox(
              width: 7,
              height: 7,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: _primaryPink,
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ),
      ],
    ),
  );
}

  // ---------- PINK PENDING VERIFICATIONS BAR ----------
  Widget _buildPendingVerificationsBar() {
    // Show only when there are pending drivers
    if (_pendingDriversCount <= 0) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderPink, width: 2),
        boxShadow: [
          BoxShadow(
            color: _primaryPink.withValues(alpha: 0.12),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _primaryPink.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.pending_actions,
              color: _primaryPink,
              size: 26,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pending Verifications',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: _primaryPink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$_pendingDriversCount drivers waiting for approval',
                  style: TextStyle(
                    fontSize: 13,
                    color: _primaryPink.withValues(alpha: 0.75),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DriverVerificationScreen(
                    token: widget.token,
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _primaryPink,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 0,
            ),
            child: const Text(
              'Review',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasPendingDrivers = _pendingDriversCount > 0;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: _primaryPink,
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Admin Dashboard',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: _primaryPink,
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.refresh,
                            color: _primaryPink,
                            size: 24,
                          ),
                          onPressed: _loadAllStats,
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.campaign,
                            color: _primaryPink,
                            size: 24,
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    SendAlertPage(token: widget.token),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Tabs
              Container(
                color: Colors.white.withValues(alpha: 0.5),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  labelColor: _primaryPink,
                  unselectedLabelColor: _primaryPink.withValues(alpha: 0.5),
                  indicatorColor: _primaryPink,
                  tabs: [
                    const Tab(text: 'Overview'),
                    const Tab(text: 'Users'),
                    // Tab(
                    //   child: _tabLabelWithDot(
                    //     'Drivers',
                    //     showDot: hasPendingDrivers,
                    //   ),
                    // ),
                    Tab(
child: _tabLabelWithDotOverlay(
    'Drivers',
    showDot: hasPendingDrivers,
  ),
),

                    const Tab(text: 'Rides'),
                    const Tab(text: 'Payments'),
                  ],
                ),
              ),

              // Tab Content
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(_primaryPink),
                        ),
                      )
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _buildOverviewTab(),
                          _buildUsersTab(),

                          // DRIVERS TAB: Pending Verifications bar at the TOP
                          Column(
                            children: [
                              // "Below the overview/users/drivers bar"
                              // In this file, that's the TabBar itself, so we put this right under it.
                              _buildPendingVerificationsBar(),
                              Expanded(child: _buildDriversTab()),
                            ],
                          ),

                          _buildRidesTab(),
                          _buildPaymentsTab(),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOverviewTab() {
    if (_overviewStats == null) {
      return const Center(child: Text(_noDataAvailable));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildStatCard(
            'Total Users',
            _getTotalUsersValue(),
            Icons.people,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Total Drivers',
            _overviewStats!['totalDrivers'].toString(),
            Icons.local_taxi,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Total Rides',
            _overviewStats!['totalRides'].toString(),
            Icons.directions_car,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Completed Rides',
            _overviewStats!['completedRides'].toString(),
            Icons.check_circle,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Admin Revenue (20% Commission)',
            'Rs ${_overviewStats!['adminRevenue'] ?? 0}',
            Icons.attach_money,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Driver Earnings (80%)',
            'Rs ${_overviewStats!['driverEarnings'] ?? 0}',
            Icons.account_balance_wallet,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Approved Drivers',
            _overviewStats!['approvedDrivers'].toString(),
            Icons.verified,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Active Rides (Real-Time)',
            _overviewStats!['activeRides'].toString(),
            Icons.play_circle,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          if (_overviewStats!['connectedUsers'] != null)
            _buildStatCard(
              'Users Online Now',
              _overviewStats!['connectedUsers'].toString(),
              Icons.person_pin,
              const Color(0xFF00BCD4),
            ),
        ],
      ),
    );
  }

  String _getTotalUsersValue() {
    final userTotal = _userStats?['totalUsers'];
    if (userTotal != null) return userTotal.toString();

    final overviewTotal = _overviewStats?['totalUsers'];
    return overviewTotal?.toString() ?? '0';
  }

  Widget _buildUsersTab() {
    if (_userStats == null) {
      return const Center(child: Text(_noDataAvailable));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Users',
            _userStats!['totalUsers'].toString(),
            Icons.people,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Verified Users',
            _userStats!['verifiedUsers'].toString(),
            Icons.verified_user,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Unverified Users',
            _userStats!['unverifiedUsers'].toString(),
            Icons.person_off,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Commuters',
            _userStats!['commuters'].toString(),
            Icons.person,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Users with Trusted Contacts',
            _userStats!['usersWithTrustedContacts'].toString(),
            Icons.contact_phone,
            const Color(0xFF00BCD4),
          ),
          const SizedBox(height: 24),
          const Text(
            'Recent Users',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: _primaryPink,
            ),
          ),
          const SizedBox(height: 12),
          ...(_userStats!['recentUsers'] as List).map((user) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    user['role'] == 'driver' ? Icons.local_taxi : Icons.person,
                    color: _primaryPink,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user['name'] ?? 'Unknown',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _primaryPink,
                          ),
                        ),
                        Text(
                          user['email'] ?? '',
                          style: TextStyle(
                            fontSize: 12,
                            color: _primaryPink.withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    user['isVerified'] == true
                        ? Icons.check_circle
                        : Icons.cancel,
                    color: user['isVerified'] == true
                        ? Colors.green
                        : Colors.red,
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  // DRIVERS TAB CONTENT ONLY (WITHOUT THE PENDING BAR; WE RENDER IT ABOVE)
  Widget _buildDriversTab() {
    if (_driverStats == null) {
      return const Center(child: Text(_noDataAvailable));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Drivers',
            _driverStats!['totalDrivers'].toString(),
            Icons.local_taxi,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Pending Approval',
            _driverStats!['pendingDrivers'].toString(),
            Icons.hourglass_empty,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Approved',
            _driverStats!['approvedDrivers'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Rejected',
            _driverStats!['rejectedDrivers'].toString(),
            Icons.cancel,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Suspended',
            _driverStats!['suspendedDrivers'].toString(),
            Icons.block,
            const Color(0xFF000000),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Available Now',
            _driverStats!['availableDrivers'].toString(),
            Icons.check,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 24),
          const Text(
            'Top Drivers',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: _primaryPink,
            ),
          ),
          const SizedBox(height: 12),
          ...(_driverStats!['topDrivers'] as List).map((driver) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.star, color: Color(0xFFFFD700)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          driver['name'] ?? 'Unknown',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _primaryPink,
                          ),
                        ),
                        Text(
                          '${driver['totalRides']} rides • ${driver['averageRating']?.toStringAsFixed(1) ?? '0.0'} ⭐',
                          style: TextStyle(
                            fontSize: 12,
                            color: _primaryPink.withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    driver['isAvailable'] == true
                        ? Icons.check_circle
                        : Icons.cancel,
                    color: driver['isAvailable'] == true
                        ? Colors.green
                        : Colors.grey,
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildRidesTab() {
    if (_rideStats == null) {
      return const Center(child: Text(_noDataAvailable));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildStatCard(
            'Total Rides',
            _rideStats!['totalRides'].toString(),
            Icons.directions_car,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Active Rides (Real-Time)',
            _rideStats!['matchedRides'].toString(),
            Icons.link,
            const Color(0xFF9C27B0),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Completed Rides',
            _rideStats!['completedRides'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Cancelled Rides',
            _rideStats!['cancelledRides'].toString(),
            Icons.cancel,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'SOS Incidents',
            _rideStats!['sosIncidents'].toString(),
            Icons.warning,
            const Color(0xFFF44336),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Average Rating',
            _rideStats!['averageRating']?.toStringAsFixed(1) ?? '0.0',
            Icons.star,
            const Color(0xFFFFD700),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentsTab() {
    if (_paymentStats == null) {
      return const Center(child: Text(_noDataAvailable));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatCard(
            'Total Payments',
            _paymentStats!['totalPayments'].toString(),
            Icons.payments,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Pending Verification',
            _paymentStats!['pendingPayments'].toString(),
            Icons.pending,
            const Color(0xFFFF9800),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Verified',
            _paymentStats!['verifiedPayments'].toString(),
            Icons.check_circle,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Admin Revenue (20% Commission)',
            'Rs ${_paymentStats!['adminRevenue'] ?? 0}',
            Icons.attach_money,
            const Color(0xFF4CAF50),
          ),
          const SizedBox(height: 12),
          _buildStatCard(
            'Driver Earnings (80%)',
            'Rs ${_paymentStats!['driverEarnings'] ?? 0}',
            Icons.account_balance_wallet,
            const Color(0xFF2196F3),
          ),
          const SizedBox(height: 24),
          const Text(
            'Payment Methods',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: _primaryPink,
            ),
          ),
          const SizedBox(height: 12),
          ...(_paymentStats!['paymentMethods'] as List).map((method) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.payment, color: _primaryPink),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      method['_id']?.toString().toUpperCase() ?? 'UNKNOWN',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _primaryPink,
                      ),
                    ),
                  ),
                  Text(
                    '${method['count']} (Rs ${method['total']})',
                    style: const TextStyle(color: _primaryPink),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.2),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    color: _primaryPink.withValues(alpha: 0.7),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: _primaryPink,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
