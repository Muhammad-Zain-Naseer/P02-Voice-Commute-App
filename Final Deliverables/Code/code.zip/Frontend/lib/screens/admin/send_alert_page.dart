import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/admin_service.dart';

class SendAlertPage extends StatefulWidget {
  final String token;

  const SendAlertPage({super.key, required this.token});

  @override
  State<SendAlertPage> createState() => _SendAlertPageState();
}

class _SendAlertPageState extends State<SendAlertPage> {
  final _messageController = TextEditingController();
  final _adminService = AdminService();

  // Default values
  String _selectedSeverity = 'medium';
  bool _isLoading = false;

  // Dropdown options
  final Map<String, Color> _severityOptions = {
    'low': Colors.blue,
    'medium': Colors.orange,
    'high': Colors.red,
    'critical': const Color(0xFFD32F2F),
  };

  @override
  void initState() {
    super.initState();
    _adminService.setToken(widget.token);
  }

  Future<void> _broadcastAlert() async {
    if (_messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a message / براہ کرم پیغام لکھیں'),
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final success = await _adminService.sendSafetyAlert(
      message: _messageController.text.trim(),
      severity: _selectedSeverity,
    );

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      if (success) {
        // Success Message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Alert Broadcasted Successfully! / پیغام نشر کر دیا گیا',
            ),
            backgroundColor: Colors.green,
          ),
        );
        _messageController.clear();
      } else {
        // Error Message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to send alert. Check connection.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text('Send Safety Alert'),
        backgroundColor: const Color(0xFFCF4374),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 1. Severity Selector
            const Text(
              'Severity Level / شدت',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _severityOptions[_selectedSeverity]!),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedSeverity,
                  items: _severityOptions.keys.map((String severity) {
                    return DropdownMenuItem<String>(
                      value: severity,
                      child: Row(
                        children: [
                          Icon(
                            Icons.circle,
                            color: _severityOptions[severity],
                            size: 16,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            severity.toUpperCase(),
                            style: TextStyle(
                              color: _severityOptions[severity],
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _selectedSeverity = newValue;
                      });
                    }
                  },
                ),
              ),
            ),

            const SizedBox(height: 24),

            // 2. Message Input
            const Text(
              'Message / پیغام',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _messageController,
              maxLines: 5,
              textDirection: TextDirection.rtl, // Right-to-left for Urdu
              style: GoogleFonts.notoNastaliqUrdu(fontSize: 18, height: 1.5),
              decoration: InputDecoration(
                hintText: 'یہاں پیغام لکھیں...', // "Type message here..."
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFFCF4374)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: Color(0xFFCF4374),
                    width: 2,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 30),

            // 3. Broadcast Button
            SizedBox(
              height: 55,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _broadcastAlert,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.podcasts, color: Colors.white),
                          SizedBox(width: 10),
                          Text(
                            'BROADCAST ALERT',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
