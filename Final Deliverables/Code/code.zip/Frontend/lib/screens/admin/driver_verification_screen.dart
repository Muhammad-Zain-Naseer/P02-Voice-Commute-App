import 'package:flutter/material.dart';
import '../../constants/app_config.dart';
import '../../services/admin_service.dart';
import 'package:hersafar/widgets/photo_viewer_dialog.dart';

class DriverVerificationScreen extends StatefulWidget {
  final String token;

  const DriverVerificationScreen({super.key, required this.token});

  @override
  State<DriverVerificationScreen> createState() =>
      _DriverVerificationScreenState();
}

class _DriverVerificationScreenState extends State<DriverVerificationScreen> {
  late AdminService _adminService;

  List<dynamic> _drivers = [];
  bool _isLoading = true;
  String _selectedStatus = 'pending';
  String _searchQuery = '';
  int _currentPage = 1;
  int _totalPages = 1;

  // Theme colors (same as your dialog)
  static const Color _bgPink = Color(0xFFFAECF1);
  static const Color _borderPink = Color(0xFFF682AA);
  static const Color _primaryPink = Color(0xFFCF4374);

  @override
  void initState() {
    super.initState();
    _adminService = AdminService();
    _adminService.setToken(widget.token);
    _loadDrivers();
  }

  Future<void> _loadDrivers() async {
    setState(() => _isLoading = true);

    try {
      final response = await _adminService.getDrivers(
        status: _selectedStatus,
        search: _searchQuery.isEmpty ? null : _searchQuery,
        page: _currentPage,
      );

      if (response != null) {
        setState(() {
          _drivers = response['drivers'] ?? [];
          _totalPages = response['pagination']?['pages'] ?? 1;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        _showError('Failed to load drivers');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Error: $e');
    }
  }

  // ======================= THEMED DIALOG BASE =======================

  Future<T?> _themedDialog<T>({
    required IconData icon,
    required String title,
    String? message,
    Widget? body,
    required List<Widget> actions,
    bool barrierDismissible = false,
  }) {
    return showDialog<T>(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: _bgPink,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: _borderPink, width: 2),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.5),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: _primaryPink, size: 50),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _primaryPink,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (message != null) ...[
                const SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: _primaryPink,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
              if (body != null) ...[
                const SizedBox(height: 14),
                body,
              ],
            ],
          ),
          actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          actions: [
            SizedBox(
              width: double.infinity,
              child: Column(
                children: actions,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _primaryBtn(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: _primaryPink,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _secondaryBtn(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: _primaryPink,
          side: const BorderSide(color: _borderPink, width: 2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  Future<bool> _showConfirmDialog(
    String title,
    String message, {
    required IconData icon,
  }) async {
    final res = await _themedDialog<bool>(
      icon: icon,
      title: title,
      message: message,
      actions: [
        _secondaryBtn('Cancel', () => Navigator.pop(context, false)),
        const SizedBox(height: 10),
        _primaryBtn('Confirm', () => Navigator.pop(context, true)),
      ],
    );
    return res ?? false;
  }

  Future<String?> _showReasonDialog(
    String title,
    String hint, {
    required IconData icon,
  }) async {
    final controller = TextEditingController();

    final res = await _themedDialog<String>(
      icon: icon,
      title: title,
      body: TextField(
        controller: controller,
        maxLines: 3,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.85),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _borderPink),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _borderPink),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _primaryPink, width: 2),
          ),
        ),
      ),
      actions: [
        _secondaryBtn('Cancel', () => Navigator.pop(context)),
        const SizedBox(height: 10),
        _primaryBtn('Submit', () => Navigator.pop(context, controller.text)),
      ],
    );

    return res;
  }

  // ======================= VIEW DETAILS (THEMED) =======================

  Future<void> _viewDriverDetails(String driverId) async {
    // Themed loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: _bgPink,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: _borderPink, width: 2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.person_search,
                  color: _primaryPink, size: 50),
            ),
            const SizedBox(height: 16),
            const Text(
              'Loading...',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _primaryPink,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 14),
            const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(_primaryPink),
            ),
          ],
        ),
      ),
    );

    try {
      final driver = await _adminService.getDriverDetails(driverId);
      if (!mounted) return;
      Navigator.pop(context); // close loading

      if (driver != null) {
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) => _buildDriverDetailsDialog(driver),
        );
      } else {
        _showError('Failed to load driver details');
      }
    } catch (e) {
      if (!mounted) return;
      Navigator.pop(context);
      _showError('Error: $e');
    }
  }

  Future<void> _approveDriver(String driverId, String driverName) async {
    final confirmed = await _showConfirmDialog(
      'Approve Driver',
      'Are you sure you want to approve $driverName?',
      icon: Icons.check_circle_outline, 
    );

    if (confirmed) {
      final success = await _adminService.approveDriver(driverId);
      if (success) {
        _showSuccess('Driver approved successfully');
        _loadDrivers();
      } else {
        _showError('Failed to approve driver');
      }
    }
  }

  Future<void> _rejectDriver(String driverId, String driverName) async {
    final reason = await _showReasonDialog(
      'Reject Driver',
      'Please provide a reason for rejecting $driverName:',
      icon: Icons.cancel_outlined, 
    );

    if (reason != null && reason.isNotEmpty) {
      final success = await _adminService.rejectDriver(driverId, reason);
      if (success) {
        _showSuccess('Driver rejected');
        _loadDrivers();
      } else {
        _showError('Failed to reject driver');
      }
    }
  }

  Future<void> _requestResubmission(String driverId, String driverName) async {
    final notes = await _showReasonDialog(
      'Request Resubmission',
      'What information needs to be resubmitted from $driverName?',
      icon: Icons.refresh, 
    );

    if (notes != null && notes.isNotEmpty) {
      final success = await _adminService.requestResubmission(driverId, notes);
      if (success) {
        _showSuccess('Resubmission requested');
        _loadDrivers();
      } else {
        _showError('Failed to request resubmission');
      }
    }
  }

  Future<void> _suspendDriver(String driverId, String driverName) async {
    final reason = await _showReasonDialog(
      'Suspend Driver',
      'Please provide a reason for suspending $driverName (e.g., forged documents):',
      icon: Icons.warning_amber_rounded, 
    );

    if (reason != null && reason.isNotEmpty) {
      final success = await _adminService.suspendDriver(driverId, reason);
      if (success) {
        _showSuccess('Driver suspended and flagged for investigation');
        _loadDrivers();
      } else {
        _showError('Failed to suspend driver');
      }
    }
  }

  Future<void> _reactivateDriver(String driverId, String driverName) async {
    final confirmed = await _showConfirmDialog(
      'Reactivate Driver',
      'Are you sure you want to reactivate $driverName?',
      icon: Icons.restore, // icon only
    );

    if (confirmed) {
      final success = await _adminService.reactivateDriver(driverId);
      if (success) {
        _showSuccess('Driver reactivated successfully');
        _loadDrivers();
      } else {
        _showError('Failed to reactivate driver');
      }
    }
  }

  Widget _buildDriverDetailsDialog(Map<String, dynamic> driverData) {
    final driver = driverData['driver'];

    return Dialog(
      backgroundColor: _bgPink,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: _borderPink, width: 2),
      ),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 520, maxHeight: 650),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Driver Details',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: _primaryPink,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: _primaryPink),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(color: _borderPink),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Name', driver['name']),
                    _buildDetailRow('Email', driver['email']),
                    _buildDetailRow('CNIC', driver['cnic']),
                    _buildDetailRow('Driving License', driver['drivingLicense']),
                    _buildDetailRow('Status', driver['status']?.toUpperCase()),

                    const SizedBox(height: 16),
                    const Text(
                      'Vehicle Information',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _primaryPink,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildDetailRow(
                      'Registration Number',
                      driver['vehicle']?['registrationNumber'],
                    ),
                    _buildDetailRow('Model', driver['vehicle']?['model']),
                    _buildDetailRow('Color', driver['vehicle']?['color']),
                    _buildDetailRow('Year', driver['vehicle']?['year']),

                    if (driver['vehicle']?['registrationPhoto'] != null) ...[
                      const SizedBox(height: 16),
                      const Text(
                        'Registration Photo',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: _primaryPink,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Builder(
                        builder: (context) {
                          String photoPath =
                              driver['vehicle']['registrationPhoto'] as String;

                          final imageUrl = photoPath.startsWith('http')
                              ? photoPath
                              : '${AppConfig.apiBaseUrl}$photoPath';

                          return GestureDetector(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) => PhotoViewerDialog(
                                  imageUrl: imageUrl,
                                  fileName:
                                      'vehicle_registration_${driver['name']?.replaceAll(' ', '_')}',
                                ),
                              );
                            },
                            child: Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    imageUrl,
                                    height: 200,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    loadingBuilder:
                                        (context, child, loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Container(
                                        height: 200,
                                        decoration: BoxDecoration(
                                          color: Colors.white.withValues(alpha: 0.7),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        child: const Center(
                                          child: CircularProgressIndicator(
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                              _primaryPink,
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        height: 200,
                                        decoration: BoxDecoration(
                                          color: Colors.white.withValues(alpha: 0.7),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        child: Center(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              const Icon(
                                                Icons.broken_image,
                                                size: 48,
                                                color: Colors.grey,
                                              ),
                                              const SizedBox(height: 8),
                                              const Text('Image not available'),
                                              const SizedBox(height: 4),
                                              Text(
                                                'URL: $imageUrl',
                                                style: const TextStyle(
                                                    fontSize: 10),
                                                textAlign: TextAlign.center,
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                Positioned(
                                  top: 8,
                                  right: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withValues(alpha: 0.7),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.zoom_in,
                                            color: Colors.white, size: 16),
                                        SizedBox(width: 4),
                                        Text(
                                          'Tap to view & download',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],

                    if (driver['rejectionReason'] != null) ...[
                      const SizedBox(height: 16),
                      const Text(
                        'Rejection Reason',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(driver['rejectionReason']),
                    ],

                    if (driver['resubmissionNotes'] != null) ...[
                      const SizedBox(height: 16),
                      const Text(
                        'Resubmission Notes',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(driver['resubmissionNotes']),
                    ],

                    if (driver['suspensionReason'] != null) ...[
                      const SizedBox(height: 16),
                      const Text(
                        'Suspension Reason',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(driver['suspensionReason']),
                    ],

                    const SizedBox(height: 14),
                    _primaryBtn('OK', () => Navigator.pop(context)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              '$label:',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: _primaryPink,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value ?? 'N/A',
              style: const TextStyle(color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: _primaryPink,
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Driver Verification',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: _primaryPink,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.refresh,
                        color: _primaryPink,
                        size: 24,
                      ),
                      onPressed: _loadDrivers,
                    ),
                  ],
                ),
              ),

              // Search and Filter
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  children: [
                    TextField(
                      onChanged: (value) {
                        setState(() => _searchQuery = value);
                      },
                      onSubmitted: (value) => _loadDrivers(),
                      decoration: InputDecoration(
                        hintText: 'Search by name, CNIC, license...',
                        prefixIcon: const Icon(Icons.search, color: _primaryPink),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  setState(() => _searchQuery = '');
                                  _loadDrivers();
                                },
                              )
                            : null,
                        filled: true,
                        fillColor: Colors.white.withValues(alpha: 0.8),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildFilterChip('Pending', 'pending'),
                          _buildFilterChip('Approved', 'approved'),
                          _buildFilterChip('Rejected', 'rejected'),
                          _buildFilterChip(
                              'Resubmission', 'resubmission_required'),
                          _buildFilterChip('Suspended', 'suspended'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              Expanded(child: _buildDriverList()),

              if (_totalPages > 1)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.chevron_left),
                        color: _primaryPink,
                        onPressed: _currentPage > 1
                            ? () {
                                setState(() => _currentPage--);
                                _loadDrivers();
                              }
                            : null,
                      ),
                      Text(
                        'Page $_currentPage of $_totalPages',
                        style: const TextStyle(
                          color: _primaryPink,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.chevron_right),
                        color: _primaryPink,
                        onPressed: _currentPage < _totalPages
                            ? () {
                                setState(() => _currentPage++);
                                _loadDrivers();
                              }
                            : null,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String value) {
    final isSelected = _selectedStatus == value;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (selected) {
          setState(() {
            _selectedStatus = value;
            _currentPage = 1;
          });
          _loadDrivers();
        },
        backgroundColor: Colors.white.withValues(alpha: 0.8),
        selectedColor: _primaryPink,
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : _primaryPink,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _buildDriverList() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(_primaryPink),
        ),
      );
    }
    if (_drivers.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox, size: 64, color: _primaryPink.withValues(alpha: 0.5)),
            const SizedBox(height: 16),
            const Text(
              'No drivers found',
              style: TextStyle(fontSize: 18, color: _primaryPink),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _drivers.length,
      itemBuilder: (context, index) => _buildDriverCard(_drivers[index]),
    );
  }

  Widget _buildDriverCard(Map<String, dynamic> driver) {
    final status = driver['status'] ?? 'pending';
    final statusColor = _getStatusColor(status);
    final driverId = driver['_id'];
    final driverName = driver['name'] ?? 'Unknown';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 4,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(Icons.local_taxi, color: statusColor, size: 28),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      driverName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _primaryPink,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      driver['email'] ?? '',
                      style: TextStyle(
                        fontSize: 12,
                        color: _primaryPink.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  status.replaceAll('_', ' ').toUpperCase(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 8),

          Row(
            children: [
              Expanded(child: _buildInfoItem('CNIC', driver['cnic'] ?? 'N/A')),
              Expanded(
                child: _buildInfoItem(
                    'License', driver['drivingLicense'] ?? 'N/A'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildInfoItem(
            'Vehicle',
            '${driver['vehicle']?['model'] ?? 'N/A'} - ${driver['vehicle']?['registrationNumber'] ?? 'N/A'}',
          ),

          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _viewDriverDetails(driverId),
                  icon: const Icon(Icons.visibility, size: 18),
                  label: const Text('View Details'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2196F3),
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (status == 'pending') ...[
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _approveDriver(driverId, driverName),
                    icon: const Icon(Icons.check, size: 18),
                    label: const Text('Approve'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4CAF50),
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ],
          ),

          if (status == 'pending') ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _rejectDriver(driverId, driverName),
                    icon: const Icon(Icons.close, size: 18),
                    label: const Text('Reject'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFF44336),
                      side: const BorderSide(color: Color(0xFFF44336)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _requestResubmission(driverId, driverName),
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('Resubmit'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFFF9800),
                      side: const BorderSide(color: Color(0xFFFF9800)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => _suspendDriver(driverId, driverName),
                icon: const Icon(Icons.block, size: 18),
                label: const Text('Suspend (Fraud)'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.black,
                  side: const BorderSide(color: Colors.black),
                ),
              ),
            ),
          ],

          if (status == 'suspended') ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _reactivateDriver(driverId, driverName),
                icon: const Icon(Icons.restore, size: 18),
                label: const Text('Reactivate'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4CAF50),
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: _primaryPink.withValues(alpha: 0.7),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: _primaryPink,
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'approved':
        return const Color(0xFF4CAF50);
      case 'rejected':
        return const Color(0xFFF44336);
      case 'pending':
        return const Color(0xFFFF9800);
      case 'resubmission_required':
        return const Color(0xFF2196F3);
      case 'suspended':
        return Colors.black;
      default:
        return const Color(0xFF9E9E9E);
    }
  }
}

