import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import "../../services/ride_details_sharing_service.dart";
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';

class ShareRideScreen extends StatefulWidget {
  final String rideId;
  final Map<String, dynamic> rideDetails;
  final String userToken;

  const ShareRideScreen({
    super.key,
    required this.rideId,
    required this.rideDetails,
    required this.userToken,
  });

  @override
  State<ShareRideScreen> createState() => _ShareRideScreenState();
}

class _ShareRideScreenState extends State<ShareRideScreen> {
  final RideSharingService _rideSharingService = RideSharingService();
  List<Map<String, dynamic>> _trustedContacts = [];
  List<String> _selectedEmails = [];
  bool _isLoading = true;
  bool _selectAll = false;

  bool _isMuted = false;
  bool _isPromptPlaying = false;
  bool _speechCancelled = false;
  Timer? _replayTimer;

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 8), () async {
      if (!_isMuted && !_speechCancelled && !_isPromptPlaying && mounted) {
        await _speakPrompt();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _speakAndWait(String text) async {
    if (_speechCancelled || _isMuted) return;
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled && !_isMuted) {
      await AudioPlayerService.playBytes(audioBytes);
    }
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();
    await _speakAndWait('سواری کی تفصیلات شیئر کریں۔');
    if (_speechCancelled || _isMuted) {
      _isPromptPlaying = false;
      return;
    }
    await _speakAndWait('قابل اعتماد رابطوں کو منتخب کریں اور شیئر کریں بٹن دبائیں۔');
    _isPromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  @override
  void initState() {
    super.initState();
    _loadTrustedContacts();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _speakPrompt();
    });
  }

  @override
  void dispose() {
    _speechCancelled = true;
    _cancelReplayTimer();
    AudioPlayerService.stop();
    super.dispose();
  }

  Future<void> _loadTrustedContacts() async {
    final result = await _rideSharingService.getTrustedContacts(
      userId: widget.userToken,
    );

    if (result['success']) {
      setState(() {
        _trustedContacts = List<Map<String, dynamic>>.from(
          result['contacts'] ?? [],
        );
        _isLoading = false;
      });
    } else {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message'] ?? 'رابطے لوڈ نہیں ہو سکے',
              textDirection: TextDirection.rtl,
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _toggleContact(String email) {
    setState(() {
      if (_selectedEmails.contains(email)) {
        _selectedEmails.remove(email);
      } else {
        _selectedEmails.add(email);
      }
      _selectAll = _selectedEmails.length == _trustedContacts.length;
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selectAll) {
        _selectedEmails.clear();
      } else {
        _selectedEmails = _trustedContacts
            .map((c) => c['email'].toString())
            .toList();
      }
      _selectAll = !_selectAll;
    });
  }

  Future<void> _shareRide() async {
    if (_selectedEmails.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'براہ کرم کم از کم ایک رابطہ منتخب کریں',
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final result = await _rideSharingService.shareRideWithSelectedContacts(
      userId: widget.userToken,
      rideId: widget.rideId,
      rideDetails: widget.rideDetails,
      contactEmails: _selectedEmails,
    );

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      if (result['success']) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: const Color(0xFFFAECF1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: const BorderSide(color: Color(0xFFF682AA), width: 2),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.check_circle,
                  color: Color(0xFFCF4374),
                  size: 60,
                ),
                const SizedBox(height: 20),
                const Text(
                  'سواری کی تفصیلات شیئر ہو گئیں!',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  '${_selectedEmails.length} رابطوں کو ای میل بھیج دی گئی',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Color(0xFFCF4374),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close dialog
                  Navigator.of(context).pop(); // Go back to ride screen
                },
                child: const Text(
                  'ٹھیک ہے',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xFFCF4374),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['message'] ?? 'شیئر کرنے میں ناکامی',
              textDirection: TextDirection.rtl,
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Color(0xFFCF4374),
                      ),
                      onPressed: () {
                        _speechCancelled = true;
                        _cancelReplayTimer();
                        AudioPlayerService.stop();
                        Navigator.pop(context);
                      },
                    ),

                    SvgPicture.asset(
                      'assets/icons/car_icon.svg',
                      width: 60,
                      height: 60,
                    ),

                    const Expanded(
                      child: Text(
                        'سواری کی تفصیلات شیئر کریں',
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _toggleMute,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                          color: const Color(0xFFCF4374),
                          size: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Ride Details Summary
              Container(
                margin: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 10,
                ),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFF682AA), width: 2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _buildDetailRow(
                      'پِک اپ',
                      widget.rideDetails['pickup'] ?? 'N/A',
                    ),
                    const SizedBox(height: 8),
                    _buildDetailRow(
                      'ڈراپ آف',
                      widget.rideDetails['dropoff'] ?? 'N/A',
                    ),
                    const SizedBox(height: 8),
                    _buildDetailRow(
                      'ڈرائیور',
                      widget.rideDetails['driverName'] ?? 'N/A',
                    ),
                  ],
                ),
              ),

              // Select All Checkbox
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 10,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const Text(
                      'سب منتخب کریں',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFCF4374),
                      ),
                    ),
                    Checkbox(
                      value: _selectAll,
                      onChanged: (value) => _toggleSelectAll(),
                      activeColor: const Color(0xFFCF4374),
                    ),
                  ],
                ),
              ),

              // Trusted Contacts List
              Expanded(
                child: _buildContactsList(),
              ),
              _buildShareButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContactsList() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      );
    }
    if (_trustedContacts.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_off, size: 60, color: Color(0xFFCF4374)),
            SizedBox(height: 20),
            Text(
              'کوئی قابل اعتماد رابطہ نہیں',
              textDirection: TextDirection.rtl,
              style: TextStyle(fontSize: 18, color: Color(0xFFCF4374)),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: _trustedContacts.length,
                        itemBuilder: (context, index) {
                          final contact = _trustedContacts[index];
                          final email = contact['email'].toString();
                          final name = contact['name']?.toString() ?? email;
                          final isSelected = _selectedEmails.contains(email);

                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFFF8BBD0)
                                  : Colors.white.withValues(alpha: 0.7),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isSelected
                                    ? const Color(0xFFCF4374)
                                    : const Color(0xFFF682AA),
                                width: 2,
                              ),
                            ),
                            child: CheckboxListTile(
                              value: isSelected,
                              onChanged: (value) => _toggleContact(email),
                              activeColor: const Color(0xFFCF4374),
                              title: Text(
                                name,
                                textDirection: TextDirection.rtl,
                                textAlign: TextAlign.right,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFCF4374),
                                ),
                              ),
                              subtitle: Text(
                                email,
                                textDirection: TextDirection.ltr,
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: const Color(
                                    0xFFCF4374,
                                  ).withValues(alpha: 0.7),
                                ),
                              ),
                              controlAffinity: ListTileControlAffinity.leading,
                            ),
                          );
                        },
                      );
  }

  Widget _buildShareButton() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: GestureDetector(
        onTap: _isLoading ? null : _shareRide,
        child: Container(
          width: double.infinity,
          height: 60,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFCF4374), Color(0xFF69223B)],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                blurRadius: 10,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_isLoading)
                const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  ),
                )
              else ...[
                const Icon(Icons.share, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Text(
                  'شیئر کریں (${_selectedEmails.length})',
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Expanded(
          child: Text(
            value,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
            style: const TextStyle(fontSize: 14, color: Color(0xFFCF4374)),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          '$label:',
          textDirection: TextDirection.rtl,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Color(0xFFCF4374),
          ),
        ),
      ],
    );
  }
}
