import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:http/http.dart' as http;
import '../../widgets/mic_button.dart';
import '../../widgets/sound_wave.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import 'signup_name_screen.dart';

class SignupPinScreen extends StatefulWidget {
  final String email;

  const SignupPinScreen({
    super.key,
    required this.email,
  });

  @override
  State<SignupPinScreen> createState() => _SignupPinScreenState();
}

class _SignupPinScreenState extends State<SignupPinScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;
  bool _isPromptPlaying = false;
  bool _obscurePin = true;

  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _setupAudio();
  }

  void _startPulse() => _pulseController.repeat(reverse: true);
  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    _speechCancelled = false;
    await _speakPrompt();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && !_isMuted && !_isPromptPlaying && mounted) {
        await _speakPrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();
    if (mounted) setState(() => _isSpeaking = true);
    final bytes1 = await VoiceService.textToSpeech('چار ہندسوں کا پن بنائیں');
    if (bytes1 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes1);
    if (_speechCancelled) { if (mounted) setState(() => _isSpeaking = false); _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    final bytes2 = await VoiceService.textToSpeech('یہ پن آپ کے اکاؤنٹ کو محفوظ رکھنے کے لیے استعمال ہوگا');
    if (bytes2 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes2);
    if (_speechCancelled) { if (mounted) setState(() => _isSpeaking = false); _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    final bytes3 = await VoiceService.textToSpeech('بولنے کے لیے مائیکروفون دبائیں');
    if (bytes3 != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes3);
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
    _isPromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _toggleListening() async {
    if (_isInterpreting) return;
    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      await _stopRecordingAndProcess();
      return;
    }
    await _startRecording();
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    _speechCancelled = true;
    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final path = kIsWeb
          ? 'hersafar_signup_pin_voice'
          : '${(await getTemporaryDirectory()).path}/hersafar_signup_pin_voice.wav';

      if (!kIsWeb) {
        final old = File(path);
        if (await old.exists()) await old.delete();
      }

      await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      if (!await _recorder.isRecording()) {
        _startReplayTimer();
        return;
      }

      setState(() => _isListening = true);
      _startPulse();

      _amplitudeTimer = Timer.periodic(const Duration(milliseconds: 500), (t) {
        if (!_isListening) t.cancel();
      });
    } catch (e) {
      debugPrint('=== Signup PIN recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      if (path == null) { _startReplayTimer(); return; }

      setState(() => _isInterpreting = true);

      final Uint8List bytes;
      if (kIsWeb) {
        final response = await http.get(Uri.parse(path));
        bytes = response.bodyBytes;
      } else {
        final file = File(path);
        if (!await file.exists() || (await file.length()) == 0) {
          setState(() => _isInterpreting = false);
          _startReplayTimer();
          return;
        }
        bytes = await file.readAsBytes();
      }

      final pin = await VoiceService.extractPinFromAudio(base64Encode(bytes));
      debugPrint('=== Signup PIN extracted (audio): $pin');
      if (pin != null && pin.isNotEmpty && mounted) {
        setState(() => _pinController.text = pin);
      }
    } catch (e) {
      debugPrint('=== Signup PIN STT error: $e');
    } finally {
      if (mounted) setState(() => _isInterpreting = false);
      _startReplayTimer();
    }
  }

  void _continue() {
    if (_formKey.currentState!.validate()) {
      _speechCancelled = true;
      _cancelReplayTimer();
      AudioPlayerService.stop();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SignupNameScreen(
            email: widget.email,
            pin: _pinController.text,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _speechCancelled = true;
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _recorder.dispose();
    _pinController.dispose();
    super.dispose();
  }

  Widget _buildTopRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Color(0xFFCF4374)),
          onPressed: () {
            _speechCancelled = true;
            _cancelReplayTimer();
            AudioPlayerService.stop();
            Navigator.pop(context);
          },
        ),
        SvgPicture.asset('assets/icons/car_icon.svg', width: 60, height: 60),
        IconButton(
          icon: Icon(_isMuted ? Icons.volume_off : Icons.volume_up, color: const Color(0xFFCF4374)),
          onPressed: _toggleMute,
        ),
      ],
    );
  }


  Widget _buildMicLabel() {
    final String micLabel;
    if (_isListening) {
      micLabel = 'سن رہا ہے...';
    } else if (_isInterpreting) {
      micLabel = 'سمجھ رہا ہے...';
    } else {
      micLabel = 'بولنے کے لیے دبائیں';
    }
    return Text(micLabel, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 13, color: Color(0xFFCF4374)));
  }

  Widget _buildPinField() {
    return Form(
      key: _formKey,
      child: TextFormField(
        controller: _pinController,
        textDirection: TextDirection.ltr,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        obscureText: _obscurePin,
        maxLength: 4,
        style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFFCF4374), letterSpacing: 20),
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        decoration: InputDecoration(
          hintText: '••••',
          hintStyle: TextStyle(color: const Color(0xFFCF4374).withValues(alpha: 0.3), fontSize: 32, letterSpacing: 20),
          counterText: '',
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.7),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFF682AA), width: 1.5)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFF682AA), width: 1.5)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFCF4374), width: 2)),
          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red, width: 1.5)),
          focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red, width: 2)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          suffixIcon: IconButton(
            icon: Icon(
              _obscurePin ? Icons.visibility_off : Icons.visibility,
              color: const Color(0xFFCF4374),
            ),
            onPressed: () => setState(() => _obscurePin = !_obscurePin),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) return 'برائے مہربانی PIN درج کریں';
          if (value.length != 4) return 'PIN 4 ہندسوں کا ہونا ضروری ہے';
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                _buildTopRow(),
                const Spacer(),
                SoundWave(isAnimating: _isSpeaking || _isListening),
                const Spacer(),
                const Text(
                  '4 ہندسوں کا PIN بنائیں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFCF4374)),
                ),
                const Spacer(),
                _buildPinField(),
                const SizedBox(height: 16),
                Text(
                  'یہ PIN آپ کے اکاؤنٹ کو محفوظ رکھنے کے لیے استعمال ہوگا',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: const Color(0xFFCF4374).withValues(alpha: 0.7)),
                ),
                const Spacer(),
                MicButton(
                  isListening: _isListening,
                  isInterpreting: _isInterpreting,
                  pulseAnimation: _pulseAnimation,
                  onTap: _isInterpreting ? null : _toggleListening,
                ),
                const SizedBox(height: 12),
                _buildMicLabel(),
                const SizedBox(height: 30),
                GestureDetector(
                  onTap: _continue,
                  child: Container(
                    width: 200,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: const Color(0xFFCF4374).withValues(alpha: 0.3), blurRadius: 10, spreadRadius: 2)],
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('اگلا', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                        SizedBox(width: 8),
                        Icon(Icons.arrow_forward, color: Colors.white, size: 24),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
                ),
              ),
          ),
        ),
      ),
    );
  }
}
