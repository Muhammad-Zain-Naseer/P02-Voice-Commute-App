import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:http/http.dart' as http;
import '../../widgets/mic_button.dart';
import '../../widgets/sound_wave.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import '../../services/auth_service.dart';
import 'login_pin_screen.dart';

class LoginEmailScreen extends StatefulWidget {
  const LoginEmailScreen({super.key});

  @override
  State<LoginEmailScreen> createState() => _LoginEmailScreenState();
}

class _LoginEmailScreenState extends State<LoginEmailScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _isCheckingEmail = false;
  bool _speechCancelled = false;
  bool _isPromptPlaying = false;
  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _setupAudio();
  }

  void _startPulse() => _pulseController.repeat(reverse: true);
  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    _speechCancelled = false;
    await _speakPrompt();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && !_isMuted && !_isPromptPlaying && mounted) {
        await _speakPrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<bool> _playTtsOrCancel(String text) async {
    if (_speechCancelled) {
      if (mounted) setState(() => _isSpeaking = false);
      return false;
    }
    final bytes = await VoiceService.textToSpeech(text);
    if (bytes != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes);
    if (_speechCancelled) {
      if (mounted) setState(() => _isSpeaking = false);
      return false;
    }
    return true;
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();
    if (mounted) setState(() => _isSpeaking = true);
    if (!await _playTtsOrCancel('لاگ ان کریں')) { _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    if (!await _playTtsOrCancel('اپنا ای میل درج کریں')) { _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    await _playTtsOrCancel('بولنے کے لیے مائیکروفون دبائیں');
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
    _isPromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _toggleListening() async {
    if (_isInterpreting) return;
    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      await _stopRecordingAndProcess();
      return;
    }
    await _startRecording();
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    _speechCancelled = true;
    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final path = kIsWeb
          ? 'hersafar_login_email_voice'
          : '${(await getTemporaryDirectory()).path}/hersafar_login_email_voice.wav';

      if (!kIsWeb) {
        final old = File(path);
        if (await old.exists()) await old.delete();
      }

      await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      if (!await _recorder.isRecording()) {
        _startReplayTimer();
        return;
      }

      setState(() => _isListening = true);
      _startPulse();

      _amplitudeTimer =
          Timer.periodic(const Duration(milliseconds: 500), (t) {
        if (!_isListening) t.cancel();
      });

      // No auto-stop — user taps mic again to stop
    } catch (e) {
      debugPrint('=== Login email recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      if (path == null) { _startReplayTimer(); return; }

      setState(() => _isInterpreting = true);

      final Uint8List bytes;
      if (kIsWeb) {
        final response = await http.get(Uri.parse(path));
        bytes = response.bodyBytes;
      } else {
        final file = File(path);
        if (!await file.exists() || (await file.length()) == 0) {
          setState(() => _isInterpreting = false);
          _startReplayTimer();
          return;
        }
        bytes = await file.readAsBytes();
      }

      final email = await VoiceService.extractEmailFromAudio(base64Encode(bytes));
      debugPrint('=== Login email extracted (audio): $email');
      if (email != null && email.isNotEmpty && mounted) {
        setState(() => _emailController.text = email);
      }
    } catch (e) {
      debugPrint('=== Login email STT error: $e');
    } finally {
      if (mounted) setState(() => _isInterpreting = false);
      _startReplayTimer();
    }
  }

  Future<void> _continue() async {
    if (!_formKey.currentState!.validate()) return;
    _speechCancelled = true;
    _cancelReplayTimer();
    await AudioPlayerService.stop();
    if (!mounted) return;

    setState(() => _isCheckingEmail = true);
    final email = _emailController.text.trim();
    final exists = await AuthService().checkEmail(email);
    if (!mounted) return;
    setState(() => _isCheckingEmail = false);

    if (!exists) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text(
          'یہ ای میل رجسٹر نہیں ہے',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Colors.red,
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LoginPinScreen(email: email),
      ),
    );
  }

  @override
  void dispose() {
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _emailController.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Widget _buildTopRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Color(0xFFCF4374), size: 24),
          onPressed: () {
            _speechCancelled = true;
            _cancelReplayTimer();
            AudioPlayerService.stop();
            Navigator.pop(context);
          },
        ),
        SvgPicture.asset('assets/icons/car_icon.svg', width: 70, height: 70),
        GestureDetector(
          onTap: _toggleMute,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: Icon(_isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: const Color(0xFFCF4374), size: 24),
          ),
        ),
      ],
    );
  }


  Widget _buildMicLabel() {
    final String micLabel;
    if (_isInterpreting) {
      micLabel = 'سمجھ رہی ہوں...';
    } else if (_isListening) {
      micLabel = 'سن رہی ہوں...';
    } else {
      micLabel = 'بولنے کے لیے دبائیں';
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Text(
        micLabel,
        key: ValueKey('$_isListening$_isInterpreting'),
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontSize: 14,
          color: (_isListening || _isInterpreting) ? const Color(0xFF8B1A4A) : const Color(0xFFCF4374),
          fontWeight: (_isListening || _isInterpreting) ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
                  child: Column(
                    children: [
                _buildTopRow(),

                const SizedBox(height: 30),

                SoundWave(isAnimating: _isSpeaking || _isListening),

                const SizedBox(height: 40),

                const Text(
                  'لاگ ان کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 8),

                const Text(
                  'اپنا ای میل درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFFCF4374),
                  ),
                ),

                const SizedBox(height: 30),

                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _emailController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.emailAddress,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 16, color: Color(0xFFCF4374)),
                    decoration: InputDecoration(
                      hintText: 'example@email.com',
                      hintStyle: TextStyle(
                          color: const Color(0xFFCF4374).withValues(alpha: 0.4),
                          fontSize: 16),
                      filled: true,
                      fillColor: Colors.white.withValues(alpha: 0.8),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFF682AA), width: 1.5),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFF682AA), width: 1.5),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Color(0xFFCF4374), width: 2),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                            color: Colors.red, width: 1.5),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 2),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 18),
                      errorStyle: const TextStyle(height: 0),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) return '';
                      final emailRegex =
                          RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');
                      if (!emailRegex.hasMatch(value.trim())) return '';
                      return null;
                    },
                  ),
                ),

                const SizedBox(height: 40),

                Column(
                  children: [
                    MicButton(
                      isListening: _isListening,
                      isInterpreting: _isInterpreting,
                      pulseAnimation: _pulseAnimation,
                      onTap: _isInterpreting ? null : _toggleListening,
                    ),
                    const SizedBox(height: 16),
                    _buildMicLabel(),
                    const SizedBox(height: 30),
                    GestureDetector(
                      onTap: _isCheckingEmail ? null : _continue,
                      child: Container(
                        width: 200,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFCF4374), Color(0xFF69223B)]),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [BoxShadow(color: const Color(0xFFCF4374).withValues(alpha: 0.3), blurRadius: 10, spreadRadius: 2)],
                        ),
                        child: _isCheckingEmail
                            ? const Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)))
                            : const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('اگلا', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                            SizedBox(width: 8),
                            Icon(Icons.arrow_forward, color: Colors.white, size: 24),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 25),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
