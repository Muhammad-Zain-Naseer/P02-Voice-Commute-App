import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import '../../../services/driver_auth_service.dart';
import '../../../widgets/sound_wave.dart';
import '../../../constants/app_config.dart';

// Upper case text formatter
class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    return TextEditingValue(
      text: newValue.text.toUpperCase(),
      selection: newValue.selection,
    );
  }
}

class _TextFieldConfig {
  final String hintText;
  final bool hasIssue;
  final String? Function(String?) validator;
  final TextDirection textDirection;
  final TextInputType keyboardType;
  final bool autoCapitalize;
  final Function(String)? onChanged;

  const _TextFieldConfig({
    required this.hintText,
    required this.hasIssue,
    required this.validator,
    this.textDirection = TextDirection.rtl,
    this.keyboardType = TextInputType.text,
    this.autoCapitalize = false,
    this.onChanged,
  });
}

class DriverResubmissionScreen extends StatefulWidget {
  final String token;
  final Map<String, dynamic> driverData;
  final String adminMessage;

  const DriverResubmissionScreen({
    super.key,
    required this.token,
    required this.driverData,
    required this.adminMessage,
  });

  @override
  State<DriverResubmissionScreen> createState() =>
      _DriverResubmissionScreenState();
}

class _DriverResubmissionScreenState extends State<DriverResubmissionScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _cnicController = TextEditingController();
  final TextEditingController _licenseController = TextEditingController();
  final TextEditingController _registrationController = TextEditingController();
  final TextEditingController _modelController = TextEditingController();
  final TextEditingController _yearController = TextEditingController();
  final TextEditingController _colorController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  
  bool _isLoading = false;
  XFile? _registrationPhoto;
  final ImagePicker _picker = ImagePicker();

  bool _nameIssue = false;
  bool _cnicIssue = false;
  bool _licenseIssue = false;
  bool _vehicleIssue = false;
  bool _registrationPhotoIssue = false;

  static const Color _bgPink = Color(0xFFFAECF1);
  static const Color _borderPink = Color(0xFFF682AA);
  static const Color _primaryPink = Color(0xFFCF4374);
  static const Color _errorRed = Colors.red;

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _analyzeAdminMessage();
  }

  void _initializeControllers() {
    final driver = widget.driverData;
    _nameController.text = driver['name'] ?? '';
    _cnicController.text = _formatCnic(driver['cnic'] ?? '');
    _licenseController.text = _formatLicense(driver['drivingLicense'] ?? '');
    
    if (driver['vehicle'] != null) {
      _registrationController.text = driver['vehicle']['registrationNumber'] ?? '';
      _modelController.text = driver['vehicle']['model'] ?? '';
      _yearController.text = driver['vehicle']['year'] ?? '';
      _colorController.text = driver['vehicle']['color'] ?? '';
    }
  }

  void _analyzeAdminMessage() {
    final message = widget.adminMessage.toLowerCase();
    if (message.contains('name') || message.contains('نام')) _nameIssue = true;
    if (message.contains('cnic') || message.contains('شناختی')) _cnicIssue = true;
    if (message.contains('license') || message.contains('لائسنس')) _licenseIssue = true;
    if (message.contains('vehicle') || message.contains('گاڑی')) _vehicleIssue = true;
    if (message.contains('photo') || message.contains('تصویر')) _registrationPhotoIssue = true;
    
    if (!_nameIssue && !_cnicIssue && !_licenseIssue && !_vehicleIssue && !_registrationPhotoIssue) {
      _nameIssue = _cnicIssue = _licenseIssue = _vehicleIssue = _registrationPhotoIssue = true;
    }
  }

  String _formatCnic(String value) {
    String digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length > 13) digits = digits.substring(0, 13);
    if (digits.length > 12) {
      return '${digits.substring(0, 5)}-${digits.substring(5, 12)}-${digits.substring(12)}';
    } else if (digits.length > 5) { return '${digits.substring(0, 5)}-${digits.substring(5)}'; }
    return digits;
  }

  String _formatLicense(String input) {
    String clean = input.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
    if (clean.length > 3 && clean.length <= 10) {
      return "${clean.substring(0, 3)}-${clean.substring(3)}";
    } else if (clean.length > 10) { return "${clean.substring(0, 3)}-${clean.substring(3, 10)}"; }
    return clean;
  }

  Widget _buildExistingPhotoDisplay() {
    final vehicle = widget.driverData['vehicle'];
    final photoPath = vehicle?['registrationPhoto'];
    if (photoPath == null || photoPath.toString().isEmpty) return const SizedBox.shrink();
    
    final String fullUrl = '${AppConfig.apiBaseUrl.replaceAll('/api', '')}$photoPath';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _primaryPink.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderPink.withValues(alpha: 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(Icons.history, color: _primaryPink, size: 16),
              SizedBox(width: 8),
              Text('موجودہ دستاویز', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: _primaryPink)),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              fullUrl,
              height: 150,
              width: double.infinity,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 150,
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(8)),
                child: Center(child: Icon(Icons.broken_image_outlined, color: _primaryPink.withValues(alpha: 0.4), size: 40)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text('نئی تصویر اپ لوڈ کرنا اختیاری ہے', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 12, color: _primaryPink.withValues(alpha: 0.7), fontStyle: FontStyle.italic)),
        ],
      ),
    );
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 1800, maxHeight: 1800, imageQuality: 85);
      if (image != null) setState(() => _registrationPhoto = image);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تصویر منتخب کرنے میں خرابی'), backgroundColor: Colors.red));
    }
  }

Future<void> _handleSubmissionAttempt() async {
  if (!_formKey.currentState!.validate()) return;

  final bool confirm = await showDialog(
    context: context,
    barrierDismissible: false, // Consistent with your login dialogs
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: _bgPink,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: _borderPink, width: 2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle_outline_rounded,
                color: _primaryPink,
                size: 50,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'تصدیق کریں',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _primaryPink,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _registrationPhotoIssue && _registrationPhoto == null
                  ? 'آپ نے نئی تصویر منتخب نہیں کی ہے۔ کیا آپ موجودہ معلومات کے ساتھ جمع کروانا چاہتے ہیں؟'
                  : 'کیا آپ دی گئی معلومات جمع کروانا چاہتے ہیں؟',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _primaryPink,
                fontSize: 16,
              ),
            ),
          ],
        ),
        actions: [
          Column(
            children: [
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _primaryPink,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'ہاں، جمع کریں',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context, false),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _primaryPink,
                    side: const BorderSide(color: _borderPink, width: 2),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'نہیں',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      );
    },
  ) ?? false;

  if (confirm) {
    _submitResubmission();
  }
}

  Future<void> _submitResubmission() async {
    setState(() => _isLoading = true);
    try {
      final result = await DriverAuthService.resubmitDocuments(
        token: widget.token,
        params: ResubmitDocumentsParams(
          name: _nameController.text.trim(),
          cnic: _cnicController.text.replaceAll('-', ''),
          drivingLicense: _licenseController.text.trim().toUpperCase(),
          registrationNumber: _registrationController.text.trim(),
          model: _modelController.text.trim(),
          year: _yearController.text.trim(),
          color: _colorController.text.trim(),
        ),
        registrationPhoto: _registrationPhoto,
      );

      if (!mounted) return;
      if (result['success']) {
        _showFinalSuccess();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message'] ?? 'دستاویزات جمع نہیں ہوئیں'), backgroundColor: Colors.red));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خرابی: $e'), backgroundColor: Colors.red));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showFinalSuccess() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: _bgPink,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: _borderPink, width: 2)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(padding: const EdgeInsets.all(16), decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle), child: const Icon(Icons.check_circle, color: Colors.green, size: 50)),
            const SizedBox(height: 16),
            const Text('دستاویزات جمع ہو گئیں', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _primaryPink)),
            const SizedBox(height: 8),
            const Text('آپ کی درخواست کا دوبارہ جائزہ لیا جائے گا۔', textDirection: TextDirection.rtl, textAlign: TextAlign.center),
          ],
        ),
        actions: [
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst), style: ElevatedButton.styleFrom(backgroundColor: _primaryPink), child: const Text('ٹھیک ہے', style: TextStyle(color: Colors.white)))),
        ],
      ),
    );
  }

  Widget _buildLabel(String text, bool hasIssue) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, right: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          if (hasIssue) const Icon(Icons.error, color: _errorRed, size: 18),
          const SizedBox(width: 8),
          Text(text, textDirection: TextDirection.rtl, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: hasIssue ? _errorRed : _primaryPink)),
        ],
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    _TextFieldConfig config,
  ) {
    final hintText = config.hintText;
    final validator = config.validator;
    final hasIssue = config.hasIssue;
    final textDirection = config.textDirection;
    final keyboardType = config.keyboardType;
    final autoCapitalize = config.autoCapitalize;
    final onChanged = config.onChanged;
    return TextFormField(
      controller: controller,
      textDirection: textDirection,
      textAlign: TextAlign.center,
      keyboardType: keyboardType,
      enabled: !_isLoading,
      inputFormatters: autoCapitalize ? [UpperCaseTextFormatter()] : null,
      onChanged: onChanged,
      style: const TextStyle(fontSize: 16, color: _primaryPink),
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: hasIssue ? _errorRed.withValues(alpha: 0.1) : Colors.white.withValues(alpha: 0.8),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: hasIssue ? _errorRed : _borderPink)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: hasIssue ? _errorRed : _borderPink)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: hasIssue ? _errorRed : _primaryPink, width: 2)),
      ),
      validator: validator,
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _cnicController.dispose();
    _licenseController.dispose();
    _registrationController.dispose();
    _modelController.dispose();
    _yearController.dispose();
    _colorController.dispose();
    super.dispose();
  }

  Widget _buildAdminMessageBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _errorRed.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _errorRed, width: 2),
      ),
      child: Column(
        children: [
          const Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            Icon(Icons.warning_amber_rounded, color: _errorRed),
            SizedBox(width: 8),
            Text('ایڈمن کا پیغام', textDirection: TextDirection.rtl, style: TextStyle(fontWeight: FontWeight.bold, color: _errorRed)),
          ]),
          const SizedBox(height: 8),
          Text(widget.adminMessage, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: _errorRed)),
        ],
      ),
    );
  }

  Widget _buildVehicleColorYearRow() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _buildLabel('رنگ', _vehicleIssue),
              _buildTextField(_colorController, _TextFieldConfig(hintText: 'سفید', hasIssue: _vehicleIssue, validator: (v) => (v == null || v.isEmpty) ? 'رنگ درج کریں' : null)),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _buildLabel('سال', _vehicleIssue),
              _buildTextField(_yearController, _TextFieldConfig(hintText: '2020', textDirection: TextDirection.ltr, keyboardType: TextInputType.number, hasIssue: _vehicleIssue, validator: (v) => (v != null && int.tryParse(v) != null) ? null : 'درست سال')),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPhotoPicker() {
    final photoLabel = _registrationPhotoIssue ? 'نئی رجسٹریشن دستاویز (ضروری)' : 'نئی رجسٹریشن دستاویز (اختیاری)';
    final bgColor = _registrationPhotoIssue ? _errorRed.withValues(alpha: 0.1) : Colors.white.withValues(alpha: 0.8);
    final borderColor = _registrationPhotoIssue ? _errorRed : _borderPink;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _buildLabel(photoLabel, _registrationPhotoIssue),
        GestureDetector(
          onTap: _isLoading ? null : _pickImage,
          child: Container(
            width: double.infinity,
            height: 160,
            decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(12), border: Border.all(color: borderColor, width: 1.5)),
            child: _buildPhotoPickerChild(),
          ),
        ),
      ],
    );
  }

  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _handleSubmissionAttempt,
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [_primaryPink, Color(0xFF69223B)]), borderRadius: BorderRadius.circular(12)),
        child: Center(
          child: _isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : const Text('دستاویزات جمع کروائیں', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      ),
    );
  }

  List<Widget> _buildPersonalInfoSection() {
    return [
      _buildLabel('نام', _nameIssue),
      _buildTextField(_nameController, _TextFieldConfig(hintText: 'نام', hasIssue: _nameIssue, validator: (v) => (v == null || v.isEmpty) ? 'نام درج کریں' : null)),
      const SizedBox(height: 16),
      _buildLabel('شناختی کارڈ نمبر', _cnicIssue),
      _buildTextField(_cnicController, _TextFieldConfig(hintText: '00000-0000000-0', textDirection: TextDirection.ltr, keyboardType: TextInputType.number, hasIssue: _cnicIssue, onChanged: (v) {
        final f = _formatCnic(v);
        if (f != v) _cnicController.value = TextEditingValue(text: f, selection: TextSelection.collapsed(offset: f.length));
      }, validator: (v) => (v != null && v.replaceAll('-', '').length == 13) ? null : '13 ہندسے درکار ہیں')),
      const SizedBox(height: 16),
      _buildLabel('ڈرائیونگ لائسنس نمبر', _licenseIssue),
      _buildTextField(_licenseController, _TextFieldConfig(hintText: 'LHR-1234567', textDirection: TextDirection.ltr, autoCapitalize: true, hasIssue: _licenseIssue, validator: (v) => (v != null && v.replaceAll('-', '').length == 10) ? null : 'لائسنس 10 حروف کا ہونا چاہیے')),
      const SizedBox(height: 20),
    ];
  }

  List<Widget> _buildVehicleInfoSection() {
    return [
      const Divider(color: _borderPink, thickness: 1.5),
      const Text('گاڑی کی تفصیلات', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _primaryPink)),
      const SizedBox(height: 16),
      _buildLabel('رجسٹریشن نمبر', _vehicleIssue),
      _buildTextField(_registrationController, _TextFieldConfig(hintText: 'ABC-123', textDirection: TextDirection.ltr, autoCapitalize: true, hasIssue: _vehicleIssue, validator: (v) => (v == null || v.isEmpty) ? 'رجسٹریشن نمبر درج کریں' : null)),
      const SizedBox(height: 16),
      _buildLabel('گاڑی کا ماڈل', _vehicleIssue),
      _buildTextField(_modelController, _TextFieldConfig(hintText: 'HONDA CIVIC', autoCapitalize: true, hasIssue: _vehicleIssue, validator: (v) => (v == null || v.isEmpty) ? 'ماڈل درج کریں' : null)),
      const SizedBox(height: 16),
      _buildVehicleColorYearRow(),
      const SizedBox(height: 24),
      _buildExistingPhotoDisplay(),
      _buildPhotoPicker(),
      const SizedBox(height: 30),
      _buildSubmitButton(),
      const SizedBox(height: 30),
    ];
  }

  Widget _buildFormContent() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          ..._buildPersonalInfoSection(),
          ..._buildVehicleInfoSection(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)])),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(width: 48),
                    SvgPicture.asset('assets/icons/car_icon.svg', width: 60, height: 60),
                    IconButton(icon: const Icon(Icons.arrow_forward_ios, color: _primaryPink), onPressed: () => Navigator.pop(context)),
                  ],
                ),
              ),
              const SoundWave(),
              const SizedBox(height: 20),
              const Text('دستاویزات دوبارہ جمع کروائیں', textDirection: TextDirection.rtl, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _primaryPink)),
              const SizedBox(height: 16),
              _buildAdminMessageBanner(),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: _buildFormContent(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPhotoPickerChild() {
    if (_registrationPhoto == null) {
      final iconColor = _registrationPhotoIssue
          ? _errorRed
          : _primaryPink.withValues(alpha: 0.6);
      final textColor = _registrationPhotoIssue ? _errorRed : _primaryPink;
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.description_outlined, size: 45, color: iconColor),
          const SizedBox(height: 12),
          Text(
            'نئی تصویر منتخب کریں',
            textDirection: TextDirection.rtl,
            style: TextStyle(
                fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
          ),
        ],
      );
    }
    final imageWidget = kIsWeb
        ? Image.network(_registrationPhoto!.path, fit: BoxFit.contain)
        : Image.file(File(_registrationPhoto!.path), fit: BoxFit.contain);
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            width: double.infinity,
            height: 160,
            child: imageWidget,
          ),
        ),
        Positioned(
          top: 8,
          right: 8,
          child: GestureDetector(
            onTap: () => setState(() => _registrationPhoto = null),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: const BoxDecoration(
                  color: Colors.red, shape: BoxShape.circle),
              child: const Icon(Icons.close, color: Colors.white, size: 20),
            ),
          ),
        ),
      ],
    );
  }
}