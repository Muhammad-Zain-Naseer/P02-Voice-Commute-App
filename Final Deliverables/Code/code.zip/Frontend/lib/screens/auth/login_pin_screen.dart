import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:http/http.dart' as http;
import '../../widgets/mic_button.dart';
import '../../widgets/sound_wave.dart';
import '../../widgets/custom_button.dart';
import '../../services/auth_service.dart';
import '../../services/admin_service.dart';
import '../../services/voice_service.dart';
import '../../services/audio_player_service.dart';
import '../home_screen.dart';
import '../../services/storage_service.dart';
import '../admin/admin_home_screen.dart';
import '../driver/driver_dashboard.dart';
import '../auth/driverSignup/driver_resubmission_screen.dart';

class LoginPinScreen extends StatefulWidget {
  final String email;

  const LoginPinScreen({super.key, required this.email});

  @override
  State<LoginPinScreen> createState() => _LoginPinScreenState();
}

class _LoginPinScreenState extends State<LoginPinScreen>
    with SingleTickerProviderStateMixin {
  static const String _okText = 'ٹھیک ہے';
  static const String _backHomeText = 'واپس ہوم اسکرین';
  final TextEditingController _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final AudioRecorder _recorder = AudioRecorder();

  bool _isLoading = false;
  bool _isSpeaking = false;
  bool _obscurePin = true;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;
  bool _isPromptPlaying = false;

  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _setupAudio();
  }

  void _startPulse() => _pulseController.repeat(reverse: true);
  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    _speechCancelled = false;
    await _speakPrompt();
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      if (!_isSpeaking && !_isListening && !_isInterpreting && !_isMuted && !_isPromptPlaying && mounted) {
        await _speakPrompt();
        _startReplayTimer();
      }
    });
  }

  void _cancelReplayTimer() {
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<bool> _playTtsOrCancel(String text) async {
    if (_speechCancelled) {
      if (mounted) setState(() => _isSpeaking = false);
      return false;
    }
    final bytes = await VoiceService.textToSpeech(text);
    if (bytes != null && !_speechCancelled) await AudioPlayerService.playBytes(bytes);
    if (_speechCancelled) {
      if (mounted) setState(() => _isSpeaking = false);
      return false;
    }
    return true;
  }

  Future<void> _speakPrompt() async {
    if (_isMuted || _speechCancelled || _isPromptPlaying) return;
    _isPromptPlaying = true;
    _cancelReplayTimer();
    if (mounted) setState(() => _isSpeaking = true);
    if (!await _playTtsOrCancel('لاگ ان کریں')) { _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    if (!await _playTtsOrCancel('اپنا پن درج کریں')) { _isPromptPlaying = false; return; }
    await Future.delayed(const Duration(milliseconds: 200));
    await _playTtsOrCancel('بولنے کے لیے مائیکروفون دبائیں');
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
    _isPromptPlaying = false;
    if (mounted && !_speechCancelled && !_isMuted) _startReplayTimer();
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    if (_isMuted) {
      _speechCancelled = true;
      await AudioPlayerService.stop();
      setState(() => _isSpeaking = false);
      _cancelReplayTimer();
    } else {
      _speechCancelled = false;
      await _speakPrompt();
    }
  }

  Future<void> _toggleListening() async {
    if (_isInterpreting) return;
    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      await _stopRecordingAndProcess();
      return;
    }
    await _startRecording();
  }

  Future<void> _startRecording() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    _speechCancelled = true;
    _cancelReplayTimer();
    await AudioPlayerService.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final path = kIsWeb
          ? 'hersafar_login_pin_voice'
          : '${(await getTemporaryDirectory()).path}/hersafar_login_pin_voice.wav';

      if (!kIsWeb) {
        final old = File(path);
        if (await old.exists()) await old.delete();
      }

      await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      if (!await _recorder.isRecording()) {
        _startReplayTimer();
        return;
      }

      setState(() => _isListening = true);
      _startPulse();

      _amplitudeTimer = Timer.periodic(const Duration(milliseconds: 500), (t) {
        if (!_isListening) t.cancel();
      });
    } catch (e) {
      debugPrint('=== Login PIN recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      if (path == null) { _startReplayTimer(); return; }

      setState(() => _isInterpreting = true);

      final Uint8List bytes;
      if (kIsWeb) {
        final response = await http.get(Uri.parse(path));
        bytes = response.bodyBytes;
      } else {
        final file = File(path);
        if (!await file.exists() || (await file.length()) == 0) {
          setState(() => _isInterpreting = false);
          _startReplayTimer();
          return;
        }
        bytes = await file.readAsBytes();
      }

      final pin = await VoiceService.extractPinFromAudio(base64Encode(bytes));
      debugPrint('=== Login PIN extracted (audio): $pin');
      if (pin != null && pin.isNotEmpty && mounted) {
        setState(() => _pinController.text = pin);
      }
    } catch (e) {
      debugPrint('=== Login PIN STT error: $e');
    } finally {
      if (mounted) setState(() => _isInterpreting = false);
      _startReplayTimer();
    }
  }

  Future<void> _navigateAfterLogin(Map<String, dynamic> result) async {
    await StorageService.saveUserData(result['data']);
    if (!mounted) return;
    final user = result['data']['user'];
    final userName = user['name'] ?? 'User';
    final userEmail = user['email'] ?? widget.email;
    final userId = user['id'] ?? '';
    final userRole = user['role'] ?? 'commuter';

    if (userRole == 'driver') {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => const DriverDashboard()));
    } else if (userRole == 'admin') {
      final token = result['data']['token'] ?? '';
      final adminService = AdminService();
      adminService.setToken(token);
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => AdminHomeScreen(
                  userName: userName, userEmail: userEmail, token: token)));
    } else {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => HomeScreen(
                  userName: userName, userEmail: userEmail, userId: userId)));
    }
  }

  bool _handleDriverSpecificError(String m, Map<String, dynamic> result) {
    if (m.contains('driver profile not found')) {
      _showDriverProfileMissingDialog();
      return true;
    }
    if (m.contains('wait for admin') || m.contains('admin to verify')) {
      _showDriverPendingDialog();
      return true;
    }
    if (m.contains('rejected')) {
      _showDriverRejectedDialog();
      return true;
    }
    if (m.contains('driver account has been suspended')) {
      _showDriverSuspendedDialog();
      return true;
    }
    return false;
  }

  void _handleLoginFailure(Map<String, dynamic> result) {
    if (result['requiresResubmission'] == true && result['data'] != null) {
      _showDriverResubmissionDialog(result['data']);
      return;
    }
    final message = (result['message'] ?? 'لاگ ان ناکام').toString();
    final m = message.toLowerCase();
    if (m.contains('verify your email') || m.contains('تصدیق')) {
      _showVerificationDialog();
    } else if (m.contains('invalid') || m.contains('غلط')) {
      _showInvalidCredentialsDialog();
    } else if (_handleDriverSpecificError(m, result)) {
      return;
    } else if (m.contains('suspended by an administrator') ||
        m.contains('account has been suspended')) {
      _showAccountSuspendedDialog(result['reason']?.toString());
    } else if (m.contains('deactivated by an administrator') ||
        m.contains('account has been deactivated')) {
      _showAccountDeactivatedDialog(result['reason']?.toString());
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(message, textDirection: TextDirection.rtl),
        backgroundColor: Colors.red,
      ));
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    try {
      final authService = AuthService();
      final result = await authService.login(
        email: widget.email,
        pin: _pinController.text,
      );
      setState(() => _isLoading = false);
      if (!mounted) return;
      if (result['success']) {
        await _navigateAfterLogin(result);
      } else {
        _handleLoginFailure(result);
      }
    } catch (e) {
      debugPrint('🔴 [LOGIN PIN] Exception: $e');
      setState(() => _isLoading = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('کوئی خرابی پیش آگئی: $e', textDirection: TextDirection.rtl),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  void dispose() {
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _pinController.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Widget _buildTopRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Color(0xFFCF4374), size: 24),
          onPressed: () {
            _speechCancelled = true;
            _cancelReplayTimer();
            AudioPlayerService.stop();
            Navigator.pop(context);
          },
        ),
        SvgPicture.asset('assets/icons/car_icon.svg', width: 70, height: 70),
        GestureDetector(
          onTap: _toggleMute,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: Icon(_isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: const Color(0xFFCF4374), size: 24),
          ),
        ),
      ],
    );
  }


  Widget _buildMicLabel() {
    final String micLabel;
    if (_isInterpreting) {
      micLabel = 'سمجھ رہی ہوں...';
    } else if (_isListening) {
      micLabel = 'سن رہی ہوں...';
    } else {
      micLabel = 'بولنے کے لیے دبائیں';
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Text(
        micLabel,
        key: ValueKey('$_isListening$_isInterpreting'),
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontSize: 14,
          color: (_isListening || _isInterpreting) ? const Color(0xFF8B1A4A) : const Color(0xFFCF4374),
          fontWeight: (_isListening || _isInterpreting) ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32.0, vertical: 20.0),
            child: Column(
              children: [
                _buildTopRow(),
                const SizedBox(height: 30),
                SoundWave(isAnimating: _isSpeaking || _isListening),
                const Spacer(),
                const Text(
                  'اپنا PIN درج کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const Spacer(),
                Form(
                  key: _formKey,
                  child: TextFormField(
                    controller: _pinController,
                    textDirection: TextDirection.ltr,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    obscureText: _obscurePin,
                    maxLength: 4,
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                      letterSpacing: 20,
                    ),
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: InputDecoration(
                      hintText: '••••',
                      hintStyle: TextStyle(
                        color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                        fontSize: 32,
                        letterSpacing: 20,
                      ),
                      counterText: '',
                      filled: true,
                      fillColor: Colors.white.withValues(alpha: 0.7),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFFF682AA), width: 1.5),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFFF682AA), width: 1.5),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Color(0xFFCF4374), width: 2),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 1.5),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            const BorderSide(color: Colors.red, width: 2),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                      errorStyle: const TextStyle(height: 0),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePin ? Icons.visibility_off : Icons.visibility,
                          color: const Color(0xFFCF4374),
                        ),
                        onPressed: () => setState(() => _obscurePin = !_obscurePin),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) return '';
                      if (value.length != 4) return '';
                      return null;
                    },
                  ),
                ),
                const Spacer(),
                MicButton(
                  isListening: _isListening,
                  isInterpreting: _isInterpreting,
                  pulseAnimation: _pulseAnimation,
                  onTap: _isInterpreting ? null : _toggleListening,
                ),
                const SizedBox(height: 16),
                _buildMicLabel(),
                const SizedBox(height: 30),
                _isLoading
                    ? const CircularProgressIndicator(color: Color(0xFFCF4374))
                    : CustomButton(
                        text: 'لاگ ان کریں',
                        onPressed: _login,
                        height: 56,
                        isPrimary: false,
                        backgroundColor: const Color(0xFFCF4374),
                        textColor: Colors.white,
                        fontSize: 20,
                        isGradient: true,
                      ),
                const SizedBox(height: 25),
              ],
            ),
          ),
                ),
              ),
        ),
      ),
    ),
  );
  }

  // ── Dialogs (unchanged) ────────────────────────────────────────────────────

  void _showVerificationDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.email_outlined,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text('براہ کرم پہلے اپنی ای میل کی تصدیق کریں',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_okText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showInvalidCredentialsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.error_outline,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text('غلط ای میل یا PIN',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _pinController.clear();
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('دوبارہ کوشش کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showDriverPendingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.hourglass_top_rounded,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text(
              'آپ کی درخواست ایڈمن کی تصدیق کے لیے زیرِ جائزہ ہے۔ براہ کرم انتظار کریں۔',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_okText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showDriverRejectedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.block_rounded,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text(
              'آپ کا ڈرائیور اکاؤنٹ منظور نہیں ہوا۔ براہ کرم سپورٹ سے رابطہ کریں۔',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).popUntil((r) => r.isFirst),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_backHomeText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showDriverSuspendedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.pause_circle_outline_rounded,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text(
              'آپ کا ڈرائیور اکاؤنٹ معطل ہے۔ براہ کرم سپورٹ سے رابطہ کریں۔',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_okText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showDriverResubmissionDialog(Map<String, dynamic> loginData) {
    final token = loginData['token'] ?? '';
    final driverData = loginData['driver'] ?? {};
    final adminMessage =
        driverData['adminMessage'] ?? 'براہ کرم اپنی دستاویزات درست کریں';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.description_outlined,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text('دستاویزات دوبارہ جمع کروائیں',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('آپ کے ڈاکومنٹس میں مسئلہ ہے۔ براہ کرم دوبارہ جمع کروائیں۔',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 16,
                  fontWeight: FontWeight.w500)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => DriverResubmissionScreen(
                        token: token,
                        driverData: driverData,
                        adminMessage: adminMessage)));
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('دستاویزات درست کریں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFCF4374),
                  side: const BorderSide(color: Color(0xFFF682AA), width: 2),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('بعد میں',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showDriverProfileMissingDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.person_off_outlined,
                color: Color(0xFFCF4374), size: 50),
          ),
          const SizedBox(height: 20),
          const Text(
              'ڈرائیور پروفائل نہیں ملا۔ براہ کرم دوبارہ سائن اپ کریں یا سپورٹ سے رابطہ کریں۔',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).popUntil((r) => r.isFirst),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFCF4374),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_backHomeText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showAccountSuspendedDialog(String? reason) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.block, color: Colors.red, size: 50),
          ),
          const SizedBox(height: 20),
          const Text('آپ کا اکاؤنٹ معطل کر دیا گیا ہے',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('سپورٹ سے رابطہ کریں براہ کرم',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 16,
                  fontWeight: FontWeight.w500)),
          if (reason != null && reason.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: Colors.red.withValues(alpha: 0.3)),
              ),
              child: Column(children: [
                const Text('وجہ:',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                        color: Colors.red,
                        fontSize: 14,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(reason,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style:
                        const TextStyle(color: Colors.red, fontSize: 14)),
              ]),
            ),
          ],
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).popUntil((r) => r.isFirst),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_backHomeText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _showAccountDeactivatedDialog(String? reason) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFFFAECF1),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFF682AA), width: 2)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.5), shape: BoxShape.circle),
            child: const Icon(Icons.cancel_outlined,
                color: Colors.orange, size: 50),
          ),
          const SizedBox(height: 20),
          const Text('آپ کا اکاؤنٹ غیر فعال کر دیا گیا ہے',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('سپورٹ سے رابطہ کریں براہ کرم',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontSize: 16,
                  fontWeight: FontWeight.w500)),
          if (reason != null && reason.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: Colors.orange.withValues(alpha: 0.3)),
              ),
              child: Column(children: [
                const Text('وجہ:',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                        color: Colors.orange,
                        fontSize: 14,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(reason,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.orange, fontSize: 14)),
              ]),
            ),
          ],
        ]),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).popUntil((r) => r.isFirst),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text(_backHomeText,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}
