import 'package:flutter/material.dart';
import '../models/trip_notification.dart';
import '../services/notification_service.dart';
import '../services/map_service.dart';
import '../utils/logger.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    Logger.log('📱 NotificationsPage opened');
    Logger.log('📊 Current notifications: ${_notificationService.allNotifications.length}');
    Logger.log('📊 Unread count: ${_notificationService.unreadCount}');
    
    // Mark all as read when opening the page
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        _notificationService.markAllAsRead();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textDirection: TextDirection.rtl,
                children: [
                  const Text(
                    'اطلاعات',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      _showClearAllDialog();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.9),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'سب صاف کریں',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Notifications List
            Expanded(
              child: ValueListenableBuilder<List<TripNotification>>(
                valueListenable: _notificationService.notificationStream,
                builder: (context, notifications, _) {
                  Logger.log('🔄 Notifications list updated: ${notifications.length} items');
                  
                  if (notifications.isEmpty) {
                    return _buildEmptyState();
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: notifications.length,
                    itemBuilder: (context, index) {
                      final notification = notifications[index];
                      return _buildNotificationCard(notification);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_off_outlined,
            size: 80,
            color: const Color(0xFFCF4374).withValues(alpha: 0.3),
          ),
          const SizedBox(height: 16),
          const Text(
            'کوئی اطلاع نہیں',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'جب آپ کی نگرانی میں کوئی سواری ہوگی\nتو یہاں اطلاعات آئیں گی',
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(TripNotification notification) {
    IconData icon;
    Color iconColor;
    Color borderColor;

    switch (notification.type) {
      case 'RIDE_STARTED':
        icon = Icons.directions_car;
        iconColor = const Color(0xFFCF4374);
        borderColor = const Color(0xFFCF4374);
        break;
      case 'RIDE_COMPLETED':
        icon = Icons.check_circle;
        iconColor = const Color(0xFFCF4374);
        borderColor = const Color(0xFFCF4374);
        break;
      case 'SOS_ALERT':
        icon = Icons.warning_amber_rounded;
        iconColor = const Color(0xFFFF0000);
        borderColor = const Color(0xFFFF0000);
        break;
      default:
        icon = Icons.info;
        iconColor = const Color(0xFFCF4374);
        borderColor = const Color(0xFFCF4374);
    }

    return GestureDetector(
      onTap: () {
        _notificationService.markAsRead(notification.id);
        _showNotificationDetails(notification);
      },
      child: FutureBuilder<String>(
        future: _getTranslatedDescription(notification),
        builder: (context, snapshot) {
          final displayDescription = snapshot.data ?? notification.description;

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: notification.isRead
                  ? Colors.white.withValues(alpha: 0.7)
                  : Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: borderColor.withValues(alpha: 0.5),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: borderColor.withValues(alpha: 0.2),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                // Icon
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: iconColor, size: 28),
                ),

                const SizedBox(width: 12),

                // Content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        notification.title,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: notification.isRead
                              ? Colors.black87
                              : const Color(0xFFCF4374),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        displayDescription,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black.withValues(alpha: 0.7),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formatTimestamp(notification.timestamp),
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.black.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),

                // Unread indicator
                if (!notification.isRead)
                  Container(
                    width: 10,
                    height: 10,
                    decoration: const BoxDecoration(
                      color: Color(0xFFCF4374),
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<String> _getTranslatedDescription(TripNotification notification) async {
    try {
      final translated = await MapService.translateAddresses(
        source: notification.ride.source.address,
        destination: notification.ride.destination.address,
      );

      final sourceUrdu = translated['source'] ?? notification.ride.source.address;
      final destUrdu = translated['destination'] ?? notification.ride.destination.address;

      // Return translated description based on notification type
      switch (notification.type) {
        case 'RIDE_STARTED':
          return '$sourceUrdu سے $destUrdu';
        case 'RIDE_COMPLETED':
          return 'سواری محفوظ طریقے سے مکمل ہوئی';
        case 'SOS_ALERT':
          return 'فوری مدد کی ضرورت ہے! $sourceUrdu';
        default:
          return notification.description;
      }
    } catch (e) {
      Logger.error('❌ Error translating description: $e');
      return notification.description;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'ابھی';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes} منٹ پہلے';
    } else if (difference.inDays < 1) {
      return '${difference.inHours} گھنٹے پہلے';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} دن پہلے';
    } else {
      return '${timestamp.day}/${timestamp.month}/${timestamp.year}';
    }
  }

  Future<void> _showNotificationDetails(TripNotification notification) async {
    // Translate addresses to Urdu
    String sourceUrdu = notification.ride.source.address;
    String destUrdu = notification.ride.destination.address;

    try {
      final translated = await MapService.translateAddresses(
        source: notification.ride.source.address,
        destination: notification.ride.destination.address,
      );
      sourceUrdu = translated['source'] ?? notification.ride.source.address;
      destUrdu = translated['destination'] ?? notification.ride.destination.address;
    } catch (e) {
      Logger.error('❌ Error translating addresses: $e');
    }

    // Translate SOS message to Urdu if needed
    String sosMessage = notification.ride.sosAlert?.message ?? 'ایمرجنسی الرٹ!';
    if (sosMessage.contains('Emergency')) {
      sosMessage = 'ایمرجنسی SOS مسافر نے متحرک کی';
    }

    if (!mounted) return;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFCF4374),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  notification.title,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 16),
                _buildDetailRow('نام:', notification.commuterName),
                const SizedBox(height: 8),
                _buildDetailRow('شروعات:', sourceUrdu),
                const SizedBox(height: 8),
                _buildDetailRow('منزل:', destUrdu),
                if (notification.ride.driverName != null) ...[
                  const SizedBox(height: 8),
                  _buildDetailRow('ڈرائیور:', notification.ride.driverName!),
                ],
                if (notification.type == 'SOS_ALERT' &&
                    notification.ride.sosAlert != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      sosMessage,
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFCF4374),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'ٹھیک ہے',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      textDirection: TextDirection.rtl,
      children: [
        Text(
          label,
          textDirection: TextDirection.rtl,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFFCF4374),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            value,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.left,
            style: const TextStyle(
              fontSize: 14,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }

  void _showClearAllDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFCF4374),
                width: 2,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.delete_outline,
                  color: Color(0xFFCF4374),
                  size: 50,
                ),
                const SizedBox(height: 16),
                const Text(
                  'کیا آپ سب اطلاعات صاف کرنا چاہتے ہیں؟',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFCF4374),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.black54,
                          size: 32,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _notificationService.clearAll();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                          color: Color(0xFFCF4374),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
