/// Mobile implementation for file operations
/// This file provides real implementations for mobile platforms
library;

export 'dart:io' show File;
export 'package:path_provider/path_provider.dart' show getTemporaryDirectory;
