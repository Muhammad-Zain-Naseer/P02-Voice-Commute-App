/// Stub implementation for web platform
/// This file provides empty implementations for file operations that are not supported on web
library;

const String _fileOpsNotSupported = 'File operations not supported on web';

class File {
  final String path;

  File(this.path);

  Future<List<int>> readAsBytes() async {
    throw UnsupportedError(_fileOpsNotSupported);
  }

  Future<void> writeAsBytes(List<int> bytes) async {
    throw UnsupportedError(_fileOpsNotSupported);
  }

  Future<void> delete() async {
    throw UnsupportedError(_fileOpsNotSupported);
  }
}

Future<Directory> getTemporaryDirectory() async {
  throw UnsupportedError('getTemporaryDirectory not supported on web');
}

class Directory {
  final String path;

  Directory(this.path);
}
