import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../utils/logger.dart';
import '/constants/app_config.dart';

class RideHistoryPage extends StatefulWidget {
  final String userId;

  const RideHistoryPage({
    super.key,
    required this.userId,
  });

  @override
  State<RideHistoryPage> createState() => _RideHistoryPageState();
}

class _RideHistoryPageState extends State<RideHistoryPage> {
  List<Map<String, dynamic>> _rides = [];
  bool _isLoading = true;
  String _errorMessage = '';
  String _filterStatus = 'all'; // all, completed, cancelled

  @override
  void initState() {
    super.initState();
    _loadRideHistory();
  }

  Future<void> _loadRideHistory() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final url = Uri.parse('${AppConfig.apiBaseUrl}/api/rideHistory/history/${widget.userId}');
      final response = await http.get(
        url,
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _rides = List<Map<String, dynamic>>.from(data['rides'] ?? []);
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = 'Failed to load ride history';
          _isLoading = false;
        });
      }
    } catch (e) {
      Logger.error('Error loading ride history: $e');
      setState(() {
        _errorMessage = 'خرابی: رائڈ ہسٹری لوڈ نہیں ہو سکی';
        _isLoading = false;
      });
    }
  }

  List<Map<String, dynamic>> get _filteredRides {
    if (_filterStatus == 'all') return _rides;
    return _rides.where((ride) => ride['status'] == _filterStatus).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header with back button
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.arrow_back,
                            color: Color(0xFFCF4374),
                            size: 28,
                          ),
                          onPressed: () => Navigator.pop(context),
                        ),
                        const Expanded(
                          child: Text(
                            'رائڈ ہسٹری',
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFCF4374),
                            ),
                          ),
                        ),
                        const SizedBox(width: 48), // Balance the back button
                      ],
                    ),
                    const SizedBox(height: 16),
                    
                    // Filter Chips
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildFilterChip('تمام', 'all'),
                        const SizedBox(width: 8),
                        _buildFilterChip('مکمل', 'completed'),
                        const SizedBox(width: 8),
                        _buildFilterChip('منسوخ', 'cancelled'),
                      ],
                    ),
                  ],
                ),
              ),

              // Content
              Expanded(
                child: _buildContent(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFCF4374)),
      );
    }
    if (_errorMessage.isNotEmpty) {
      return _buildErrorState();
    }
    if (_filteredRides.isEmpty) {
      return _buildEmptyState();
    }
    return _buildRidesList();
  }

  Widget _buildFilterChip(String label, String value) {
    final isSelected = _filterStatus == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _filterStatus = value;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFFCF4374)
              : Colors.white.withValues(alpha: 0.7),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFFCF4374),
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: isSelected ? Colors.white : const Color(0xFFCF4374),
          ),
        ),
      ),
    );
  }

  Widget _buildRidesList() {
    return RefreshIndicator(
      onRefresh: _loadRideHistory,
      color: const Color(0xFFCF4374),
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: _filteredRides.length,
        itemBuilder: (context, index) {
          final ride = _filteredRides[index];
          return _buildRideCard(ride);
        },
      ),
    );
  }

  Widget _buildRideCard(Map<String, dynamic> ride) {
    final status = ride['status'] ?? 'unknown';
    final pickup = ride['pickup_location'] ?? 'Unknown';
    final dropoff = ride['dropoff_location'] ?? 'Unknown';
    final driverName = ride['driver_name'] ?? 'N/A';
    final fare = ride['fare']?.toString() ?? '0';
    final date = ride['created_at'] ?? '';
    final rating = ride['rating']?.toDouble() ?? 0.0;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCF4374).withValues(alpha: 0.1),
            blurRadius: 10,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _showRideDetails(ride),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status and Date Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildStatusBadge(status),
                    Text(
                      _formatDate(date),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Pickup Location
                Row(
                  children: [
                    const Icon(
                      Icons.trip_origin,
                      color: Color(0xFFCF4374),
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        pickup,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF69223B),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 4),

                // Connecting Line
                Container(
                  margin: const EdgeInsets.only(left: 10),
                  height: 20,
                  width: 2,
                  color: const Color(0xFFCF4374).withValues(alpha: 0.3),
                ),

                const SizedBox(height: 4),

                // Dropoff Location
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      color: Color(0xFFCF4374),
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        dropoff,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF69223B),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                const Divider(height: 1),

                const SizedBox(height: 12),

                // Driver and Fare Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Driver Info
                    Row(
                      children: [
                        const CircleAvatar(
                          radius: 16,
                          backgroundColor: Color(0xFFFDEAF0),
                          child: Icon(
                            Icons.person,
                            size: 18,
                            color: Color(0xFFCF4374),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          driverName,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF69223B),
                          ),
                        ),
                      ],
                    ),

                    // Fare
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFDEAF0),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'Rs. $fare',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                    ),
                  ],
                ),

                // Rating (if available)
                if (rating > 0) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Text(
                        'آپ کی ریٹنگ:',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 8),
                      ...List.generate(5, (index) {
                        return Icon(
                          index < rating ? Icons.star : Icons.star_border,
                          size: 16,
                          color: Colors.amber,
                        );
                      }),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color bgColor;
    Color textColor;
    String label;

    switch (status.toLowerCase()) {
      case 'completed':
        bgColor = Colors.green.shade50;
        textColor = Colors.green.shade700;
        label = 'مکمل';
        break;
      case 'cancelled':
        bgColor = Colors.red.shade50;
        textColor = Colors.red.shade700;
        label = 'منسوخ';
        break;
      case 'ongoing':
        bgColor = Colors.blue.shade50;
        textColor = Colors.blue.shade700;
        label = 'جاری';
        break;
      default:
        bgColor = Colors.grey.shade50;
        textColor = Colors.grey.shade700;
        label = status;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history,
            size: 80,
            color: const Color(0xFFCF4374).withValues(alpha: 0.3),
          ),
          const SizedBox(height: 16),
          const Text(
            'کوئی رائڈ نہیں ملی',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFFCF4374),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'ابھی تک کوئی رائڈ بک نہیں کی گئی',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            size: 80,
            color: Colors.red,
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _errorMessage,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.red,
              ),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadRideHistory,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFCF4374),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 32,
                vertical: 12,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: const Text(
              'دوبارہ کوشش کریں',
              textDirection: TextDirection.rtl,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  void _showRideDetails(Map<String, dynamic> ride) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildRideDetailsSheet(ride),
    );
  }

  Widget _buildRideDetailsSheet(Map<String, dynamic> ride) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) {
          return SingleChildScrollView(
            controller: scrollController,
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Handle bar
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Title
                  const Text(
                    'رائڈ کی تفصیلات',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Details
                  _buildDetailRow('حیثیت', ride['status'] ?? 'N/A'),
                  _buildDetailRow('تاریخ', _formatDate(ride['created_at'] ?? '')),
                  _buildDetailRow('ڈرائیور', ride['driver_name'] ?? 'N/A'),
                  _buildDetailRow('گاڑی', '${ride['vehicle_make'] ?? 'N/A'} ${ride['vehicle_model'] ?? ''}'),
                  _buildDetailRow('نمبر پلیٹ', ride['vehicle_number'] ?? 'N/A'),
                  _buildDetailRow('کرایہ', 'Rs. ${ride['fare'] ?? '0'}'),
                  _buildDetailRow('فاصلہ', '${ride['distance'] ?? 'N/A'} کلومیٹر'),
                  _buildDetailRow('مدت', '${ride['duration'] ?? 'N/A'} منٹ'),

                  const SizedBox(height: 20),

                  // Locations
                  const Text(
                    'مقامات',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFCF4374),
                    ),
                  ),

                  const SizedBox(height: 12),

                  _buildLocationRow(
                    Icons.trip_origin,
                    'پک اپ',
                    ride['pickup_location'] ?? 'Unknown',
                  ),

                  const SizedBox(height: 8),

                  _buildLocationRow(
                    Icons.location_on,
                    'ڈراپ آف',
                    ride['dropoff_location'] ?? 'Unknown',
                  ),

                  const SizedBox(height: 24),

                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.refresh),
                          label: const Text(
                            'دوبارہ بک کریں',
                            textDirection: TextDirection.rtl,
                          ),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFFCF4374),
                            side: const BorderSide(
                              color: Color(0xFFCF4374),
                              width: 2,
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.receipt_long),
                          label: const Text(
                            'رسید دیکھیں',
                            textDirection: TextDirection.rtl,
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFCF4374),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF69223B),
            ),
          ),
          Text(
            label,
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationRow(IconData icon, String label, String address) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFFCF4374), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                address,
                style: const TextStyle(
                  fontSize: 14,
                  color: Color(0xFF69223B),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatDate(String dateString) {
    if (dateString.isEmpty) return 'N/A';
    
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inDays == 0) {
        final hour = date.hour;
        final minute = date.minute.toString().padLeft(2, '0');
        final period = hour >= 12 ? 'PM' : 'AM';
        final int displayHour;
        if (hour > 12) {
          displayHour = hour - 12;
        } else if (hour == 0) {
          displayHour = 12;
        } else {
          displayHour = hour;
        }
        return 'آج $displayHour:$minute $period';
      } else if (difference.inDays == 1) {
        return 'کل';
      } else if (difference.inDays < 7) {
        return '${difference.inDays} دن پہلے';
      } else {
        final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return '${date.day} ${months[date.month - 1]} ${date.year}';
      }
    } catch (e) {
      return dateString;
    }
  }
}