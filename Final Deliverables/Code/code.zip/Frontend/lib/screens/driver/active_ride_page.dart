import 'package:flutter/material.dart';
import '../../models/ride_request.dart';
import '../../services/socket_service.dart';
import '../../services/map_service.dart';
import '../../services/location_tracking_service.dart';
import '../../utils/logger.dart';
import '../chat/chat_page.dart';
import '../../widgets/live_tracking_map.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';
import 'package:url_launcher/url_launcher.dart';

/// Driver Active Ride Page - Shows ongoing ride with complete button
class DriverActiveRidePage extends StatefulWidget {
  final RideRequest ride;
  final String driverId;

  const DriverActiveRidePage({
    super.key,
    required this.ride,
    required this.driverId,
  });

  @override
  State<DriverActiveRidePage> createState() => _DriverActiveRidePageState();
}

class _DriverActiveRidePageState extends State<DriverActiveRidePage> {
  bool _isCompletingRide = false;
  bool _hasReached = false;
  int _unreadCount = 0;

  // Location tracking state
  double? _driverLat;
  double? _driverLng;
  double? _passengerLat;
  double? _passengerLng;
  double? _destinationLat;
  double? _destinationLng;
  String? _polylineEncoded;
  Timer? _locationUpdateTimer;
  Timer? _polylineUpdateTimer;
  @override
  void initState() {
    super.initState();
    Logger.log('🚗 DriverActiveRidePage: Initializing...');
    _ensureSocketConnection();
    _setupCancellationListener();
    _setupUnreadCountListener();
    _setupPassengerLocationListener();
    _initializeChatSystem();
    _startLocationTracking();
    // Don't load static source coordinates - wait for real-time passenger GPS
    // This prevents the map from showing source/destination before switching to actual locations
    // _getPassengerLocation(); // Commented out - will use real-time updates only
    _getCurrentDriverLocation();
    _loadDestinationCoordinates();
    Logger.log('🚗 DriverActiveRidePage: Initialization complete');
  }

  /// Initialize chat system for this ride
  void _initializeChatSystem() {
    // Register this driver as a participant even before opening chat
    // This ensures messages can be received from the start
    ChatPage.registerParticipant(widget.ride.id, widget.driverId);
    Logger.log(
      '✅ Driver registered as chat participant for ride ${widget.ride.id}',
    );
  }

  /// Ensure socket connection is maintained for active ride
  void _ensureSocketConnection() {
    SocketService.ensureConnection();
    Logger.log('🔌 Socket connection verified for driver active ride page');
  }

  /// Setup listener for matched ride cancellation
  void _setupCancellationListener() {
    Logger.log('👂 Setting up matched ride cancellation listener');

    SocketService.onMatchedRideCancelled((rideId, message) {
      Logger.log('🚫 Ride cancelled by commuter: $rideId');

      if (!mounted) {
        Logger.log('⚠️ Widget not mounted, skipping navigation');
        return;
      }

      if (rideId == widget.ride.id) {
        // Show cancellation dialog
        _showCancellationDialog(message);
      }
    });

    Logger.log('✅ Cancellation listener setup complete');
  }

  /// Setup listener for unread message count updates
  void _setupUnreadCountListener() {
    // Poll unread count every second
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;

      final newCount = ChatPage.getUnreadCount(widget.ride.id, widget.driverId);
      if (newCount != _unreadCount) {
        setState(() {
          _unreadCount = newCount;
        });
        Logger.log('📬 Updated unread count for driver: $_unreadCount');
      }

      return mounted; // Continue polling while mounted
    });
  }

  /// Show dialog when commuter cancels the ride
  void _showCancellationDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'Ride Cancelled',
            style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
          ),
          content: Text(message, style: const TextStyle(fontSize: 16)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Navigate back to available rides page (previous page in stack)
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFCF4374),
              ),
              child: const Text('OK', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  /// Start location tracking for driver
  Future<void> _startLocationTracking() async {
    Logger.log('📍 Starting driver location tracking');

    // Start sending location updates to passenger
    await LocationTrackingService.startTracking(
      rideId: widget.ride.id,
      interval: const Duration(seconds: 5),
    );

    Logger.log('✅ Location tracking started');
  }

  /// Listen for passenger location updates
  void _setupPassengerLocationListener() {
    Logger.log(
      '👂 Setting up passenger location listener in DriverActiveRidePage',
    );

    SocketService.onPassengerLocationUpdate((rideId, lat, lng, timestamp) {
      if (!mounted) {
        return;
      }

      if (rideId == widget.ride.id) {
        setState(() {
          _passengerLat = lat;
          _passengerLng = lng;
        });

        Logger.log('📍 Passenger location updated: ($lat, $lng)');
      }
    });

    Logger.log('✅ Passenger location listener setup complete');
  }

  /// Get current driver location
  Future<void> _getCurrentDriverLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      setState(() {
        _driverLat = position.latitude;
        _driverLng = position.longitude;
      });
      Logger.log(
        '📍 Driver location: (${position.latitude}, ${position.longitude})',
      );

      // Start periodic location updates for the map
      _startPeriodicLocationUpdates();
      // Start periodic polyline updates
      _startPeriodicPolylineUpdates();
    } catch (e) {
      Logger.error('❌ Failed to get driver location: $e');
    }
  }

  Future<void> _loadDestinationCoordinates() async {
    if (widget.ride.destination.coordinates != null) {
      if (mounted) {
        setState(() {
          _destinationLat = widget.ride.destination.coordinates!.lat;
          _destinationLng = widget.ride.destination.coordinates!.lon;
        });
      }
      // Retry polyline now that destination coords are available
      _fetchPolyline();
      return;
    }

    try {
      final coords = await MapService.geocodeAddress(
        widget.ride.destination.address,
      );
      if (coords != null && mounted) {
        setState(() {
          _destinationLat = coords['latitude'];
          _destinationLng = coords['longitude'];
        });
        // Retry polyline with freshly geocoded destination
        _fetchPolyline();
      }
    } catch (e) {
      Logger.error('❌ Failed to geocode destination: $e');
    }
  }

  /// Start periodic updates of driver's location for map display
  void _startPeriodicLocationUpdates() {
    _locationUpdateTimer?.cancel();
    _locationUpdateTimer = Timer.periodic(const Duration(seconds: 5), (
      timer,
    ) async {
      if (!mounted) {
        timer.cancel();
        return;
      }

      try {
        final position = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.high,
          ),
        );
        setState(() {
          _driverLat = position.latitude;
          _driverLng = position.longitude;
        });
        Logger.log(
          '🔄 Driver location updated: (${position.latitude}, ${position.longitude})',
        );
      } catch (e) {
        Logger.error('❌ Failed to update driver location: $e');
      }
    });
  }

  /// Start periodic updates of route polyline
  void _startPeriodicPolylineUpdates() {
    // Fetch polyline immediately
    _fetchPolyline();

    // Then fetch every 15 seconds
    _polylineUpdateTimer?.cancel();
    _polylineUpdateTimer = Timer.periodic(const Duration(seconds: 15), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      _fetchPolyline();
    });
  }

  /// Fetch route polyline between driver and passenger
  Future<void> _fetchPolyline() async {
    final bool useDestination = _hasReached;
    final double? targetLat = useDestination ? _destinationLat : _passengerLat;
    final double? targetLng = useDestination ? _destinationLng : _passengerLng;

    if (_driverLat == null ||
        _driverLng == null ||
        targetLat == null ||
        targetLng == null) {
      return;
    }

    try {
      // Only pass stops as waypoints when routing to the final destination
      // (after passenger pickup). When routing to the passenger pickup location,
      // stops should not be waypoints — the passenger IS the current target.
      final stopLatLngs = useDestination
          ? widget.ride.stops
              .where((s) => s.coordinates != null)
              .map((s) => {'lat': s.coordinates!.lat, 'lng': s.coordinates!.lon})
              .toList()
          : <Map<String, double>>[];
      final polyline = await MapService.getDirectionsPolylineWithStops(
        sourceLat: _driverLat!,
        sourceLng: _driverLng!,
        destLat: targetLat,
        destLng: targetLng,
        stops: stopLatLngs.isEmpty ? null : stopLatLngs,
      );

      if (mounted) {
        setState(() {
          _polylineEncoded = polyline;
        });
        Logger.log('🗺️ Polyline updated');
      }
    } catch (e) {
      Logger.error('❌ Failed to fetch polyline: $e');
    }
  }

  @override
  void dispose() {
    // Cancel timers
    _locationUpdateTimer?.cancel();
    _polylineUpdateTimer?.cancel();
    // Stop location tracking
    LocationTrackingService.stopTracking();
    Logger.log('🛑 Location tracking stopped');

    // Remove the cancellation listener when leaving this page
    if (SocketService.socket != null) {
      SocketService.socket!.off('ride:cancelled:matched');
      Logger.log('🗑️ Removed ride:cancelled:matched listener');
    }
    // Remove passenger location listener
    SocketService.removePassengerLocationListener();
    Logger.log(
      '🗑️ Removed passenger location listener from DriverActiveRidePage',
    );
    // IMPORTANT: Keep socket connected even after completing ride
    // Only disconnect when the driver completely exits the app or logs out
    Logger.log('🗑️ Disposing DriverActiveRidePage - keeping socket connected');
    super.dispose();
  }

  /// Notify commuter that driver has reached
  Future<void> _notifyReached() async {
    setState(() {
      _hasReached = true;
    });

    try {
      Logger.log('🚗 Notifying commuter that driver has reached...');
      SocketService.emitDriverReached(widget.ride.id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Passenger notified that you have arrived!'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      Logger.error('❌ Failed to notify reached: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send notification: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> _openGoogleMapsNavigation() async {
    final destination = _hasReached
        ? widget.ride.destination.coordinates
        : widget.ride.source.coordinates;

    double? destLat;
    double? destLng;

    if (!_hasReached && _passengerLat != null && _passengerLng != null) {
      destLat = _passengerLat;
      destLng = _passengerLng;
    } else if (destination != null) {
      destLat = destination.lat;
      destLng = destination.lon;
    }

    if (destLat == null || destLng == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Destination location not available yet.'),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 2),
          ),
        );
      }
      return;
    }

    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&destination=$destLat,$destLng&travelmode=driving',
    );

    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not open Google Maps.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// Complete the ride - automatically calculate fare from distance
  Future<void> _completeRide() async {
    // Show confirmation dialog first
    final confirmed = await _showCompleteRideConfirmation();
    if (!confirmed) return;

    setState(() {
      _isCompletingRide = true;
    });

    try {
      // Get coordinates from ride
      final sourceCoords = widget.ride.source.coordinates;
      final destCoords = widget.ride.destination.coordinates;

      if (sourceCoords == null || destCoords == null) {
        throw Exception('Coordinates not available');
      }

      Logger.log('📍 Calculating distance from coordinates...');

      // Build stops waypoints
      final stopWaypoints = widget.ride.stops
          .where((s) => s.coordinates != null)
          .map((s) => {'lat': s.coordinates!.lat, 'lng': s.coordinates!.lon})
          .toList();

      // Calculate total distance including stops
      final routeData = await MapService.calculateRouteWithStops(
        sourceLat: sourceCoords.lat,
        sourceLng: sourceCoords.lon,
        destLat: destCoords.lat,
        destLng: destCoords.lon,
        stops: stopWaypoints.isEmpty ? null : stopWaypoints,
      );

      final distanceKm = (routeData['distanceKm'] as num?)?.toDouble() ?? 0.0;

      Logger.log('✅ Distance calculated: $distanceKm km');

      if (distanceKm <= 0) {
        throw Exception('Invalid distance calculated');
      }

      // Verify socket is still connected before sending
      if (!SocketService.isConnected) {
        throw Exception('Socket connection lost! Cannot complete ride.');
      }

      Logger.log('📡 Sending ride completion to backend...');
      Logger.log('   Ride ID: ${widget.ride.id}');
      Logger.log('   Distance: $distanceKm km');
      Logger.log('   Socket Connected: ${SocketService.isConnected}');
      Logger.log('   Socket ID: ${SocketService.socket?.id}');

      // Send to backend with distance - this triggers payment calculation
      SocketService.completeRide(widget.ride.id, distanceKm: distanceKm);

      Logger.log('✅ Ride completion event sent to backend');
      Logger.log(
        '💳 Backend should now calculate fare and send payment request to commuter',
      );

      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Ride completed! Distance: ${distanceKm.toStringAsFixed(1)} km\nPayment request sent to passenger.',
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );

        Logger.log('⏳ Waiting 3 seconds before navigating back...');

        // Navigate back to available rides page after 3 seconds
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) {
            Logger.log('🏠 Navigating back to available rides page');
            Navigator.of(context).pop();
          }
        });
      }
    } catch (e) {
      Logger.error('❌ Failed to complete ride: $e');
      setState(() {
        _isCompletingRide = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to complete ride: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  /// Show complete ride confirmation dialog
  Future<bool> _showCompleteRideConfirmation() async {
    return await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text(
                'Complete Ride',
                style: TextStyle(
                  color: Color(0xFFCF4374),
                  fontWeight: FontWeight.bold,
                ),
              ),
              content: const Text(
                'Are you sure you want to complete this ride?\n\nFare will be calculated automatically based on distance.',
                style: TextStyle(fontSize: 16),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCF4374),
                  ),
                  child: const Text(
                    'Complete',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    final bool useDestination = _hasReached;
    final double? targetLat = useDestination ? _destinationLat : _passengerLat;
    final double? targetLng = useDestination ? _destinationLng : _passengerLng;

    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: AppBar(
        title: const Text(
          'Active Ride',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFCF4374),
        elevation: 0,
        automaticallyImplyLeading: false, // Remove back button
        actions: [
          // Chat button with notification badge
          Stack(
            children: [
              IconButton(
                icon: const Icon(
                  Icons.chat_bubble_outline,
                  color: Colors.white,
                ),
                onPressed: () {
                  // Clear unread count when opening chat
                  ChatPage.clearUnreadCount(widget.ride.id, widget.driverId);
                  setState(() {
                    _unreadCount = 0;
                  });

                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => ChatPage(
                        rideId: widget.ride.id,
                        currentUserId: widget.driverId,
                        otherUserName: widget.ride.userName,
                        userType: 'driver',
                      ),
                    ),
                  );
                },
                tooltip: 'Chat with passenger',
              ),
              if (_unreadCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 18,
                      minHeight: 18,
                    ),
                    child: Text(
                      _unreadCount > 9 ? '9+' : '$_unreadCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Live Tracking Map (if locations are available)
              if (_driverLat != null &&
                  _driverLng != null &&
                  targetLat != null &&
                  targetLng != null)
                SizedBox(
                  height: 400,
                  child: LiveTrackingMap(
                    driverLat: _driverLat!,
                    driverLng: _driverLng!,
                    passengerLat: targetLat,
                    passengerLng: targetLng,
                    polylineEncoded: _polylineEncoded,
                    showRoute: true,
                    stops: widget.ride.stops
                        .where((s) => s.coordinates != null)
                        .map((s) => LatLng(s.coordinates!.lat, s.coordinates!.lon))
                        .toList(),
                  ),
                )
              else
                // Loading indicator while getting location
                const SizedBox(
                  height: 400,
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(color: Color(0xFFCF4374)),
                        SizedBox(height: 16),
                        Text(
                          'Loading map...',
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),

              // Ride Details Section
              Container(
                color: const Color(0xFFFCE4EC),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      // Status Badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFCF4374), Color(0xFF69223B)],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(
                                0xFFCF4374,
                              ).withValues(alpha: 0.3),
                              blurRadius: 10,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.local_taxi,
                              color: Colors.white,
                              size: 20,
                            ),
                            SizedBox(width: 8),
                            Text(
                              'Ride in Progress',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Ride Details Card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: const Color(0xFFF682AA),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withValues(alpha: 0.1),
                              blurRadius: 10,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Passenger Name
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFFCE4EC),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.person,
                                    color: Color(0xFFCF4374),
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Passenger',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      Text(
                                        widget.ride.userName,
                                        style: const TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFFCF4374),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 24),

                            const Divider(color: Color(0xFFF682AA)),

                            const SizedBox(height: 24),

                            // Source Location
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(
                                  Icons.location_on,
                                  color: Colors.green,
                                  size: 24,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Pickup Location',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        widget.ride.source.address,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          color: Colors.black87,
                                          height: 1.4,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            // Intermediate Stops
                            if (widget.ride.stops.isNotEmpty) ...[
                              ...widget.ride.stops.asMap().entries.map((entry) {
                                final i = entry.key;
                                final stop = entry.value;
                                return Column(
                                  children: [
                                    const SizedBox(height: 20),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 24,
                                          height: 24,
                                          decoration: const BoxDecoration(
                                            color: Color(0xFF7986CB),
                                            shape: BoxShape.circle,
                                          ),
                                          child: Center(
                                            child: Text(
                                              '${i + 1}',
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Stop ${i + 1}',
                                                style: const TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                stop.address,
                                                style: const TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.black87,
                                                  height: 1.4,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              }),
                            ],

                            const SizedBox(height: 20),

                            // Destination Location
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(
                                  Icons.flag,
                                  color: Colors.red,
                                  size: 24,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Drop-off Location',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        widget.ride.destination.address,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          color: Colors.black87,
                                          height: 1.4,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 40),

                      SizedBox(
                        width: double.infinity,
                        height: 60,
                        child: ElevatedButton(
                          onPressed: _openGoogleMapsNavigation,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: const Color(0xFFCF4374),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                              side: const BorderSide(
                                color: Color(0xFFCF4374),
                                width: 2,
                              ),
                            ),
                            elevation: 4,
                            shadowColor: const Color(
                              0xFFCF4374,
                            ).withValues(alpha: 0.2),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.map_outlined, size: 28),
                              SizedBox(width: 12),
                              Text(
                                'Open Google Maps',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Reached Button (shown when driver hasn't notified yet)
                      if (!_hasReached) ...[
                        SizedBox(
                          width: double.infinity,
                          height: 70,
                          child: ElevatedButton(
                            onPressed: _notifyReached,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(35),
                              ),
                              elevation: 8,
                              shadowColor: Colors.orange.withValues(alpha: 0.4),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.location_on,
                                  color: Colors.white,
                                  size: 32,
                                ),
                                SizedBox(width: 12),
                                Text(
                                  'I Have Reached',
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],

                      // Complete Ride Button (enabled after reaching)
                      SizedBox(
                        width: double.infinity,
                        height: 70,
                        child: ElevatedButton(
                          onPressed: (_isCompletingRide || !_hasReached)
                              ? null
                              : _completeRide,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFCF4374),
                            disabledBackgroundColor: Colors.grey,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35),
                            ),
                            elevation: 8,
                            shadowColor: const Color(
                              0xFFCF4374,
                            ).withValues(alpha: 0.4),
                          ),
                          child: _isCompletingRide
                              ? const CircularProgressIndicator(
                                  color: Colors.white,
                                )
                              : const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.check_circle_outline,
                                      color: Colors.white,
                                      size: 32,
                                    ),
                                    SizedBox(width: 12),
                                    Text(
                                      'Complete Ride',
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
