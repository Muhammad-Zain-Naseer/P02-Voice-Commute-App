import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:http/http.dart' as http;
import '../widgets/custom_button.dart';
import '../widgets/mic_button.dart';
import '../widgets/sound_wave.dart';
import '../services/voice_service.dart';
import '../services/audio_player_service.dart';
import 'auth/signup_email_screen.dart';
import 'auth/login_email_screen.dart';
import 'auth/driverSignup/driver_signup_email_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  final AudioRecorder _recorder = AudioRecorder();

  bool _isSpeaking = false;
  bool _isListening = false;
  bool _isMuted = false;
  bool _isInterpreting = false;
  bool _speechCancelled = false;
  bool _isWelcomePlaying = false; // guard — prevents concurrent _speakWelcome runs
  int _highlightedButton = -1;
  bool _hasUserInteracted = false;
  Timer? _replayTimer;
  Timer? _autoStopTimer;
  Timer? _amplitudeTimer;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  String get _state =>
      'muted=$_isMuted | cancelled=$_speechCancelled | welcomePlaying=$_isWelcomePlaying'
      ' | speaking=$_isSpeaking | listening=$_isListening | interpreting=$_isInterpreting'
      ' | highlighted=$_highlightedButton | web=$kIsWeb';

  @override
  void initState() {
    super.initState();
    debugPrint('=== WelcomeScreen initState | $_state');
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    if (!kIsWeb) {
      debugPrint('=== native platform — calling _setupAudio');
      _setupAudio();
    } else {
      debugPrint('=== web platform — waiting for user tap to start audio');
    }
  }

  void _startPulse() => _pulseController.repeat(reverse: true);

  void _stopPulse() {
    _pulseController.stop();
    _pulseController.reset();
  }

  Future<void> _setupAudio() async {
    debugPrint('=== _setupAudio called | $_state');
    _speechCancelled = false;
    await _speakWelcome();
    debugPrint('=== _setupAudio: _speakWelcome done — starting replay timer | $_state');
    _startReplayTimer();
  }

  void _startReplayTimer() {
    _replayTimer?.cancel();
    debugPrint('=== replayTimer scheduled (5s) | $_state');
    _replayTimer = Timer(const Duration(seconds: 5), () async {
      debugPrint('=== replayTimer FIRED | $_state');
      if (!_isSpeaking && !_isListening && !_isInterpreting && !_speechCancelled && !_isMuted && mounted) {
        debugPrint('=== replayTimer: conditions met — calling _speakWelcome');
        await _speakWelcome();
        _startReplayTimer();
      } else {
        debugPrint('=== replayTimer: conditions NOT met — skipping '
            '(speaking=$_isSpeaking listening=$_isListening interpreting=$_isInterpreting '
            'cancelled=$_speechCancelled mounted=$mounted)');
      }
    });
  }

  void _cancelReplayTimer() {
    if (_replayTimer != null) {
      debugPrint('=== replayTimer CANCELLED | $_state');
    }
    _replayTimer?.cancel();
    _replayTimer = null;
  }

  Future<void> _speakAndWait(String text) async {
    if (_isMuted || _speechCancelled) {
      debugPrint('=== _speakAndWait SKIPPED "$text" (muted=$_isMuted cancelled=$_speechCancelled)');
      return;
    }
    debugPrint('=== _speakAndWait FETCHING "$text"');
    if (mounted) setState(() => _isSpeaking = true);
    final audioBytes = await VoiceService.textToSpeech(text);
    if (audioBytes != null && !_speechCancelled) {
      debugPrint('=== _speakAndWait PLAYING "$text" (${audioBytes.length} bytes)');
      await AudioPlayerService.playBytes(audioBytes);
      debugPrint('=== _speakAndWait DONE "$text"');
    } else {
      debugPrint('=== _speakAndWait PLAY SKIPPED "$text" (bytes=${audioBytes?.length ?? 0} cancelled=$_speechCancelled)');
    }
    if (mounted) setState(() => _isSpeaking = false);
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _speakWelcome() async {
    if (_speechCancelled || _isWelcomePlaying || _isMuted) {
      debugPrint('=== _speakWelcome BLOCKED | $_state');
      return;
    }
    _isWelcomePlaying = true;
    debugPrint('=== _speakWelcome START | $_state');
    _cancelReplayTimer();
    if (mounted) setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted || _speechCancelled) {
      debugPrint('=== _speakWelcome EXIT after 800ms delay | $_state');
      _isWelcomePlaying = false;
      return;
    }

    await _speakAndWait('ایک انتخاب کریں');
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted || _speechCancelled) { debugPrint('=== _speakWelcome EXIT after line1 | $_state'); _isWelcomePlaying = false; return; }

    setState(() => _highlightedButton = 0);
    await _speakAndWait('نیا صارف');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) { debugPrint('=== _speakWelcome EXIT after line2 | $_state'); _isWelcomePlaying = false; return; }

    setState(() => _highlightedButton = 1);
    await _speakAndWait('پہلے سے رجسٹر ہیں');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) { debugPrint('=== _speakWelcome EXIT after line3 | $_state'); _isWelcomePlaying = false; return; }

    setState(() => _highlightedButton = 2);
    await _speakAndWait('رجسٹر بطور ڈرائیور');
    setState(() => _highlightedButton = -1);
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted || _speechCancelled) { debugPrint('=== _speakWelcome EXIT after line4 | $_state'); _isWelcomePlaying = false; return; }

    await _speakAndWait('بولنے کے لیے مائیکروفون دبائیں');
    debugPrint('=== _speakWelcome END (completed fully) | $_state');
    _isWelcomePlaying = false;
    if (mounted && !_speechCancelled) _startReplayTimer();
  }

  // ── MAIN toggle — same for web and native ─────
  Future<void> _toggleListening() async {
    if (_isInterpreting) return;

    if (_isListening) {
      _autoStopTimer?.cancel();
      _amplitudeTimer?.cancel();
      await _stopRecordingAndProcess();
      return;
    }

    await _startRecording();
  }

  // ── Records WAV on both web and mobile ──────
  Future<void> _startRecording() async {
    debugPrint('=== _startRecording called | $_state');
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      debugPrint('=== Microphone permission denied');
      return;
    }

    _speechCancelled = true;
    _isWelcomePlaying = false;
    _cancelReplayTimer();
    await AudioPlayerService.stop();
    debugPrint('=== _startRecording: audio stopped, starting mic | $_state');
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) setState(() => _isSpeaking = false);

    try {
      final path = kIsWeb
          ? 'hersafar_welcome_voice'
          : '${(await getTemporaryDirectory()).path}/hersafar_voice.wav';

      if (!kIsWeb) {
        final oldFile = File(path);
        if (await oldFile.exists()) await oldFile.delete();
      }

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 16000,
          numChannels: 1,
        ),
        path: path,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      final isRecording = await _recorder.isRecording();
      if (!isRecording) {
        debugPrint('=== Recorder failed to start');
        _startReplayTimer();
        return;
      }

      setState(() {
        _isListening = true;
      });
      _startPulse();
      debugPrint('=== Recording started (web: $kIsWeb)');

      _amplitudeTimer =
          Timer.periodic(const Duration(milliseconds: 500), (t) async {
        if (!_isListening) {
          t.cancel();
          return;
        }
        final amp = await _recorder.getAmplitude();
        debugPrint('=== Amp: ${amp.current.toStringAsFixed(1)}');
      });

      _autoStopTimer = Timer(const Duration(seconds: 8), () {
        if (_isListening) _stopRecordingAndProcess();
      });
    } catch (e) {
      debugPrint('=== Start recording error: $e');
      _startReplayTimer();
    }
  }

  Future<void> _stopRecordingAndProcess() async {
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    if (!_isListening) return;

    _stopPulse();
    setState(() => _isListening = false);

    try {
      final path = await _recorder.stop();
      debugPrint('=== Recording stopped: $path');

      if (path == null) {
        _startReplayTimer();
        return;
      }

      setState(() => _isInterpreting = true);

      final Uint8List bytes;
      if (kIsWeb) {
        final response = await http.get(Uri.parse(path));
        bytes = response.bodyBytes;
      } else {
        final file = File(path);
        if (!await file.exists()) {
          debugPrint('=== Recording file not found');
          setState(() => _isInterpreting = false);
          _startReplayTimer();
          return;
        }
        bytes = await file.readAsBytes();
      }

      debugPrint('=== File size: ${bytes.length} bytes');

      if (bytes.isEmpty) {
        debugPrint('=== Recording file is empty');
        setState(() => _isInterpreting = false);
        _startReplayTimer();
        return;
      }

      final audioBase64 = base64Encode(bytes);
      await _handleAudio(audioBase64);
    } catch (e) {
      debugPrint('=== STT error: $e');
      setState(() {
        _isListening = false;
        _isInterpreting = false;
      });
      _startReplayTimer();
    }
  }

  // ── Audio direct to Gemini ────────────
  Future<void> _handleAudio(String audioBase64) async {
    debugPrint('=== _handleAudio: sending to Gemini | $_state');
    if (mounted) setState(() => _isInterpreting = true);
    final matched = await VoiceService.interpretAudio(audioBase64);
    debugPrint('=== Gemini matched: $matched (0=signup 1=login 2=driver -1=unknown) | $_state');
    await _navigate(matched);
  }

  // ── Shared navigation after intent resolved ──────────────────────
  Future<void> _navigate(int matched) async {
    if (!mounted) return;
    setState(() => _isInterpreting = false);
    debugPrint('=== _navigate($matched) | $_state');

    if (matched != -1) {
      _cancelReplayTimer();
      setState(() { _highlightedButton = matched; });
      debugPrint('=== _navigate: scheduling _navigateTo($matched) in 800ms');
      Future.delayed(const Duration(milliseconds: 800), () {
        debugPrint('=== _navigate: 800ms elapsed — calling _navigateTo($matched) | $_state');
        _navigateTo(matched);
      });
    } else {
      debugPrint('=== _navigate: no match — restarting replay timer');
      _startReplayTimer();
    }
  }

  void _toggleMute() async {
    setState(() => _isMuted = !_isMuted);
    debugPrint('=== _toggleMute → muted=$_isMuted | $_state');
    if (_isMuted) {
      _speechCancelled = true;
      _isWelcomePlaying = false;
      await AudioPlayerService.stop();
      setState(() {
        _isSpeaking = false;
        _highlightedButton = -1;
      });
      _cancelReplayTimer();
      debugPrint('=== _toggleMute: muted, audio stopped | $_state');
    } else {
      _speechCancelled = false;
      setState(() => _highlightedButton = -1);
      debugPrint('=== _toggleMute: unmuted — calling _speakWelcome | $_state');
      await _speakWelcome();
      _startReplayTimer();
    }
  }

  Future<void> _navigateTo(int index) async {
    debugPrint('=== _navigateTo($index) called | $_state');
    _speechCancelled = true;
    _isWelcomePlaying = false;
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    await AudioPlayerService.stop();
    await _recorder.stop();
    if (!mounted) return;
    setState(() {
      _isSpeaking = false;
      _isListening = false;
      _highlightedButton = -1;
    });
    debugPrint('=== _navigateTo($index): audio stopped, navigating | $_state');
    switch (index) {
      case 0:
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const SignupEmailScreen()));
        break;
      case 1:
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const LoginEmailScreen()));
        break;
      case 2:
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => const DriverSignupEmailScreen()));
        break;
    }
  }

  @override
  void dispose() {
    debugPrint('=== WelcomeScreen dispose | $_state');
    _speechCancelled = true;
    _isWelcomePlaying = false;
    _cancelReplayTimer();
    _autoStopTimer?.cancel();
    _amplitudeTimer?.cancel();
    _pulseController.dispose();
    _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFDEAF0), Color(0xFFF8BBD0)],
              ),
            ),
            child: SafeArea(
              child: SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height -
                        MediaQuery.of(context).padding.top -
                        MediaQuery.of(context).padding.bottom,
                  ),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32.0, vertical: 10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              const SizedBox(height: 10),
                              Align(
                                alignment: Alignment.topRight,
                                child: GestureDetector(
                                  onTap: _toggleMute,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.5),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      _isMuted
                                          ? Icons.volume_off_rounded
                                          : Icons.volume_up_rounded,
                                      color: const Color(0xFFCF4374),
                                      size: 24,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              SvgPicture.asset(
                                'assets/icons/logo_hersafar.svg',
                                width: 160,
                                height: 100,
                              ),
                              const SizedBox(height: 24),
                              SoundWave(isAnimating: _isSpeaking),
                              const SizedBox(height: 20),
                              const Text(
                                'ایک انتخاب کریں',
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFCF4374),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(vertical: 16.0),
                            child: Column(
                              children: [
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 0,
                                  child: CustomButton(
                                    text: 'نیا صارف',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(0);
                                    },
                                    height: 60,
                                    isPrimary: true,
                                    borderColor: const Color(0xFFF682AA),
                                    backgroundColor: const Color(0xFFF8BBD0),
                                    textColor: const Color(0xFFCF4374),
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 1,
                                  child: CustomButton(
                                    text: 'پہلے سے رجسٹر ہیں؟',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(1);
                                    },
                                    height: 60,
                                    isPrimary: true,
                                    borderColor: const Color(0xFFF682AA),
                                    backgroundColor: const Color(0xFFFAECF1),
                                    textColor: const Color(0xFFCF4374),
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _AnimatedButton(
                                  isHighlighted: _highlightedButton == 2,
                                  child: CustomButton(
                                    text: 'رجسٹر بطور ڈرائیور',
                                    onPressed: () {
                                      _cancelReplayTimer();
                                      _navigateTo(2);
                                    },
                                    height: 50,
                                    isPrimary: false,
                                    borderColor: const Color(0xFFCF4374),
                                    backgroundColor: const Color(0xFFCF4374),
                                    textColor: Colors.white,
                                    fontSize: 18,
                                    isGradient: true,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 16.0),
                            child: Column(
                              children: [
                                MicButton(
                                  isListening: _isListening,
                                  isInterpreting: _isInterpreting,
                                  pulseAnimation: _pulseAnimation,
                                  onTap: _isInterpreting ? null : _toggleListening,
                                ),
                                const SizedBox(height: 12),
                                Builder(builder: (context) {
                                  final String micLabel;
                                  if (_isInterpreting) {
                                    micLabel = 'سمجھ رہا ہوں...';
                                  } else if (_isListening) {
                                    micLabel = 'سننا بند کریں';
                                  } else {
                                    micLabel = 'بولنے کے لیے دبائیں';
                                  }
                                  return AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 300),
                                    child: Text(
                                      micLabel,
                                      key: ValueKey('$_isListening$_isInterpreting'),
                                      textDirection: TextDirection.rtl,
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: (_isListening || _isInterpreting)
                                            ? const Color(0xFF8B1A4A)
                                            : const Color(0xFFCF4374),
                                        fontWeight: (_isListening || _isInterpreting)
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (kIsWeb && !_hasUserInteracted)
            GestureDetector(
              onTap: () {
                debugPrint('=== Web overlay tapped — user first interaction | $_state');
                setState(() => _hasUserInteracted = true);
                _speechCancelled = false;
                debugPrint('=== Web overlay: calling _speakWelcome (unawaited) | $_state');
                _speakWelcome();
                // NOTE: _speakWelcome is unawaited here. It will restart the
                // replay timer itself at the end. We do NOT call
                // _startReplayTimer() here to avoid the timer firing while
                // _speakWelcome is still running.
              },
              child: Container(
                color: const Color(0xFFF8BBD0).withValues(alpha: 0.92),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.touch_app,
                          size: 60, color: Color(0xFFCF4374)),
                      SizedBox(height: 16),
                      Text(
                        'شروع کرنے کے لیے تھپتھپائیں',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFCF4374),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Tap anywhere to start',
                        style: TextStyle(
                            fontSize: 16, color: Color(0xFFCF4374)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}


class _AnimatedButton extends StatelessWidget {
  final bool isHighlighted;
  final Widget child;

  const _AnimatedButton({required this.isHighlighted, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: isHighlighted ? 1.06 : 1.0,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: isHighlighted
              ? [
                  BoxShadow(
                    color: const Color(0xFFCF4374).withValues(alpha: 0.45),
                    blurRadius: 14,
                    spreadRadius: 3,
                  )
                ]
              : [],
        ),
        child: child,
      ),
    );
  }
}