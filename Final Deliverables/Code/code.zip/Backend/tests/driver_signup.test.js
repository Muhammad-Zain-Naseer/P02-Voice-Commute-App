/**
 * HerSafar – Use Case 3: Driver Signup
 * ======================================
 * Routes:
 *   POST /api/driver/auth/request-otp
 *   POST /api/driver/auth/verify-otp
 *   POST /api/driver/auth/submit-name
 *   POST /api/driver/auth/submit-cnic
 *   POST /api/driver/auth/submit-license
 *   POST /api/driver/auth/submit-pin
 *
 * Techniques:
 *   T01 – ECP Valid Class     : Full correct path through all steps (OTP→name→CNIC→license→PIN)
 *                               (vehicle step skipped – requires multipart/file upload)
 *   T02 – ECP Invalid Class   : Duplicate driver email → blocked at request-otp
 *   T03 – BVA Lower Boundary  : CNIC = 12 digits (one below valid boundary of 13) → 400
 *   T04 – BVA Lower Boundary  : PIN = 3 digits (one below valid boundary of 4) → 400
 *   T05 – Pairwise            : Invalid license format (no city prefix) + valid name/CNIC → 400
 */

import request from "supertest";
import app from "../src/app/app.js";
import Driver from "../src/models/Driver.js";
import User from "../src/models/User.js";
import OTP from "../src/models/OTP.js";
import mongoose from "mongoose";

const BASE = "/api/driver/auth";

const TEST_EMAILS = [
  "t01_driver@hersafar.test",
  "t02_dupdriver@hersafar.test",
  "t03_cnic12@hersafar.test",
  "t04_pin3@hersafar.test",
  "t05_badlicense@hersafar.test",
];

// ── helper: submit name + CNIC steps and return the token after CNIC ────
async function submitNameAndCnic(app, token, cnic) {
  const nameRes = await request(app)
    .post(`${BASE}/submit-name`)
    .set("Authorization", `Bearer ${token}`)
    .send({ name: "Test Driver" });
  const cnicRes = await request(app)
    .post(`${BASE}/submit-cnic`)
    .set("Authorization", `Bearer ${nameRes.body.data.token}`)
    .send({ cnic });
  return cnicRes.body.data.token;
}

// ── helper: request OTP then verify it via DB to get a registration token ────
async function getRegistrationToken(email) {
  await request(app).post(`${BASE}/request-otp`).send({ email });

  const otpRecord = await OTP.findOne({ email, type: "driver_registration" });
  if (!otpRecord) throw new Error(`OTP not found in DB for ${email}`);

  const res = await request(app)
    .post(`${BASE}/verify-otp`)
    .send({ email, otp: otpRecord.otp });

  if (!res.body?.data?.token)
    throw new Error(`Token not returned for ${email}: ${JSON.stringify(res.body)}`);

  return res.body.data.token;
}

// ── setup / teardown ────
beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await Driver.deleteMany({ email: { $in: TEST_EMAILS } });
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
  await OTP.deleteMany({ email: { $in: TEST_EMAILS } });
});

afterAll(async () => {
  await Driver.deleteMany({ email: { $in: TEST_EMAILS } });
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
  await OTP.deleteMany({ email: { $in: TEST_EMAILS } });
  await mongoose.connection.close();
});

// ══════════════════════════════════════════════════════════════════════════════
// USE CASE 22 – DRIVER SIGNUP
// ══════════════════════════════════════════════════════════════════════════════

describe("UC-22 | Driver Signup – /api/driver/auth", () => {

  // ── T01 – ECP Valid Class ──────────────────────────────────────────────────
  test("T01 [ECP – Valid Class] Full correct path: OTP → name → CNIC → license → 200 at each step", async () => {
    const email = "t01_driver@hersafar.test";

    // Steps 1-2: Request OTP + Verify (uses helper to bypass live email service in test env)
    // OTP is planted via request-otp then read directly from DB and verified.
    let token = await getRegistrationToken(email);
    expect(token).toBeDefined();

    // Step 3: Submit name (≥ 2 chars)
    const nameRes = await request(app)
      .post(`${BASE}/submit-name`)
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Ahmed Ali" });
    expect(nameRes.status).toBe(200);
    expect(nameRes.body.success).toBe(true);
    token = nameRes.body.data.token;

    // Step 4: Submit CNIC – exactly 13 digits (valid boundary)
    const cnicRes = await request(app)
      .post(`${BASE}/submit-cnic`)
      .set("Authorization", `Bearer ${token}`)
      .send({ cnic: "3520112345671" });
    expect(cnicRes.status).toBe(200);
    expect(cnicRes.body.success).toBe(true);
    token = cnicRes.body.data.token;

    // Step 5: Submit driving license – valid format (3-letter city + 7 digits)
    const licenseRes = await request(app)
      .post(`${BASE}/submit-license`)
      .set("Authorization", `Bearer ${token}`)
      .send({ drivingLicense: "LHR-1234561" });
    expect(licenseRes.status).toBe(200);
    expect(licenseRes.body.success).toBe(true);

  });

  // ── T02 – ECP Invalid Class ─────
  test("T02 [ECP – Invalid Class] Duplicate driver email → 400 'already exists'", async () => {
    const email = "t02_dupdriver@hersafar.test";

    // Seed a verified driver with this email
    await Driver.create({
      userId: "dup-uuid-002",
      email,
      name: "Existing Driver",
      cnic: "3520199999992",
      drivingLicense: "LHR-9999992",
      vehicle: {
        registrationNumber: "DUP002",
        model: "Toyota",
        year: "2020",
        color: "White",
        registrationPhoto: "/uploads/vehicle-registrations/dummy.jpg",
      },
      isVerified: true,
      status: "pending",
    });

    const res = await request(app)
      .post(`${BASE}/request-otp`)
      .send({ email });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    // Controller message: "Driver account already exists. Please login."
    expect(res.body.message).toMatch(/already exists/i);
  });

  // ── T03 – BVA Lower Boundary (CNIC) ───────────────────────────────────────
  test("T03 [BVA – Lower Boundary] CNIC = 12 digits (valid is 13) → 400 'CNIC must be 13 digits'", async () => {
    const email = "t03_cnic12@hersafar.test";
    let token = await getRegistrationToken(email);

    // Submit name first (required before CNIC in the flow)
    const nameRes = await request(app)
      .post(`${BASE}/submit-name`)
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Test Driver" });
    token = nameRes.body.data.token;

    // Submit CNIC with 12 digits – one below lower boundary
    const res = await request(app)
      .post(`${BASE}/submit-cnic`)
      .set("Authorization", `Bearer ${token}`)
      .send({ cnic: "352011234567" }); // 12 digits

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    // Controller message: "CNIC must be 13 digits"
    expect(res.body.message).toMatch(/13 digits/i);
  });

  // ── T04 – BVA Lower Boundary (PIN) ───
  test("T04 [BVA – Lower Boundary] PIN = 3 digits (valid is 4) → 400 'PIN must be exactly 4 digits'", async () => {
    const email = "t04_pin3@hersafar.test";
    let token = await getRegistrationToken(email);

    token = await submitNameAndCnic(app, token, "3520112345672");

    const licenseRes = await request(app)
      .post(`${BASE}/submit-license`)
      .set("Authorization", `Bearer ${token}`)
      .send({ drivingLicense: "LHR-1234562" });
    token = licenseRes.body.data.token;

    // Submit PIN with 3 digits – one below lower boundary
    const res = await request(app)
      .post(`${BASE}/submit-pin`)
      .set("Authorization", `Bearer ${token}`)
      .send({ pin: "123" }); // 3 digits

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    // Controller message: "PIN must be exactly 4 digits"
    expect(res.body.message).toMatch(/4 digits/i);
  });

  // ── T05 – Pairwise ───
  test("T05 [Pairwise] Invalid license format (no city prefix) + valid name/CNIC → 400", async () => {
    const email = "t05_badlicense@hersafar.test";
    let token = await getRegistrationToken(email);

    token = await submitNameAndCnic(app, token, "3520112345673");

    // Submit license with numeric-only value – no 3-letter city prefix
    const res = await request(app)
      .post(`${BASE}/submit-license`)
      .set("Authorization", `Bearer ${token}`)
      .send({ drivingLicense: "1234567890" }); // fails /^[A-Z]{3}-?\d{7}$/

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    // Controller message: "Invalid license format. Expected format: LHR-1234567"
    expect(res.body.message).toMatch(/invalid license format/i);
  });

});