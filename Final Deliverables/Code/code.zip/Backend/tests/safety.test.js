import request from "supertest";
import express from "express";
import { jest } from "@jest/globals";

// ─── Mocks must be declared before importing the controller ───────────────────

// Mock SafetyAlert model
const mockAlertCreate = jest.fn();
const mockAlertFind = jest.fn();

jest.unstable_mockModule("../src/models/SafetyAlert.js", () => ({
    default: {
        create: mockAlertCreate,
        find: mockAlertFind,
    },
}));

// Mock connectionPool so socket.io doesn't need to be running
jest.unstable_mockModule("../src/services/connectionPool.service.js", () => ({
    default: {
        io: { emit: jest.fn() },
        setIO: jest.fn(),
    },
}));

// Mock logger to suppress noise during tests
jest.unstable_mockModule("../src/utils/logger.js", () => ({
    default: {
        info: jest.fn(),
        warn: jest.fn(),
        error: jest.fn(),
    },
}));

// Mock auth middleware — inject a fake admin user into req.user
jest.unstable_mockModule("../src/middleware/auth.middleware.js", () => ({
    authenticate: (req, res, next) => {
        req.user = { userId: "admin-001", name: "Test Admin", role: "admin" };
        next();
    },
    authorize: (...roles) => (req, res, next) => {
        if (!roles.includes(req.user?.role)) {
            return res.status(403).json({ success: false, message: "Forbidden" });
        }
        next();
    },
}));

// Mock rate limiter so it never blocks tests
jest.unstable_mockModule("../src/middleware/rateLimit.middleware.js", () => ({
    alertRateLimiter: (req, res, next) => next(),
}));

// ─── Now import controller and routes (after mocks are registered) ─────────────
const { default: safetyRoutes } = await import("../src/routes/safety.routes.js");

// ─── Build a minimal Express app (no DB, no socket server) ────────────────────
const app = express();
app.use(express.json());
app.use("/api/admin/alerts", safetyRoutes);

// ─── Test Suites ──────────────────────────────────────────────────────────────

describe("Send Safety Alert — POST /api/admin/alerts/alerts", () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    // T01: Happy path — valid message and severity
    test("T01: Admin broadcasts a valid high-severity alert", async () => {
        const fakeAlert = {
            _id: "alert-001",
            message: "Road closure on Main Boulevard due to flooding.",
            severity: "high",
            targetAudience: "all",
            senderId: "admin-001",
            senderName: "Test Admin",
            sentAt: new Date(),
        };
        mockAlertCreate.mockResolvedValue(fakeAlert);

        const res = await request(app)
            .post("/api/admin/alerts/alerts")
            .set("Authorization", "Bearer fake-admin-token")
            .send({
                message: "Road closure on Main Boulevard due to flooding.",
                severity: "high",
            });

        expect(res.status).toBe(201);
        expect(res.body.success).toBe(true);
        expect(res.body.message).toBe("Safety alert broadcasted successfully");
        expect(res.body.data.severity).toBe("high");
        expect(mockAlertCreate).toHaveBeenCalledTimes(1);
    });

    // T02: Empty message — rejected by backend validation
    test("T02: Rejects request when message is empty string", async () => {
        const res = await request(app)
            .post("/api/admin/alerts/alerts")
            .set("Authorization", "Bearer fake-admin-token")
            .send({ message: "", severity: "high" });

        expect(res.status).toBe(400);
        expect(res.body.success).toBe(false);
        expect(res.body.error).toMatch(/required/i);
        expect(mockAlertCreate).not.toHaveBeenCalled();
    });

    // T03: Low severity — valid, should be saved as "low"
    test("T03: Admin broadcasts a valid low-severity alert", async () => {
        const fakeAlert = {
            _id: "alert-002",
            message: "Low traffic alert near Gulberg.",
            severity: "low",
            targetAudience: "all",
            senderId: "admin-001",
            senderName: "Test Admin",
            sentAt: new Date(),
        };
        mockAlertCreate.mockResolvedValue(fakeAlert);

        const res = await request(app)
            .post("/api/admin/alerts/alerts")
            .set("Authorization", "Bearer fake-admin-token")
            .send({ message: "Low traffic alert near Gulberg.", severity: "low" });

        expect(res.status).toBe(201);
        expect(res.body.success).toBe(true);
        expect(res.body.data.severity).toBe("low");
    });

    // T04: No auth token — middleware rejects with 401
    test("T04: Rejects request with no Authorization token (401)", async () => {
        // Build a separate app that simulates real authenticate rejecting missing token
        const appNoAuth = express();
        appNoAuth.use(express.json());
        appNoAuth.use("/api/admin/alerts", (req, res, next) => {
            const token = req.header("Authorization")?.replace("Bearer ", "");
            if (!token) {
                return res.status(401).json({
                    success: false,
                    message: "No authentication token provided",
                });
            }
            next();
        }, safetyRoutes);

        const res = await request(appNoAuth)
            .post("/api/admin/alerts/alerts")
            .send({ message: "Test alert", severity: "medium" });

        expect(res.status).toBe(401);
        expect(res.body.success).toBe(false);
        expect(mockAlertCreate).not.toHaveBeenCalled();
    });

    // T05: Whitespace-only message — trim() makes it empty
    test("T05: Rejects request when message is whitespace only", async () => {
        const res = await request(app)
            .post("/api/admin/alerts/alerts")
            .set("Authorization", "Bearer fake-admin-token")
            .send({ message: "     ", severity: "medium" });

        expect(res.status).toBe(400);
        expect(res.body.success).toBe(false);
        expect(mockAlertCreate).not.toHaveBeenCalled();
    });
});

describe("Get Alert History — GET /api/admin/alerts/alerts", () => {
    beforeEach(() => jest.clearAllMocks());

    test("Returns list of alerts sorted by sentAt descending", async () => {
        const fakeAlerts = [
            { _id: "a2", message: "Alert 2", severity: "high", sentAt: new Date() },
            { _id: "a1", message: "Alert 1", severity: "low", sentAt: new Date(Date.now() - 10000) },
        ];
        mockAlertFind.mockReturnValue({
            sort: jest.fn().mockReturnValue({
                limit: jest.fn().mockResolvedValue(fakeAlerts),
            }),
        });

        const res = await request(app)
            .get("/api/admin/alerts/alerts")
            .set("Authorization", "Bearer fake-admin-token");

        expect(res.status).toBe(200);
        expect(res.body.success).toBe(true);
        expect(res.body.data).toHaveLength(2);
        expect(res.body.data[0]._id).toBe("a2");
    });
});

describe("Get Public Alert History — GET /api/admin/alerts/history", () => {
    beforeEach(() => jest.clearAllMocks());

    test("Returns only alerts from the last 7 days", async () => {
        const recentAlerts = [
            { _id: "a3", message: "Recent alert", severity: "critical", sentAt: new Date() },
        ];
        mockAlertFind.mockReturnValue({
            select: jest.fn().mockReturnValue({
                sort: jest.fn().mockResolvedValue(recentAlerts),
            }),
        });

        const res = await request(app)
            .get("/api/admin/alerts/history")
            .set("Authorization", "Bearer fake-admin-token");

        expect(res.status).toBe(200);
        expect(res.body.success).toBe(true);
        expect(res.body.count).toBe(1);
        expect(res.body.data[0].severity).toBe("critical");
    });
});