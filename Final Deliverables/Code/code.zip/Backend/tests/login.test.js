/**
 * HerSafar – Use Case 1: User Login
 * =====================================
 * Route   : POST /api/auth/login
 * Techniques:
 *   T01 – ECP Valid Class
 *   T02 – ECP Invalid Class (wrong PIN)
 *   T03 – BVA State Boundary (unverified account)
 *   T04 – ECP Invalid + Pairwise (suspended account + correct PIN)
 *   T05 – Pairwise (non-existent email)
 */

import request from "supertest";
import app from "../src/app/app.js";
import User from "../src/models/User.js";
import mongoose from "mongoose";

const BASE = "/api/auth";

const TEST_EMAILS = [
  "t01_login@hersafar.test",
  "t03_unverified@hersafar.test",
  "t04_suspended@hersafar.test",
];

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await User.deleteMany({ email: { $in: TEST_EMAILS } });

  // ── Seed T01: verified commuter ────
  await request(app).post(`${BASE}/signup`).send({
    name : "Login User",
    email: "t01_login@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });
  await User.findOneAndUpdate(
    { email: "t01_login@hersafar.test" },
    {
      isVerified             : true,
      verificationToken      : undefined,
      verificationTokenExpiry: undefined,
    }
  );

  // ── Seed T03: unverified commuter (isVerified stays false) ──
  await request(app).post(`${BASE}/signup`).send({
    name : "Unverified User",
    email: "t03_unverified@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });

  // ── Seed T04: verified + suspended commuter ─────
  await request(app).post(`${BASE}/signup`).send({
    name : "Suspended User",
    email: "t04_suspended@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });
  await User.findOneAndUpdate(
    { email: "t04_suspended@hersafar.test" },
    {
      isVerified       : true,
      isSuspended      : true,
      suspensionReason : "Policy violation during testing",
      verificationToken: undefined,
    }
  );
});

afterAll(async () => {
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
  await mongoose.connection.close();
});

describe("UC-02 | User Login – POST /api/auth/login", () => {

  // ── T01 – ECP Valid Class ───
  test("T01 [ECP – Valid Class] Correct email + PIN → 200 + JWT issued", async () => {
    const res = await request(app)
      .post(`${BASE}/login`)
      .send({
        email: "t01_login@hersafar.test",
        pin  : "1234",
      });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.message).toMatch(/login successful/i);
    expect(res.body.data.token).toBeDefined();
    expect(res.body.data.user.email).toBe("t01_login@hersafar.test");
    expect(res.body.data.user.role).toBe("commuter");

    // DB: lastLogin updated
    const user = await User.findOne({ email: "t01_login@hersafar.test" });
    expect(user.lastLogin).not.toBeNull();
  });

  // ── T02 – ECP Invalid Class ────
  test("T02 [ECP – Invalid Class] Wrong PIN → 401 + no token", async () => {
    const res = await request(app)
      .post(`${BASE}/login`)
      .send({
        email: "t01_login@hersafar.test",
        pin  : "9999",
      });

    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/invalid email or pin/i);
    expect(res.body.data).toBeUndefined();
  });

  // ── T03 – BVA State Boundary ────
  test("T03 [BVA – State Boundary] Unverified account (isVerified=false) → 403", async () => {
    const res = await request(app)
      .post(`${BASE}/login`)
      .send({
        email: "t03_unverified@hersafar.test",
        pin  : "1234",
      });

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/verify your email/i);
    expect(res.body.data).toBeUndefined();
  });

  // ── T04 – ECP Invalid + Pairwise ─────
  test("T04 [ECP Invalid + Pairwise] Suspended account + correct PIN → 403 + reason", async () => {
    const res = await request(app)
      .post(`${BASE}/login`)
      .send({
        email: "t04_suspended@hersafar.test",
        pin  : "1234",
      });

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/suspended/i);
    expect(res.body.accountStatus).toBe("suspended");
    expect(res.body.reason).toBeDefined();
  });

  // ── T05 – Pairwise ───
  test("T05 [Pairwise] Non-existent email → 401 (no user enumeration)", async () => {
    const res = await request(app)
      .post(`${BASE}/login`)
      .send({
        email: "ghost@hersafar.test",
        pin  : "1234",
      });

    // 401 as wrong PIN — prevents user enumeration attack
    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/invalid email or pin/i);
  });

});