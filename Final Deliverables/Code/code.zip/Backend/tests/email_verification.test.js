/**
 * HerSafar – Use Case 3: Email Verification
 * ==========================================
 * Route   : GET /api/auth/verify-email?token=<token>
 * Techniques:
 *   T01 – ECP Valid Class         (valid token → 200 + JWT)
 *   T02 – ECP Invalid Class       (wrong/random token → 400)
 *   T03 – BVA State Boundary      (expired token → 400)
 *   T04 – Pairwise                (missing token param → 400)
 *   T05 – Pairwise                (token already used/cleared → 400)
 */

import request from "supertest";
import app from "../src/app/app.js";
import User from "../src/models/User.js";
import mongoose from "mongoose";

const BASE = "/api/auth";

const TEST_EMAILS = [
  "t01_verify@hersafar.test",
  "t03_expired@hersafar.test",
  "t05_reuse@hersafar.test",
];

let validToken = "";
let usedToken  = "";

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await User.deleteMany({ email: { $in: TEST_EMAILS } });

  // ── Seed T01: unverified commuter with a valid token ──
  await request(app).post(`${BASE}/signup`).send({
    name : "Verify User",
    email: "t01_verify@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });
  const t01User = await User.findOne({ email: "t01_verify@hersafar.test" });
  validToken = t01User.verificationToken;

  // ── Seed T03: user whose token expiry is set to the past ──
  await request(app).post(`${BASE}/signup`).send({
    name : "Expired User",
    email: "t03_expired@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });
  await User.findOneAndUpdate(
    { email: "t03_expired@hersafar.test" },
    { verificationTokenExpiry: new Date(Date.now() - 1000) } // 1 second in the past
  );

  // ── Seed T05: user whose token we will consume first, then reuse ──
  await request(app).post(`${BASE}/signup`).send({
    name : "Reuse User",
    email: "t05_reuse@hersafar.test",
    pin  : "1234",
    role : "commuter",
  });
  const t05User = await User.findOne({ email: "t05_reuse@hersafar.test" });
  usedToken = t05User.verificationToken;
  // Consume the token by verifying successfully
  await request(app).get(`${BASE}/verify-email?token=${usedToken}`);
});

afterAll(async () => {
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
  await mongoose.connection.close();
});

describe("UC-03 | Email Verification – GET /api/auth/verify-email", () => {

  // ── T01 – ECP Valid Class ───────────────────────────────────────────────
  test("T01 [ECP – Valid Class] Valid token → 200 + JWT issued", async () => {
    const res = await request(app)
      .get(`${BASE}/verify-email?token=${validToken}`);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.token).toBeDefined();

    // DB: isVerified set to true, token cleared
    const user = await User.findOne({ email: "t01_verify@hersafar.test" });
    expect(user.isVerified).toBe(true);
    expect(user.verificationToken).toBeFalsy();
  });

  // ── T02 – ECP Invalid Class ─────────────────────────────────────────────
  test("T02 [ECP – Invalid Class] Random/wrong token → 400 invalid token", async () => {
    const res = await request(app)
      .get(`${BASE}/verify-email?token=totally-invalid-random-token-xyz`);

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/invalid or expired/i);
  });

  // ── T03 – BVA State Boundary ────────────────────────────────────────────
  test("T03 [BVA – State Boundary] Expired token → 400 invalid/expired", async () => {
    const expiredUser = await User.findOne({ email: "t03_expired@hersafar.test" });
    const expiredToken = expiredUser.verificationToken;

    const res = await request(app)
      .get(`${BASE}/verify-email?token=${expiredToken}`);

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/invalid or expired/i);

    // DB: user remains unverified
    const user = await User.findOne({ email: "t03_expired@hersafar.test" });
    expect(user.isVerified).toBe(false);
  });

  // ── T04 – Pairwise ──────────────────────────────────────────────────────
  test("T04 [Pairwise] Missing token query param → 400 required", async () => {
    const res = await request(app)
      .get(`${BASE}/verify-email`);

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/required/i);
  });

  // ── T05 – Pairwise ──────────────────────────────────────────────────────
  test("T05 [Pairwise] Already-used token resubmitted → 400 invalid/expired", async () => {
    // usedToken was consumed in beforeAll — the DB entry no longer holds it
    const res = await request(app)
      .get(`${BASE}/verify-email?token=${usedToken}`);

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/invalid or expired/i);
  });

});
