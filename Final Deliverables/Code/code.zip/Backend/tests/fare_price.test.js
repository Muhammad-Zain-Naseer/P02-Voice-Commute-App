/**
 * HerSafar – Use Case 5: Fare Price Management
 * ==============================================
 * Routes  : GET  /api/fares/current   (public)
 *           PUT  /api/fares/update    (admin only)
 * Techniques:
 *   T01 – ECP Valid Class       (GET current fare → 200, no auth)
 *   T02 – ECP Valid Class       (PUT update with admin JWT + valid rate → 200)
 *   T03 – ECP Invalid Class     (PUT update without auth token → 401)
 *   T04 – BVA Lower Boundary    (PUT update with ratePerKm = 0 → 400)
 *   T05 – BVA Lower Boundary    (PUT update with ratePerKm = -1 → 400)
 */

import request from "supertest";
import app from "../src/app/app.js";
import User from "../src/models/User.js";
import mongoose from "mongoose";

const AUTH_BASE  = "/api/auth";
const FARES_BASE = "/api/fares";

const ADMIN_EMAIL = "t_admin_fare@hersafar.test";

let adminToken = "";

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await User.deleteMany({ email: ADMIN_EMAIL });

  // ── Seed admin user ──
  await request(app).post(`${AUTH_BASE}/signup`).send({
    name : "Fare Admin",
    email: ADMIN_EMAIL,
    pin  : "4321",
    role : "admin",
  });
  await User.findOneAndUpdate(
    { email: ADMIN_EMAIL },
    {
      isVerified             : true,
      verificationToken      : undefined,
      verificationTokenExpiry: undefined,
    }
  );

  // ── Login to get JWT ──
  const loginRes = await request(app).post(`${AUTH_BASE}/login`).send({
    email: ADMIN_EMAIL,
    pin  : "4321",
  });
  adminToken = loginRes.body.data?.token;
});

afterAll(async () => {
  await User.deleteMany({ email: ADMIN_EMAIL });
  await mongoose.connection.close();
});

describe("UC-05 | Fare Price Management – GET /api/fares/current + PUT /api/fares/update", () => {

  // ── T01 – ECP Valid Class ───────────────────────────────────────────────
  test("T01 [ECP – Valid Class] GET /current (no auth) → 200 with fare data", async () => {
    const res = await request(app).get(`${FARES_BASE}/current`);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeDefined();
    // Returns active fare or default
    const fare = res.body.data;
    expect(fare.ratePerKm).toBeDefined();
    expect(typeof fare.ratePerKm).toBe("number");
    expect(fare.ratePerKm).toBeGreaterThan(0);
  });

  // ── T02 – ECP Valid Class ───────────────────────────────────────────────
  test("T02 [ECP – Valid Class] PUT /update with admin JWT + valid rate → 200 fare updated", async () => {
    const res = await request(app)
      .put(`${FARES_BASE}/update`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ ratePerKm: 25 });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toBeDefined();
    expect(res.body.data.ratePerKm).toBe(25);
  });

  // ── T03 – ECP Invalid Class ─────────────────────────────────────────────
  test("T03 [ECP – Invalid Class] PUT /update without auth token → 401 unauthorized", async () => {
    const res = await request(app)
      .put(`${FARES_BASE}/update`)
      .send({ ratePerKm: 30 });

    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
  });

  // ── T04 – BVA Lower Boundary ────────────────────────────────────────────
  test("T04 [BVA – Lower Boundary] ratePerKm = 0 → 400 must be positive", async () => {
    const res = await request(app)
      .put(`${FARES_BASE}/update`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ ratePerKm: 0 });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/positive/i);
  });

  // ── T05 – BVA Lower Boundary ────────────────────────────────────────────
  test("T05 [BVA – Lower Boundary] ratePerKm = -1 → 400 must be positive", async () => {
    const res = await request(app)
      .put(`${FARES_BASE}/update`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ ratePerKm: -1 });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/positive/i);
  });

});
