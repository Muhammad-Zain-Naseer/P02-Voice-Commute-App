import request from "supertest";
import express from "express";
import { jest } from "@jest/globals";
import mongoose from "mongoose";

// ─── Mocks must be declared before importing the controller ───────────────────

// Mock SupportTicket model
const mockTicketCreate = jest.fn();
const mockTicketFind = jest.fn();
const mockTicketFindByIdAndUpdate = jest.fn();
const mockTicketCountDocuments = jest.fn();

jest.unstable_mockModule("../src/models/SupportTicket.js", () => ({
    default: {
        create: mockTicketCreate,
        find: mockTicketFind,
        findByIdAndUpdate: mockTicketFindByIdAndUpdate,
        countDocuments: mockTicketCountDocuments,
    },
}));

// Mock auth middleware — inject a fake commuter user by default
jest.unstable_mockModule("../src/middleware/auth.middleware.js", () => ({
    authenticate: (req, res, next) => {
        req.user = { userId: "user_commuter_001", role: "commuter" };
        next();
    },
}));

// Mock upload middleware — no real file handling needed
jest.unstable_mockModule("../src/middleware/upload.middleware.js", () => ({
    default: {
        single: () => (req, res, next) => next(),
    },
}));

// Mock logger to suppress noise
jest.unstable_mockModule("../src/utils/logger.js", () => ({
    default: {
        info: jest.fn(),
        warn: jest.fn(),
        error: jest.fn(),
    },
}));

// ─── Now import routes (after mocks are registered) ───────────────────────────
const { default: supportRoutes } = await import("../src/routes/support.routes.js");

// ─── Build minimal Express app (no DB, no real uploads) ───────────────────────
const app = express();
app.use(express.json());
app.use("/api/support", supportRoutes);

// ─── App with NO auth (for T03) ───────────────────────────────────────────────
const appNoAuth = express();
appNoAuth.use(express.json());
appNoAuth.use("/api/support", (req, res, next) => {
    const token = req.header("Authorization")?.replace("Bearer ", "");
    if (!token) {
        return res.status(401).json({
            success: false,
            message: "No authentication token provided",
        });
    }
    next();
}, supportRoutes);

// ─── Clear mocks between tests ────────────────────────────────────────────────
beforeEach(() => {
    jest.clearAllMocks();
});

// ════════════════════════════════════════════════════════════════════════════
// T01 – Happy path: submit valid ticket → admin fetches → admin resolves
// ════════════════════════════════════════════════════════════════════════════
describe("T01 – Submit valid ticket and resolve it (happy path)", () => {

    test("POST /api/support → 201, ticket saved with status=open", async () => {
        const fakeTicket = {
            _id: "ticket-001",
            userId: "user_commuter_001",
            role: "commuter",
            category: "safety_concern",
            descriptionText: "Driver was rude",
            audioUrl: null,
            status: "open",
            createdAt: new Date(),
        };
        mockTicketCreate.mockResolvedValue(fakeTicket);

        const res = await request(app)
            .post("/api/support")
            .send({ category: "safety_concern", role: "commuter", descriptionText: "Driver was rude" });

        expect(res.statusCode).toBe(201);
        expect(res.body.success).toBe(true);
        expect(res.body.data.status).toBe("open");
        expect(res.body.data.category).toBe("safety_concern");
        expect(res.body.data.descriptionText).toBe("Driver was rude");
        expect(mockTicketCreate).toHaveBeenCalledTimes(1);
    });

    test("GET /api/support/tickets?status=open → 200, returns ticket list", async () => {
        const fakeTickets = [
            {
                _id: "ticket-001",
                userId: "user_commuter_001",
                role: "commuter",
                category: "safety_concern",
                descriptionText: "Driver was rude",
                status: "open",
                createdAt: new Date(),
            },
        ];
        mockTicketFind.mockReturnValue({
            sort: jest.fn().mockReturnValue({
                lean: jest.fn().mockResolvedValue(fakeTickets),
            }),
        });

        const res = await request(app)
            .get("/api/support/tickets?status=open");

        expect(res.statusCode).toBe(200);
        expect(res.body.success).toBe(true);
        expect(res.body.count).toBe(1);
        expect(res.body.data[0].status).toBe("open");
        expect(res.body.data[0].category).toBe("safety_concern");
    });

    test("PATCH /api/support/:id/status → 200, status=resolved with resolvedAt set", async () => {
        const resolvedTicket = {
            _id: "ticket-001",
            category: "safety_concern",
            status: "resolved",
            resolvedAt: new Date(),
            resolvedBy: "user_admin_001",
        };
        mockTicketFindByIdAndUpdate.mockResolvedValue(resolvedTicket);

        const res = await request(app)
            .patch("/api/support/ticket-001/status")
            .send({ status: "resolved" });

        expect(res.statusCode).toBe(200);
        expect(res.body.success).toBe(true);
        expect(res.body.data.status).toBe("resolved");
        expect(res.body.data.resolvedAt).toBeTruthy();
    });
});

// ════════════════════════════════════════════════════════════════════════════
// T02 – Missing category → 400 validation error
// ════════════════════════════════════════════════════════════════════════════
describe("T02 – Submit ticket without category → 400", () => {

    test("returns 400 with 'Issue category is required'", async () => {
        const res = await request(app)
            .post("/api/support")
            .send({ role: "commuter", descriptionText: "Some issue" });

        expect(res.statusCode).toBe(400);
        expect(res.body.success).toBe(false);
        expect(res.body.error).toMatch(/category is required/i);
    });

    test("SupportTicket.create is never called when category is missing", async () => {
        await request(app)
            .post("/api/support")
            .send({ role: "commuter" });

        expect(mockTicketCreate).not.toHaveBeenCalled();
    });
});

// ════════════════════════════════════════════════════════════════════════════
// T03 – No auth token → 401
// ════════════════════════════════════════════════════════════════════════════
describe("T03 – Submit ticket without auth token → 401", () => {

    test("returns 401 and SupportTicket.create is never called", async () => {
        const res = await request(appNoAuth)
            .post("/api/support")
            .send({ category: "payment_issue", role: "commuter" });

        expect(res.statusCode).toBe(401);
        expect(res.body.success).toBe(false);
        expect(mockTicketCreate).not.toHaveBeenCalled();
    });
});

// ════════════════════════════════════════════════════════════════════════════
// T04 – Invalid status value → 400
// ════════════════════════════════════════════════════════════════════════════
describe("T04 – Admin sends invalid status value → 400", () => {

    test("returns 400 with 'Invalid status value'", async () => {
        const res = await request(app)
            .patch("/api/support/ticket-001/status")
            .send({ status: "closed" }); // not in enum

        expect(res.statusCode).toBe(400);
        expect(res.body.success).toBe(false);
        expect(res.body.error).toMatch(/invalid status/i);
    });

    test("SupportTicket.findByIdAndUpdate is never called when status is invalid", async () => {
        await request(app)
            .patch("/api/support/ticket-001/status")
            .send({ status: "closed" });

        expect(mockTicketFindByIdAndUpdate).not.toHaveBeenCalled();
    });
});

// ════════════════════════════════════════════════════════════════════════════
// T05 – Resolve a non-existent ticket → 404
// ════════════════════════════════════════════════════════════════════════════
describe("T05 – Admin resolves a ticket that does not exist → 404", () => {

    test("returns 404 with 'Ticket not found'", async () => {
        mockTicketFindByIdAndUpdate.mockResolvedValue(null); // simulates no ticket found

        const fakeId = new mongoose.Types.ObjectId().toString();

        const res = await request(app)
            .patch(`/api/support/${fakeId}/status`)
            .send({ status: "resolved" });

        expect(res.statusCode).toBe(404);
        expect(res.body.success).toBe(false);
        expect(res.body.error).toMatch(/ticket not found/i);
    });

    test("SupportTicket.findByIdAndUpdate is called but returns null", async () => {
        mockTicketFindByIdAndUpdate.mockResolvedValue(null);

        const fakeId = new mongoose.Types.ObjectId().toString();

        await request(app)
            .patch(`/api/support/${fakeId}/status`)
            .send({ status: "resolved" });

        expect(mockTicketFindByIdAndUpdate).toHaveBeenCalledTimes(1);
    });
});