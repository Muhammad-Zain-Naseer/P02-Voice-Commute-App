/**
 * HerSafar – Use Case 1: User Signup
 * =====================================
 * Route   : POST /api/auth/signup
 * Techniques:
 *   T01 – ECP Valid Class
 *   T02 – ECP Invalid Class (duplicate email)
 *   T03 – BVA Lower Boundary (PIN = 3 digits)
 *   T04 – BVA Upper Boundary (PIN = 5 digits)
 *   T05 – Pairwise (trusted contact = own email)
 */

import request from "supertest";
import app from "../src/app/app.js";
import User from "../src/models/User.js";
import mongoose from "mongoose";

const BASE = "/api/auth";

async function signupWithPin(email, pin) {
  return request(app).post(`${BASE}/signup`).send({ name: "Zara Malik", email, pin, role: "commuter" });
}

const TEST_EMAILS = [
  "t01_signup@hersafar.test",
  "t03_pin3@hersafar.test",
  "t04_pin5@hersafar.test",
  "t05_trusted@hersafar.test",
];

beforeAll(async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI_TEST);
  }
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
});

afterAll(async () => {
  await User.deleteMany({ email: { $in: TEST_EMAILS } });
  await mongoose.connection.close();
});

describe("UC-01 | User Signup – POST /api/auth/signup", () => {

  // ── T01 – ECP Valid Class ────
  test("T01 [ECP – Valid Class] All valid fields → 201 + verification email sent", async () => {
    const res = await request(app)
      .post(`${BASE}/signup`)
      .send({
        name : "Fatima Ahmed",
        email: "t01_signup@hersafar.test",
        pin  : "1234",
        role : "commuter",
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.message).toMatch(/check your email/i);
    expect(res.body.data.email).toBe("t01_signup@hersafar.test");

    // DB: record created with isVerified = false
    const user = await User.findOne({ email: "t01_signup@hersafar.test" });
    expect(user).not.toBeNull();
    expect(user.isVerified).toBe(false);
  });

  // ── T02 – ECP Invalid Class ────
  test("T02 [ECP – Invalid Class] Duplicate email → 400 + error message", async () => {
    // t01_signup@hersafar.test was created in T01
    const res = await request(app)
      .post(`${BASE}/signup`)
      .send({
        name : "Ali Khan",
        email: "t01_signup@hersafar.test",
        pin  : "5678",
        role : "commuter",
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/already exists/i);
  });

  // ── T03 – BVA Lower Boundary ─────
  test("T03 [BVA – Lower Boundary] PIN = 3 digits (below valid) → 400", async () => {
    const res = await signupWithPin("t03_pin3@hersafar.test", "123");
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/4 digits/i);
    const user = await User.findOne({ email: "t03_pin3@hersafar.test" });
    expect(user).toBeNull();
  });

  // ── T04 – BVA Upper Boundary ────
  test("T04 [BVA – Upper Boundary] PIN = 5 digits (above valid) → 400", async () => {
    const res = await signupWithPin("t04_pin5@hersafar.test", "12345");
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/4 digits/i);
    const user = await User.findOne({ email: "t04_pin5@hersafar.test" });
    expect(user).toBeNull();
  });

  // ── T05 – Pairwise ────
  test("T05 [Pairwise] Trusted contact email = user's own email → 400", async () => {
    const res = await request(app)
      .post(`${BASE}/signup`)
      .send({
        name               : "Hina Baig",
        email              : "t05_trusted@hersafar.test",
        pin                : "4321",
        role               : "commuter",
        trustedContactEmail: "t05_trusted@hersafar.test",
      });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/same as your email/i);

    // DB: no record created
    const user = await User.findOne({ email: "t05_trusted@hersafar.test" });
    expect(user).toBeNull();
  });

});