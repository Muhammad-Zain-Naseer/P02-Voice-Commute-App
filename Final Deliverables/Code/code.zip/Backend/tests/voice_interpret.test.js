/**
 * UC-AI-01 | Welcome Screen Intent Classifier
 * ============================================
 * Route  : POST /api/voice/interpret
 * Source : Gold Dataset rows 24–32 (Section 1)
 *          "AI Test Cases Template.xlsx" – Sprint 4
 *
 * matched values:
 *   0  = new user (sign up)
 *   1  = existing user (login)
 *   2  = driver sign up
 *  -1  = no match / off-topic
 *
 * Audio files: audio files/welcome screen/
 *
 * NOTE: Tests T1.1 ("naya account banana hai") and T1.5 ("Login karna hai")
 * are omitted – no corresponding audio file is present in the folder.
 */

import request from "supertest";
import app from "../src/app/app.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const AUDIO_DIR = path.resolve(__dirname, "../audio files/welcome screen");
const MIME = "audio/mp4";

function loadAudio(filename) {
  return fs.readFileSync(path.join(AUDIO_DIR, filename)).toString("base64");
}

describe("UC-AI-01 | Welcome Screen Intent Classifier – POST /api/voice/interpret", () => {

  const LABEL = { 0: "New User", 1: "Login", 2: "Driver", "-1": "No Match" };

  function log(testId, file, expected, res) {
    const got = res.body.matched;
    const pass = got === expected ? "PASS" : "FAIL";
    console.log(`\n[${pass}] ${testId}`);
    console.log(`  Input  : ${file ?? "(empty)"}`);
    console.log(`  HTTP   : ${res.status}`);
    console.log(`  Expected matched=${expected} (${LABEL[expected]})`);
    console.log(`  Got      matched=${got} (${LABEL[got] ?? "?"})`);
  }

  // ── T1.2 – Gold Row 25 ──────────────────────────────────────────────────────
  // Urdu: "میں پہلے سے رجسٹرڈ ہوں، لاگ ان کرنا ہے"
  test(
    "T1.2 [Gold] Urdu login intent → matched:1",
    async () => {
      const file = "Main pehle se registered hoon, log in karna hai.m4a";
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: loadAudio(file), mimeType: MIME });

      log("T1.2", file, 1, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(1);
    },
    30000
  );

  // ── T1.3 – Gold Row 26 ──────────────────────────────────────────────────────
  // Urdu: "میں ڈرائیور بننا چاہتی ہوں" (female speaker)
  test(
    "T1.3 [Gold] Urdu driver signup intent (female) → matched:2",
    async () => {
      const file = "Main driver banna chahti hoon..m4a";
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: loadAudio(file), mimeType: MIME });

      log("T1.3", file, 2, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(2);
    },
    30000
  );

  // ── T1.4 – Gold Row 27 ──────────────────────────────────────────────────────
  // English: "I want to sign up as a new user"
  test(
    "T1.4 [Gold] English new-user signup intent → matched:0",
    async () => {
      const file = "I want to sign up as a new user.m4a";
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: loadAudio(file), mimeType: MIME });

      log("T1.4", file, 0, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(0);
    },
    30000
  );

  // ── T1.6 – Gold Row 29 ──────────────────────────────────────────────────────
  // Roman Urdu: "Driver register karna hai" (male speaker saying "Main driver banna chahta hoon")
  test(
    "T1.6 [Gold] Roman Urdu driver signup intent (male) → matched:2",
    async () => {
      const file = "Ma driver banna chahta Ho.m4a";
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: loadAudio(file), mimeType: MIME });

      log("T1.6", file, 2, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(2);
    },
    30000
  );

  // ── T1.7 – Gold Row 30 ──────────────────────────────────────────────────────
  // Urdu (off-topic): "آج موسم اچھا ہے" – weather comment, unrelated to app options
  test(
    "T1.7 [Gold] Off-topic Urdu speech → matched:-1",
    async () => {
      const file = "Aaj mausam acha hai.m4a";
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: loadAudio(file), mimeType: MIME });

      log("T1.7", file, -1, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(-1);
    },
    30000
  );

  // ── T1.8 – Gold Row 31 ──────────────────────────────────────────────────────
  // Silent / empty audio – route short-circuits to matched:-1 without calling Gemini
  test(
    "T1.8 [Gold] Empty audio submission → matched:-1",
    async () => {
      const res = await request(app)
        .post("/api/voice/interpret")
        .send({ audioBase64: "", mimeType: MIME });

      log("T1.8", null, -1, res);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.matched).toBe(-1);
    }
  );

});
