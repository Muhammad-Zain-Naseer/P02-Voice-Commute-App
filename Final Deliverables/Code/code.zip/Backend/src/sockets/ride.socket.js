/**
 * Socket Event Handlers for Ride Matching System
 * Handles real-time ride requests, matching, and updates for trusted contacts
 */

import connectionPoolService from "../services/connectionPool.service.js";
import emailService from "../services/emailService.js";
import encryptionService from "../services/encryption.service.js";
import User from "../models/User.js";
import Driver from "../models/Driver.js";
import FarePrice from "../models/FarePrice.js";
import Ride from "../models/Ride.js";
import logger from "../utils/logger.js";

// store session keys for each ride
const rideSessionKeys = new Map();

const EMPTY_ACCOUNT = { accountTitle: "", accountNumber: "" };

async function fetchDriverPaymentDetails(ride) {
  let driver = null;
  if (ride.matchedWith.driverId) driver = await Driver.findOne({ userId: ride.matchedWith.driverId });
  if (!driver && ride.matchedWith.driverEmail) driver = await Driver.findOne({ email: ride.matchedWith.driverEmail });
  if (!driver) {
    const connectionUser = connectionPoolService.getUser(ride.matchedWith.socketId);
    if (connectionUser?.userEmail) driver = await Driver.findOne({ email: connectionUser.userEmail });
  }
  if (!driver?.paymentAccounts) return { easyPaisa: EMPTY_ACCOUNT, jazzCash: EMPTY_ACCOUNT };
  return {
    easyPaisa: driver.paymentAccounts.easyPaisa || EMPTY_ACCOUNT,
    jazzCash:  driver.paymentAccounts.jazzCash  || EMPTY_ACCOUNT,
  };
}

const pendingDriverOffers = new Map();

// store trusted contact socket connections (email -> socketId)
const trustedContactSockets = new Map();

/**
 * Register trusted contact socket connection
 */
export const registerTrustedContact = (socket) => {
  socket.on("trustedContact:register", async (data) => {
    try {
      const { email } = data;

      if (!email) {
        socket.emit("error", { message: "Email is required" });
        return;
      }

      // store the socket connection
      trustedContactSockets.set(email, socket.id);

      logger.info(`📱 Trusted contact registered: ${email} -> ${socket.id}`);

      // find users who have this email as trusted contact
      const users = await User.find({
        "trustedContacts.email": email
      }).select("_id name email");

      socket.emit("trustedContact:registered", {
        success: true,
        monitoringCount: users.length,
        users: users.map((u) => ({
          userId: u._id.toString(),
          name: u.name
        }))
      });
    } catch (error) {
      logger.error(`Error in trustedContact:register: ${error.message}`);
      socket.emit("error", { message: "Failed to register trusted contact" });
    }
  });

  socket.on("disconnect", () => {
    // Remove from trusted contact sockets
    for (const [email, socketId] of trustedContactSockets.entries()) {
      if (socketId === socket.id) {
        trustedContactSockets.delete(email);
        logger.info(`📱 Trusted contact disconnected: ${email}`);
        break;
      }
    }
  });
};

/**
 * Notify trusted contacts about ride events
 */
export const notifyTrustedContacts = async (
  io,
  userIdOrEmail,
  eventType,
  rideData
) => {
  try {
    logger.info(
      `📢 Attempting to notify trusted contacts for: ${userIdOrEmail}, event: ${eventType}`
    );

    let user = null;

    // If it looks like an email, search by email
    if (userIdOrEmail.includes("@")) {
      logger.info(`🔍 Searching by email: ${userIdOrEmail}`);
      user = await User.findOne({ email: userIdOrEmail }).select(
        "name email trustedContacts"
      );
    }
    // if MongoDB ObjectId (24 hex chars)
    else if (/^[0-9a-fA-F]{24}$/.test(userIdOrEmail)) {
      logger.info(`🔍 Searching by MongoDB _id: ${userIdOrEmail}`);
      user = await User.findById(userIdOrEmail).select(
        "name email trustedContacts"
      );
    }
    // Otherwise, search by userId field (UUID)
    else {
      logger.info(`🔍 Searching by userId field: ${userIdOrEmail}`);
      user = await User.findOne({ userId: userIdOrEmail }).select(
        "name email trustedContacts"
      );
    }

    if (!user) {
      logger.warn(`User not found with identifier: ${userIdOrEmail}`);
      return;
    }

    logger.info(`✅ User found: ${user.name} (${user.email})`);
    logger.info(`Trusted contacts count: ${user.trustedContacts?.length || 0}`);

    if (!user.trustedContacts || user.trustedContacts.length === 0) {
      logger.info(`ℹUser ${user.name} has no trusted contacts configured`);
      return;
    }

    logger.info(
      `📢 Notifying ${user.trustedContacts.length} trusted contacts for ${eventType}`
    );

    const notification = {
      type: eventType,
      commuterName: user.name,
      commuterEmail: user.email,
      timestamp: new Date().toISOString(),
      ride: rideData
    };

    // Send notification to each trusted contact if they're connected
    let notificationsSent = 0;
    for (const contact of user.trustedContacts) {
      const socketId = trustedContactSockets.get(contact.email);

      if (socketId) {
        io.to(socketId).emit("trip:notification", notification);
        notificationsSent++;
        logger.info(`Notification sent to ${contact.name} (${contact.email})`);
      } else {
        logger.info(`Trusted contact ${contact.email} not connected`);
      }
    }

    logger.info(
      `Summary: ${notificationsSent}/${user.trustedContacts.length} notifications sent`
    );
  } catch (error) {
    logger.error(`Error notifying trusted contacts: ${error.message}`);
    logger.error(`Stack trace: ${error.stack}`);
  }
};

/**
 Fetch driver's averageRating 
 */
const getDriverRating = async (driverId, driverEmail) => {
  try {
    let user = null;
    if (driverId) {
      user = await User.findOne({ userId: driverId }).select("averageRating ratings");
    }
    if (!user && driverEmail) {
      user = await User.findOne({ email: driverEmail }).select("averageRating ratings");
    }
    return {
      averageRating: user?.averageRating ?? 0,
      totalRides: user?.ratings?.count ?? 0
    };
  } catch (err) {
    logger.error(`Failed to fetch driver rating: ${err.message}`);
    return { averageRating: 0, totalRides: 0 };
  }
};

/**
 Finalize ride match after commuter selects a driver
 */
const finalizeMatch = async (io, rideId, selectedOffer) => {
  const matchedRide = connectionPoolService.matchRide(rideId, {
    driverId: selectedOffer.driverId,
    driverName: selectedOffer.driverName,
    driverEmail: selectedOffer.driverEmail,
    socketId: selectedOffer.socketId
  });

  if (!matchedRide) return null;

  const sessionKey = encryptionService.generateSessionKey();
  rideSessionKeys.set(matchedRide.id, sessionKey);

  // Notify the selected driver
  io.to(selectedOffer.socketId).emit("ride:matched", {
    success: true,
    ride: matchedRide.toJSON(),
    role: "driver",
    sessionKey
  });

  // Notify the commuter
  io.to(matchedRide.socketId).emit("ride:matched", {
    success: true,
    ride: matchedRide.toJSON(),
    role: "commuter",
    sessionKey
  });

  // Notify all other offering drivers that ride is no longer available
  const allOffers = pendingDriverOffers.get(rideId) || [];
  for (const offer of allOffers) {
    if (offer.socketId !== selectedOffer.socketId) {
      io.to(offer.socketId).emit("ride:offer:rejected", {
        rideId,
        message: "The commuter selected another driver"
      });
    }
  }

  // Notify all drivers that this ride is gone
  io.to("drivers").emit("ride:unavailable", { rideId: matchedRide.id });

  // Clean up pending offers
  pendingDriverOffers.delete(rideId);

  logger.info(`Ride ${rideId} finalized with driver: ${selectedOffer.driverName}`);
  return matchedRide;
};

/**
 * Setup ride-related socket event handlers
 */
export const handleRideEvents = (io, socket) => {
  logger.info(`Setting up ride event handlers for socket: ${socket.id}`);

  // Register the trusted contact handlers
  registerTrustedContact(socket);

  /**
   * Handle user connection initialization
   */
  socket.on("user:register", (userData) => {
    try {
      logger.info(`User registration: ${JSON.stringify(userData)}`);

      const userType = userData.userType || "commuter";

      // Add user to connection pool - store the email too
      connectionPoolService.addUser(socket.id, {
        userId: userData.userId || socket.id,
        userName: userData.userName || "Anonymous User",
        userEmail: userData.userEmail || null,
        userType: userType
      });

      // If this user had an active matched ride (e.g. reconnected), update socket IDs
      if (userData.userId) {
        const updated = connectionPoolService.updateRideSocketIds(
          userData.userId,
          socket.id
        );
        if (updated > 0) {
          logger.info(
            `Reconnect: updated ${updated} ride socket ID(s) for user ${userData.userId}`
          );
        }
      }

      // Join appropriate room based on user type
      if (userType === "driver") {
        socket.join("drivers");
        logger.info(`Driver joined 'drivers' room: ${socket.id}`);

        const pendingRides = connectionPoolService.getPendingRides();
        socket.emit("ride:list", {
          success: true,
          rides: pendingRides.map((ride) => ride.toJSON()),
          count: pendingRides.length
        });
      } else if (userType === "commuter") {
        socket.join("commuters");
        logger.info(`Commuter joined 'commuters' room: ${socket.id}`);
      } else if (userType === "admin") {
        socket.join("admins");
        logger.info(`Admin joined 'admins' room: ${socket.id}`);
      }

      const stats = connectionPoolService.getStats();
      socket.emit("user:registered", {
        success: true,
        socketId: socket.id,
        userType: userType,
        room: (() => {
          if (userType === "driver") return "drivers";
          if (userType === "admin") return "admins";
          return "commuters";
        })(),
        stats
      });

      logger.info(`User registered successfully: ${socket.id} as ${userType}`);
    } catch (error) {
      logger.error(`Error in user:register: ${error.message}`);
      socket.emit("error", {
        event: "user:register",
        message: "Failed to register user"
      });
    }
  });

  /**
   * Handle new ride creation
   */
  socket.on("ride:create", (rideData) => {
    try {
      logger.info(`Ride creation request: ${JSON.stringify(rideData)}`);

      if (!rideData.source || !rideData.destination) {
        socket.emit("ride:error", {
          message: "Source and destination are required"
        });
        return;
      }

      const user = connectionPoolService.getUser(socket.id);

      const ride = connectionPoolService.addRide({
        userId: user?.userId || socket.id,
        userName: user?.userName || rideData.userName || "Anonymous User",
        userEmail: user?.userEmail || rideData.userEmail || null,
        userType: "commuter",
        source: rideData.source,
        destination: rideData.destination,
        sourceCoordinates: rideData.sourceCoordinates || null,
        destinationCoordinates: rideData.destinationCoordinates || null,
        stops: Array.isArray(rideData.stops) ? rideData.stops : [],
        socketId: socket.id
      });

      socket.emit("ride:created", {
        success: true,
        ride: ride.toJSON()
      });

      io.to("drivers").emit("ride:new", {
        ride: ride.toJSON()
      });

      logger.info(`Ride created and sent to drivers room: ${ride.id}`);
    } catch (error) {
      logger.error(`Error in ride:create: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to create ride request"
      });
    }
  });

  /**
   * Handle ride list request
   */
  socket.on("ride:list", () => {
    try {
      const rides = connectionPoolService.getPendingRides();

      socket.emit("ride:list", {
        success: true,
        rides: rides.map((ride) => ride.toJSON()),
        count: rides.length
      });

      logger.info(`Sent ${rides.length} pending rides to ${socket.id}`);
    } catch (error) {
      logger.error(`Error in ride:list: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to fetch ride list"
      });
    }
  });


  /**
   * Handle driver offering themselves for a ride.
   */
  socket.on("ride:offer", async (offerData) => {
    try {
      logger.info(`Ride offer request: ${JSON.stringify(offerData)}`);

      const { rideId, driverId, driverName } = offerData;

      if (!rideId) {
        socket.emit("ride:error", { message: "Ride ID is required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", { message: "Ride not found" });
        return;
      }

      if (ride.status !== "pending") {
        socket.emit("ride:error", { message: "Ride is no longer available" });
        return;
      }

      const driverConnection = connectionPoolService.getUser(socket.id);
      const resolvedDriverId = driverId || driverConnection?.userId || socket.id;
      const resolvedDriverName = driverName || driverConnection?.userName || "Driver";
      const resolvedDriverEmail = driverConnection?.userEmail || null;

      // Prevent the same driver from offering twice on the same ride
      const existingOffers = pendingDriverOffers.get(rideId) || [];
      const alreadyOffered = existingOffers.some(
        (o) => o.socketId === socket.id || o.driverId === resolvedDriverId
      );
      if (alreadyOffered) {
        socket.emit("ride:error", { message: "You have already offered for this ride" });
        return;
      }

      // Fetch rating from MongoDB
      const { averageRating, totalRides } = await getDriverRating(
        resolvedDriverId,
        resolvedDriverEmail
      );

      // Store the offer
      const offer = {
        driverId: resolvedDriverId,
        driverName: resolvedDriverName,
        driverEmail: resolvedDriverEmail,
        socketId: socket.id,
        averageRating,
        totalRides,
        offeredAt: new Date().toISOString()
      };

      existingOffers.push(offer);
      pendingDriverOffers.set(rideId, existingOffers);

      // Confirm to the driver that their offer was received
      socket.emit("ride:offer:sent", {
        success: true,
        rideId,
        message: "Your offer has been sent to the commuter"
      });

      // Forward the offer to the commuter
      io.to(ride.socketId).emit("ride:driver:offered", {
        rideId,
        driver: {
          driverId: resolvedDriverId,
          driverName: resolvedDriverName,
          averageRating,
          totalRides,
          offeredAt: offer.offeredAt
        }
      });

      logger.info(
        `Driver ${resolvedDriverName} offered for ride ${rideId}. Rating: ${averageRating}`
      );
    } catch (error) {
      logger.error(`Error in ride:offer: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to submit ride offer" });
    }
  });

  /**
   * Handle commuter selecting a driver from the list of offers.
   */
  socket.on("ride:select", async (selectData) => {
    try {
      logger.info(`Ride select request: ${JSON.stringify(selectData)}`);

      const { rideId, driverId } = selectData;

      if (!rideId || !driverId) {
        socket.emit("ride:error", { message: "Ride ID and driver ID are required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", { message: "Ride not found" });
        return;
      }

      if (ride.status !== "pending") {
        socket.emit("ride:error", { message: "Ride is no longer available" });
        return;
      }

      // Verify the commuter owns this ride
      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", { message: "You can only select a driver for your own ride" });
        return;
      }

      // Find the chosen driver's offer
      const offers = pendingDriverOffers.get(rideId) || [];
      const selectedOffer = offers.find((o) => o.driverId === driverId);

      if (!selectedOffer) {
        socket.emit("ride:error", { message: "Selected driver offer not found" });
        return;
      }

      // Finalize the match
      const matchedRide = await finalizeMatch(io, rideId, selectedOffer);

      if (!matchedRide) {
        socket.emit("ride:error", { message: "Failed to match ride" });
        return;
      }

      logger.info(
        `Ride ${rideId} matched successfully: commuter selected driver ${driverId}`
      );

      // Notify trusted contacts
      await notifyTrustedContacts(io, matchedRide.userEmail, "RIDE_STARTED", {
        rideId: matchedRide.id,
        source: matchedRide.source,
        destination: matchedRide.destination,
        driverName: matchedRide.matchedWith.driverName,
        status: "matched"
      });
    } catch (error) {
      logger.error(`Error in ride:select: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to select driver" });
    }
  });

  /**
   * Handle driver reached notification
   */
  socket.on("driver:reached", (data) => {
    try {
      const { rideId } = data;

      if (!rideId) {
        socket.emit("ride:error", { message: "Ride ID is required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (ride?.status !== "matched") {
        socket.emit("ride:error", { message: "Ride not found or not matched" });
        return;
      }

      if (ride.matchedWith?.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "Only assigned driver can send notification"
        });
        return;
      }

      io.to(ride.socketId).emit("driver:reached", {
        success: true,
        rideId: ride.id
      });

      logger.info(`Driver reached notification sent for ride: ${rideId}`);
    } catch (error) {
      logger.error(`Error in driver:reached: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to send notification" });
    }
  });

  /**
   * Handle driver location updates
   * Driver sends real-time location while en route to passenger
   */
  socket.on("driver:location:update", (data) => {
    try {
      const { rideId, latitude, longitude, heading, speed } = data;

      if (!rideId || latitude === undefined || longitude === undefined) {
        socket.emit("ride:error", {
          message: "Ride ID, latitude, and longitude are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      if (ride.status !== "matched") {
        return;
      }

      // Check if the driver owns this ride
      if (ride.matchedWith?.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "Only the assigned driver can send location updates"
        });
        return;
      }

      ride.lastDriverLocation = {
        latitude,
        longitude,
        heading: heading || null,
        speed: speed || null,
        timestamp: new Date().toISOString()
      };

      // Broadcast driver location to the matched commuter
      io.to(ride.socketId).emit("driver:location:updated", {
        rideId: ride.id,
        latitude,
        longitude,
        heading: heading || null,
        speed: speed || null,
        timestamp: new Date().toISOString()
      });

      io.to("admins").emit("admin:ride:location", {
        rideId: ride.id,
        role: "driver",
        latitude,
        longitude,
        heading: heading || null,
        speed: speed || null,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      logger.error(`Error in driver:location:update: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to update driver location"
      });
    }
  });

  /**
   * Handle passenger location updates
   * Passenger sends real-time location while waiting for driver
   */
  socket.on("passenger:location:update", (data) => {
    try {
      const { rideId, latitude, longitude } = data;

      if (!rideId || latitude === undefined || longitude === undefined) {
        socket.emit("ride:error", {
          message: "Ride ID, latitude, and longitude are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      // Ride may have already been removed from pool after completion — ignore silently
      if (!ride) {
        return;
      }

      // Check if the ride is matched, ignore silently if not matched
      if (ride.status !== "matched") {
        return;
      }

      // Check if the passenger owns this ride
      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "Only the ride owner can send location updates"
        });
        return;
      }

      ride.lastPassengerLocation = {
        latitude,
        longitude,
        timestamp: new Date().toISOString()
      };

      // Broadcast passenger location to the matched driver
      if (ride.matchedWith?.socketId) {
        io.to(ride.matchedWith.socketId).emit("passenger:location:updated", {
          rideId: ride.id,
          latitude,
          longitude,
          timestamp: new Date().toISOString()
        });
      }

      io.to("admins").emit("admin:ride:location", {
        rideId: ride.id,
        role: "passenger",
        latitude,
        longitude,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      logger.error(`Error in passenger:location:update: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to update passenger location"
      });
    }
  });

  /**
   * Handle ride cancellation with reason
   */
  socket.on("ride:cancel", (data) => {
    try {
      const { rideId, reasonCode, reasonText } = data;

      if (!rideId) {
        socket.emit("ride:error", { message: "Ride ID is required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", { message: "Ride not found" });
        return;
      }

      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "You can only cancel your own rides"
        });
        return;
      }

      // Capture match data BEFORE cancelling
      const wasMatched = ride.status === "matched" && ride.matchedWith;
      const matchedDriverId = ride.matchedWith?.driverId;
      const matchedDriverSocketId = ride.matchedWith?.socketId;

      // Store cancellation reason on in-memory ride
      ride.cancel({ reasonCode, reasonText, cancelledBy: "commuter" });

      rideSessionKeys.delete(rideId);
      pendingDriverOffers.delete(rideId);

      socket.emit("ride:cancelled", { success: true, rideId });

      if (wasMatched) {
        io.to(matchedDriverSocketId).emit("ride:cancelled:matched", {
          rideId,
          message: "The commuter has cancelled the ride"
        });
      } else {
        io.to("drivers").emit("ride:cancelled", { rideId });
      }

      logger.info(`Ride cancelled: ${rideId}, reason: ${reasonCode || "none"}`);

      // Async: persist to DB and handle fraud detection
      (async () => {
        try {
          const isFraud =
            reasonCode === "driver_request" && wasMatched && matchedDriverId;

          await Ride.findOneAndUpdate(
            { rideId },
            {
              $set: {
                status: "cancelled",
                cancellationReasonCode: reasonCode || null,
                cancellationReasonText: reasonText || null,
                cancelledBy: "commuter",
                cancelledAt: new Date(),
                driverFraudFlagged: !!isFraud,
                updatedAt: new Date()
              },
              $setOnInsert: {
                rideId,
                userId: ride.userId,
                userType: ride.userType || "commuter",
                userName: ride.userName,
                userEmail: ride.userEmail || null,
                source: { address: ride.source.address },
                destination: { address: ride.destination.address },
                createdAt: new Date(ride.createdAt)
              }
            },
            { upsert: true, new: true }
          );

          if (isFraud) {
            const driver = await User.findById(matchedDriverId);
            if (driver) {
              driver.fraudFlagCount = (driver.fraudFlagCount || 0) + 1;
              driver.fraudFlags.push({
                rideId,
                reportedAt: new Date(),
                reasonText: reasonText || null
              });
              if (driver.fraudFlagCount >= 3) {
                driver.flaggedForReview = true;
              }
              await driver.save();
              logger.warn(
                `🚨 Fraud flag recorded for driver ${driver.name}. Total: ${driver.fraudFlagCount}`
              );
            }
          }
        } catch (dbErr) {
          logger.error(`Error persisting cancellation to DB: ${dbErr.message}`);
        }
      })();
    } catch (error) {
      logger.error(`Error in ride:cancel: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to cancel ride" });
    }
  });

  /**
   * Handle ride completion
   */
  socket.on("ride:complete", async (data) => {
    try {
      const { rideId, distanceKm } = data;
      logger.info(
        `🏁 ride:complete received | rideId=${rideId} | distanceKm=${distanceKm} | socketId=${socket.id}`
      );

      if (!rideId) {
        logger.warn(`ride:complete rejected: no rideId provided`);
        socket.emit("ride:error", { message: "Ride ID is required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (ride?.status !== "matched") {
        logger.warn(
          `ride:complete rejected: ride not found or wrong status | rideId=${rideId} | status=${ride?.status ?? "NOT_FOUND"}`
        );
        socket.emit("ride:error", { message: "Ride not found or not matched" });
        return;
      }

      const currentUser = connectionPoolService.getUser(socket.id);
      logger.info(
        `ride:complete auth check | currentUser=${currentUser?.userId} | ride.matchedWith.driverId=${ride.matchedWith?.driverId}`
      );
      if (ride.matchedWith?.driverId !== currentUser?.userId) {
        logger.warn(
          `ride:complete rejected: driver mismatch | expected=${ride.matchedWith?.driverId} | got=${currentUser?.userId}`
        );
        socket.emit("ride:error", {
          message: "Only assigned driver can complete ride"
        });
        return;
      }

      // Fetch current fare rate from database
      const FARE_RATE_PER_KM = await FarePrice.getCurrentFareRate();
      const calculatedDistance = distanceKm || 0;
      const baseFare = Math.round(calculatedDistance * FARE_RATE_PER_KM);

      // First 3 rides discount: check completed rides in DB for this user
      const DISCOUNT_RIDE_LIMIT = 3;
      const DISCOUNT_PERCENTAGE = 20;
      const completedRidesCount = await Ride.countDocuments({
        userId: ride.userId,
        status: "completed"
      });
      const discountEligible = completedRidesCount < DISCOUNT_RIDE_LIMIT;
      const discountAmount = discountEligible
        ? Math.round(baseFare * (DISCOUNT_PERCENTAGE / 100))
        : 0;
      const fare = baseFare - discountAmount;
      const ridesRemainingForDiscount = Math.max(
        0,
        DISCOUNT_RIDE_LIMIT - completedRidesCount - 1
      );

      const completedRide = connectionPoolService.completeRide(rideId);

      if (!completedRide) {
        socket.emit("ride:error", { message: "Failed to complete ride" });
        return;
      }

      // Fetch driver payment details
      let driverPaymentDetails = { easyPaisa: EMPTY_ACCOUNT, jazzCash: EMPTY_ACCOUNT };

      try {
        driverPaymentDetails = await fetchDriverPaymentDetails(ride);
      } catch (error) {
        logger.error(
          `Failed to fetch driver payment details: ${error.message}`
        );
      }

      const fareObject = {
        distanceKm: calculatedDistance,
        ratePerKm: FARE_RATE_PER_KM,
        baseFare,
        discountApplied: discountEligible,
        discountPercentage: discountEligible ? DISCOUNT_PERCENTAGE : 0,
        discountAmount,
        totalAmount: fare,
        rideNumber: completedRidesCount + 1,
        ridesRemainingForDiscount
      };

      const rideWithFare = {
        ...completedRide.toJSON(),
        fare: fareObject
      };

      socket.emit("ride:completed", {
        success: true,
        ride: rideWithFare,
        fare: fareObject
      });

      io.to(completedRide.socketId).emit("ride:payment:request", {
        success: true,
        ride: rideWithFare,
        fare: fareObject,
        driverPaymentDetails,
        message: discountEligible
          ? `Your ride is complete. 20% discount applied! Total fare: PKR ${fare}`
          : `Your ride is complete. Total fare: PKR ${fare}`
      });

      logger.info(
        `📧 Notifying trusted contacts using email: ${completedRide.userEmail}`
      );
      await notifyTrustedContacts(
        io,
        completedRide.userEmail,
        "RIDE_COMPLETED",
        {
          rideId: completedRide.id,
          source: completedRide.source,
          destination: completedRide.destination,
          status: "completed"
        }
      );

      rideSessionKeys.delete(rideId);
      logger.info(`Ride completed successfully: ${rideId}`);
    } catch (error) {
      logger.error(`Error in ride:complete: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to complete ride" });
    }
  });

  /**
   * Handle SOS alert
   */
  socket.on("ride:sos", async (data) => {
    try {
      logger.warn(`🚨 SOS ALERT REQUEST: ${JSON.stringify(data)}`);

      const { rideId, location, message } = data;

      if (!rideId) {
        socket.emit("ride:error", { message: "Ride ID is required" });
        return;
      }

      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", { message: "Ride not found" });
        return;
      }

      if (ride.socketId !== socket.id) {
        socket.emit("ride:error", {
          message: "You can only trigger SOS for your own rides"
        });
        return;
      }

      const sosData = {
        triggeredBy: ride.userId,
        location: location || null,
        message: message || "Emergency SOS triggered"
      };

      const updatedRide = connectionPoolService.triggerSOS(rideId, sosData);

      if (!updatedRide) {
        socket.emit("ride:error", { message: "Failed to trigger SOS" });
        return;
      }

      socket.emit("ride:sos:triggered", {
        success: true,
        ride: updatedRide.toJSON(),
        sosAlert: updatedRide.sosAlert
      });

      if (updatedRide.matchedWith) {
        io.to(updatedRide.matchedWith.socketId).emit("ride:sos:alert", {
          ride: updatedRide.toJSON(),
          sosAlert: updatedRide.sosAlert
        });
      }

      logger.info(
        `Notifying trusted contacts using email: ${updatedRide.userEmail}`
      );
      await notifyTrustedContacts(io, updatedRide.userEmail, "SOS_ALERT", {
        rideId: updatedRide.id,
        source: updatedRide.source,
        destination: updatedRide.destination,
        driverName: updatedRide.matchedWith?.driverName,
        sosAlert: updatedRide.sosAlert,
        status: "emergency"
      });

      // Send SOS emails
      try {
        const user = await User.findOne({
          email: updatedRide.userEmail
        }).select("name email trustedContacts");

        if (user?.trustedContacts?.length > 0) {
          const sosEmailData = {
            commuterName: user.name || ride.userName,
            commuterEmail: user.email,
            driverName: updatedRide.matchedWith?.driverName || null,
            pickupLocation: updatedRide.source.address,
            dropoffLocation: updatedRide.destination.address,
            triggeredAt: updatedRide.sosAlert.triggeredAt,
            sosMessage: updatedRide.sosAlert.message
          };

          const emailPromises = user.trustedContacts.map(async (contact) => {
            try {
              await emailService.sendSOSAlert(contact.email, sosEmailData);
              logger.warn(`✅ SOS email sent to ${contact.email}`);
            } catch (emailError) {
              logger.error(
                `❌ Failed to send SOS email to ${contact.email}: ${emailError.message}`
              );
            }
          });

          Promise.all(emailPromises);
        }
      } catch (dbError) {
        logger.error(
          `❌ Database error while fetching user for SOS: ${dbError.message}`
        );
      }

      logger.warn(`🚨 SOS TRIGGERED for ride ${rideId}`);
    } catch (error) {
      logger.error(`Error in ride:sos: ${error.message}`);
      socket.emit("ride:error", { message: "Failed to trigger SOS" });
    }
  });

  socket.on("chat:message", (data) => {
    // ... existing chat:message logic ...
    try {
      const {
        rideId,
        message,
        senderId,
        senderName,
        encrypted: isClientEncrypted,
        iv,
        authTag
      } = data;

      // Log without exposing message content
      logger.info(
        `Chat message received for ride: ${rideId}, encrypted: ${!!isClientEncrypted}`
      );

      if (!rideId || !message) {
        socket.emit("ride:error", {
          message: "Ride ID and message are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      // Check if ride is matched
      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Chat is only available for matched rides"
        });
        return;
      }

      // Determine recipient socket ID
      let recipientSocketId;
      if (socket.id === ride.socketId) {
        // Sender is commuter, send to driver
        recipientSocketId = ride.matchedWith?.socketId;
      } else if (socket.id === ride.matchedWith?.socketId) {
        // Sender is driver, send to commuter
        recipientSocketId = ride.socketId;
      } else {
        socket.emit("ride:error", {
          message: "You are not part of this ride"
        });
        return;
      }

      // Send message to recipient
      if (recipientSocketId) {
        // Get session key for this ride
        const sessionKey = rideSessionKeys.get(rideId);

        let messagePayload;

        if (isClientEncrypted && iv && authTag) {
          // Client already encrypted - pass through
          messagePayload = {
            rideId,
            message,
            iv,
            authTag,
            encrypted: true,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
        } else if (sessionKey) {
          // Server-side encryption
          const encryptedData = encryptionService.encrypt(message, sessionKey);
          messagePayload = {
            rideId,
            message: encryptedData.encrypted,
            iv: encryptedData.iv,
            authTag: encryptedData.authTag,
            encrypted: true,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
          logger.info(`Message encrypted for ride ${rideId}`);
        } else {
          logger.warn(
            `No session key found for ride ${rideId}, sending unencrypted`
          );
          messagePayload = {
            rideId,
            message,
            encrypted: false,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
        }

        io.to(recipientSocketId).emit("chat:message", messagePayload);

        logger.info(
          `Chat message sent from ${socket.id} to ${recipientSocketId} for ride ${rideId}`
        );
      }
    } catch (error) {
      logger.error(`Error in chat:message: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to send chat message"
      });
    }
  });

  /**
   * Handle voice chat messages
   * Send encrypted voice messages between driver and commuter
   */
  socket.on("chat:voice", (data) => {
    try {
      const {
        rideId,
        audioData,
        duration,
        senderId,
        senderName,
        encrypted: isClientEncrypted,
        iv,
        authTag
      } = data;

      logger.info(
        `Voice message received for ride: ${rideId}, encrypted: ${!!isClientEncrypted}`
      );

      if (!rideId || !audioData) {
        socket.emit("ride:error", {
          message: "Ride ID and audio data are required"
        });
        return;
      }

      // Get the ride
      const ride = connectionPoolService.getRide(rideId);

      if (!ride) {
        socket.emit("ride:error", {
          message: "Ride not found"
        });
        return;
      }

      if (ride.status !== "matched") {
        socket.emit("ride:error", {
          message: "Chat is only available for matched rides"
        });
        return;
      }

      // Determine recipient socket ID
      let recipientSocketId;
      if (socket.id === ride.socketId) {
        // Sender is commuter, send to driver
        recipientSocketId = ride.matchedWith?.socketId;
      } else if (socket.id === ride.matchedWith?.socketId) {
        // Sender is driver, send to commuter
        recipientSocketId = ride.socketId;
      } else {
        socket.emit("ride:error", {
          message: "You are not part of this ride"
        });
        return;
      }

      // Send voice message to recipient
      if (recipientSocketId) {
        const sessionKey = rideSessionKeys.get(rideId);

        let voicePayload;

        if (isClientEncrypted && iv && authTag) {
          voicePayload = {
            rideId,
            audioData,
            iv,
            authTag,
            encrypted: true,
            duration,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
        } else if (sessionKey) {
          // Server-side encryption for audio
          const encryptedAudio = encryptionService.encryptBinary(
            audioData,
            sessionKey
          );
          voicePayload = {
            rideId,
            audioData: encryptedAudio.encrypted,
            iv: encryptedAudio.iv,
            authTag: encryptedAudio.authTag,
            encrypted: true,
            duration,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
          logger.info(`🔐 Voice message encrypted for ride ${rideId}`);
        } else {
          // Fallback to unencrypted
          logger.warn(
            `⚠️ No session key found for ride ${rideId}, sending voice unencrypted`
          );
          voicePayload = {
            rideId,
            audioData,
            encrypted: false,
            duration,
            senderId,
            senderName,
            timestamp: new Date().toISOString()
          };
        }

        io.to(recipientSocketId).emit("chat:voice", voicePayload);

        logger.info(
          `Voice message sent from ${socket.id} to ${recipientSocketId} for ride ${rideId}`
        );
      }
    } catch (error) {
      logger.error(`Error in chat:voice: ${error.message}`);
      socket.emit("ride:error", {
        message: "Failed to send voice message"
      });
    }
  });

  /**
   * Handle connection pool stats request
   */
  socket.on("pool:stats", () => {
    try {
      const stats = connectionPoolService.getStats();
      socket.emit("pool:stats", stats);
      logger.info(`Pool stats sent to ${socket.id}`);
    } catch (error) {
      logger.error(`Error in pool:stats: ${error.message}`);
    }
  });

  /**
   * Handle disconnection
   */
  socket.on("disconnect", () => {
    logger.info(`Client disconnecting: ${socket.id}`);

    const removedUser = connectionPoolService.getUser(socket.id);
    connectionPoolService.removeUser(socket.id);

    if (removedUser?.userType === "commuter") {
      const pendingRides = connectionPoolService.getPendingRides();
      io.to("drivers").emit("ride:list:updated", {
        rides: pendingRides.map((ride) => ride.toJSON()),
        count: pendingRides.length
      });
    }
  });
};
