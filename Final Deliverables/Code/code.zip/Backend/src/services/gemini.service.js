import { GoogleGenAI } from "@google/genai";
import fs from "node:fs";
import logger from "../utils/logger.js";

const STATE_FILE = ".gemini-key-state.json";

// All models in priority order — all accept audio + text
// Fallback: exhaust all keys on model N before moving to model N+1
const MODELS = [
  "gemini-2.5-flash",       // best quality, 500 RPD/key
  "gemini-2.5-flash-lite",  // 1500 RPD/key, separate quota pool
  "gemini-2.0-flash",       // 1500 RPD/key, separate quota pool
  "gemini-2.0-flash-lite",  // 1500 RPD/key, last resort
];

const MIME_TYPES = {
  mp3: "audio/mp3",
  wav: "audio/wav",
  m4a: "audio/mp4",
  aac: "audio/aac",
  ogg: "audio/ogg",
  flac: "audio/flac",
  webm: "audio/webm",
};

class GeminiService {
  constructor() {
    this.keys = [];
    let i = 1;
    while (process.env[`GEMINI_API_KEY_${i}`]) {
      this.keys.push(process.env[`GEMINI_API_KEY_${i}`]);
      i++;
    }
    if (this.keys.length === 0 && process.env.GEMINI_API_KEY) {
      this.keys.push(process.env.GEMINI_API_KEY);
    }
    if (this.keys.length === 0) {
      logger.warn("No GEMINI_API_KEY configured. Gemini features will be disabled.");
      this.client = null;
      return;
    }

    this.currentKeyIndex = this._loadKeyIndex();
    if (this.currentKeyIndex >= this.keys.length) this.currentKeyIndex = 0;

    logger.info(`Gemini: ${this.keys.length} key(s), ${MODELS.length} models configured.`);
    this._initClient();
  }

  // ── Infrastructure ──────────────────────────────────────────────────────────

  _loadKeyIndex() {
    try {
      if (fs.existsSync(STATE_FILE)) {
        const state = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
        return typeof state.keyIndex === "number" ? state.keyIndex : 0;
      }
    } catch (_err) { logger.debug(`Gemini state file error (non-critical): ${_err.message}`); }
    return 0;
  }

  _saveKeyIndex() {
    try {
      fs.writeFileSync(STATE_FILE, JSON.stringify({ keyIndex: this.currentKeyIndex }));
    } catch (_err) { logger.debug(`Gemini state file error (non-critical): ${_err.message}`); }
  }

  _initClient() {
    const key = this.keys[this.currentKeyIndex];
    this.client = new GoogleGenAI({ apiKey: key });
    logger.info(`Gemini using key [${this.currentKeyIndex + 1}/${this.keys.length}]: ${key.substring(0, 10)}...${key.slice(-4)}`);
  }

  _rotateKey() {
    if (this.keys.length <= 1) return false;
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.keys.length;
    this._saveKeyIndex();
    this._initClient();
    return true;
  }

  _isQuotaError(err) {
    return err.message?.includes("429") ||
      err.message?.includes("RESOURCE_EXHAUSTED") ||
      err.message?.includes("quota");
  }

  isAvailable() {
    return this.client !== null;
  }

  getMimeType(filePath) {
    const ext = filePath.split(".").pop().toLowerCase();
    return MIME_TYPES[ext] || "audio/mpeg";
  }

  cleanupFile(filePath) {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        logger.info(`Cleaned up temp file: ${filePath}`);
      }
    } catch (err) {
      logger.error(`Error cleaning up file ${filePath}: ${err.message}`);
    }
  }

  // Try every key for a single model. Returns result or throws last error.
  async _tryAllKeys(params, attempt = 0) {
    if (attempt >= this.keys.length) throw new Error("All keys exhausted");
    try {
      return await this.client.models.generateContent(params);
    } catch (err) {
      if (this._isQuotaError(err) && this.keys.length > 1) {
        logger.warn(`Gemini key [${this.currentKeyIndex + 1}] quota exceeded, rotating key...`);
        this._rotateKey();
        return this._tryAllKeys(params, attempt + 1);
      }
      throw err;
    }
  }

  // Central wrapper — tries all keys × all models until one succeeds.
  async generateContent(params) {
    if (!this.isAvailable()) throw new Error("Gemini API key is not configured");

    let lastError;
    for (const model of MODELS) {
      try {
        logger.info(`Gemini trying model: ${model}`);
        return await this._tryAllKeys({ ...params, model });
      } catch (err) {
        lastError = err;
        if (this._isQuotaError(err)) {
          logger.warn(`All keys exhausted for ${model}, trying next model...`);
          continue;
        }
        throw err; // non-quota error — stop immediately
      }
    }
    throw lastError; // all models + all keys exhausted
  }

  // ── Business Methods ─────────────────────────────────────────────────────────

  // Parse JSON from Gemini response (strips markdown code fences if present)
  _parseJson(text) {
    const cleaned = text.trim().replaceAll(/```json\n?/g, "").replaceAll(/```\n?/g, "").trim();
    return JSON.parse(cleaned);
  }

  // Build audio inlineData part from base64 + mimeType
  _audioPart(audioBase64, mimeType) {
    return { inlineData: { data: audioBase64, mimeType } };
  }

  // Shared: send prompt + audio to Gemini, parse JSON response, log result.
  async _callAudio(prompt, audioBase64, mimeType, logFn) {
    const response = await this.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt }, this._audioPart(audioBase64, mimeType)] }]
    });
    const parsed = this._parseJson(response.text);
    logFn(parsed);
    return parsed;
  }

  /**
   * Classify user voice command on the active ride screen.
   * Returns: 0 = SOS/emergency, 1 = share ride details, 2 = cancel ride, -1 = no match
   */
  async interpretRideActionAudio(audioBase64, mimeType) {
    const prompt = `A user is on the active ride screen of HerSafar (a women-only ride service in Pakistan).

The screen has exactly 3 action buttons:
0 = SOS / Emergency  (ایمرجنسی، SOS، مدد، خطرہ، بچاؤ، حادثہ، help، emergency، danger، accident)
1 = Share Ride Details  (شیئر کریں، تفصیلات بھیجیں، رابطوں کو بتائیں، share، ride share، family ko batao)
2 = Cancel Ride  (منسوخ کریں، رد کریں، cancel، سواری ختم، واپس جانا ہے، band karo)

Listen to the audio and determine which action the user wants.

Rules:
- The user may speak in ANY language: Urdu, Hindi, English, Roman Urdu, or any mix
- Be VERY generous — if there is ANY hint of intent, match it
- SOS: ANY mention of emergency, danger, help, accident, fear — always prioritise safety
- Only return -1 if the audio is completely unrelated to these 3 actions

Respond ONLY with valid JSON, no markdown:
{
  "matched": <0, 1, 2, or -1>,
  "confidence": "<high|medium|low>",
  "reasoning": "<one short sentence>"
}`;

    const parsed = await this._callAudio(prompt, audioBase64, mimeType, (p) =>
      logger.info(`Gemini interpret-ride-action: matched=${p.matched} (${p.confidence}) — ${p.reasoning}`)
    );
    return parsed.matched ?? -1;
  }

  /**
   * Transcribe audio and classify user intent on the welcome screen.
   * Returns: 0 = new user, 1 = login, 2 = driver, -1 = no match
   */
  async interpretAudio(audioBase64, mimeType) {
    const prompt = `A user is on the welcome screen of a ride-hailing app called HerSafar (a women-only ride service in Pakistan).

The screen has exactly 3 options:
0 = New User (signup, register, new account, naya, jadeed, first time)
1 = Already Registered (login, signin, existing user, pehle se, already, account hai)
2 = Register as Driver (driver, drive, car, chalana, gaari, sawari, DriverSignup)

Listen to the audio and determine which option the user wants.

Rules:
- The user may speak in ANY language: Urdu, Hindi, English, Roman Urdu, or any mix
- Be VERY generous — if there is ANY hint of intent, match it
- "register as driver", "i want to drive", "driver signup", "main driver hoon", "driver banna hai" → 2
- "new user", "signup", "register", "naya account", "naya user" → 0
- "login", "already registered", "i have an account", "pehle se hoon" → 1
- Only return -1 if the audio is completely unrelated to these 3 options

Respond ONLY with valid JSON, no markdown:
{
  "matched": <0, 1, 2, or -1>,
  "confidence": "<high|medium|low>",
  "reasoning": "<one short sentence>"
}`;

    const parsed = await this._callAudio(prompt, audioBase64, mimeType, (p) =>
      logger.info(`Gemini interpret: matched=${p.matched} (${p.confidence}) — ${p.reasoning}`)
    );
    return parsed.matched ?? -1;
  }

  /**
   * Transcribe audio and extract email address from Urdu phonetic speech.
   * Returns: email string or null
   */
  async extractEmailFromAudio(audioBase64, mimeType) {
    const prompt = `Listen to this audio and convert the spoken email address into a valid email address.

The user is speaking in Urdu, phonetically spelling out an email address.

CRITICAL RULES:
1. The @ symbol is spoken in many ways — ALL of these mean "@":
   - "ایٹ", "at", "ایٹ دا ریٹ", "ایٹ دی ریٹ", "اینڈ ریٹ آف", "اینڈ دا ریٹ آف"
   - Replace the entire phrase with @

2. The dot (.) is spoken as: "ڈاٹ", "dot", "پوائنٹ", "نقطہ"

3. Domain name mappings:
   - "ہرسفر", "ہر سفر", "حارث سفر", "ہیر سفر", "ہارسفر" → hersafar
   - "جی میل", "جیمیل" → gmail
   - "یاہو" → yahoo
   - "ہاٹ میل" → hotmail
   - "آؤٹ لک" → outlook
   - "کام", "com" → com

4. Urdu letter names:
   اے=a, بی=b, سی=c, ڈی=d, ای=e, ایف=f, جی=g, ایچ=h, آئی=i, جے=j, کے=k, ایل=l, ایم=m, این=n, او=o, پی=p, آر=r, ایس=s, ٹی=t, یو=u, وی=v, وائی=y, زیڈ=z

EXAMPLES:
- "ڈرائیور اینڈ ریٹ آف ہرسفر ڈاٹ کام" → driver@hersafar.com
- "علی ایٹ جی میل ڈاٹ کام" → ali@gmail.com
- "اے بی سی ایٹ یاہو ڈاٹ کام" → abc@yahoo.com

Respond ONLY with valid JSON, no markdown:
{
  "email": "<the email address or null if cannot be determined>",
  "transcription": "<what you actually heard in the audio, even if you could not parse an email from it>"
}`;

    let response;
    try {
      response = await this.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }, this._audioPart(audioBase64, mimeType)] }]
      });
    } catch (err) {
      logger.error(`Gemini extract-email: API call failed — ${err.message}`);
      throw err;
    }

    const rawText = response.text?.trim();
    logger.debug(`Gemini extract-email raw response: ${rawText}`);

    let parsed;
    try {
      parsed = this._parseJson(rawText);
    } catch (err) {
      logger.error(`Gemini extract-email: JSON parse failed — ${err.message} | raw: ${rawText}`);
      return null;
    }

    if (parsed.email) {
      parsed.email = parsed.email.toLowerCase().trim();
      logger.info(`Gemini extract-email: extracted "${parsed.email}"`);
    } else {
      logger.warn(`Gemini extract-email: model returned null — audio unclear or no email detected | transcript hint: ${parsed.original_text ?? parsed.transcription ?? '(none)'}`);
    }

    return parsed.email ?? null;
  }

  /**
   * Transcribe audio and extract a 4-digit PIN from Urdu/English speech.
   * Returns: 4-digit string or null
   */
  async extractPinFromAudio(audioBase64, mimeType) {
    const prompt = `Listen to this audio and extract a 4-digit PIN number.

The user is speaking digits in Urdu, English, or a mix of both.

Urdu digit words:
- صفر/zero = 0
- ایک/one = 1
- دو/two = 2
- تین/three = 3
- چار/four = 4
- پانچ/five = 5
- چھ/six = 6
- سات/seven = 7
- آٹھ/eight = 8
- نو/nine = 9

Examples:
- "ایک دو تین چار" → "1234"
- "five six seven eight" → "5678"
- "نو آٹھ سات چھ" → "9876"

Respond ONLY with valid JSON, no markdown:
{
  "pin": "<4-digit string or null if cannot be determined>"
}`;

    const parsed = await this._callAudio(prompt, audioBase64, mimeType, (p) =>
      logger.info(`Gemini extract-pin: ${p.pin}`)
    );
    return parsed.pin ?? null;
  }

  /**
   * Transcribe a person's name from Urdu/English audio.
   * Returns: name string or null
   */
  async extractNameFromAudio(audioBase64, mimeType) {
    const prompt = `Listen to this audio and extract the person's name being spoken.

The user is speaking their name in Urdu, English, or a mix of both.

RULES:
- The name may be a Pakistani/Urdu name (e.g. فاطمہ، علی، زینب، عمر، آمنہ) or an English name
- Return the name properly capitalised (first letter of each word uppercase)
- If the user spells out their name letter by letter, reconstruct the full name
- Only return the spoken name — do not include titles like "میرا نام" (my name is) etc.
- If you cannot determine a name, return null

Respond ONLY with valid JSON, no markdown:
{
  "name": "<the person's name or null if cannot be determined>",
  "transcription": "<what you actually heard in the audio>"
}`;

    let response;
    try {
      response = await this.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }, this._audioPart(audioBase64, mimeType)] }]
      });
    } catch (err) {
      logger.error(`Gemini extract-name: API call failed — ${err.message}`);
      throw err;
    }

    const rawText = response.text?.trim();
    logger.debug(`Gemini extract-name raw response: ${rawText}`);

    let parsed;
    try {
      parsed = this._parseJson(rawText);
    } catch (err) {
      logger.error(`Gemini extract-name: JSON parse failed — ${err.message} | raw: ${rawText}`);
      return null;
    }

    if (parsed.name) {
      logger.info(`Gemini extract-name: extracted "${parsed.name}"`);
    } else {
      logger.warn(`Gemini extract-name: model returned null | transcript: ${parsed.transcription ?? '(none)'}`);
    }

    return parsed.name ?? null;
  }

  /**
   * Extract source + destination locations from an audio file on disk.
   * Used by POST /api/audio/process (book ride page).
   */
  async extractLocationsFromAudio(audioFilePath) {
    try {
      logger.info(`Processing audio file with Gemini: ${audioFilePath}`);

      const audioBase64 = fs.readFileSync(audioFilePath).toString("base64");
      const mimeType = this.getMimeType(audioFilePath);

      const prompt = `Listen to this audio and extract the travel booking information.

Extract:
1. Source location (where the journey starts from) - Look for keywords like "سے" (se/from)
2. Destination location (final destination) - Look for keywords like "کو", "میں" (ko/mein/to/in), "جانا ہے" (jana hai/want to go)
3. Intermediate stops (optional waypoints mentioned between source and destination) - Look for keywords like "رک کر" (ruk kar/stop at), "پہلے" (pehle/first), "پھر" (phir/then), "بعد میں" (baad mein/after that), "راستے میں" (raastay mein/on the way), "via", "ہوتے ہوئے" (hote hue/passing through)

CRITICAL RULES:
- ALWAYS include house numbers, flat numbers, building numbers in address fields
- Extract the COMPLETE address with ALL details: house/flat number, street, area, city
- DO NOT drop house numbers or building numbers — they are essential
- Translate to English but keep all numbers exactly as mentioned
- If no source is explicitly mentioned, set source to null
- If no stops are mentioned, return an empty array for stops
- Stops must be in order of travel (first stop first, last stop last)

Common Urdu/Hindi keywords:
- "سے" / "se" = from (SOURCE)
- "کو" / "ko" = to (DESTINATION)
- "میں" / "mein" = in/at (DESTINATION)
- "جانا ہے" / "jana hai" = want to go (DESTINATION)
- "مکان نمبر" / "makaan number" = house number
- "رک کر" / "ruk kar" = stop at (INTERMEDIATE STOP)
- "پہلے" / "pehle" = first go to (INTERMEDIATE STOP)
- "پھر" / "phir" = then go to (INTERMEDIATE STOP)
- "راستے میں" / "raastay mein" = on the way (INTERMEDIATE STOP)
- "ہوتے ہوئے" / "hote hue" = passing through (INTERMEDIATE STOP)

EXAMPLES:
- "گھر سے مارکیٹ رک کر پھر ہسپتال جانا ہے" → source: home, stops: ["market"], destination: hospital
- "لالہ زار سے ماڈل ٹاؤن ہوتے ہوئے گلبرگ جانا ہے" → source: lalarukh, stops: ["Model Town"], destination: Gulberg

Respond ONLY in valid JSON format (no markdown, no code blocks):
{
  "source": "complete source address in English OR null if not mentioned",
  "destination": "complete destination address in English with ALL details",
  "stops": ["stop 1 address", "stop 2 address"],
  "original_text": "the exact text you heard from the audio"
}`;

      const response = await this.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }, this._audioPart(audioBase64, mimeType)] }]
      });

      const locationData = this._parseJson(response.text);
      const result = {
        source: locationData.source,
        destination: locationData.destination,
        stops: Array.isArray(locationData.stops) ? locationData.stops : [],
        original_text: locationData.original_text || "Audio processed"
      };

      logger.info(`Locations extracted — Source: ${result.source}, Destination: ${result.destination}, Stops: ${result.stops.length}`);
      this.cleanupFile(audioFilePath);
      return result;
    } catch (error) {
      logger.error(`Gemini audio processing error: ${error.message}`);
      this.cleanupFile(audioFilePath);
      throw new Error(`Failed to process audio: ${error.message}`);
    }
  }
}

export default new GeminiService();
