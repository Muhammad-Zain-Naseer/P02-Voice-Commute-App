// If you want to automatically extract vehicle info from registration photo
// Install: npm install tesseract.js

import Tesseract from "tesseract.js";
import logger from "../utils/logger.js";

class OCRService {
  /**
   * Extract text from vehicle registration image
   */
  async extractVehicleInfo(imagePath) {
    try {
      const {
        data: { text }
      } = await Tesseract.recognize(imagePath, "eng", {
        logger: (m) => console.log(m)
      });

      // Parse the extracted text to find vehicle information
      const vehicleInfo = this.parseVehicleRegistration(text);

      return vehicleInfo;
    } catch (error) {
      logger.error("OCR extraction error:", error);
      throw error;
    }
  }

  /**
   * Parse extracted text to identify vehicle details
   */
  parseVehicleRegistration(text) {
    const info = {
      registrationNumber: null,
      color: null,
      make: null,
      model: null,
      year: null,
      ownerName: null,
      chassisNumber: null,
      engineNumber: null
    };

    // Registration number pattern (e.g., ABC-123, LEA-1234)
    const regNumberPattern = /[A-Z]{2,3}[-\s]?\d{3,4}/gi;
    const regNumberMatch = text.match(regNumberPattern);
    if (regNumberMatch) {
      info.registrationNumber = regNumberMatch[0].replaceAll(/[\s-]/g, "");
    }

    // Year pattern (4 digits)
    const yearPattern = /\b(19|20)\d{2}\b/g;
    const yearMatch = text.match(yearPattern);
    if (yearMatch) {
      info.year = Number.parseInt(yearMatch[yearMatch.length - 1]);
    }

    // Color keywords
    const colorKeywords = [
      "white",
      "black",
      "silver",
      "red",
      "blue",
      "grey",
      "gray",
      "green",
      "yellow",
      "brown",
      "golden"
    ];
    const lowerText = text.toLowerCase();
    for (const color of colorKeywords) {
      if (lowerText.includes(color)) {
        info.color = color.charAt(0).toUpperCase() + color.slice(1);
        break;
      }
    }

    // Chassis number (alphanumeric, usually 17 characters)
    const chassisPattern = /chassis[:\s]*([A-Z0-9]{17})/gi;
    const chassisMatch = text.match(chassisPattern);
    if (chassisMatch) {
      info.chassisNumber = chassisMatch[0]
        .replaceAll(/chassis[:\s]*/gi, "")
        .trim();
    }

    // Engine number
    const enginePattern = /engine[:\s]*([A-Z0-9]+)/gi;
    const engineMatch = text.match(enginePattern);
    if (engineMatch) {
      info.engineNumber = engineMatch[0].replaceAll(/engine[:\s]*/gi, "").trim();
    }

    // Make/Model - Common Pakistani car brands
    const carBrands = [
      "Toyota",
      "Honda",
      "Suzuki",
      "Daihatsu",
      "Nissan",
      "Mitsubishi",
      "Hyundai",
      "KIA",
      "FAW",
      "MG",
      "Changan",
      "Proton"
    ];

    for (const brand of carBrands) {
      const brandPattern = new RegExp(brand, "gi");
      if (brandPattern.test(text)) {
        info.make = brand;
        break;
      }
    }

    return info;
  }
}

export default new OCRService();
