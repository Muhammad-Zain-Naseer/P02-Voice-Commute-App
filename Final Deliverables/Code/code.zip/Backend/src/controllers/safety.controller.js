import SafetyAlert from "../models/SafetyAlert.js";
import connectionPoolService from "../services/connectionPool.service.js";
import logger from "../utils/logger.js";

class SafetyController {
  /**
   * Broadcast a safety alert to all users
   * POST /api/admin/alerts
   */
  async sendSafetyAlert(req, res, next) {
    try {
      const { message, severity, targetAudience } = req.body;
      const senderId = req.user.userId;
      const senderName = req.user.name;

      if (!message || typeof message !== "string" || message.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: "Alert message is required and must be a string"
        });
      }

      const validSeverities = ["low", "medium", "high", "critical"];
      const safeSeverity = validSeverities.includes(severity)
        ? severity
        : "medium";

      const validAudiences = ["all", "drivers", "commuters"];
      const safeAudience = validAudiences.includes(targetAudience)
        ? targetAudience
        : "all";

      logger.warn(
        `🚨 [SAFETY] Admin ${senderName} is broadcasting a ${safeSeverity} alert.`
      );

      const alertPayload = {
        message: String(message.trim()),
        severity: String(safeSeverity),
        targetAudience: String(safeAudience),
        senderId: String(senderId),
        senderName: String(senderName),
        sentAt: new Date()
      };

      const alert = await SafetyAlert.create(alertPayload);

      const alertData = {
        id: alert._id,
        message: alert.message,
        severity: alert.severity,
        sentAt: alert.sentAt
      };

      const io = connectionPoolService.io;

      if (io) {
        io.emit("admin:safety_alert", alertData);
        logger.info(
          `📡 [SAFETY] Socket event 'admin:safety_alert' emitted to all users.`
        );
      } else {
        logger.error(
          `❌ [SAFETY] Failed to emit socket: IO instance not found in connectionPool.`
        );
      }

      res.status(201).json({
        success: true,
        message: "Safety alert broadcasted successfully",
        data: alert
      });
    } catch (error) {
      logger.error(`Error in sendSafetyAlert: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get history of safety alerts
   * GET /api/admin/alerts
   */
  async getAlertHistory(req, res, next) {
    try {
      const alerts = await SafetyAlert.find().sort({ sentAt: -1 }).limit(50);

      res.status(200).json({
        success: true,
        data: alerts
      });
    } catch (error) {
      logger.error(`Error in getAlertHistory: ${error.message}`);
      next(error);
    }
  }

  /**
   * Get public alert history for commuters and drivers (Last 7 Days)
   * GET /api/safety/history
   */
  async getPublicAlertHistory(req, res, next) {
    try {
      // Calculate date 7 days ago
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const alerts = await SafetyAlert.find({
        sentAt: { $gte: sevenDaysAgo }
      })
        .select("message severity sentAt targetAudience")
        .sort({ sentAt: -1 });

      res.status(200).json({
        success: true,
        count: alerts.length,
        data: alerts
      });
    } catch (error) {
      logger.error(`Error in getPublicAlertHistory: ${error.message}`);
      next(error);
    }
  }
}

export default new SafetyController();
