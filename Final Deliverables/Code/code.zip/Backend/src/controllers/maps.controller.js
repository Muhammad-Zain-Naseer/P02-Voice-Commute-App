import axios from "axios";
import logger from "../utils/logger.js";

const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
logger.info(
  `🗺️ Google Maps API Key loaded: ${GOOGLE_MAPS_API_KEY ? "Yes" : " No"}`
);

// Build Google Directions API params with optional waypoints
function buildDirectionsParams(sourceLat, sourceLng, destLat, destLng, waypoints) {
  const params = {
    origin: `${sourceLat},${sourceLng}`,
    destination: `${destLat},${destLng}`,
    key: GOOGLE_MAPS_API_KEY
  };
  if (waypoints && waypoints.length > 0) {
    params.waypoints = waypoints.map((w) => `${w.lat},${w.lng}`).join("|");
  }
  return params;
}

// Helper function to translate to Urdu using Google Translate API
let _translationApiDisabled = false;
const translateToUrdu = async (text) => {
  if (_translationApiDisabled) return text;
  try {
    const response = await axios.post(
      `https://translation.googleapis.com/language/translate/v2?key=${GOOGLE_MAPS_API_KEY}`,
      {
        q: text,
        target: "ur",
        format: "text"
      }
    );

    return response.data.data.translations[0].translatedText;
  } catch (error) {
    if (error.response?.status === 403) {
      _translationApiDisabled = true;
      logger.warn('Cloud Translation API is disabled or not enabled for this project. Address translation will be skipped.');
    } else {
      logger.error(`Translation API error: ${error.message}`);
    }
    return text; // Return original text if translation fails
  }
};

// Translate addresses to Urdu
export const translateAddresses = async (req, res) => {
  try {
    const { source, destination } = req.body;

    logger.info(`Translating addresses: ${source} -> ${destination}`);

    const [sourceTranslation, destTranslation] = await Promise.all([
      translateToUrdu(source),
      translateToUrdu(destination)
    ]);

    logger.info(
      `Translation complete: ${sourceTranslation}, ${destTranslation}`
    );

    res.json({
      source: sourceTranslation,
      destination: destTranslation
    });
  } catch (error) {
    logger.error(`Translation error: ${error.message}`);
    res.status(500).json({ error: "Translation failed" });
  }
};

// Geocode an address
export const geocodeAddress = async (req, res) => {
  try {
    const { address } = req.body;

    logger.info(`Geocoding address: ${address}`);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/geocode/json",
      {
        params: {
          address: address,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.results.length > 0) {
      const location = response.data.results[0].geometry.location;
      logger.info(`Geocoded: ${address} -> ${location.lat}, ${location.lng}`);
      res.json({
        latitude: location.lat,
        longitude: location.lng
      });
    } else {
      logger.error(
        `Geocoding failed for: ${address} | status=${response.data.status} | error_message=${response.data.error_message ?? "none"}`
      );
      res.status(404).json({ error: "Address not found" });
    }
  } catch (error) {
    logger.error("Geocoding error:", error);
    res.status(500).json({ error: "Geocoding failed" });
  }
};

// Calculate route (distance matrix)
export const calculateRoute = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng } = req.body;

    logger.info(
      `Calculating route: (${sourceLat},${sourceLng}) -> (${destLat},${destLng})`
    );

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/distancematrix/json",
      {
        params: {
          origins: `${sourceLat},${sourceLng}`,
          destinations: `${destLat},${destLng}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK") {
      const element = response.data.rows[0].elements[0];
      logger.info(
        `Route calculated: ${element.distance.text}, ${element.duration.text}`
      );
      res.json({
        distance: element.distance.text,
        duration: element.duration.text
      });
    } else {
      logger.error("Route calculation failed:", response.data.status);
      res.status(400).json({ error: "Route calculation failed" });
    }
  } catch (error) {
    logger.error("Route calculation error:", error);
    res.status(500).json({ error: "Route calculation failed" });
  }
};

// Get directions polyline
export const getDirectionsPolyline = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng } = req.body;

    logger.info(
      `Fetching directions polyline: (${sourceLat},${sourceLng}) -> (${destLat},${destLng})`
    );

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/directions/json",
      {
        params: {
          origin: `${sourceLat},${sourceLng}`,
          destination: `${destLat},${destLng}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.routes.length > 0) {
      const polyline = response.data.routes[0].overview_polyline.points;
      logger.info(`Polyline fetched successfully (${polyline.length} chars)`);
      res.json({ polyline });
    } else {
      logger.error("Directions not found:", response.data.status);
      res.status(400).json({ error: "Directions not found" });
    }
  } catch (error) {
    logger.error("Directions error:", error);
    res.status(500).json({ error: "Directions fetch failed" });
  }
};

// Generate static map URL
export const getStaticMapUrl = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng, polyline } = req.body;

    logger.info(`Generating static map URL`);

    let url = `https://maps.googleapis.com/maps/api/staticmap?size=600x400&markers=color:green|label:A|${sourceLat},${sourceLng}&markers=color:red|label:B|${destLat},${destLng}`;

    if (polyline && polyline.length > 0) {
      url += `&path=enc:${polyline}`;
    }

    url += `&key=${GOOGLE_MAPS_API_KEY}`;

    logger.info(`Static map URL generated`);
    res.json({ mapUrl: url });
  } catch (error) {
    logger.error("Static map URL error:", error);
    res.status(500).json({ error: "Failed to generate map URL" });
  }
};

// Get directions polyline with intermediate stops (waypoints)
export const getDirectionsPolylineWithStops = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng, waypoints } = req.body;
    // waypoints: [{lat, lng}, ...]

    logger.info(
      `Fetching polyline with stops: (${sourceLat},${sourceLng}) -> stops[${(waypoints || []).length}] -> (${destLat},${destLng})`
    );

    const params = buildDirectionsParams(sourceLat, sourceLng, destLat, destLng, waypoints);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/directions/json",
      { params }
    );

    if (response.data.status === "OK" && response.data.routes.length > 0) {
      const polyline = response.data.routes[0].overview_polyline.points;
      logger.info(`Polyline with stops fetched (${polyline.length} chars)`);
      res.json({ polyline });
    } else {
      logger.error("Directions with stops not found:", response.data.status);
      res.status(400).json({ error: "Directions not found" });
    }
  } catch (error) {
    logger.error("Directions with stops error:", error);
    res.status(500).json({ error: "Directions fetch failed" });
  }
};

// Generate static map URL with stop markers and route
export const getStaticMapUrlWithStops = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng, stops, polyline } =
      req.body;
    // stops: [{lat, lng}]

    logger.info(`Generating static map URL with ${(stops || []).length} stops`);

    let url = `https://maps.googleapis.com/maps/api/staticmap?size=600x400`;
    url += `&markers=color:green|label:A|${sourceLat},${sourceLng}`;

    if (stops && stops.length > 0) {
      stops.forEach((stop, i) => {
        url += `&markers=color:blue|label:${i + 1}|${stop.lat},${stop.lng}`;
      });
    }

    url += `&markers=color:red|label:B|${destLat},${destLng}`;

    if (polyline && polyline.length > 0) {
      url += `&path=enc:${encodeURIComponent(polyline)}`;
    }

    url += `&key=${GOOGLE_MAPS_API_KEY}`;

    res.json({ mapUrl: url });
  } catch (error) {
    logger.error("Static map with stops error:", error);
    res.status(500).json({ error: "Failed to generate map URL" });
  }
};

// Calculate route distance/duration through multiple stops (waypoints)
export const calculateRouteWithStops = async (req, res) => {
  try {
    const { sourceLat, sourceLng, destLat, destLng, waypoints } = req.body;
    // waypoints: [{lat, lng}, ...]

    logger.info(
      `Calculating route with stops: (${sourceLat},${sourceLng}) -> stops[${(waypoints || []).length}] -> (${destLat},${destLng})`
    );

    const params = buildDirectionsParams(sourceLat, sourceLng, destLat, destLng, waypoints);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/directions/json",
      { params }
    );

    if (response.data.status === "OK" && response.data.routes.length > 0) {
      const legs = response.data.routes[0].legs;
      // Sum all legs for total distance and duration
      const totalDistanceMeters = legs.reduce((sum, leg) => sum + leg.distance.value, 0);
      const totalDurationSeconds = legs.reduce((sum, leg) => sum + leg.duration.value, 0);
      const totalDistanceKm = (totalDistanceMeters / 1000).toFixed(1);
      const totalDurationMin = Math.round(totalDurationSeconds / 60);

      logger.info(`Route with stops: ${totalDistanceKm} km, ${totalDurationMin} min`);
      res.json({
        distance: `${totalDistanceKm} km`,
        duration: `${totalDurationMin} mins`,
        distanceKm: Number.parseFloat(totalDistanceKm)
      });
    } else {
      logger.error("Route with stops calculation failed:", response.data.status);
      res.status(400).json({ error: "Route calculation failed" });
    }
  } catch (error) {
    logger.error("Route with stops calculation error:", error);
    res.status(500).json({ error: "Route calculation failed" });
  }
};

// Reverse geocode coordinates to address
export const reverseGeocode = async (req, res) => {
  try {
    const { latitude, longitude } = req.body;

    logger.info(`Reverse geocoding: ${latitude}, ${longitude}`);

    const response = await axios.get(
      "https://maps.googleapis.com/maps/api/geocode/json",
      {
        params: {
          latlng: `${latitude},${longitude}`,
          key: GOOGLE_MAPS_API_KEY
        }
      }
    );

    if (response.data.status === "OK" && response.data.results.length > 0) {
      const address = response.data.results[0].formatted_address;
      logger.info(`Reverse geocoded: ${latitude}, ${longitude} -> ${address}`);
      res.json({
        address: address
      });
    } else {
      logger.error(`Reverse geocoding failed`);
      res.status(404).json({ error: "Address not found" });
    }
  } catch (error) {
    logger.error("Reverse geocoding error:", error);
    res.status(500).json({ error: "Reverse geocoding failed" });
  }
};
