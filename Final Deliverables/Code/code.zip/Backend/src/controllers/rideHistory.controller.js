import Ride from "../models/Ride.js";
import User from "../models/User.js";
import mongoose from "mongoose";

function formatRide(ride) {
  return {
    id: ride.rideId,
    ride_id: ride.rideId,
    status: ride.status,
    pickup_location: ride.source?.address || "Unknown",
    dropoff_location: ride.destination?.address || "Unknown",
    driver_name: ride.matchedWith?.driverName || "N/A",
    driver_id: ride.matchedWith?.driverId || null,
    fare: ride.fare || 0,
    distance: ride.distance || 0,
    duration: ride.duration || 0,
    rating: ride.rating || 0,
    vehicle_make: ride.vehicle?.make || "N/A",
    vehicle_model: ride.vehicle?.model || "",
    vehicle_number: ride.vehicle?.number || "N/A",
    created_at: ride.createdAt,
    completed_at: ride.completedAt || null,
    matched_at: ride.matchedWith?.matchedAt || null,
    source_coordinates: ride.source?.coordinates?.coordinates || null,
    destination_coordinates: ride.destination?.coordinates?.coordinates || null,
    user_name: ride.userName,
    user_email: ride.userEmail,
    sos_alert: ride.sosAlert || null
  };
}

/**
 * Get Ride History for a User
 * GET /api/rides/history/:userId
 */
export const getRideHistory = async (req, res) => {
  try {
    const { userId } = req.params;
    const { status, limit = 50, page = 1 } = req.query;

    if (!userId) {
      return res.status(400).json({ success: false, message: "User ID is required" });
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ success: false, message: "Invalid user ID format" });
    }

    const query = { userId: new mongoose.Types.ObjectId(userId) };

    const allowedRideStatuses = ["pending", "matched", "active", "completed", "cancelled"];
    if (status && status !== "all") {
      if (!allowedRideStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: "Invalid status value" });
      }
      query.status = allowedRideStatuses[allowedRideStatuses.indexOf(status)];
    }

    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit);

    const rides = await Ride.find(query)
      .sort({ createdAt: -1 })
      .limit(Number.parseInt(limit))
      .skip(skip)
      .lean();

    const totalRides = await Ride.countDocuments(query);

    return res.status(200).json({
      success: true,
      rides: rides.map(formatRide),
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(totalRides / Number.parseInt(limit)),
        totalRides,
        ridesPerPage: Number.parseInt(limit)
      }
    });
  } catch (error) {
    console.error("❌ Error fetching ride history:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch ride history", error: error.message });
  }
};

/**
 * Get Single Ride Details
 * GET /api/rides/:rideId
 */
export const getRideDetails = async (req, res) => {
  try {
    const { rideId } = req.params;

    if (!rideId) {
      return res.status(400).json({ success: false, message: "Ride ID is required" });
    }

    const ride = await Ride.findOne({ rideId }).lean();

    if (!ride) {
      return res.status(404).json({ success: false, message: "Ride not found" });
    }

    return res.status(200).json({ success: true, ride: formatRide(ride) });
  } catch (error) {
    console.error("❌ Error fetching ride details:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch ride details", error: error.message });
  }
};

/**
 * Get Ride Statistics for a User
 * GET /api/rides/stats/:userId
 */
export const getRideStats = async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({ success: false, message: "User ID is required" });
    }

    const [totalRides, completedRides, cancelledRides, pendingRides] = await Promise.all([
      Ride.countDocuments({ userId }),
      Ride.countDocuments({ userId, status: "completed" }),
      Ride.countDocuments({ userId, status: "cancelled" }),
      Ride.countDocuments({ userId, status: "pending" })
    ]);

    const user = await User.findOne({ userId }).lean();
    const averageRating = user?.averageRating || 0;

    const completedRidesData = await Ride.find({ userId, status: "completed" }).select("fare").lean();
    const totalFare = completedRidesData.reduce((sum, ride) => sum + (ride.fare || 0), 0);

    return res.status(200).json({
      success: true,
      stats: {
        total_rides: totalRides,
        completed_rides: completedRides,
        cancelled_rides: cancelledRides,
        pending_rides: pendingRides,
        average_rating: averageRating,
        total_fare: totalFare
      }
    });
  } catch (error) {
    console.error("❌ Error fetching ride stats:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch ride statistics", error: error.message });
  }
};

/**
 * Update Ride Rating
 * PUT /api/rides/:rideId/rating
 */
export const updateRideRating = async (req, res) => {
  try {
    const { rideId } = req.params;
    const { rating, userId } = req.body;

    if (!rideId || !rating || !userId) {
      return res.status(400).json({ success: false, message: "Ride ID, rating, and user ID are required" });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: "Rating must be between 1 and 5" });
    }

    const ride = await Ride.findOne({
      rideId: String(rideId),
      userId: String(userId)
    });

    if (!ride) {
      return res.status(404).json({ success: false, message: "Ride not found or unauthorized" });
    }

    if (ride.status !== "completed") {
      return res.status(400).json({ success: false, message: "Can only rate completed rides" });
    }

    ride.rating = rating;
    ride.updatedAt = new Date();
    await ride.save();

    if (ride.matchedWith?.driverId) {
      const driver = await User.findOne({ userId: ride.matchedWith.driverId });
      if (driver) {
        driver.ratings.push(rating);
        const sum = driver.ratings.reduce((a, b) => a + b, 0);
        driver.averageRating = sum / driver.ratings.length;
        await driver.save();
      }
    }

    return res.status(200).json({ success: true, message: "Rating updated successfully", rating });
  } catch (error) {
    console.error("❌ Error updating ride rating:", error);
    return res.status(500).json({ success: false, message: "Failed to update rating", error: error.message });
  }
};

/**
 * Get Recent Rides (Last 5)
 * GET /api/rides/recent/:userId
 */
export const getRecentRides = async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({ success: false, message: "User ID is required" });
    }

    const rides = await Ride.find({ userId }).sort({ createdAt: -1 }).limit(5).lean();

    const formattedRides = rides.map((ride) => ({
      id: ride.rideId,
      status: ride.status,
      pickup_location: ride.source?.address || "Unknown",
      dropoff_location: ride.destination?.address || "Unknown",
      driver_name: ride.matchedWith?.driverName || "N/A",
      created_at: ride.createdAt
    }));

    return res.status(200).json({ success: true, rides: formattedRides });
  } catch (error) {
    console.error("❌ Error fetching recent rides:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch recent rides", error: error.message });
  }
};
