import Driver from "../models/Driver.js";
import logger from "../utils/logger.js";
import crypto from "node:crypto";
import emailService from "../services/emailService.js";
import config from "../config/env.config.js";

const verificationTokens = new Map();

function updateAccountFields(existing, accountData) {
  const numberChanged = accountData.accountNumber?.trim() !== (existing?.accountNumber ?? "");
  return {
    accountTitle:  accountData.accountTitle?.trim()  || "",
    accountNumber: accountData.accountNumber?.trim() || "",
    isVerified: numberChanged ? false : (existing?.isVerified ?? false),
    verifiedAt: numberChanged ? null  : (existing?.verifiedAt ?? null),
    verifiedBy: numberChanged ? null  : (existing?.verifiedBy ?? null),
  };
}

async function findDriverForRequest(req) {
  if (req.driver) return req.driver;
  if (req.user?.userId) return Driver.findOne({ userId: req.user.userId });
  if (req.user?.email)  return Driver.findOne({ email: req.user.email });
  return null;
}

// ─────────────────────────────────────────────────────────────
// GET PAYMENT ACCOUNTS
// ─────────────────────────────────────────────────────────────
export const getPaymentAccounts = async (req, res) => {
  try {
    const driver = await findDriverForRequest(req);
    if (!driver) return res.status(404).json({ success: false, message: "Driver profile not found" });

    res.status(200).json({
      success: true,
      data: {
        easyPaisa: driver.paymentAccounts?.easyPaisa || { accountTitle: "", accountNumber: "", isVerified: false },
        jazzCash:  driver.paymentAccounts?.jazzCash  || { accountTitle: "", accountNumber: "", isVerified: false },
      }
    });
  } catch (error) {
    logger.error("Error fetching payment accounts:", error);
    res.status(500).json({ success: false, message: "Failed to fetch payment accounts" });
  }
};

// ─────────────────────────────────────────────────────────────
// UPDATE PAYMENT ACCOUNTS
// ─────────────────────────────────────────────────────────────
export const updatePaymentAccounts = async (req, res) => {
  try {
    const { easyPaisa, jazzCash } = req.body;
    const driver = await findDriverForRequest(req);
    if (!driver) return res.status(404).json({ success: false, message: "Driver profile not found" });

    if (!driver.paymentAccounts) driver.paymentAccounts = { easyPaisa: {}, jazzCash: {} };

    if (easyPaisa) {
      driver.paymentAccounts.easyPaisa = updateAccountFields(driver.paymentAccounts.easyPaisa, easyPaisa);
    }

    if (jazzCash) {
      driver.paymentAccounts.jazzCash = updateAccountFields(driver.paymentAccounts.jazzCash, jazzCash);
    }

    driver.paymentAccountsUpdatedAt = new Date();
    await driver.save();
    logger.info(`Driver ${driver.email} updated payment accounts`);

    res.status(200).json({
      success: true,
      message: "Payment accounts updated successfully",
      data: {
        easyPaisa: driver.paymentAccounts.easyPaisa,
        jazzCash:  driver.paymentAccounts.jazzCash,
        updatedAt: driver.paymentAccountsUpdatedAt,
      }
    });
  } catch (error) {
    logger.error("Error updating payment accounts:", error);
    res.status(500).json({ success: false, message: "Failed to update payment accounts" });
  }
};

// ─────────────────────────────────────────────────────────────
// REQUEST PAYMENT VERIFICATION EMAIL
// ─────────────────────────────────────────────────────────────
export const requestPaymentVerification = async (req, res) => {
  try {
    const { provider } = req.body;

    if (!provider || !["easypaisa", "jazzcash"].includes(provider)) {
      return res.status(400).json({ success: false, message: "provider must be 'easypaisa' or 'jazzcash'" });
    }

    const driver = await findDriverForRequest(req);
    if (!driver) return res.status(404).json({ success: false, message: "Driver profile not found" });

    const providerField = provider === "easypaisa" ? "easyPaisa" : "jazzCash";
    const account = driver.paymentAccounts?.[providerField];

    if (!account?.accountNumber) {
      return res.status(400).json({ success: false, message: "Please save your account details first before verifying." });
    }

    const token     = crypto.randomBytes(32).toString("hex");
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000;

    verificationTokens.set(token, {
      driverEmail:   driver.email,
      provider,
      accountNumber: account.accountNumber,
      accountTitle:  account.accountTitle || "",
      expiresAt,
    });

    const baseUrl    = process.env.API_BASE_URL || "http://localhost:3000";
    const approveUrl = `${baseUrl}/api/driver/payment-accounts/verify/confirm?token=${token}&action=approve`;
    const rejectUrl  = `${baseUrl}/api/driver/payment-accounts/verify/confirm?token=${token}&action=reject`;

    const providerLabel = provider === "easypaisa" ? "EasyPaisa" : "JazzCash";
    const providerColor = provider === "easypaisa" ? "#00A859"   : "#FF6B00";
    const appName       = config.appName || "HerSafar";

    const now       = new Date();
    const timeStamp = now.toLocaleTimeString("en-PK", { hour: "2-digit", minute: "2-digit", hour12: true });
    const subject   = `[${timeStamp}] Verify your ${providerLabel} account — ${appName}`;

    await emailService.sendMail({
      to:       driver.email,
      subject,
      fromName: appName,
      html: buildVerificationEmail({
        driverName:    driver.name,
        providerLabel,
        providerColor,
        accountNumber: account.accountNumber,
        accountTitle:  account.accountTitle || "",
        approveUrl,
        rejectUrl,
        appName,
        requestId: token.slice(0, 8).toUpperCase(),
      })
    });

    logger.info(`[PAYMENT VERIFY] Email sent to ${driver.email} for ${provider}`);

    res.status(200).json({
      success: true,
      message: `Verification email sent to ${driver.email}. Please check your inbox.`
    });
  } catch (error) {
    logger.error(`[PAYMENT VERIFY] requestPaymentVerification error: ${error.message}`);
    logger.error(error.stack);
    res.status(500).json({ success: false, message: "Failed to send verification email. Please try again." });
  }
};

// ─────────────────────────────────────────────────────────────
// CONFIRM PAYMENT VERIFICATION 
// ─────────────────────────────────────────────────────────────
export const confirmPaymentVerification = async (req, res) => {
  const { token, action } = req.query;

  if (!token || !["approve", "reject"].includes(action)) {
    return res.status(400).send(resultPage("Invalid Link", "This verification link is invalid.", false));
  }

  const stored = verificationTokens.get(token);

  if (!stored) {
    return res.status(400).send(resultPage("Link Already Used", "This verification link has already been used or does not exist.", false));
  }

  if (Date.now() > stored.expiresAt) {
    verificationTokens.delete(token);
    return res.status(400).send(resultPage("Link Expired", "This verification link has expired. Please request a new one from the app.", false));
  }

  try {
    const { driverEmail, provider } = stored;
    const providerField = provider === "easypaisa" ? "easyPaisa" : "jazzCash";
    const providerLabel = provider === "easypaisa" ? "EasyPaisa" : "JazzCash";

    const driver = await Driver.findOne({ email: driverEmail });
    if (!driver) {
      verificationTokens.delete(token);
      return res.status(404).send(resultPage("Error", "Driver account not found.", false));
    }

    if (action === "approve") {
      driver.paymentAccounts[providerField].isVerified = true;
      driver.paymentAccounts[providerField].verifiedAt = new Date();
      await driver.save();
      verificationTokens.delete(token);
      logger.info(`[PAYMENT VERIFY] ${provider} verified for driver: ${driverEmail}`);
      return res.send(resultPage(
        "Account Verified! ✓",
        `Your ${providerLabel} account <strong>${stored.accountNumber}</strong> has been successfully verified. You can now receive payments.`,
        true
      ));
    } else {
      verificationTokens.delete(token);
      logger.info(`[PAYMENT VERIFY] ${provider} rejected for driver: ${driverEmail}`);
      return res.send(resultPage(
        "Verification Rejected",
        `Your ${providerLabel} account was not verified. If this was a mistake, open the app and request a new verification email.`,
        false
      ));
    }
  } catch (error) {
    logger.error(`[PAYMENT VERIFY] confirmPaymentVerification error: ${error.message}`);
    return res.status(500).send(resultPage("Error", "Something went wrong. Please try again.", false));
  }
};

// ═════════════════════════════════════════════════════════════
// EMAIL HTML BUILDER
// ═════════════════════════════════════════════════════════════

function buildVerificationEmail({
  driverName, providerLabel, providerColor,
  accountNumber, accountTitle, approveUrl, rejectUrl, appName, requestId,
}) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Verify Payment Account</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background-color:#FCE4EC; padding:30px 16px; }
    .wrapper { max-width:560px; margin:0 auto; }
    .header {
      background:linear-gradient(135deg,#CF4374,#E91E63);
      border-radius:16px 16px 0 0;
      padding:32px 24px;
      text-align:center;
    }
    .header h1 { color:#fff; font-size:22px; font-weight:700; margin-bottom:4px; }
    .header p  { color:rgba(255,255,255,0.85); font-size:14px; }
    .card {
      background:#fff;
      border-radius:0 0 16px 16px;
      padding:32px 28px;
      box-shadow:0 4px 20px rgba(207,67,116,0.12);
    }
    .greeting { font-size:16px; color:#2D3748; margin-bottom:12px; }
    .greeting strong { color:#CF4374; }
    .desc { font-size:14px; color:#555; line-height:1.6; margin-bottom:24px; }
    .account-box {
      background:#FAEAF0;
      border:1.5px solid #F682AA;
      border-radius:12px;
      padding:20px;
      margin-bottom:28px;
    }
    .provider-badge {
      display:inline-block;
      background:${providerColor};
      color:#fff;
      font-size:12px;
      font-weight:700;
      padding:4px 12px;
      border-radius:20px;
      letter-spacing:0.5px;
      margin-bottom:14px;
    }
    .account-row { display:flex; justify-content:space-between; margin-bottom:8px; }
    .account-row:last-child { margin-bottom:0; }
    .account-label { font-size:12px; color:#888; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; }
    .account-value { font-size:14px; color:#2D3748; font-weight:600; }
    .warning {
      background:#FFF8E1;
      border-left:4px solid #FFB300;
      border-radius:6px;
      padding:12px 16px;
      font-size:13px;
      color:#7A5900;
      margin-bottom:28px;
      line-height:1.5;
    }
    .actions { display:flex; gap:12px; margin-bottom:28px; }
    .btn {
      flex:1;
      display:block;
      text-align:center;
      padding:14px 10px;
      border-radius:10px;
      font-size:15px;
      font-weight:700;
      text-decoration:none;
      letter-spacing:0.3px;
    }
    .btn-approve {
      background:linear-gradient(135deg,#CF4374,#E91E63);
      color:#fff !important;
      box-shadow:0 4px 12px rgba(207,67,116,0.35);
    }
    .btn-reject {
      background:#f5f5f5;
      color:#666 !important;
      border:2px solid #ddd;
    }
    .divider { border:none; border-top:1px solid #F0E4EA; margin:24px 0; }
    .footer { text-align:center; font-size:12px; color:#AAA; line-height:1.7; }
    .footer strong { color:#CF4374; }
    .request-id { font-size:11px; color:#CCC; text-align:center; margin-top:8px; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <h1>${appName}</h1>
      <p>Payment Account Verification</p>
    </div>
    <div class="card">
      <p class="greeting">Hi <strong>${driverName}</strong>,</p>
      <p class="desc">
        You requested to verify your <strong>${providerLabel}</strong> payment account.
        Please review the details below and confirm whether this account belongs to you.
      </p>
      <div class="account-box">
        <div class="provider-badge">${providerLabel}</div>
        <div class="account-row">
          <span class="account-label">Account Number</span>
          <span class="account-value">${accountNumber}</span>
        </div>
        ${accountTitle ? `
        <div class="account-row">
          <span class="account-label">Account Title</span>
          <span class="account-value">${accountTitle}</span>
        </div>` : ""}
      </div>
      <div class="warning">
        ⚠️ Only approve if <strong>you</strong> added this account.
        If you did not request this, press <strong>Reject</strong>.
      </div>
      <div class="actions">
        <a href="${approveUrl}" class="btn btn-approve">✓ &nbsp;Yes, Verify</a>
        <a href="${rejectUrl}"  class="btn btn-reject">✕ &nbsp;Reject</a>
      </div>
      <hr class="divider"/>
      <div class="footer">
        <p>This link expires in <strong>24 hours</strong>.</p>
        <p style="margin-top:6px;">Sent by <strong>${appName}</strong> · Do not reply to this email.</p>
      </div>
      <p class="request-id">Ref: ${requestId}</p>
    </div>
  </div>
</body>
</html>`;
}

// ═════════════════════════════════════════════════════════════
// RESULT PAGE  (shown in browser after clicking approve/reject)
// ═════════════════════════════════════════════════════════════

function resultPage(title, message, success) {
  const color  = success ? "#CF4374" : "#888";
  const icon   = success ? "✓" : "✕";
  const iconBg = success ? "linear-gradient(135deg,#CF4374,#E91E63)" : "#ddd";

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>${title}</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family:'Segoe UI',Arial,sans-serif;
      background:#FCE4EC;
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:24px;
    }
    .card {
      background:#fff;
      border-radius:20px;
      padding:48px 36px;
      max-width:420px;
      width:100%;
      text-align:center;
      box-shadow:0 8px 32px rgba(207,67,116,0.15);
    }
    .icon {
      width:72px; height:72px;
      border-radius:50%;
      background:${iconBg};
      color:#fff;
      font-size:32px;
      display:flex;
      align-items:center;
      justify-content:center;
      margin:0 auto 24px;
    }
    h1 { font-size:22px; color:${color}; margin-bottom:14px; }
    p  { font-size:15px; color:#555; line-height:1.6; }
    .brand { margin-top:36px; font-size:13px; color:#CF4374; font-weight:700; letter-spacing:0.5px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">${icon}</div>
    <h1>${title}</h1>
    <p>${message}</p>
    <p class="brand">HerSafar</p>
  </div>
</body>
</html>`;
}