/**
 * Coupon Model
 * Represents a discount coupon that users can apply to ride payments
 */

import mongoose from "mongoose";

const couponSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true,
      index: true
    },
    discountPercentage: {
      type: Number,
      required: true,
      min: 1,
      max: 100
    },
    description: {
      type: String,
      default: ""
    },
    maxUses: {
      type: Number,
      default: null // null = unlimited
    },
    usedCount: {
      type: Number,
      default: 0
    },
    expiryDate: {
      type: Date,
      default: null // null = no expiry
    },
    isActive: {
      type: Boolean,
      default: true
    }
  },
  {
    timestamps: true
  }
);

const Coupon = mongoose.model("Coupon", couponSchema);

export default Coupon;
