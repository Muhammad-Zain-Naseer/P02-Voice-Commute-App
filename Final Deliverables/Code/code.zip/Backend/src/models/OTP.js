import mongoose from "mongoose";

const otpSchema = new mongoose.Schema({
  // Support both phone and email
  phoneNumber: {
    type: String,
    trim: true,
    sparse: true
  },
  email: {
    type: String,
    lowercase: true,
    trim: true,
    sparse: true
  },
  otp: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: [
      "driver_registration",
      "user_registration",
      "password_reset",
      "phone_verification"
    ],
    default: "phone_verification"
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 600 // Auto-delete after 10 minutes (600 seconds)
  },
  verified: {
    type: Boolean,
    default: false
  },
  attempts: {
    type: Number,
    default: 0
  }
});

otpSchema.index({ phoneNumber: 1, createdAt: -1 });
otpSchema.index({ email: 1, otp: 1 });
otpSchema.index({ phoneNumber: 1, otp: 1 });

// Validation: Either phoneNumber or email must be present
otpSchema.pre("save", function (next) {
  if (!this.phoneNumber && !this.email) {
    next(new Error("Either phoneNumber or email is required"));
  } else {
    next();
  }
});

export default mongoose.model("OTP", otpSchema);
