import mongoose from "mongoose";

const farePriceSchema = new mongoose.Schema(
  {
    ratePerKm: {
      type: Number,
      required: true,
      min: 0,
      default: 18
    },
    currency: {
      type: String,
      default: "PKR"
    },
    isActive: {
      type: Boolean,
      default: true
    },
    updatedBy: {
      userId: {
        type: String,
        required: true
      },
      userName: {
        type: String,
        required: true
      }
    },
    effectiveFrom: {
      type: Date,
      default: Date.now
    },
    notes: {
      type: String,
      default: ""
    }
  },
  {
    timestamps: true
  }
);

// Index to quickly find active fare price
farePriceSchema.index({ isActive: 1, effectiveFrom: -1 });

// Static method to get current active fare rate
farePriceSchema.statics.getCurrentFareRate = async function () {
  const activeFare = await this.findOne({ isActive: true })
    .sort({ effectiveFrom: -1 })
    .limit(1);

  return activeFare ? activeFare.ratePerKm : 18; // Default to 18 if none found
};

const FarePrice = mongoose.model("FarePrice", farePriceSchema);

export default FarePrice;
