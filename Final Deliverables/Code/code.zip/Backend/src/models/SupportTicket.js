import mongoose from "mongoose";

const supportTicketSchema = new mongoose.Schema(
    {
        userId: {
            type: String,
            required: true,
            index: true
        },
        role: {
            type: String,
            enum: ["commuter", "driver"],
            required: true
        },
        category: {
            type: String,
            enum: [
                "safety_concern",
                "payment_issue",
                "behavior_complaint",
                "app_bug"
            ],
            required: true
        },
        descriptionText: {
            type: String,
            trim: true,
            maxlength: 1000
        },
        audioUrl: {
            type: String,
            default: null
        },
        status: {
            type: String,
            enum: ["open", "in_progress", "resolved"],
            default: "open",
            index: true
        },
        resolvedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        },
        resolvedAt: {
            type: Date
        }
    },
    {
        timestamps: true
    }
);

export default mongoose.model("SupportTicket", supportTicketSchema);