import mongoose from "mongoose";

const auditLogSchema = new mongoose.Schema(
  {
    timestamp: { type: Date, required: true, index: true },
    action: { type: String, required: true, index: true },
    driverId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      index: true
    },
    email: { type: String },
    ipAddress: { type: String },
    userAgent: { type: String },
    changedFields: { type: mongoose.Schema.Types.Mixed },
    fileUploaded: { type: Boolean },
    fileHash: { type: String },
    error: { type: String }
  },
  {
    timestamps: true,
    collection: "audit_logs"
  }
);

auditLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 63072000 });

export default mongoose.model("AuditLog", auditLogSchema);
