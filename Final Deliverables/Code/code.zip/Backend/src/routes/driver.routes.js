import express from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { getTodayStats, getDriverProfile } from "../controllers/driver.controller.js";
import {
  getPaymentAccounts,
  updatePaymentAccounts,
  requestPaymentVerification,
  confirmPaymentVerification,
} from "../controllers/driverPaymentController.js";

const router = express.Router();
const driverAuth = [authenticate, authorize("driver")];

// Stats & Profile
router.get("/stats/today", ...driverAuth, getTodayStats);
router.get("/profile",     ...driverAuth, getDriverProfile);

// Payment Accounts
router.get("/payment-accounts",          ...driverAuth, getPaymentAccounts);
router.put("/payment-accounts",          ...driverAuth, updatePaymentAccounts);

// Email Verification
router.post("/payment-accounts/verify/request", ...driverAuth, requestPaymentVerification);

router.get("/payment-accounts/verify/confirm",  confirmPaymentVerification);

export default router;