import express from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import paymentController from "../controllers/payment.controller.js";

const router = express.Router();

const driverAuth = [authenticate, authorize("driver")];
const userAuth   = [authenticate, authorize("commuter")];
const adminAuth  = [authenticate, authorize("admin")];

// Submit a payment for a completed ride (user pays)
router.post("/", ...userAuth, paymentController.submitPayment);

// Get payment stats (admin dashboard)
router.get("/stats", ...adminAuth, paymentController.getPaymentStats);

// Get payment for a specific ride
router.get("/ride/:rideId", authenticate, paymentController.getPaymentByRide);

// Get all payments for a user
router.get("/user/:userId", ...userAuth, paymentController.getPaymentsByUser);

// Get all payments received by a driver
router.get("/driver/:driverId", ...driverAuth, paymentController.getPaymentsByDriver);

// Get a specific payment by ID
router.get("/:id", authenticate, paymentController.getPayment);

// Update payment status (admin only)
router.patch("/:id/status", ...adminAuth, paymentController.updatePaymentStatus);

export default router;
