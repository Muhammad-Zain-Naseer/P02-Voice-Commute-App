import express from "express";
import supportController from "../controllers/support.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import upload from "../middleware/upload.middleware.js";

const router = express.Router();

// Commuter/Driver creates a ticket 
router.post(
    "/",
    authenticate,
    upload.single("audio"),
    supportController.createTicket
);

// Admin Routes 
router.get(
    "/tickets",
    authenticate,
    supportController.getTickets
);

router.patch(
    "/:id/status",
    authenticate,
    supportController.updateTicketStatus
);

export default router;