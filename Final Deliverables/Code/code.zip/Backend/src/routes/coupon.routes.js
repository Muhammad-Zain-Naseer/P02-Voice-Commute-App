/**
 * Coupon Routes
 * REST API endpoints for coupon management
 */

import express from "express";
import couponController from "../controllers/coupon.controller.js";

const router = express.Router();

/**
 * @route   POST /api/coupons/validate
 * @desc    Validate a coupon code (used by Flutter before submitting payment)
 * @access  Public
 * @body    { code }
 */
router.post("/validate", couponController.validateCoupon);

/**
 * @route   GET /api/coupons
 * @desc    Get all coupons (admin)
 * @access  Admin
 */
router.get("/", couponController.getCoupons);

/**
 * @route   POST /api/coupons
 * @desc    Create a new coupon (admin)
 * @access  Admin
 * @body    { code, discountPercentage, description?, maxUses?, expiryDate? }
 */
router.post("/", couponController.createCoupon);

/**
 * @route   PATCH /api/coupons/:id/toggle
 * @desc    Toggle coupon active/inactive (admin)
 * @access  Admin
 */
router.patch("/:id/toggle", couponController.toggleCoupon);

/**
 * @route   DELETE /api/coupons/:id
 * @desc    Delete a coupon (admin)
 * @access  Admin
 */
router.delete("/:id", couponController.deleteCoupon);

export default router;
