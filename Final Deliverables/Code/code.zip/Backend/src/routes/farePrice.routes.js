import express from "express";
import {
  getCurrentFarePrice,
  getFarePriceHistory,
  updateFarePrice
} from "../controllers/farePrice.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorize } from "../middleware/role.middleware.js";
import { alertRateLimiter } from "../middleware/rateLimit.middleware.js";

const router = express.Router();

// Public route - Get current active fare price
router.get("/current", getCurrentFarePrice);

// Admin routes - Protected
router.get("/history", authenticate, authorize("admin"), getFarePriceHistory);

router.put(
  "/update",
  authenticate,
  authorize("admin"),
  alertRateLimiter, // Reuse alert rate limiter (5 per 15 min)
  updateFarePrice
);

export default router;
