import express from "express";
import driverAuthController from "../controllers/driverAuthController.js";
import { authenticateDriver } from "../middleware/driverAuth.middleware.js";
import vehicleUpload, {
  handleMulterError
} from "../middleware/vehicleUpload.middleware.js";
import {
  validateFileIntegrity,
  sanitizeResubmissionInput
} from "../middleware/fileValidation.middleware.js";
import { resubmissionRateLimiter } from "../middleware/rateLimiter.middleware.js";
import { requestTimeout } from "../middleware/timeout.middleware.js";
import { preventProtectedFieldModification } from "../middleware/fieldAuthorization.middleware.js";

const router = express.Router();

router.post("/request-otp", (req, res) =>
  driverAuthController.requestOTP(req, res)
);

router.post("/verify-otp", (req, res) =>
  driverAuthController.verifyOTP(req, res)
);

router.post("/submit-name", authenticateDriver, (req, res) =>
  driverAuthController.submitName(req, res)
);

router.post("/submit-cnic", authenticateDriver, (req, res) =>
  driverAuthController.submitCNIC(req, res)
);

router.post("/submit-license", authenticateDriver, (req, res) =>
  driverAuthController.submitDrivingLicense(req, res)
);

router.post(
  "/submit-vehicle",
  authenticateDriver,
  vehicleUpload.single("registrationPhoto"),
  (req, res) => driverAuthController.submitVehicleRegistration(req, res)
);

router.post("/submit-pin", authenticateDriver, (req, res) =>
  driverAuthController.submitPIN(req, res)
);

router.post("/login", (req, res) => driverAuthController.login(req, res));

router.get("/registration-status", authenticateDriver, (req, res) =>
  driverAuthController.getRegistrationStatus(req, res)
);

router.get("/me", authenticateDriver, (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      driver: req.driver
    }
  });
});

router.get("/resubmission-status", authenticateDriver, (req, res) =>
  driverAuthController.getResubmissionStatus(req, res)
);

router.post(
  "/resubmit",
  requestTimeout(30000),
  authenticateDriver,
  preventProtectedFieldModification,
  resubmissionRateLimiter,
  vehicleUpload.single("registrationPhoto"),
  handleMulterError,
  validateFileIntegrity,
  sanitizeResubmissionInput,
  (req, res) => driverAuthController.resubmitDocuments(req, res)
);

export default router;
