import express from "express";
import safetyController from "../controllers/safety.controller.js";
import { authorize } from "../middleware/role.middleware.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { alertRateLimiter } from "../middleware/rateLimit.middleware.js";

const router = express.Router();

/**
 * @route   POST /api/admin/alerts
 * @desc    Broadcast a safety alert
 * @access  Admin only
 */
router.post(
  "/alerts",
  authenticate,
  authorize("admin"),
  alertRateLimiter,
  safetyController.sendSafetyAlert
);

/**
 * @route   GET /api/admin/alerts
 * @desc    View alert history
 * @access  Admin only
 */
router.get("/alerts", authenticate, authorize("admin"), safetyController.getAlertHistory);

/**
 * @route   GET /api/admin/alerts/history
 * @desc    Get safety alerts from the last 7 days for app users
 * @access  Public to all Authenticated Users (Drivers & Commuters)
 */
router.get(
  "/history",
  authenticate,
  safetyController.getPublicAlertHistory
);

export default router;
