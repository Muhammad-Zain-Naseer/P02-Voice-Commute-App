import express from "express";
import {
  getRideHistory,
  getRideDetails,
  getRideStats,
  updateRideRating,
  getRecentRides
} from "../controllers/rideHistory.controller.js";

const router = express.Router();

/**
 * Ride History Routes
 */

// Get ride history for a user
// GET /api/rides/history/:userId?status=all&limit=50&page=1
router.get("/history/:userId", getRideHistory);

// Get single ride details
// GET /api/rides/:rideId
router.get("/:rideId", getRideDetails);

// Get ride statistics for a user
// GET /api/rides/stats/:userId
router.get("/stats/:userId", getRideStats);

// Get recent rides (last 5)
// GET /api/rides/recent/:userId
router.get("/recent/:userId", getRecentRides);

// Update ride rating
// PUT /api/rides/:rideId/rating
// Body: { rating: 4, userId: "user123" }
router.put("/:rideId/rating", updateRideRating);

export default router;
