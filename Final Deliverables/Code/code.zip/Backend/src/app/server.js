import mongoose from "mongoose";
import config from "../config/env.config.js";
import logger from "../utils/logger.js";
import emailService from "../services/emailService.js";
import { handleRideEvents } from "../sockets/ride.socket.js";
import { httpServer, io } from "./app.js";

// Socket.IO connection handling
io.on("connection", (socket) => {
  logger.info(`Socket connected: ${socket.id}`);
  handleRideEvents(io, socket);
  socket.on("disconnect", (reason) => {
    logger.info(`Socket disconnected: ${socket.id} | Reason: ${reason}`);
  });
});

// DATABASE CONNECTION
const connectDatabase = async () => {
  try {
    await mongoose.connect(config.mongoUri);
    logger.info("MongoDB connected successfully");
  } catch (error) {
    logger.error("MongoDB connection error:", error);
    process.exit(1);
  }
};

await connectDatabase();
httpServer.listen(config.port, () => {
  logger.info(`Server running on port ${config.port} in ${config.nodeEnv} mode`);
  logger.info("Socket.IO enabled and ready for connections");
  logger.info(`WebSocket URL: ws://localhost:${config.port}`);
});
await emailService.verifyConnection();

httpServer.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    logger.error(`Port ${config.port} is already in use. Stop the conflicting process or set a different PORT.`);
  } else {
    logger.error("HTTP server encountered an error:", error);
  }
  process.exit(1);
});
