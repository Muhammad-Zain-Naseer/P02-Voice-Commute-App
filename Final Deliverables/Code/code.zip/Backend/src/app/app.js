import "../config/env.config.js"; // must be first — loads dotenv before any other module
import express from "express";
import { createServer } from "node:http";
import { Server } from "socket.io";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";
import socketConfig from "../config/socket.config.js";
import connectionPoolService from "../services/connectionPool.service.js";
import audioRoutes from "../routes/audio.routes.js";
import rideRoutes from "../routes/ride.routes.js";
import authRoutes from "../routes/authRoutes.js";
import driverAuthRoutes from "../routes/driverAuth.routes.js";
import paymentRoutes from "../routes/payment.routes.js";
import mapsRoutes from "../routes/maps.routes.js";
import commuterRoutes from "../routes/commuter.routes.js";
import adminRoutes from "../routes/admin.routes.js";
import safetyRoutes from "../routes/safety.routes.js";
import tripMonitoringRoutes from "../routes/tripMonitoring.routes.js";
import rideHistoryRoutes from "../routes/rideHistory.routes.js";
import driverRoutes from "../routes/driver.routes.js";
import farePriceRoutes from "../routes/farePrice.routes.js";
import policyRoutes from "../routes/policy.routes.js";
import unsafeAreaRoutes from "../routes/unsafeArea.routes.js";
import supportRoutes from "../routes/support.routes.js";
import couponRoutes from "../routes/coupon.routes.js";
import voiceRoutes from "../routes/voice.routes.js";
import { authenticate } from "../middleware/auth.middleware.js";
import {
  errorHandler,
  notFoundHandler
} from "../middleware/errorHandler.middleware.js";
import rateLimit from "express-rate-limit";

const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uploadsPath = path.join(__dirname, "..", "..", "uploads");
const vehicleUploadsDir = path.join(uploadsPath, "vehicle-registrations");

if (!fs.existsSync(vehicleUploadsDir)) {
  fs.mkdirSync(vehicleUploadsDir, { recursive: true });
}

const httpServer = createServer(app);
const io = new Server(httpServer, socketConfig);

app.set("io", io);
connectionPoolService.setIO(io);

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));
app.use("/uploads", express.static(uploadsPath));

// Global rate limiter — blocks scanner bots (max 100 req/min per IP)
app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json({ success: false, message: 'Too many requests.' }),
}));

app.get("/", (req, res) => {
  res.json({ message: "Server is running!" });
});

// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/driver/auth", driverAuthRoutes);
app.use("/api/driver", driverRoutes);
app.use("/api/audio", audioRoutes);
app.use("/api/rides", rideRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/maps", mapsRoutes);
app.use("/api/commuter", commuterRoutes);
app.use("/api/admin/alerts", authenticate, safetyRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/monitoring", tripMonitoringRoutes);
app.use("/api/rideHistory", rideHistoryRoutes);
app.use("/api/fares", farePriceRoutes);
app.use("/api/policies", policyRoutes);
app.use("/api/admin/unsafe-areas", authenticate, unsafeAreaRoutes);
app.use("/api/unsafe-areas", unsafeAreaRoutes);
app.use("/api/support", supportRoutes);
app.use("/api/coupons", couponRoutes);
app.use("/api/voice", voiceRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

export { httpServer, io };
export default app;
