import logger from "../utils/logger.js";

export const requestTimeout = (timeout = 30000) => {
  return (req, res, next) => {
    const timer = setTimeout(() => {
      logger.warn(
        `Request timeout for ${req.method} ${req.path} from ${req.ip}`
      );
      if (!res.headersSent) {
        res.status(408).json({
          success: false,
          message: "Request timeout. Please try again."
        });
      }
    }, timeout);

    res.on("finish", () => clearTimeout(timer));
    res.on("close", () => clearTimeout(timer));

    next();
  };
};
