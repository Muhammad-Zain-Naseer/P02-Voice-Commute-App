import rateLimit from "express-rate-limit";
import logger from "../utils/logger.js";

export const resubmissionRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    logger.warn(
      `Rate limit exceeded for driver resubmission: ${req.driver?.email}`
    );
    res.status(429).json({
      success: false,
      message: "Too many resubmission attempts. Please try again in 1 hour."
    });
  }
});
