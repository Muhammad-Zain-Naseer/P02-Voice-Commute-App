import logger from "../utils/logger.js";

const PROTECTED_FIELDS = new Set([
  "status",
  "role",
  "isVerified",
  "verifiedBy",
  "verifiedAt",
  "verificationHistory",
  "averageRating",
  "totalRides",
  "lastLogin",
  "userId"
]);

export const preventProtectedFieldModification = (req, res, next) => {
  const attemptedFields = Object.keys(req.body || {}).filter((field) =>
    PROTECTED_FIELDS.has(field)
  );

  if (attemptedFields.length > 0) {
    logger.warn(
      `Unauthorized field modification attempt by ${req.driver?.email}: ${attemptedFields.join(", ")}`
    );
    return res.status(403).json({
      success: false,
      message: "Unauthorized: Cannot modify protected fields"
    });
  }

  next();
};
