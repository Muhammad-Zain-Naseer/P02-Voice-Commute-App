import crypto from "node:crypto";
import fs from "node:fs";
import logger from "../utils/logger.js";
import validator from "validator";

export const validateFileIntegrity = async (req, res, next) => {
  if (!req.file) return next();

  try {
    const fileBuffer = fs.readFileSync(req.file.path);
    const fileHash = crypto
      .createHash("sha256")
      .update(fileBuffer)
      .digest("hex");
    req.fileHash = fileHash;

    const allowedTypes = new Set(["image/jpeg", "image/png", "image/jpg"]);
    if (!allowedTypes.has(req.file.mimetype)) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        success: false,
        message: "Invalid file type. Only JPEG and PNG allowed"
      });
    }

    if (req.file.size > 5 * 1024 * 1024) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        success: false,
        message: "File too large. Maximum 5MB allowed"
      });
    }

    next();
  } catch (error) {
    logger.error("File validation error:", error);
    return res.status(500).json({
      success: false,
      message: "File validation failed"
    });
  }
};

export const sanitizeResubmissionInput = (req, res, next) => {
  const { name, cnic, model, color } = req.body;

  if (name) req.body.name = validator.escape(validator.trim(name));
  if (model) req.body.model = validator.escape(validator.trim(model));
  if (color) req.body.color = validator.escape(validator.trim(color));

  if (cnic && !/^\d{13}$/.test(cnic.replaceAll("-", "").replaceAll(" ", ""))) {
    return res.status(400).json({
      success: false,
      message: "Invalid CNIC format"
    });
  }

  next();
};
