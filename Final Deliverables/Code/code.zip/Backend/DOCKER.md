# Docker Commands

## Production

```bash
# Build and start
docker-compose up -d

# View logs
docker-compose logs -f backend

# Stop
docker-compose down

# Rebuild
docker-compose up -d --build
```

## Development (with nodemon)

```bash
# Build and start
docker-compose -f docker-compose.dev.yml up -d

# View logs
docker-compose -f docker-compose.dev.yml logs -f backend

# Stop
docker-compose -f docker-compose.dev.yml down

# Rebuild
docker-compose -f docker-compose.dev.yml up -d --build
```

## Useful Commands

```bash
# Enter container shell
docker exec -it fyp-backend sh

# Remove all containers and volumes
docker-compose down -v

# Check running containers
docker ps
```
